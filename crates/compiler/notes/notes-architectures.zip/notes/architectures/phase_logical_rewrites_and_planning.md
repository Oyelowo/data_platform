# Phase: Logical Rewrites, Physical Planning, and Execution

**Status:** Active.  
**Goal:** Turn the real `.ye`-stdlib logical plans into optimized, backend-agnostic logical plans, then into physical plans and an executable form.  
**Depends on:** `phase_stdlib_and_pipeline.md` (complete).

---

## 1. Why this phase is next

The previous phase proved that `select ... from ... where ... group by ... order by ... range ...` can be lowered into a `LogicalPlan` using real trait definitions from `stdlib/core/src/*.ye`.  That plan is correct but naive: filters sit above maps, adjacent maps are not fused, constants are not folded, and there is no notion of correlation or distribution.

This phase makes the plans efficient and robust:

1. **Logical rewrites** clean up the plan using algebraic identities.
2. **Decorrelation / unnesting** turns nested comprehensions and correlated subplans into flat joins (Neumann top-down).
3. **Predicate and projection pushdown** move work closer to the data.
4. **Physical planning** picks concrete algorithms (hash vs. sort aggregate, exchange placement, join implementation).
5. **Execution** runs the plan against in-memory, storage, distributed, or streaming backends.

---

## 2. Research foundations

### 2.1 Decorrelation / unnesting

- **Thomas Neumann & Alfons Kemper, "Unnesting Arbitrary Queries" (BTW 2015).** The classic bottom-up algorithm using dependent joins and rewrite identities.
- **Thomas Neumann, "Improving Unnesting of Complex Queries" (BTW 2025).** Shows the bottom-up algorithm can explode binding domains on deeply nested queries and proposes a **holistic top-down** pass.  
  - [PDF](https://15799.courses.cs.cmu.edu/spring2025/papers/11-unnesting/neumann-btw2025.pdf)
- **Neumann, "A Formalization of Top-Down Unnesting" (arXiv 2412.04294).** Correctness proof for the top-down variant.  
  - [arXiv](https://arxiv.org/abs/2412.04294)

Yelang adopts the **top-down holistic** variant because:
- Selector comprehensions (`users@u[*].{ ... links@l[*] ... }`) naturally produce stacked dependent joins.
- Graph-style queries with multi-hop links are exactly the deeply nested case the 2025 paper warns about.
- A rule-based rewrite engine with a per-operator *correlation context* (set of outer binders in scope) maps cleanly to the QIR data model.

### 2.2 Comprehension / monad algebra

- **Leonidas Fegaras, MRQL algebra (UTA).** MRQL normalizes nested comprehensions to a core of `concatMap`, `groupBy`, `join`, `union`, `orderBy`.  The key insight is that map-reduce-style physical operators emerge from normalization, not from SQL surface patterns.  
  - [MRQL algebra PDF](https://lambda.uta.edu/mrql-algebra.pdf)
- Yelang selector syntax (`@u[*]`, `@u[where p]`, `[**]`) already desugars to `Expr::Comprehension`.  The rewrite layer normalizes these using monad laws before decorrelation.

### 2.3 Distributed aggregation

- **DryadLINQ accumulator pattern:** `init`, `step`, `merge`, `finish`.
- **Aggregate classes** come from the stdlib `Aggregate::class()` method:
  - `Distributive` — partial states merge directly (`sum`, `count`, `min`, `max`).
  - `Algebraic` — fixed-size intermediate (`avg`, `stddev`, `variance`).
  - `Holistic` — must see all values co-located (`median`, `percentile`, `mode`).

The planner inserts `Exchange` / `LocalRepartition` / `Gather` based solely on `AggregateClass`, not on hardcoded aggregate names.

---

## 3. Logical rewrite architecture

Rewrites are implemented as small, stateless passes over `LogicalPlan`.  A pass implements:

```rust
pub trait RewritePass {
    fn run(&self, plan: &mut LogicalPlan) -> Result<bool, LoweringError>;
}
```

The driver (`rewrite::apply_rewrites`) runs passes in a fixpoint loop until no pass changes the plan.

### 3.1 Pass inventory

| Pass | File | Purpose |
|------|------|---------|
| `NormalizePass` | `rewrite/normalize.rs` | Ensure root exists; elide identity maps; drop `Filter(true)`. |
| `SimplifyPass` | `rewrite/simplify.rs` | Constant folding, boolean / arithmetic identities. |
| `MergeMapsPass` | `rewrite/merge_maps.rs` | Fuse adjacent `Map` operators by composing closures. |
| `PushFilterPass` | `rewrite/push_filter.rs` | Push filters below `Map` via capture-aware substitution. |
| `PushProjectPass` | `rewrite/push_project.rs` | Push projections down through compatible operators. |
| `PredicatePushdownPass` | `rewrite/predicate_pushdown.rs` | Split conjunctive predicates and push them through joins / set ops. |
| `ProjectionPushdownPass` | `rewrite/projection_pushdown.rs` | Propagate `DemandSet` back to producers and trim projections. |
| `DecorrelatePass` | `rewrite/decorrelate.rs` | Top-down elimination of `DependentJoin`. |
| `UnnestSubqueriesPass` | `rewrite/unnest_subqueries.rs` | Convert scalar / EXISTS subplans into joins. |

### 3.2 Shared utilities

- **`util::subst::subst_columns`** — capture-aware replacement of `Column` references inside `QExpr`.  Used by map fusion and filter pushdown.
- **`util::subst::free_binders`** — compute free binders of a `QExpr`, used to recompute closure captures after substitution.
- **`rewrite::apply_id_rewrites`** — apply a map `old LirId -> new LirId` to every child reference and the root, following chains.
- **`rewrite::as_closure`** — extract `(param, body)` from a single-parameter `QExpr::Closure`.

### 3.3 Key invariants

- Rewrites never change the type of the root expression.
- Rewrites never introduce binders that shadow outer expressions.
- `LirOp::children()` and `LirOp::map_children()` are the only ways a pass navigates the operator tree, so new operators automatically participate in traversal.

---

## 4. Decorrelation design (Neumann top-down)

### 4.1 Representation

Correlation is represented by two QIR constructs:

- `LirOp::DependentJoin { outer, inner, predicate }` — the inner plan may reference binders defined by the outer plan.
- `QExpr::Subplan(LirId, TyId)` inside a scalar expression — a subquery that will be decorrelated into a join.

`DependentJoin` is produced during comprehension lowering when a nested selector references an outer binder.

### 4.2 Correlation context

Each operator carries a *correlation context*: the set of `BinderId`s that are in scope from outer plans.  The rewrite pass walks top-down, maintaining this context.

```rust
pub struct CorrelationContext {
    pub outer_binders: Vec<BinderId>,
}
```

When the pass enters an `inner` side of a `DependentJoin`, it adds the outer binders to the context.  When it reaches an operator whose free binders are all in the current context, it can be treated as decorrelated.

### 4.3 Rewrite rules

The algorithm is essentially Neumann's top-down rewrite:

| Pattern | Result |
|---------|--------|
| `DependentJoin(outer, Filter(input, p), pred)` | `Filter(DependentJoin(outer, input, pred), p)` |
| `DependentJoin(outer, Map(input, f), pred)` | `Map(DependentJoin(outer, input, pred), f)` |
| `DependentJoin(outer, Aggregate(input, agg), pred)` | `Aggregate(DependentJoin(outer, input, pred), agg)` (if agg is distributive/algebraic) |
| `DependentJoin(outer, Join(left, right, p), pred)` | push dependent join into the side that references outer binders |
| `DependentJoin(outer, inner, pred)` where `inner` no longer references outer | `Join(Cross, outer, inner, pred)` or `Filter(Join(Cross, outer, inner, None), pred)` |

When `inner` becomes a simple scan/filter over a collection that does not reference outer binders, the dependent join becomes a regular join.

### 4.4 Subquery unnesting

Scalar subqueries are embedded as `QExpr::Subplan`.  `UnnestSubqueriesPass` runs after `DecorrelatePass` and:
1. Identifies `Subplan` expressions.
2. Replaces them with a regular `Join` (or `DependentJoin` -> `Join`) that produces the required cardinality.
3. Rewrites the parent operator to reference the join output.

For cardinality:
- Scalar subquery → single-row aggregation, then join.
- `EXISTS` → semi-join.
- `NOT EXISTS` → anti-join.

---

## 5. Physical planning (Cascades)

### 5.1 Architecture

`pir::planner::Planner` is a Cascades-style optimizer:
- `Memo` groups logically equivalent expressions.
- Each `Group` stores the logical expression, candidate physical expressions, and required physical properties.
- `optimize_group` enforces properties (ordering, partitioning, location) and picks the cheapest plan.

Currently `optimize_group` is a stub returning `PlanError::NoValidPlan`.  This phase implements it.

### 5.2 Physical properties

Defined in `pir::props`:

- `PhysicalOrdering` — sorted by a list of `OrderKey`.
- `PhysicalPartitioning` — hash/range partitioning by expressions, or `Single`.
- `Location` — `Memory`, `Storage`, `Remote`.
- `Boundedness` — `Bounded` vs `Unbounded`.

Each physical operator implements `satisfies(properties) -> bool`.  If an operator does not satisfy the required properties, an *enforcer* is inserted:
- `Sort` for ordering.
- `Exchange` / `LocalRepartition` for partitioning.
- `Gather` for `Single` location.

### 5.3 Cost model

`pir::cost::Cost { startup, per_row }`.  Physical operators provide an estimate; the planner sums costs bottom-up.

### 5.4 Physical operator inventory

`PirOp` (in `pir/operator.rs`) includes:

- Scans: `TableScan`, `IndexScan`, `Values`.
- Unary pipeline: `Filter`, `Project`, `FlatMap`, `Sort`, `TopK`, `Slice`, `Distinct`, `HashAggregate`, `SortAggregate`, `StreamingAggregate`, `Window`.
- Joins: `HashJoin`, `MergeJoin`, `NestedLoopJoin`.
- Set ops: `Union`, `UnionAll`, `Intersect`, `IntersectAll`, `Except`, `ExceptAll`.
- Distribution: `Exchange`, `LocalRepartition`, `Gather`.
- Graph: `EdgeExpand`, `Construct`, `AttachField`.
- Scalar: `Expr`.

### 5.5 Aggregate placement

For `AggregateClass`:

| Class | Local strategy | Global strategy |
|-------|----------------|-----------------|
| `Distributive` | `Partial` aggregate per partition. | `Final` merge of partial states. |
| `Algebraic` | `Partial` aggregate per partition (fixed-size state). | `Final` merge. |
| `Holistic` | Collect all rows. | `Gather` to single node, then `Full` aggregate. |

The planner chooses `HashAggregate` for unordered input and `SortAggregate` when input is already sorted on group keys.

---

## 6. Execution

### 6.1 Architecture

`ExecPlan` (`exec/plan.rs`) is an arena of `ExecOp` nodes.  Each operator carries a bound kernel or aggregate function pointer.

`KernelRegistry` (`exec/kernels.rs`) resolves scalar operations (`+`, `>`, `&&`, field access) to executable closures.  Aggregates are resolved by `Aggregate` trait impls compiled to native code.

`MemoryExecutor` (`exec/memory.rs`) is the reference in-memory implementation.  Other backends implement `backend::capability::BackendCapability` and supply backend-specific rules to the planner.

### 6.2 Operator kernels

- `ScanKernel` — read from in-memory array, storage cursor, or remote fragment.
- `FilterKernel` — evaluate predicate per row.
- `ProjectKernel` — evaluate projection expression per row.
- `HashJoinExec` / `MergeJoinExec` / `NestedLoopJoinExec` — join implementations.
- `HashAggregateExec` / `SortAggregateExec` — aggregation implementations.
- `ExchangeExec` — ship batches between nodes.

### 6.3 Values

`exec::value::Value` represents rows, arrays, records, and scalar primitives.  The executor uses `RecordBatch` for columnar batches where possible.

---

## 7. File tree

```
yelang-qir/src/
├── lib.rs                    # Entry points: lower_query, plan_logical
├── errors.rs                 # QirError, LoweringError, PlanError, ExecError
├── ids.rs                    # LirId, PirId, ExecId, QExprId, BinderId
├── expr.rs                   # QExpr scalar-expression enum
├── demand.rs                 # DemandSet for projection pushdown
├── volatility.rs             # Volatility classification
│
├── logical/                  # Logical plan (LIR)
│   ├── mod.rs
│   ├── plan.rs               # LogicalPlan arena + builder helpers
│   ├── operator.rs           # LirOp enum
│   ├── props.rs              # LogicalProps (cardinality, ordering, demand, ...)
│   ├── shape.rs              # NestedShape, CorrelationMode
│   ├── lower.rs              # LoweringCtxt and trait tables
│   ├── lower_expr.rs         # HIR expr -> QExpr
│   ├── lower_method.rs       # Method dispatch
│   ├── lower_query.rs        # Query/surface syntax -> LIR
│   ├── lower_selector.rs     # Comprehension -> LIR
│   ├── queryable.rs          # Queryable trait lowering
│   ├── aggregate.rs          # Aggregate trait lowering
│   ├── iterator.rs           # Iterator/IntoIterator lowering
│   ├── links.rs              # Graph link traversals
│   └── stdlib.rs             # Introspection of stdlib traits/impls
│
├── rewrite/                  # Logical rewrites
│   ├── mod.rs                # Pass driver + shared helpers
│   ├── pass.rs               # RewritePass trait
│   ├── normalize.rs
│   ├── simplify.rs
│   ├── merge_maps.rs
│   ├── push_filter.rs
│   ├── push_project.rs
│   ├── predicate_pushdown.rs
│   ├── projection_pushdown.rs
│   ├── decorrelate.rs
│   └── unnest_subqueries.rs
│
├── pir/                      # Physical plan (PIR)
│   ├── mod.rs
│   ├── plan.rs
│   ├── operator.rs
│   ├── props.rs              # Physical properties + enforcers
│   ├── cost.rs               # Cost model
│   ├── planner.rs            # Cascades planner
│   ├── aggregations.rs       # Aggregate physical strategies
│   ├── exchanges.rs          # Exchange / repartition rules
│   ├── joins.rs              # Join physical rules
│   └── enforcers.rs          # Sort / gather insertion
│
├── exec/                     # Execution
│   ├── mod.rs
│   ├── plan.rs
│   ├── operator.rs
│   ├── value.rs
│   ├── kernels.rs            # Scalar kernel registry
│   ├── memory.rs             # In-memory executor
│   ├── pipeline.rs           # Pipeline / morsel scheduling
│   ├── morsel.rs             # Batch representation
│   ├── spill.rs              # Spilling to disk
│   └── interface.rs          # Executor trait
│
├── backend/                  # Backend capabilities
│   ├── mod.rs
│   ├── capability.rs
│   ├── memory_backend.rs
│   ├── storage_backend.rs
│   ├── remote_backend.rs
│   └── stream_backend.rs
│
└── util/                     # Shared utilities
    ├── mod.rs
    ├── arena.rs
    ├── equivalence.rs
    ├── graph.rs
    ├── print.rs
    ├── subst.rs              # Capture-aware substitution + free binders
    └── visitor.rs
```

---

## 8. Checklist

- [x] Implement capture-aware `subst_columns` and `free_binders`.
- [x] Implement `NormalizePass` (root, identity map, true filter).
- [x] Implement `SimplifyPass` (constant folding, boolean identities).
- [x] Implement `MergeMapsPass` (closure composition).
- [x] Implement `PushFilterPass` (filter below map via substitution).
- [x] Implement `ProjectionPushdownPass` (demand propagation, trim Map/Construct fields).
- [x] Add unit tests for Normalize, Simplify, MergeMaps, PushFilter, ProjectionPushdown.
- [x] Wire `apply_rewrites` into `lower_query`.
- [x] Implement `PushProjectPass` (push Map through Slice/Take/Skip and other shape-preserving ops).
- [x] Implement `PredicatePushdownPass` (merge nested filters; CrossJoin + Filter → InnerJoin; InnerJoin predicate merge).
- [ ] Extend `PredicatePushdownPass` with conjunct splitting and side-only predicate pushdown once binder/field provenance is tracked.
- [ ] Extend `PredicatePushdownPass` to push filters through `UnionAll`/`Union`.
- [x] Implement `DecorrelatePass` (Neumann top-down) with `output_binder` provenance.
- [x] Implement `UnnestSubqueriesPass` (scalar uncorrelated -> cross join; correlated -> dependent join).
- [x] Implement top-down physical planner (`pir::planner`) with property enforcers.
- [x] Implement aggregate physical strategies by `AggregateClass` (framework in place; distributed partial/final to be extended).
- [x] Implement exchange / repartition insertion for distributed plans (enforcer framework in place).
- [x] Implement in-memory executor kernels for `TableScan`, `Filter`, `Project`, `Sort`, `Slice`, `HashAggregate`, `GroupBy`, and `NestedLoopJoin`.
- [x] Add end-to-end execution tests for `filter.map`, `order_by.range`, scalar aggregate, and grouped aggregate.
- [x] Inline local `let`-bound array sources so `from users@u` works with in-memory data.
- [x] Run `cargo test --workspace` with no regressions.

---

## 9. Immediate next steps

1. Extend `PredicatePushdownPass` with conjunct splitting and side-only predicate pushdown once binder/field provenance is tracked.
2. Extend `PredicatePushdownPass` to push filters through `UnionAll`/`Union`.
3. Implement `EXISTS` / `NOT EXISTS` semi/anti-join unnesting in `UnnestSubqueriesPass`.
4. Implement lateral / correlated execution so dependent joins that cannot be decorrelated still run correctly.
5. Evolve the planner into a full Cascades memo structure with statistics and multi-candidate pruning.
6. Add distributed execution tests with exchange operators and partial/final aggregation.
