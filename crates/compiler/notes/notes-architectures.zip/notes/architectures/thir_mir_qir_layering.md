# IR Layering: HIR, THIR, MIR, QIR — who consumes what

**Status:** Accepted. Resolves the THIR-sequencing thread. Binding on Phase J
(QIR) and the future MIR phase. Related: `PHASEJ_QIR_STRUCTURE_DESIGN.md`
(J1.0 typed-view facade), `query_language_and_execution_design.md`.

---

## 1. The IR inventory and the query bypass

HIR already factors query expressions out of the expression tree:
`Expr::Query(QueryId)` is an opaque leaf; the query's internals live in side
tables (`SelectQuery`, `FromNode`, … keyed by `QueryId`). Consequence — the
single most important decision in this document:

> **THIR never sees queries. Queries bypass THIR entirely.**

```
                         ┌─────────────────────────────────────────┐
 source → AST → resolve →│                  HIR                    │
                         └─────────────────────────────────────────┘
                              │                        │
                ordinary items & exprs          Expr::Query(QueryId)
                              │                        │
                              ▼                        ▼
                    THIR (incremental,          QIR lowering
                    MIR-phase crate)            (HIR query node +
                              │                 typed-view facade, J1.0)
                              ▼                        │
                    MIR ──► codegen              LIR → rewrites → PIR
                              │                        │
                              └──── boundary ──────────┘
                        MIR sees only: QueryCall { plan, captures }
                        → qir_runtime::execute(plan, captures) : T
```

- THIR's job: typed, simplified tree for **ordinary** code (coercions
  explicit, autoderef/autoref materialized, patterns simplified) — rustc's
  proven model (AST → HIR → THIR → MIR, THIR built after type checking).
- QIR's job: the query algebra. Its input is the HIR query node and the
  ordinary expressions *embedded inside it* (projection, where-clause, group
  keys), typed via the facade (§4).

## 2. Why QExpr exists when `Expr` already does

Every IR level re-projects expressions into a right-sized form. rustc does it
twice; nobody calls it redundant:

| level | expression form | what it drops | what it gains |
|---|---|---|---|
| HIR `Expr` | spans, `Res`, scopes, full language | — | resolution done |
| THIR `Expr` (planned) | no spans/scopes | sugar, implicit coercions | types baked in, patterns simple |
| MIR `Rvalue` (planned) | no nesting | control flow → CFG | SSA, borrow/drop analysis |
| **QIR `QExpr`** | binder ids, no scopes/mutation/loops/references | everything with effects or control flow | totality: any node moves anywhere its binders are in scope; closed for serialization |

QExpr is to HIR `Expr` what MIR `Rvalue` is to THIR `Expr`: a *projection*,
not a second language. The four things it buys that HIR cannot:

1. **Binder discipline.** Optimizer rewrites (decorrelation, pushdown)
   constantly rewire bindings. `BinderId` positions with free-var/subst
   analysis are the tool; HIR's `Res`+scope machinery is the wrong shape and
   carries dead weight (spans, resolutions) at this level.
2. **Totality.** No blocks, statements, mutation, loops, references — every
   node is a pure value. "Any QExpr may be moved, duplicated, or folded
   wherever its binders are in scope" holds *structurally*, which is what
   makes rewrite rules one-liners instead of analyses.
3. **Serialization.** Plan fragments ship to shards: a closed, versionable,
   minimal form. HIR is session-internal (DefIds, interner state).
4. **Volatility.** Calls carry `pure`/`stable`/`volatile`; folding and
   shipping legality read it directly.

Structural similarity to HIR `Expr` is a *feature*: it makes the lowering
mechanical and the later THIR-backed swap (§4) cheap.

## 3. The boundary contract: how a query re-enters the program

A query expression evaluates to an ordinary value of the projection's type.
Two delivery modes, chosen per query:

```rust
// ── mode A: staged query (lazy/backend source) ──────────────────
// MIR lowers Expr::Query(id) to a runtime call:
let result: T = qir_runtime::execute(PLAN_HANDLE[id], captures);
// PLAN_HANDLE: the optimized PIR fragment, compiled once, cached by QueryId.
// captures: the free variables the plan closes over (host vars).

// ── mode B: eager local query (in-memory [T] source) ────────────
// no plan at all — MIR lowers straight to iterator code:
let result: T = users.iter().filter(|u| u.age > 18).map(|u| u.name).collect();
// identical semantics; LLVM fuses. This path never touches QIR.
```

Mode selection: the source's type (a `Queryable` backend handle → A; an
in-memory `[T]` → B), made at lowering time, visible in EXPLAIN.

## 4. The typed-view facade (Phase J, J1.0)

QIR lowering reads types/resolutions exclusively through one API:

```rust
trait TypedView {
    fn ty_of(&self, e: ExprId) -> TyId;
    fn method(&self, e: ExprId) -> Option<MethodRes>;
    fn adjustments(&self, e: ExprId) -> &[Adjustment]; // empty until THIR
}
```

- **v1 impl (now):** HIR + `TypeckResults`. Contained in `lir/lower/typed.rs`;
  nothing else in `lir/lower/` touches `TypeckResults`.
- **v2 impl (MIR phase, optional):** THIR-backed, once THIR covers the full
  expression language. Query-internal expressions are lowered through the
  THIR machinery as a subroutine. Swap is one module; lowering algorithms
  untouched.

## 5. Incremental THIR (not a big bang)

THIR is a **MIR-phase deliverable**, grown in tiers — QIR is never blocked on
it:

- **Tier 0 (skeleton):** crate, `Expr`/`Pat`/`Stmt` enums mirroring HIR,
  lowering for the straight-line subset (lets, calls, literals, blocks,
  if/match, field/index).
- **Tier 1:** closures + captures, method calls (concrete DefIds), autoderef/
  autoref/coercion nodes, `for`/loops.
- **Tier 2:** full pattern language, compound assignment, ranges, `Option`
  helpers, async/gen lowerings (with MIR state machines).
- Coverage gate: a variant graduates when MIR consumes it. `Expr::Query` is
  never a THIR variant — see §1.

## 6. Consequences

- Phase J is unaffected: J1.0 (facade) stays as specced; no THIR dependency.
- MIR phase starts with Tier 0 + the boundary node (`QueryCall`).
- No double work: QIR's lowering algorithms are facade-stable; THIR is
  additive for ordinary code only.

## 7. External validation (checked 2026-07-19)

- **rustc's THIR** — [rustc-dev-guide: The THIR](https://rustc-dev-guide.rust-lang.org/thir.html):
  generated after type checking with all types filled in; used for MIR
  construction, exhaustiveness, and unsafety checking. Confirms §1–§2. One
  refinement: THIR represents **bodies only** (executable code; no struct/
  trait items) — which fits the boundary model, since queries live inside
  bodies and cross as the single `QueryCall` node.
- **Staging lineage** — [LMS / Delite / LegoBase](https://scala-lms.github.io/):
  programs and queries staged through one IR with domain-specific nodes
  layered on top. Independent confirmation that a query algebra embedded in a
  host-compiler pipeline (rather than rewriting the host IR) is the proven
  shape.
- **Query codegen without a general-purpose IR** — Funke, Mühlig & Teubner,
  *Low-Latency Query Compilation* (Flounder IR / ReSQL,
  [VLDB Journal 31(6), 2022](https://link.springer.com/article/10.1007/s00778-022-00741-5)):
  a small DB-specific IR translated to machine code in one pass beats LLVM
  IR on compile latency for interactive queries. Informs the eventual Phase-6
  choice for the LIR→MIR bridge (our MIR bridge must stay cheap, or kernels
  get their own tiny lowering — decided when codegen exists).
