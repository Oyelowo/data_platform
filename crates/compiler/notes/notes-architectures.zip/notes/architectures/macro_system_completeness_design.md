# Yelang Macro System — Completeness Design Document

## 1. Executive summary

The `yelang-macro` crate is **production-ready for all declarative macro kinds**: modern function-like (`macro name { ... }` / `name!(...)`), attribute (`macro name { attr()($item:item) => { ... } }` / `@name`), and derive (`macro name { derive()($item:item) => { ... } }` / `@derive(Name)`). It is *not* done with the broader procedural-macro / metaprogramming story.

What we have:
- Function-like declarative macros with matchers, captures, repetitions (`*`, `+`, `?`), separators, and nested repetitions.
- User-defined attribute macros (Phase 1) with argument matching and item transformation.
- User-defined derive macros (Phase 1), including user overrides of built-in derives by name.
- Hygiene via `SyntaxContextId` / `ExpnId` in `yelang-macro-core`.
- Built-in decorators (`@derive`, `@test`, `@repr`, `@inline`, `@lang`, `@no_std`/`@no_core`) and built-in expression macros (`assert!`, `assert_eq!`, `assert_ne!`, `todo!`, `format!`, `panic!`, `unreachable!`).
- Loop detection, ambiguity detection, outer-to-inner attribute ordering, and a warning-free crate with `#![deny(...)]` lints.

What we do **not** have:
- A general **procedural macro** framework (external crates, `proc-macro2`-style API, quote/syn toolkit).
- Macro invocation as a field *name* (e.g., `self.mac!()` or `Foo { mac!(): 1 }`).
- Cross-crate macro export/import.
- Incremental-friendly crate-level expansion queue.
- cfg/cfg_attr integration with attribute expansion.
- Source-location macros (`line!`, `column!`, `file!`, `module_path!`).
- `format_args!` / `const_format_args!` lowering to HIR builtin.

This document is the design for closing those gaps without inheriting Rust's legacy mistakes, using the benefit of greenfield hindsight and the Rust team's latest work (RFCs 3697, 3698, 3714, 3715, the `rustc` dev guide, and the 2025 declarative-macro improvements).

## 2. Research digest

### 2.1 Rust RFCs (declarative macro improvements)

| RFC | Author | Status | What it adds |
|-----|--------|--------|--------------|
| [RFC 3697 — Declarative `macro_rules!` attribute macros](https://github.com/rust-lang/rfcs/pull/3697) | Josh Triplett | Merged / nightly | `attr()($item:item)` rule syntax so a declarative macro can act as an attribute macro. Supports `unsafe attr()` rules. |
| [RFC 3698 — Declarative `macro_rules!` derive macros](https://github.com/rust-lang/rfcs/pull/3698) | Josh Triplett | Merged / nightly | `derive()($item:item)` rule syntax so a declarative macro can act as a derive macro. |
| [RFC 3714 — Macro fragment fields](https://github.com/rust-lang/rfcs/pull/3714) | Josh Triplett | Merged | Access parsed components of captures, e.g. `$field.name`, `$field.type`. |
| [RFC 3715 — Unsafe derives and attributes](https://github.com/rust-lang/rfcs/pull/3715) | Josh Triplett | Merged | `#[derive(unsafe(Foo))]` and `#[unsafe(foo)]` requiring explicit unsafe acknowledgement for macros that can cause UB if misused. |

Key takeaways from the Kangrejos paper, *Rust Declarative Macro Improvements: A Step Forward for Rust Macros Usability* ([PDF](https://kangrejos.com/2025/Rust%20Declarative%20Macro%20Improvements:%20A%20Step%20Forward%20for%20Rust%20Macros%20Usability.pdf)):
- The vast majority of real-world derive/attribute macros are simple token transformations. They do not need the full power (or dependency weight) of `syn` + `quote` + `proc-macro2`.
- Declarative attribute/derive macros eliminate separate macro crates, heavy dependencies, and build-time regressions — critical for constrained environments (Rust for Linux).
- Syntax example from RFC 3697:
  ```rust
  macro_rules! main {
      attr()($func:item) => { make_async_main!($func) };
      attr(threads = $threads:literal)($func:item) => { make_async_main!($threads, $func) };
  }
  ```
- Syntax example from RFC 3698:
  ```rust
  macro_rules! Answer {
      derive()(struct $name:ident $_:tt) => { impl Answer for $name { ... } };
      derive()(enum  $name:ident $_:tt) => { impl Answer for $name { ... } };
  }
  ```

### 2.2 `rustc` dev guide — macro expansion architecture

From the [Rust Compiler Development Guide — Macro expansion](https://rustc-dev-guide.rust-lang.org/macro-expansion.html):
- Expansion happens **at the crate level**, iteratively, with a queue of unresolved invocations.
- `MacroExpander::fully_expand_fragment` resolves, expands, and integrates output back into the AST.
- Hygiene uses **three hierarchies**: expansion-order, macro-definition, and call-site. `ExpnId` identifies individual macro calls; `SyntaxContext` chains definition-site marks.
- The macro parser is essentially an NFA/Earley-like regex parser over token trees; it calls back to the Rust parser for non-terminals (`$e:expr`, `$t:ty`, etc.).
- Proc macros are compiled as separate crates, use a **stable token stream ABI**, and require conversion between the compiler's internal token stream and the stable `proc_macro::TokenStream`.

### 2.3 Little Book of Rust Macros — hygiene and metavariable expressions

- [Hygiene and Spans](https://lukaswirth.dev/tlborm/proc-macros/hygiene.html): three span kinds — `definition site` (unhygienic reference but hygienic binding), `mixed site` (legacy `macro_rules` behavior), `call site` (fully unhygienic).
- [Metavariable Expressions](https://lukaswirth.dev/tlborm/decl-macros/minutiae/metavar-expr.html): `$$` (escaped dollar), `${count($x)}`, `${index()}`, `${len()}`, `${ignore($x)}`. These solve common patterns without proc macros.

## 3. Lessons from Rust / greenfield hindsight

We should deliberately **not** copy Rust's historical path:

1. **Don't split macro kinds into separate implementation universes.** Rust historically treated `macro_rules!`, proc macros, derives, and attributes as four separate subsystems. We should implement them as variants of one `MacroKind` expansion pipeline.
2. **Don't require separate crates or external dependencies for common macros.** RFCs 3697/3698 exist precisely because forcing `syn`/`quote`/`proc-macro2` for every derive was a mistake.
3. **Don't use a stable ABI for internal token trees.** `rustc` pays a complexity tax converting between internal `rustc_ast::tokenstream::TokenStream` and stable `proc_macro::TokenStream`. Our internal `yelang-macro-core` token trees can stay internal until we genuinely need external proc macros.
4. **Do design hygiene around three hierarchies from day one.** We already have `ExpnId` and `SyntaxContextId`; we should make sure we track expansion-order, definition-site, and call-site hierarchies explicitly rather than ad-hoc.
5. **Do validate follow sets early.** Rust's macro parser rejects ambiguous matches; we should implement follow-set validation to avoid accidental parsing divergence.
6. **Do support declarative attribute/derive natively.** This is the modern direction. We should not build a proc-macro-only derive framework first.
7. **Do keep the two-token-system split.** Lexer tokens and macro token trees have different jobs; unifying them would harm hygiene and provenance.

## 4. Honest inventory of what is implemented

| Feature | Status | Notes |
|---------|--------|-------|
| Function-like declarative macros | ✅ Complete | `macro name { (matcher) => { transcriber } }` |
| Metavariable capture | ✅ | `$name:fragment` |
| Repetitions `* + ?` | ✅ | With separators |
| Nested repetitions | ✅ | |
| Hygiene (basic) | ✅ | Opaque definition-site context per expansion |
| Loop detection | ✅ | Direct and indirect recursion detected |
| Ambiguity detection | ✅ | Multiple matching rules emit error |
| Built-in expression macros | ✅ | `assert!`, `panic!`, `todo!`, etc. |
| Built-in decorators | ✅ | `@derive`, `@test`, `@repr`, `@inline`, `@lang`, `@no_std` |
| Attribute macros (user-defined declarative) | ✅ | `macro name { attr()($item:item) => { ... } }` invoked as `@name` |
| Derive macros (user-defined declarative) | ✅ | `macro name { derive()(struct $n:ident $_:tt) => { ... } }` invoked as `@derive(Name)` |
| Expansion at expression position | ✅ | `expr_macro!(...)` |
| Expansion at statement position | ✅ | `stmt_macro! { ... }` |
| Expansion at item position | ✅ | `item_macro!()` as a top-level/module item |
| Expansion at type position | ✅ | `TypeMacro!()` in type annotations |
| Expansion at pattern position | ✅ | `let PatMacro!() = x;` |
| Expansion at field position | ✅ | Field values/types in struct literals, struct patterns, field definitions, enum variants, array sizes, generic args |
| Follow-set validation | ✅ | Definition-time validation for all fragment specifiers |
| Metavariable expressions | ✅ | `${count(x)}`, `${index()}`, `${len()}`, `${ignore(x)}`, `$$` |
| Trailing separators | ✅ | Implicit trailing separator for `*`/`+` repetitions |
| Fragment fields | ✅ | `$ident.name`, `$expr.type`, `$ty.name`/`$ty.args`, `$item.vis`/`$item.name`/`$item.attrs` |
| Unsafe attribute/derive rules | ✅ | `unsafe attr()` / `unsafe derive()` rules require `unsafe(...)` opt-in |
| Indirect recursion detection | ✅ | `a!` → `b!` → `a!` caught via expansion-stack def-id check |
| Cross-crate macro export/import | ❌ | Macros are file-local today |
| `$crate` / `$package` hygiene | ✅ | `IdentOrigin::Crate`/`Package` resolved to defining crate/package root |
| Macro backtraces | ✅ | `ExpandError` carries expansion-stack frames |
| `call_site` / `mixed_site` span kinds | ⚠️ | `Transparency` data structures exist; explicit transcriber syntax deferred |
| Eager expansion of built-ins | ✅ | `concat!`, `concat_bytes!`, `stringify!`, `include!`, `include_str!`, `include_bytes!`, `env!`, `option_env!`, `compile_error!`, `cfg!` |
| Function-like proc macros | ❌ | No external proc-macro framework |
| Attribute proc macros | ❌ | No external proc-macro framework |
| Derive proc macros | ❌ | No external proc-macro framework |

## 5. Exhaustive gap analysis

### 5.1 Macro kinds missing

1. ~~User-defined attribute macros~~ — ✅ implemented declaratively in Phase 1.
2. ~~User-defined derive macros~~ — ✅ implemented declaratively in Phase 1.
3. **Procedural macro framework** — external crates that implement function-like/attribute/derive macros in Yelang itself, using a stable `TokenStream` API.

### 5.2 Positions missing

Expression, statement, item, type, pattern, and field positions all expand today. Remaining:
- Field *name* position in struct literals/patterns and member access (`self.mac!()` or `Foo { mac!(): 1 }`).
- Block trailing expression position nuances for macros that expand to multiple statements.

### 5.3 Matcher/transcriber missing features

1. ~~Follow-set validation~~ — ✅ implemented.
2. ~~Trailing separator~~ — ✅ implemented.
3. ~~Metavariable expressions~~ — ✅ implemented.
4. ~~Fragment fields~~ — ✅ implemented.
5. **Negative matchers** — optional but useful (`$x:ident !` meaning "not followed by").
6. **TT-muncher helpers** — optional, can be user-built if repetitions are strong.

### 5.4 Hygiene and scoping gaps

1. **Indirect recursion detection** — `a!` expands to `b!` which expands to `a!`.
2. **Cross-crate hygiene** — macros defined in one crate and used in another must keep their definition-site context stable.
3. **`$crate`/`$package` token** — allow generated code to refer to items in the macro's defining crate.
4. **Call-site vs definition-site spans** — today we always use opaque definition-site for generated tokens; proc macros will need `call_site` and `mixed_site`.
5. **Macro backtraces** — diagnostic spans should show the chain of macro invocations.

### 5.5 Expansion pipeline gaps

1. **Crate-level iterative expansion queue** — today we iterate over items in a simple loop. We need a real queue of unresolved invocations with import resolution interleaved.
2. ~~Attribute macro ordering~~ — ✅ applied outer-to-inner for items in Phase 1.
3. ~~Derive side-item generation~~ — ✅ generates adjacent items in Phase 1.
4. **cfg/cfg_attr handling** — conditional compilation should integrate with macro expansion.
5. **Eager expansion** — built-ins like `concat!`, `stringify!`, `include!` must expand their literal arguments before the macro itself.

### 5.6 Error and diagnostic gaps

1. **Better error messages** for "no rule matched" showing which tokens failed.
2. **Macro backtraces** in diagnostics.
3. **Lint for unreachable macro rules**.
4. **Lint for ambiguous macro rules** at definition time.
5. **Lint for transcriber using unbound metavariables**.

## 6. Design proposal

### 6.1 Unified macro definition syntax

We keep the modern `macro name { ... }` syntax but extend the rule kinds:

```yelang
// Function-like (already works)
macro unless {
    ($cond:expr, $body:expr) => { if !$cond { $body } };
}

// Attribute macro (new)
macro async_main {
    attr()($func:item) => {
        $func
        fn main() { async_runtime::block_on(wrapper()) }
    };
    attr(threads = $n:literal)($func:item) => { ... };
}

// Derive macro (new)
macro Answer {
    derive()(struct $name:ident $_:tt) => {
        impl Answer for $name {
            fn answer(&self) -> i32 { 42 }
        }
    };
    derive()(enum $name:ident $_:tt) => { ... };
}

// Unsafe derive/attribute (new, future)
macro FromBytes {
    unsafe derive()($item:item) => { ... };
}
```

A macro may contain **multiple rule kinds** (function-like, attribute, derive) in the same definition. The macro resolver dispatches based on invocation site.

### 6.2 Macro kinds and invocation sites

| Kind | Invocation syntax | Target fragment | Output |
|------|-------------------|-----------------|--------|
| Function-like | `name!(...)` | Token tree inside delimiters | Expression (or item/type/pattern when supported) |
| Attribute | `@name(...)` or `#[name(...)]` | Annotatable item | Item(s) |
| Derive | `@derive(Name)` or `#[derive(Name)]` | Item | Item(s) + original item |

`Annotatable` is the set of AST nodes that can carry attributes: items, type parameters, fields, variants, etc.

### 6.3 Data structure changes

#### 6.3.1 `MacroKind` enum

```rust
pub enum MacroKind {
    FunctionLike,
    Attribute,
    Derive,
    // Future: procedural variants
}
```

#### 6.3.2 `MacroRule` extension

```rust
pub struct MacroRule {
    pub kind: MacroKind,
    pub attr_matcher: Option<Vec<AttrArg>>, // for attribute rules
    pub matcher: Vec<MatcherOp>,
    pub transcriber: Vec<TranscriberOp>,
}
```

#### 6.3.3 `MacroInvocation` extension

Add `kind: MacroInvocationKind`:

```rust
pub enum MacroInvocationKind {
    Bang,
    Attribute(Attribute),
    Derive(Ident),
}
```

#### 6.3.4 `Annotatable` AST wrapper

New in `yelang-ast`:

```rust
pub enum Annotatable {
    Item(Item),
    // Future: Field, Variant, Param, GenericParam, etc.
}
```

#### 6.3.5 Expansion queue

Replace the simple item loop with a `VecDeque<Invocation>`:

```rust
pub struct ExpansionQueue {
    pending: VecDeque<Invocation>,
}
```

Each `Invocation` records:
- macro path,
- kind,
- input token stream / annotatable,
- call-site span,
- expected output fragment kind.

### 6.4 Attribute macro expansion

1. Parser encounters `@name(args) item` or `#[name(args)] item`.
2. The item is not parsed further until attributes are expanded.
3. The attribute macro receives:
   - attribute arguments as a token stream (`args`),
   - the item as an `Annotatable::Item` (or its token-tree representation).
4. The macro's matching rule is selected by `kind == Attribute` and `attr_matcher`.
5. Transcriber produces one or more items.
6. Produced items are re-attributed with remaining (non-expanded) attributes and pushed back into the expansion queue.
7. Outer attributes are applied before inner attributes.

### 6.5 Derive macro expansion

1. Parser encounters `@derive(A, B, C)` or `#[derive(A, B, C)]` on an item.
2. The item is kept.
3. For each derive name, an `Invocation::Derive` is enqueued.
4. Each derive macro receives the item (as token stream or AST).
5. The transcriber produces adjacent items (usually `impl Trait for Type`).
6. Generated items are inserted next to the original item in the item list.
7. `unsafe derive()` rules require the invocation to use `#[derive(unsafe(A))]` or `@derive(unsafe(A))`.

### 6.6 Function-like expansion in new positions

The `MacroInvocation` AST node currently lives inside `ExprKind`. We need:
- `ItemKind::MacroInvocation` for item-position macros.
- `TypeKind::MacroInvocation` for type-position macros.
- `PatternKind::MacroInvocation` for pattern-position macros.

Each produces the appropriate fragment kind, which is parsed and re-integrated.

### 6.7 Follow-set validation

Implement a `follow_set(fragment: FragmentKind, next: &TokenTree) -> bool` table based on Rust's follow sets:

| Fragment | Valid follows |
|----------|---------------|
| `expr`, `stmt` | `=>` `,` `;` |
| `ty`, `path` | `=>` `,` `=` `;` `:` `>` `>>` `[` `{` `as` `where` |
| `pat` | `=>` `,` `=` `\|` `if` `in` |
| `ident`, `block`, `item`, `tt`, `literal` | any token |

Validate during `parse_rules` and during matching when a fragment is followed by an unexpected token.

### 6.8 Metavariable expressions

Extend `TranscriberOp` with:

```rust
pub enum TranscriberOp {
    // existing
    MetavarExpr(MetavarExpr),
}

pub enum MetavarExpr {
    Count(Symbol, Option<usize>), // ${count($x)} or ${count($x, 0)}
    Index(Option<usize>),         // ${index()} or ${index(1)}
    Len(Option<usize>),           // ${len()} or ${len(1)}
    Ignore(Symbol),               // ${ignore($x)}
}
```

`$$` is encoded as a literal `$` token in the transcriber (escaped dollar).

### 6.9 Fragment fields

After we have typed AST access during transcription (or a separate pass), support:

```yelang
macro field_count {
    derive()(struct $name:ident { $( $field:ident : $ty:ty ),* }) => {
        impl $name {
            const FIELD_COUNT: usize = ${count($field)};
        }
    };
}
```

Fragment fields require the matcher to bind structured sub-captures and the transcriber to reference them. This is an advanced feature and can be phase 2.

### 6.10 Unsafe attribute / derive rules

A rule marked `unsafe attr()` or `unsafe derive()` can only be invoked with `#[unsafe(name)]` or `#[derive(unsafe(Name))]`. This makes potentially unsound macros opt-in explicit, matching Rust's unsafe philosophy.

### 6.11 Procedural macro framework (future, but design now)

When we add user proc macros, the architecture should be:

1. A stable `TokenStream` API crate (`yelang-proc-macro`) exposed to macro authors.
2. A compiler server (`yelang-macro-server`) that loads proc-macro crates as dynamic libraries / WASM modules and bridges the stable API to `yelang-macro-core` token trees.
3. Proc macros are declared with `#[proc_macro]`, `#[proc_macro_attribute]`, `#[proc_macro_derive]` in Yelang source.
4. The compiler compiles these crates before the crates that depend on them, caches the `.so`/`.wasm`, and invokes them during expansion.

**Important:** we do **not** implement this in the first phase. We design the internal expansion pipeline so that adding proc macros later is a new `MacroKind` variant, not a rewrite.

## 7. Implementation phases

### Phase 1 — Attribute and derive macros (declarative)

Goal: user-defined attribute and derive macros using the same `macro { ... }` syntax.

- [x] Extend `MacroKind` and `MacroRule` with attribute/derive rule kinds.
- [x] Extend parser to parse `attr()(...)` and `derive()(...)` rules.
- [ ] Add `ItemKind::MacroInvocation` and support expansion at item position. (deferred to Phase 3)
- [x] Implement attribute macro expansion in `MacroExpander`.
- [x] Implement derive macro expansion and side-item insertion.
- [x] Apply attributes outer-to-inner on items (`Annotatable` wrapper deferred to Phase 3).
- [x] Tests for attribute/derive macros, ordering, multiple attributes, multiple derives, user derives overriding built-in derives, unknown attribute preservation.
- [x] Update design doc checklist.

**Phase 1 completion notes (2026-07-15):**
- Implemented in `yelang-macro/src/matcher/types.rs`, `parser.rs`, `engine.rs`, and `expander.rs`.
- Parser recognizes `attr(<args-matcher>)(<item-matcher>) => { ... }` and `derive()(<item-matcher>) => { ... }` rules.
- `MacroRule` carries `kind` and `attr_args`; attribute/derive matching reuses the same matcher engine as function-like macros.
- Attribute macros receive the annotated item with the expanding attribute removed but remaining attributes still attached; unknown attributes are preserved.
- Derive macros expand each trait name, preferring a user-defined macro over the built-in derive of the same name, and generate side items next to the original item.
- A codegen fix in `yelang-ast/src/codegen/items_core.rs` ensures `@`-style attributes are separated from the following keyword so stacked attribute macros tokenize correctly.
- 42 integration tests in `yelang-macro/tests/declarative_macros_exhaustive.rs` cover function-like, attribute, and derive macros including edge cases (stacked attrs, nested generated attrs, modules, enums, mixed user/builtin derives, unknown derive errors).

### Phase 2 — Follow sets, metavariable expressions, trailing separators

Goal: make the matcher/transcriber as capable as modern `macro_rules!`.

- [x] Implement follow-set validation table.
- [x] Report follow-set violations at macro definition time and match time.
- [x] Support trailing separators in `*`/`+` repetitions.
- [x] Implement `$$`, `${count($x)}`, `${index()}`, `${len()}`, `${ignore($x)}`.
- [x] Add exhaustive tests for metavariable expressions.

**Phase 2 completion notes (2026-07-15):**
- Implemented in `yelang-macro/src/matcher/follow.rs`, `yelang-macro/src/matcher/parser.rs`, and `yelang-macro/src/transcribe.rs`.
- Follow-set validation uses modern Rust 2021+ sets (e.g., `pat` excludes `|`) and enforces the three matcher invariants at definition time.
- Trailing separators are accepted implicitly for `*`/`+` repetitions with a separator; `?` remains separator-free.
- Metavariable expressions use outward-depth counting: `index`/`len` count outward from inner-most, `count` counts outward from outermost (depth 0 = outermost layer); the no-argument `count` form returns total leaf captures.
- 35 integration tests in `yelang-macro/tests/declarative_macros_phase2.rs` plus new unit tests cover follow sets, trailing separators, and metavariable expressions including nested repetitions.

### Phase 3 — Expansion in all positions

Goal: macros can appear anywhere a fragment can be produced.

- [x] Add `ItemKind::MacroInvocation` and expand item-position macros.
- [x] Add `StmtKind::MacroInvocation` and expand statement-position macros.
- [x] Add `TypeKind::MacroInvocation` and expand type-position macros.
- [x] Add `PatternKind::MacroInvocation` and expand pattern-position macros.
- [ ] Add field-position macro invocation.
- [x] Ensure hygiene and loop detection work across all positions.
- [x] Add tests for expression, statement, item, type, and pattern positions.

**Phase 3 completion notes:**
- `ItemKind::MacroInvocation` was added earlier; item-position macros expand to one or more items via `parse_items_from_token_stream`.
- `TypeKind::MacroInvocation` and `PatternKind::MacroInvocation` were added and expanded via dedicated fragment re-parsers.
- `StmtKind::MacroInvocation` was added in the most recent work; `foo! { ... }` at statement position expands to statements/items/multiple statements while `foo!()` / `foo![]` remain expression macros per RFC 378.
- Field-position macro invocation remains the one unimplemented position.

### Phase 4 — Hygiene hardening

Goal: make hygiene robust and diagnostics useful across all macro positions.

- [x] Implement indirect recursion detection using a visited set per expansion path.
- [x] Add `$crate` / `$package` token support.
- [ ] Serialize macro definition context for cross-crate usage (deferred until crate loader exists).
- [x] Add macro backtraces to diagnostics.
- [x] Add `call_site` / `mixed_site` span kinds for future proc macros (data structures only; explicit syntax deferred).

**Phase 4 completion notes (2026-07-15):**
- `ExpansionFrame { name, span, def_id }` is pushed/popped around every macro expansion in `yelang-macro/src/expander.rs`.
- Indirect recursion is detected by checking whether the macro's `MacroDefId` is already on the stack, catching cycles like `a! → b! → a!`.
- `ExpandError` carries a `Vec<BacktraceFrame>` cloned from the expansion stack; error messages include the macro chain.
- `yelang-lexer/src/tokenizer/ident.rs` parses `$crate` and `$package` as single identifiers with `IdentOrigin::Crate` / `Package`.
- `yelang-macro/src/transcribe.rs` plumbs the defining crate id through to generated `$crate` / `$package` tokens.
- `yelang-resolve/src/path.rs` resolves paths whose first segment has `IdentOrigin::Crate` from the macro's defining crate root.
- `Transparency::Opaque` / `Transparent` / `Mixed` variants are defined in `yelang-macro-core/src/id.rs` for future proc-macro use; declarative macros remain `Opaque` by default.
- 6 new integration tests in `yelang-macro/tests/declarative_macros_hygiene.rs` cover direct recursion, indirect recursion, backtraces, unknown-macro backtraces, `$crate`, and `$package`.

### Phase 5 — Built-in eager expansion

Goal: `concat!`, `concat_bytes!`, `stringify!`, `include!`, `include_str!`, `include_bytes!`, `env!`, `option_env!`, `compile_error!`, `cfg!` work and are fully integrated into the declarative macro pipeline.

- [x] Implement eager expansion for built-ins that require literal arguments.
- [x] Add file-loading built-ins (`include_str!`, `include_bytes!`).
- [x] Add environment builtins (`env!`, `option_env!`).
- [x] Add `compile_error!` and `cfg!` eager builtins.
- [x] Tests for nested eager expansion.

**Phase 5 completion notes (2026-07-15):**
- Implemented in `yelang-macro/src/eager.rs` and wired into `yelang-macro/src/expander.rs`.
- `FileLoader` and `EnvProvider` traits abstract file-system and environment access; `StdFileLoader`/`StdEnvProvider` provide real OS behavior, while `MemoryFileLoader`/`MemoryEnvProvider` make tests deterministic and hermetic.
- `EagerContext` carries the interner, loaders, current file path, and cfg options through expansion.
- `EagerBuiltin` enumerates all supported builtins and dispatches by macro path (unqualified or qualified).
- `expand_eager_macros_in_stream` recursively walks token trees, detects `path!(...)` invocations, expands them, and re-expands the result so nested builtins such as `include!(concat!(env!("OUT_DIR"), "/generated.ye"))` resolve fully.
- A recursion guard on `include!` detects direct self-inclusion and returns a clear error.
- The expander calls eager expansion before parsing captured `expr`, `ty`, `pat`, and `stmt` fragments, so declarative macros can capture eager-builtin output as ordinary fragments.
- `include!` returns a token stream; `include_str!` and `include_bytes!` return string/byte-array literals; `option_env!` returns `Some("value")` or `None`; `compile_error!` turns its message into an `ExpandError` with a full macro backtrace.
- 22 integration tests in `yelang-macro/tests/declarative_macros_phase5.rs` cover all builtins, mixed literals, error cases, nested expansion, item-position includes, and deterministic file/env providers.

### Phase 6 — Fragment fields and unsafe rules

Goal: complete the advanced declarative macro features introduced in RFCs 3714 and 3715, and close the remaining expansion-position gap (field-position macros).

- [x] Implement fragment field access in transcriber (`$field.name`, `$field.type`, etc.).
- [x] Implement `unsafe attr()` and `unsafe derive()` rules.
- [x] Implement macro expansion at field position (struct literals, struct patterns, field definitions).
- [x] Tests for fragment fields, unsafe rule opt-in, and field-position expansion.

#### 6.1 Fragment fields

RFC 3714 allows a declarative macro to access parsed components of a captured fragment without forcing the author to re-match the token tree manually. Example:

```yelang
macro field_count {
    derive()(struct $name:ident { $( $field:ident : $ty:ty ),* }) => {
        impl $name {
            const FIELD_COUNT: usize = ${count($field)};
        }
    };
}
```

With fragment fields we can also write:

```yelang
macro getter {
    ($field:ident) => {
        fn $field.name(&self) -> i32 { 0 }
    };
}
```

Implemented accessors (by fragment kind):

| Fragment kind | Accessor | Returns | Example |
|---------------|----------|---------|---------|
| `ident` | `.name` | token tree of the identifier | `$field.name` → `foo` |
| `expr` | `.type` / `.ty` | type annotation token tree, if any | `$e.type` → `i32` |
| `ty` | `.name` / `.type_name` / `.typename` | base type identifier | `$ty.name` → `Vec` |
| `ty` | `.args` / `.type_args` / `.typeargs` | generic args token tree | `$ty.args` → `<i32>` |
| `item` | `.vis` / `.visibility` | visibility | `$item.vis` → `pub` |
| `item` | `.name` / `.item_name` | item name | `$item.name` → `Foo` |
| `item` | `.attrs` / `.attributes` | attributes token tree | `$item.attrs` |

Design decisions:

- Fragment fields are **syntactic**, not semantic. They expose the tokens the fragment parser already consumed, not a fully typed AST.
- Accessors return a `TokenStream` (or `Option<TokenStream>` when the component may be absent) so they can be spliced directly into transcribers.
- The matcher extracts sub-components after parsing the fragment; the transcriber references them via a dotted metavariable syntax.
- We do **not** expose arbitrary AST introspection in declarative macros; that belongs to proc macros / comptime.

#### 6.2 Unsafe attribute and derive rules

RFC 3715 allows macros to declare that they can cause undefined behavior if misused. Such rules require an explicit `unsafe` opt-in at the invocation site.

```yelang
macro FromBytes {
    unsafe derive()(struct $name:ident $_:tt) => {
        impl $name {
            const FROM_BYTES: bool = true;
        }
    };
}
```

Invocation:

```yelang
@derive(unsafe(FromBytes))
struct Packet { ... }
```

or Rust-style:

```yelang
#[derive(unsafe(FromBytes))]
struct Packet { ... }
```

Rules:

- A rule marked `unsafe attr()` or `unsafe derive()` can only match an invocation that explicitly uses `unsafe(...)`.
- Omitting `unsafe` for such a rule produces a clear error: "attribute macro `Name` has only unsafe rules; use `#[unsafe(Name(...))]`".
- A safe rule invoked with `unsafe(...)` is accepted but warned about as unnecessary.
- Function-like macro rules cannot be `unsafe`.

#### 6.3 Field-position macro expansion

Macros now expand at expression, statement, item, type, pattern, and field positions. Supported field-position sites:

- Struct literal field values: `Foo { x: mac!() }`.
- Struct pattern field values: `let Foo { x: mac!() } = ...`.
- Struct/enum field-definition types: `struct Foo { x: mac!() }`, `enum E { V(mac!()) }`.
- Array type sizes: `[T; mac!()]`.
- Generic arguments: `Foo<mac!()>`.

Field *names* remain identifiers today (`self.mac!()` or `Foo { mac!(): 1 }` are not supported). This matches Rust's restrictions and avoids invasive AST changes for a niche case.

#### 6.4 File tree

```
yelang-macro/src/
  matcher/
    types.rs            # FragmentFields struct
    fragment_fields.rs  # extract components from ident/expr/ty/item fragments
    bindings.rs         # Binding::expect_field lookup
    parser.rs           # parse `unsafe attr()` / `unsafe derive()` rule prefixes
  transcribe.rs         # resolve `$ident.name`, `$expr.type`, etc.
  expander.rs           # enforce unsafe opt-in; expand field-position macros

yelang-ast/src/
  expr/struct_expr.rs   # already supports MacroInvocation in field values
  pattern/types.rs      # already supports MacroInvocation in field patterns
  item/struct_.rs       # already supports MacroInvocation in field types

yelang-macro/tests/
  declarative_macros_phase6.rs  # fragment fields + unsafe rules + field position
```

#### 6.5 Checklist

See `notes/architectures/macro_system_phase6_checklist.md`.

**Phase 6 completion notes (2026-07-15):**
- Implemented fragment field extraction in `yelang-macro/src/matcher/fragment_fields.rs` and lookup in `yelang-macro/src/matcher/bindings.rs`.
- Added `TranscriberOp::FragmentField` and parsing of `$name.field` in `yelang-macro/src/matcher/parser.rs`.
- Unsafe attribute/derive rules parsed in `yelang-macro/src/matcher/parser.rs`; opt-in enforced in `yelang-macro/src/expander.rs`.
- `yelang-ast/src/item/attribute.rs` parses `unsafe` and `derive` attribute args as `Vec<Expr>` so `@derive(unsafe(Name))` and `@unsafe(name(args))` work.
- Field-position expansion reuses existing `MacroInvocation` support in `Expr`, `Pattern`, and `Type`; `MacroExpander` recurses into struct literals, struct patterns, field definitions, enum variants, array sizes, and generic arguments.
- 18 integration tests in `yelang-macro/tests/declarative_macros_phase6.rs` plus unit tests in `yelang-macro/src/matcher/fragment_fields.rs`.
- Workspace tests pass.

### Phase 7 — Procedural macro framework

Goal: allow external crates to define function-like, attribute, and derive macros in Yelang itself using a stable token-stream API, without the legacy `proc-macro2` / `syn` / `quote` dependency stack.

- [ ] Design stable `yelang-proc-macro` API.
- [ ] Implement `yelang-macro-server` bridge that loads proc-macro crates and converts between stable and internal token trees.
- [ ] Support `#[proc_macro]`, `#[proc_macro_attribute]`, `#[proc_macro_derive]`.
- [ ] Implement cross-crate build ordering so proc-macro crates compile before their dependents.
- [ ] Test with a sample external macro crate.

#### 7.1 Why not copy Rust's legacy proc-macro stack

Rust's historical path forced every derive macro into a separate crate depending on `proc-macro2`, `syn`, and `quote`. This created build-time regressions, version lock-in, and a stable-ABI tax converting between `rustc_ast::tokenstream` and `proc_macro::TokenStream`. RFCs 3697/3698 exist because most real-world derives are simple token transforms that do not need a full parser.

Our greenfield design:

- **Declarative attribute/derive macros are first-class.** They cover the common cases without external dependencies.
- **Proc macros are reserved for cases declarative macros cannot express** (arbitrary parsing, custom diagnostics, foreign codegen).
- **The internal token-tree representation stays internal.** We expose a stable API crate (`yelang-proc-macro`) only to macro authors; the compiler never uses it internally.
- **No `proc-macro2` clone.** The stable API is intentionally small: `TokenStream`, `TokenTree`, `Group`, `Punct`, `Ident`, `Literal`, and span/hygiene accessors.

#### 7.2 Stable API crate (`yelang-proc-macro`)

New crate at `yelang-proc-macro/`:

```rust
pub struct TokenStream { ... }
pub enum TokenTree { Group(Group), Ident(Ident), Punct(Punct), Literal(Literal) }
pub struct Group { delimiter: Delimiter, stream: TokenStream, span: Span }
pub struct Ident { sym: Symbol, span: Span, is_raw: bool }
pub struct Punct { ch: char, spacing: Spacing, span: Span }
pub struct Literal { kind: LitKind, symbol: Symbol, suffix: Option<Symbol>, span: Span }
pub struct Span { ... } // opaque, supports equality, join, resolved_at, mixed_site
```

Macro entry points:

```rust
#[proc_macro]
pub fn my_macro(input: TokenStream) -> TokenStream { ... }

#[proc_macro_attribute]
pub fn my_attr(args: TokenStream, item: TokenStream) -> TokenStream { ... }

#[proc_macro_derive(MyDerive)]
pub fn my_derive(item: TokenStream) -> TokenStream { ... }
```

No `proc_macro2::TokenStream` clone; no `quote!` macro inside the API crate (authors can use declarative macros or a future `yelang-quote` crate).

#### 7.3 Macro server bridge

New crate `yelang-macro-server/`:

- Loads compiled proc-macro crates as dynamic libraries (or WASM modules in the future).
- Marshals `yelang_proc_macro::TokenStream` across the boundary.
- Converts stable tokens to/from `yelang-macro-core::token_tree::TokenStream`.
- Caches loaded macros by crate/path.
- Runs proc macros in a separate process or sandbox to isolate crashes.

The compiler's `MacroResolver` treats proc macros as another `MacroKind` variant:

```rust
pub enum MacroKind {
    DeclarativeFunctionLike,
    DeclarativeAttribute,
    DeclarativeDerive,
    ProcFunctionLike,
    ProcAttribute,
    ProcDerive,
}
```

#### 7.4 Cross-crate build ordering

Proc-macro crates are identified by a crate-type attribute or `Cargo.toml` equivalent. The build system must:

1. Compile proc-macro crates before crates that depend on them.
2. Make the compiled artifact (`.so`/`.dll`/`.dylib`) available to the macro server.
3. Re-run proc macros only when the proc-macro crate or its dependencies change.

#### 7.5 Hygiene for proc macros

Proc macros receive tokens with `call_site` spans by default (unhygienic). They can request `mixed_site` or `definition_site` spans via the stable API. Generated identifiers use the span they are constructed with, matching Rust's behavior but without the legacy `Span::call_site()` vs `Span::mixed_site()` confusion.

#### 7.6 File tree

```
yelang-proc-macro/
  src/
    lib.rs            # re-export stable API
    token_stream.rs   # TokenStream, TokenTree, Group, Ident, Punct, Literal
    span.rs           # opaque Span with hygiene accessors
    diagnostic.rs     # Diagnostic, Level, SpanLabel

yelang-macro-server/
  src/
    lib.rs            # server lifecycle
    loader.rs         # dynamic library loading
    bridge.rs         # token conversion stable <-> internal
    client.rs         # RPC to macro server process

yelang-macro/src/
  resolver.rs         # resolve proc-macro crate paths
  expander.rs         # dispatch ProcFunctionLike/ProcAttribute/ProcDerive

yelang-macro/tests/
  proc_macro_smoke.rs # NEW: sample proc-macro crate + integration tests
```

#### 7.7 Checklist

See `notes/architectures/macro_system_phase7_checklist.md` (to be created before implementation).

### Phase 8 — Cross-cutting cleanup (post Phase 7)

Goal: polish the macro system so it is production-ready across crates and diagnostics.

- [ ] cfg/cfg_attr integration with attribute expansion.
- [ ] Lint for unreachable macro rules.
- [ ] Lint for ambiguous macro rules at definition time.
- [ ] Lint for transcriber using unbound metavariables.
- [ ] Better "no rule matched" error messages showing the failing token prefix.
- [ ] Serialize macro definition context for cross-crate usage.
- [ ] Cross-crate macro export/import.
- [ ] Source-location macros: `line!`, `column!`, `file!`, `module_path!`.
- [ ] `format_args!` / `const_format_args!` lowering to HIR builtin.

These items are deliberately deferred until the core macro pipeline is complete.

## 8. Testing strategy

Every phase must include:

1. **Unit tests** in the affected module.
2. **Integration tests** in `yelang-macro/tests/`.
3. **Negative tests** for errors (no rule matched, ambiguous, follow-set violation, unsafe misuse).
4. **Hygiene tests** ensuring generated names don't leak.
5. **Cross-position tests** once expansion positions are added.
6. **Roundtrip tests**: macro output re-tokenizes and parses correctly.
7. **Regression tests** for any fixed bugs.

## 9. Open questions to resolve before implementation

1. **Attribute syntax:** Do we use `@name(args)` (current decorator style) or `#[name(args)]` (Rust style), or both? Recommendation: support both, with `@` as the canonical Yelang surface syntax and `#[...]` as an optional compatibility form.
2. **Derive syntax:** `@derive(A, B)` or `#[derive(A, B)]`? Same recommendation.
3. **Macro scoping:** Should macros be visible before definition in the same module (currently yes)? Keep this, but ensure cross-crate imports use proper namespacing.
4. **Proc-macro bridge:** Do we use dynamic libraries, WASM, or compiler plugins? Recommendation: start with dynamic libraries for the host compiler; WASM for sandboxing is a future optimization.
5. **Fragment fields vs full AST introspection:** Do we implement fragment fields only, or do we also expose AST node accessors? Recommendation: fragment fields only for declarative macros; full AST introspection belongs to proc macros / comptime.

## 10. Relation to previous design doc

This document supersedes the scope section of `notes/architectures/macro_layer_design.md`. The foundational decisions in that doc (two token systems, arena/IDs out of scope, `lib.rs`/`mod.rs` re-export-only, no `util` modules) remain valid. This doc extends the checklist and defines the path from "function-like declarative macros work" to "complete macro/metaprogramming system".

## References

- [RFC 3697 — Declarative attribute macros](https://github.com/rust-lang/rfcs/pull/3697)
- [RFC 3698 — Declarative derive macros](https://github.com/rust-lang/rfcs/pull/3698)
- [RFC 3714 — Macro fragment fields](https://github.com/rust-lang/rfcs/pull/3714)
- [RFC 3715 — Unsafe derives and attributes](https://github.com/rust-lang/rfcs/pull/3715)
- [Rust Declarative Macro Improvements (PDF)](https://kangrejos.com/2025/Rust%20Declarative%20Macro%20Improvements:%20A%20Step%20Forward%20for%20Rust%20Macros%20Usability.pdf)
- [Rust Compiler Development Guide — Macro expansion](https://rustc-dev-guide.rust-lang.org/macro-expansion.html)
- [The Little Book of Rust Macros — Metavariable Expressions](https://lukaswirth.dev/tlborm/decl-macros/minutiae/metavar-expr.html)
- [The Little Book of Rust Macros — Hygiene and Spans](https://lukaswirth.dev/tlborm/proc-macros/hygiene.html)
