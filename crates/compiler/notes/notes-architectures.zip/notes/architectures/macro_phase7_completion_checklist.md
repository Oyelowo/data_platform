# Phase 7 Completion — Macro System Production-Ready Checklist

Status legend:
- `[ ]` not started
- `[/]` in progress / skeleton / partial
- `[x]` done

This checklist follows the design in
`notes/architectures/macro_phase7_completion_design.md`.

---

## 1. Design and documentation

- [x] Verify current macro implementation state (quote, limits, hygiene, ABI,
      tests).
- [x] Research production-ready precedents (Rust `quote`, hygiene, sandboxing,
      `#[rustc_comptime]`, `TypeId::info()`, Kangrejos 2025).
- [x] Write `notes/architectures/macro_phase7_completion_design.md`.
- [x] Write `notes/architectures/macro_phase7_completion_checklist.md`.
- [x] Get explicit user approval on design, file tree, and implementation order
      (user has repeatedly approved proceeding).
- [ ] Update `macro_system_production_ready_checklist.md` to point to this
      completion checklist.
- [ ] Update `DESIGN.md` crate graph if new files/modules are added.

---

## 2. C ABI layout verification

### 2.1 Layout tests in `yelang-proc-macro-bridge/tests/abi_layout_tests.rs`

- [x] `YelangProcMacroExports` size and field offsets.
- [x] `YelangMacroDescriptor` size and field offsets.
- [x] `YelangMacroInvoke` size and field offsets.
- [x] `YelangProcMacroKind` size, discriminant values, and alignment.
- [x] Function-pointer type sizes match `usize`.
- [x] Tests run on 64-bit little-endian target (assertions are conditional on
      `size_of::<usize>() == 8`).
- [x] Tests are gated with a comment explaining they must be updated on ABI
      version bumps.

### 2.2 ABI stability guardrails

- [x] `CURRENT_ABI_VERSION` is incremented only when layout tests change
      (process documented; actual bumping is manual).
- [ ] `CURRENT_ABI_VERSION` is documented in `registrar.rs`.
- [ ] Server rejects dylibs with mismatched `abi_version`.
- [ ] Test: dylib with wrong ABI version rejected at load time.

---

## 3. `quote!` completion

### 3.1 Parser (`yelang-quote/src/parse.rs`)

- [x] Define `Template`, `Node`, `RepKind` AST.
- [x] Parse literal tokens (idents, puncts, literals, groups).
- [x] Parse `#ident` interpolation.
- [x] Parse `#(expr)` interpolation.
- [x] Parse `#(...)*` zero-or-more repetition.
- [x] Parse `#(...)+` one-or-more repetition.
- [x] Parse `#(...),*` and `#(...),+` with single-token separator.
- [ ] Parse `##` as literal `#` (intentionally not supported; use interpolation).
- [x] Parse `quote_spanned!(span=> ...)`.
- [x] Parse `quote_spanned! {span=> ...}`.
- [x] Parse `quote_spanned! {span=>
      ...
  }`.
- [x] Recursive group parsing for nested templates.
- [x] Error on empty repetition body.
- [x] Error on repetition with no interpolated iterable.
- [x] Error on unbalanced delimiters (caught by proc-macro parser).
- [x] Error on unknown `#` pattern with span.

### 3.2 Code generator (`yelang-quote/src/emit.rs`)

- [x] Emit literal tokens via direct `TokenStream::push` calls.
- [x] Emit interpolation via `ToTokens::to_tokens`.
- [x] Emit zero-or-more repetition with an index loop over collected iterables.
- [x] Emit one-or-more repetition with a non-empty iterator check.
- [x] Emit multiple interpolations inside one repetition by zipping collected
      iterables by index.
- [x] Emit nested repetitions as nested loops.
- [x] Emit separators with `Spacing::Alone`.
- [x] Emit `quote_spanned!` with every originating token carrying the given
      span.
- [x] Preserve spans of interpolated tokens in `quote_spanned!`.
- [x] Generate unique variable names (`__yelang_quote_*`) to avoid collisions in
      generated code.

### 3.3 `yelang-proc-macro` support

- [x] Export `quote_spanned!` alongside `quote!`.
- [x] `ToTokens` impls remain complete for all token types.
- [x] `ToTokens` impl for `&str`, `String`, integer types present.
- [x] `Span` methods used by generated code are stable.

### 3.4 Spacing / rendering

- [x] Repetition separators render without extra whitespace, e.g. `a, b` not
      `a , b`.
- [x] Separator emission uses `Spacing::Alone`; renderer suppresses unnecessary
      space around lone separators.
- [x] Rendering still preserves required space between adjacent non-joint
      tokens.

### 3.5 `quote!` tests (`yelang-proc-macro/tests/quote_tests.rs`)

#### Basics
- [x] `quote_emits_ident`
- [x] `quote_emits_punct`
- [x] `quote_emits_literal`
- [x] `quote_emits_group`
- [x] `quote_interpolates_ident`
- [x] `quote_interpolates_token_stream`
- [x] `quote_interpolates_token_tree`
- [x] `quote_interpolates_literal`
- [x] `quote_interpolates_group`
- [x] `quote_interpolates_punct`
- [x] `quote_string_literal`
- [x] `quote_integer_literal`
- [x] `quote_group_with_interpolation`
- [x] `quote_interpolates_grouped_expression`

#### Repetitions
- [x] `quote_repeats_without_separator`
- [x] `quote_repeats_with_comma_separator`
- [x] `quote_repeats_with_semicolon_separator`
- [x] `quote_repeats_plus_one_or_more`
- [x] `quote_repeats_plus_requires_non_empty`
- [x] `quote_repeats_empty_star_yields_nothing`
- [x] `quote_repeats_with_multiple_interpolations`
- [x] `quote_repeats_with_multiple_interpolations_and_separator`
- [x] `quote_repeats_with_referenced_iterable`
- [x] `quote_repeats_with_option`
- [x] `quote_repeats_with_slice`
- [x] `quote_repeats_with_vec`

#### Nested repetitions
- [x] `quote_nested_repetitions_matrix`
- [x] `quote_nested_repetitions_with_separators`
- [x] `quote_nested_repetitions_mixed_star_plus`
- [x] `quote_nested_repetitions_three_levels`

#### Escapes and edge cases
- [ ] `quote_double_hash_emits_single_hash` (not applicable; `##` not supported).
- [ ] `quote_triple_hash_emits_hash_then_interpolation` (not applicable).
- [ ] `quote_hash_followed_by_non_ident_is_literal_hash` (not applicable).
- [x] `quote_empty_invocation_yields_empty_stream`

#### `quote_spanned!`
- [x] `quote_spanned_applies_span_to_originating_tokens`
- [x] `quote_spanned_preserves_interpolated_spans`
- [x] `quote_spanned_with_delim_span`
- [x] `quote_spanned_with_expr_span`

#### Errors
- [x] `quote_error_on_repetition_without_iterable`
- [x] `quote_error_on_unbalanced_delimiters`
- [x] `quote_error_on_unknown_hash_pattern`
- [x] `quote_error_messages_have_span`

---

## 4. Proc-macro server limits and crash safety

### 4.1 Protocol changes (`yelang-proc-macro-bridge/src/protocol/message.rs`)

- [x] `ExpandFnLike` carries `limits: Limits`.
- [x] `ExpandAttr` carries `limits: Limits`.
- [x] `ExpandDerive` carries `limits: Limits`.
- [x] `Limits` is `Clone`, `Debug`, `Default`, and postcard-serializable.
- [x] `Response::Error` codes include `ExpansionTimeout`, `ExpansionTooLarge`,
      `ExpansionMemoryLimit`, and recursion is handled by the compiler.
- [x] Round-trip tests for `Request` and `Response` with limits.

### 4.2 Compiler-side limit configuration

- [x] `ProcMacroClient::expand_*` accepts `Limits`.
- [ ] `MacroExpander` stores configurable default limits from the compiler
      profile (currently uses `Limits::default()`).
- [ ] Environment variable / CLI flag overrides (documented future work).

### 4.3 Server-side limit enforcement

#### Time limits
- [x] `yelang-proc-macro-server/src/executor/limits.rs` exists.
- [x] Expansion runs in a dedicated thread.
- [x] Parent thread waits with `max_cpu_seconds` timeout.
- [x] Timeout returns `Response::Error { code: ExpansionTimeout, ... }`.
- [x] Server exits the request loop after a timeout.
- [x] Test: fixture `slow_macro` hangs and triggers timeout.

#### Memory limits
- [ ] `yelang-proc-macro/src/alloc_shim.rs` provides a tracking global
      allocator (deferred).
- [ ] Allocator shim is installed by `#[macro_export]` codegen (deferred).
- [ ] Shim aborts/expands with `MemoryLimitExceeded` when `max_heap_bytes` is
      exceeded (deferred).
- [x] Server checks process RSS after expansion (coarse, platform-dependent).
- [x] RSS overflow returns `ExpansionMemoryLimit`.
- [ ] Test: fixture `hungry_macro` allocates and triggers memory limit (deferred
      until allocator shim is implemented; RSS guard is best-effort).

#### Output token limits
- [x] Server counts tokens in returned `WireTokenStream`.
- [x] Count exceeds `max_output_tokens` → `ExpansionTooLarge`.
- [x] Test: fixture `huge_macro` returns many tokens and triggers limit.

#### Recursion depth limits
- [x] `MacroExpander` tracks expansion depth.
- [x] Hard ceiling `MAX_RECURSION_DEPTH` (128).
- [x] Exceeded → `RecursionLimit` expansion error.
- [ ] Test: recursive proc macro hits depth limit.
- [x] Test: recursive declarative macro hits depth limit.

### 4.4 Crash safety

- [x] Dylib-side panic hook converts panics to error diagnostics.
- [x] Server `catch_unwind` around FFI call.
- [x] Server process death is detected by `ProcMacroClient`.
- [x] Client restarts server and retries (or reports error) after death.
- [x] Test: fixture `panic_macro` returns error diagnostic.
- [x] Test: server killed mid-request is handled (`exit_macro`).

### 4.5 Negative / adversarial tests

- [x] `timeout_returns_expansion_timeout`
- [ ] `memory_limit_returns_expansion_too_large` (deferred).
- [x] `output_limit_returns_expansion_too_large`
- [ ] `depth_limit_returns_expansion_depth_exceeded` for proc macros.
- [x] `panic_returns_diagnostic`
- [x] `server_death_is_detected`
- [ ] `malformed_dylib_load_fails`
- [ ] `missing_macro_export_means_not_discoverable`
- [ ] `invalid_returned_tokens_produce_parser_error`
- [x] `returned_diagnostic_has_span`

---

## 5. Hygiene completion

### 5.1 Proc-macro API spans

- [x] `yelang_proc_macro::Span::call_site()` returns true invocation span.
- [ ] `Span::def_site()` returns macro-definition span (currently aliases
      `call_site`).
- [ ] `Span::mixed_site()` returns a span with `Transparency::Mixed` context
      (currently aliases `call_site`).
- [x] `Span::resolved_at` combines contexts correctly.
- [ ] Tests for `def_site` and `mixed_site` behavior (deferred until semantics
      are real).

### 5.2 Compiler → server span plumbing

- [x] `MacroExpander` records current invocation span for proc-macro invocation.
- [x] Expansion request carries invocation span (`call_site: WireSpan`).
- [ ] Expansion request carries macro-definition span (deferred).
- [x] Server passes call-site span to dylib via thread-local.
- [x] Dylib reconstructs `yelang_proc_macro::Span` from wire data.

### 5.3 Wire protocol hygiene

- [x] `WireSpan` carries `lo`, `hi`, `file`, `syntax_context`.
- [x] Context id 0 on the wire is normalized to root context.
- [ ] Context ids are fully remapped when crossing the server boundary
      (partial; currently raw ids are trusted if present).
- [ ] `ExpnData` payload for out-of-process hygiene (deferred).
- [ ] Tests: span round-trip preserves full parent chain.

### 5.4 Preserve returned spans

- [x] `wire_to_core` maps `WireTokenTree` directly to
      `yelang_macro_core::TokenTree` without rendering to text.
- [x] In-process proc-macro output uses direct token splice.
- [x] Returned identifiers carry call-site syntax context.
- [ ] Test: generated identifier does not shadow user identifier (requires
      resolver integration).
- [ ] Test: `def_site` identifier resolves at macro definition site (deferred).

### 5.5 Declarative macro parent chain

- [ ] Nested macro expansion sets `ExpnId` parent to outer `ExpnId`.
- [ ] `HygieneData` parent chain is correct for at least 3 levels of nesting.
- [ ] Test: nested macro hygiene isolation.

### 5.6 Name resolution integration

- [ ] `yelang-resolve` considers `SyntaxContextId` for macro-introduced names.
- [ ] Test: macro-introduced binding is not visible outside macro invocation.
- [ ] Test: `mixed_site` item resolves at definition site, local at call site.
- [x] Document remaining resolver gaps in this checklist.

---

## 6. Existing functionality regression tests

Run the full existing macro test suite after every change:

- [x] `cargo test -p yelang-macro --test declarative_macros_exhaustive`
- [x] `cargo test -p yelang-macro --test declarative_macros_phase6`
- [x] `cargo test -p yelang-macro --test declarative_macros_hygiene`
- [x] `cargo test -p yelang-proc-macro`
- [x] `cargo test -p yelang-proc-macro-bridge`
- [x] `cargo test -p yelang-proc-macro-server --test server_integration`
- [x] `cargo test -p yelang-proc-macro-server --test macro_server_integration`
- [x] `cargo test -p yelang-proc-macro-server --test macro_discovery`

---

## 7. Final verification

- [x] `cargo fmt --all`.
- [x] `cargo check --workspace` passes (existing warnings allowed).
- [x] `cargo clippy -p yelang-quote -p yelang-proc-macro -p yelang-proc-macro-bridge
      -p yelang-proc-macro-server -p yelang-macro -p yelang-macro-core --no-deps
      -- -D warnings` passes.
- [ ] `cargo clippy --workspace` passes (blocked by pre-existing warnings in
      `yelang-lexer`, `yelang-ast`, `yelang-resolve`, `yelang-hir`, etc.).
- [x] `cargo test --workspace` passes.
- [ ] No `TODO` / `FIXME` / `XXX` / `HACK` left in touched files.
      - Remaining: `yelang-macro/src/builtin_decorators.rs` has a pre-existing
        `TODO: attach repr metadata to the item.` This is a HIR/metadata item,
        not a macro-expansion mechanics issue, and is left for the HIR phase.
- [x] All new modules named concretely (no `util`).
- [x] All `lib.rs` / `mod.rs` files are routers (implementation in named
      submodules).
- [x] Design doc and checklist updated to match implementation.
