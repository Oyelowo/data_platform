# Phase 8 hygiene checklist

This file tracks the concrete implementation and test cases for Phase 8.
Each item must be implemented and verified before the phase is considered complete.

## 8.1 Span-preserving macro-output parser (`yelang-macro/src/parse_macro_output.rs`)

- [ ] Module created with `parse_macro_output` public entry point.
- [ ] `ParseMacroOutputError` enum with helpful variants.
- [ ] Identifier conversion:
  - [ ] Non-keyword identifiers -> `TokenKind::Ident`.
  - [ ] Keyword identifiers -> correct `TokenKind` variant.
  - [ ] `$crate`/`$package` origins preserved.
- [ ] Literal conversion for all `LitKind` variants:
  - [ ] `Int`
  - [ ] `Float`
  - [ ] `Str` (normal + raw)
  - [ ] `Char`
  - [ ] `Bool`
  - [ ] `ByteStr` (normal + raw)
  - [ ] `Byte`
- [ ] Group conversion:
  - [ ] `Parenthesis` -> `OpenParen` / `CloseParen`.
  - [ ] `Brace` -> `OpenBrace` / `CloseBrace`.
  - [ ] `Bracket` -> `OpenBracket` / `CloseBracket`.
  - [ ] `None` -> no delimiter tokens (just inner tokens).
- [ ] Compound-operator combination:
  - [ ] Three-character: `..=`, `<<=`, `>>=`, `<->`.
  - [ ] Two-character: `==`, `&&`, `->`, `..`, `<-`, `<=`, `>=`, `=>`, `::`, `+=`, `-=`, `*=`, `/=`, `%=`, `^=`, `&=`, `|=`, `!=`.
  - [ ] `||` intentionally left as two `Pipe` tokens.
- [ ] Lifetime combination: `'` + `Ident` -> `TokenKind::Lifetime`.
- [ ] Span preservation: every output token carries the original `yelang_macro_core::Span` converted to `yelang_lexer::Span`, including `syntax_context`.
- [ ] Replace render-and-tokenize in:
  - [ ] `parse_items_from_token_stream`
  - [ ] `parse_stmts_from_token_stream`
  - [ ] `parse_expr_from_token_stream`
  - [ ] `parse_type_from_token_stream`
  - [ ] `parse_pattern_from_token_stream`
- [ ] Delete or deprecate the local-interner clone hack in those helpers.

### Parser tests

- [ ] Single identifier round-trips text and context.
- [ ] Keyword identifier maps to keyword token kind.
- [ ] Integer literal preserves value and context.
- [ ] String literal preserves kind and context.
- [ ] Group `(a + b)` emits correct delimiters.
- [ ] Compound operator `+=` emits single token.
- [ ] `||` emits two tokens.
- [ ] Lifetime `'a` emits `Lifetime`.
- [ ] Unknown punctuation returns error, not panic.
- [ ] Empty stream returns empty token stream.
- [ ] Full token stream compared against real tokenizer output for a representative sample.

## 8.2 Declarative macro transparency

- [ ] `transcribe_rule` uses `Transparency::Mixed`.
- [ ] Unit tests updated.
- [ ] Expander test: generated local binding does not capture call-site local.
- [ ] Expander test: generated item is visible outside the macro.
- [ ] Expander test: captured identifier resolves at call site.

## 8.3 Hygiene-aware resolver

- [ ] `resolve_crate` accepts `Option<&HygieneData>`.
- [ ] `Rib` stores `(syntax_context, Resolution)` bindings.
- [ ] `Rib::insert` takes `syntax_context`.
- [ ] `ModuleTree` stores `(DefId, syntax_context)` for items.
- [ ] `yelang-resolve/src/hygiene.rs` exists with `is_visible`.
- [ ] `Resolver::resolve_name_with_context` implemented.
- [ ] All identifier lookups pass `ident.span.syntax_context()`.
- [ ] `def_collector.rs` records syntax context.
- [ ] Fallback behavior when `HygieneData` is `None` (exact match / root).

### Resolver tests

- [ ] Same context resolves.
- [ ] Root binding resolves from root context.
- [ ] Opaque mark blocks local binding resolution from outside.
- [ ] Opaque mark blocks item resolution from outside.
- [ ] Transparent mark allows resolution from outside.
- [ ] Mixed mark blocks local binding but allows item resolution.
- [ ] Captured identifier (call-site context) resolves to call-site binding even inside macro output.
- [ ] Missing context data fails closed (no resolution).
- [ ] Deeply nested contexts walk correctly.

## 8.4 Integration / end-to-end tests

- [ ] Macro `let` hygiene: no collision.
- [ ] Macro item visibility: generated `fn` callable.
- [ ] Nested declarative macros produce chained contexts.
- [ ] Proc-macro `call_site` token resolves to call-site binding.
- [ ] Proc-macro `def_site` token does not resolve to call-site local.

## 8.5 Verification

- [ ] `cargo fmt --all`
- [ ] `cargo test --workspace`
- [ ] `cargo clippy -p yelang-macro -p yelang-resolve -p yelang-macro-core -p yelang-lexer -p yelang-ast`
- [ ] Design doc updated if assumptions changed.
