# Yelang Macro System — Phase 7 Completion Design

**Status:** Chunk 3 (server limits, crash safety, C ABI verification,
`quote!` rewrite, and proc-macro span plumbing) is landed and tested.
Chunk 4 (full hygiene semantics) and Chunk 5 (remaining negative tests) are
still open.  
**Scope:** finish the existing declarative + procedural macro subsystem to a
production-ready, battle-tested state.  
**Explicitly out of scope:** `comptime` / introspection (Phase 8), HIR/type-system
ID migration, and any language features beyond macros.

This document is based on the current Yelang codebase, the Rust `quote` crate
implementation, Rust proc-macro hygiene and server designs, the Rust
`#[rustc_comptime]` / `TypeId::info()` reflection work, and the Kangrejos 2025
declarative-macro paper. Nothing here is considered implemented unless marked
`[implemented]`.

---

## 1. Goals

1. Make `quote!` feature-complete and robust.
2. Make the proc-macro server enforce resource limits and crash safely.
3. Make hygiene correct end-to-end for both declarative and procedural macros.
4. Make the C ABI stable and verifiable.
5. Make the test matrix exhaustive, including adversarial and negative cases.
6. Leave no stubbed code paths that silently degrade behavior.

---

## 2. Current gaps (verified against the codebase)

### 2.1 `quote!` (`yelang-quote` + `yelang-proc-macro`)

- `[x]` Literal tokens, `#ident` interpolation, `#(...)*`, `#(...),*`.
- `[x]` `#(...)+` one-or-more repetition.
- `[x]` Multiple interpolations inside one repetition, e.g. `#(#name = #value),*`.
- `[x]` Repetitions use `.iter()` so the same collection can participate in
  nested repetitions without being consumed.
- `[x]` `quote_spanned!(span=> ...)`.
- `[x]` Exhaustive quote tests in `yelang-proc-macro/tests/quote_tests.rs`.
- `[x]` Nested repetitions (e.g. `#(#(#row),*);*`) are supported.
- `[ ]` True matrix-style repetitions where an inner repetition iterates over a
  variable bound by an outer repetition require loop-variable plumbing and are
  not yet supported.
- `[x]` Literal `#` is emitted by interpolating a `Punct` value; a `##` escape
  is intentionally not provided because it adds parser complexity for a case
  that is trivially handled by interpolation.

### 2.2 Proc-macro server limits / sandboxing

- `[x]` `Limits` is `Serialize`/`Deserialize` and carried by every `Request::Expand*`.
- `[x]` Per-expansion CPU time limit enforced via a worker thread + timeout.
- `[x]` Per-expansion output-token limit enforced after deserialization.
- `[x]` Coarse resident-set-size guard enforced after expansion (Linux `/proc/self/statm`,
  macOS `getrusage`).
- `[x]` Server exits after a timeout so a hanging worker cannot starve future requests.
- `[x]` `ProcMacroClient` detects server death and can restart the server.
- `[ ]` Dylib-side allocator shim for precise memory accounting (deferred; documented gap).
- `[ ]` Filesystem / network sandboxing (deferred; documented gap).

### 2.3 Hygiene

- `[x]` Core data structures exist (`Span`, `SyntaxContextId`, `ExpnId`,
  `HygieneData`, `Transparency`).
- `[x]` Declarative macro expansion creates a fresh syntax context.
- `[x]` Procedural macro output is now spliced directly into core token trees,
  preserving `SyntaxContextId` per token instead of re-tokenizing from text.
- `[x]` The macro invocation span (file + offsets) is sent to the server and
  exposed through `Span::call_site()`.
- `[ ]` `Span::def_site()` and `Span::mixed_site()` are still aliases for
  `call_site()`; real definition-site / mixed transparency requires passing the
  macro definition span and `ExpnData` across the wire.
- `[ ]` The wire protocol transports raw `syntax_context` ids; full parent-chain
  `ExpnData` is not yet serialized for out-of-process macros.
- `[ ]` Nested macro expansion always parents new `ExpnId`s to the root context
  rather than the active outer expansion.
- `[ ]` Name resolution does not yet consult syntax contexts.

### 2.4 C ABI

- `[x]` `#[repr(C)]` structs and stable symbol names exist.
- `[x]` Layout tests in `yelang-proc-macro-bridge/tests/abi_layout_tests.rs`
  verify sizes, alignments, and field offsets for `YelangProcMacroExports`,
  `YelangMacroDescriptor`, `YelangMacroInvoke`, and `YelangProcMacroKind`.

### 2.5 Negative tests

- `[x]` Server timeout produces `ExpansionTimeout` (`fn_like_macro_times_out`).
- `[x]` Oversized output produces `ExpansionTooLarge` (`fn_like_macro_output_limit`).
- `[x]` Server process death is detected and the client restarts
  (`client_detects_server_death_and_restarts`).
- `[x]` Proc-macro panic is reported as a diagnostic (`panic_in_macro_returns_error_diagnostic`).
- `[x]` Macro index out of bounds / wrong kind return `MacroNotFound`.
- `[x]` Recursive declarative expansion hits `MAX_RECURSION_DEPTH`.
- `[ ]` Missing `macro_export` means the macro is not discoverable (depends on
  name-resolution integration).
- `[ ]` Malformed dylib load produces a clear error (partial coverage via
  `load_library_reports_not_found`).
- `[ ]` Returned invalid tokens produce a parser error with span.

---

## 3. Design principles

1. **No legacy.** Because Yelang is greenfield, we adopt the best known design
   immediately rather than carrying Rust's historical workarounds.
2. **lib.rs / mod.rs are routers.** Implementation lives in named submodules.
3. **No `util` modules.** Every module has a concrete name.
4. **SlotMap-style IDs.** Server session handles and hygiene arenas already use
   slotmap; this pattern is preserved.
5. **Exhaustive tests.** Every feature has positive, negative, and adversarial
   tests before it is considered done.
6. **Fail loudly.** A missing feature must produce a clear compile-time or
   runtime error, not silently degrade.
7. **Defense in depth for sandboxing.** Time, memory, output, and crash limits
   are enforced independently.

---

## 4. Lessons from Rust and other sources

| Source | Lesson for Yelang |
|---|---|
| [Rust `quote` crate](https://github.com/dtolnay/quote) | A `quote!` macro can be implemented without `macro_rules` tricks if it is itself a proc-macro. We therefore parse the template into a real AST and generate code, which makes nested repetitions and multiple interpolations straightforward. |
| [Rust `#[rustc_comptime]`](https://github.com/rust-lang/rust/pull/157647) | Compile-time-only functions (`comptime fn`) are the right primitive for reflection intrinsics. This validates keeping `comptime fn` in our Phase 8 design, but it is out of scope here. |
| [Rust `TypeId::info()` reflection MVP](https://github.com/rust-lang/rust/pull/146923) | Reflection should return a rich `Type` struct with a non-exhaustive `kind` enum. We will adopt the same shape for `@typeInfo` in Phase 8. |
| [Rust proc-macro hygiene issues](https://github.com/rust-lang/rust/issues/45934) | `def_site`, `mixed_site`, and `call_site` behavior is subtle. We implement all three correctly from the start rather than retrofitting them. |
| [Little Book of Rust Macros — Hygiene](https://lukaswirth.dev/tlborm/proc-macros/hygiene.html) | `mixed_site` gives `macro_rules!`-like behavior: items resolve at the definition site, local variables/labels at the call site. |
| [Rust internals — sandboxing proc-macros](https://internals.rust-lang.org/t/sandbox-build-rs-and-possibly-proc-macro-by-providing-a-runner-as-env-variable/18172) | True sandboxing eventually requires OS-level isolation or WASM. For the current phase we enforce time/memory/output limits and document the remaining sandbox gap. |
| [Kangrejos 2025 — Declarative Macro Improvements](https://kangrejos.com/2025/Rust%20Declarative%20Macro%20Improvements:%20A%20Step%20Forward%20for%20Rust%20Macros%20Usability.pdf) | Declarative attribute and derive macros should be first-class. Already implemented; only RFC 3714 fragment fields remain partial. |

---

## 5. Detailed designs

### 5.1 Complete `quote!`

#### 5.1.1 Supported surface

```rust
use yelang_proc_macro::{quote, quote_spanned, Ident, TokenStream};

let name: Ident = ...;
let fields: Vec<(Ident, TokenStream)> = ...;
let ts: TokenStream = quote! {
    impl Clone for #name {
        fn clone(&self) -> Self { *self }
    }
};

// Multiple interpolations in one repetition.
let ts = quote! {
    struct #name {
        #(#field_name: #field_ty),*
    }
};

// One-or-more repetition.
let ts = quote! {
    #(#arm)+ else { panic!("no match") }
};

// Nested repetitions.
let matrix: Vec<Vec<Ident>> = ...;
let ts = quote! {
    [ #(#(#row),*);* ]
};

// Emit a literal # by interpolating a Punct.
let hash = Punct::new('#', Spacing::Alone, Span::call_site());
let ts = quote! { count #hash 1 };

// Apply a span to every originating token.
let ts = quote_spanned!(name.span()=> #name: Copy);
```

#### 5.1.2 Design

`yelang-quote` is a proc-macro crate, so we can parse the template with the
full `yelang_proc_macro::parse` machinery rather than the `macro_rules`
context-window technique used by Rust's `quote` crate.

Template AST:

```rust
pub enum Template {
    Literal(TokenTree),
    Interpolate { expr: Expr },
    Repetition {
        body: Vec<Template>,
        separator: Option<Punct>,
        kind: RepKind,          // Star | Plus
    },
}
```

Parsing rules:

- `#ident` or `#(expr)` is interpolation.
- `#(...)*` is zero-or-more repetition.
- `#(...)+` is one-or-more repetition.
- `#(...),*` / `#(...),+` use the single token before `*`/`+` as separator.
- Literal `#` is emitted by interpolating a `Punct` value; there is no `##`
  escape.
- Groups are recursively parsed so nested repetitions and interpolations work
  naturally.
- `quote_spanned!(span=> ...)` parses the span expression, then the template.

Code generation:

- For each interpolation, emit `ToTokens::to_tokens(&expr, &mut __stream);`.
- For a repetition, collect all interpolated identifiers, bind them to local
  iterators with `quote_into_iter`, zip them, and emit the body per element.
  This is similar to Rust's `pounded_var_names` / `RepInterp` approach but
  generated procedurally, so it supports multiple interpolations cleanly.
- For `+`, assert that at least one iterator is non-empty before the loop or
  emit a runtime check.
- For nested repetitions, generate nested loops.
- For `quote_spanned!`, every originating token is emitted with the given span;
  interpolated tokens keep their own spans.

Error handling:

- Parse errors produce `compile_error!` with a span pointing at the `quote!`
  invocation.
- Repetition with no iterable interpolation is a compile error.
- Mismatched delimiters are caught by the parser.

#### 5.1.3 Spacing fix

The current implementation emits separators with `Spacing::Alone`, producing
`"a , b"`. Separators inside a repetition should be emitted as
`Spacing::Alone` but with no extra whitespace when rendered. The renderer in
`yelang-macro-core/src/token_tree/render.rs` must treat a separator punct as
not requiring surrounding space when it is adjacent to a non-punct token.

### 5.2 Proc-macro server limits and crash safety

#### 5.2.1 Threat model

A proc-macro crate is arbitrary native code. It can:

- Infinite loop.
- Allocate unbounded memory.
- Return enormous token streams.
- Crash (panic or abort).
- Access the filesystem or network.

The server must:

- Convert panics into reported errors.
- Enforce configurable time, memory, and output limits.
- Restart cleanly after a crash.
- Prevent a single macro from monopolizing the server.

#### 5.2.2 Limit model

```rust
// yelang-proc-macro-bridge/src/sandbox/limits.rs
pub struct Limits {
    pub max_heap_bytes: usize,   // default 512 MiB
    pub max_cpu_seconds: u64,    // default 30
    pub max_output_tokens: usize,// default 1_000_000
}
```

`Request::ExpandFnLike`, `ExpandAttr`, and `ExpandDerive` carry both `limits:
Limits` and `call_site: WireSpan`. The compiler currently uses
`Limits::default()`; future work can expose profile/command-line overrides.

#### 5.2.3 Time limit

Implemented in `yelang-proc-macro-server/src/executor/limits.rs`:

- Each expansion runs in a dedicated OS thread spawned by `enforce_limits`.
- The parent thread waits on a bounded channel for `max_cpu_seconds`.
- If the timeout fires, the server returns
  `Response::Error { code: ExpansionTimeout, ... }` and exits the request loop,
  terminating the process. The compiler's `ProcMacroClient` reconnects on the
  next expansion.

This is cooperative in the sense that the worker thread is not forcefully
killed, but because the server is a separate process, a hanging macro cannot
hang the compiler.

Future improvement: spawn worker processes with stricter OS-level limits.

#### 5.2.4 Memory limit

Implemented as a server-side guard only for this phase:

- `yelang-proc-macro-server/src/executor/limits.rs` records the process RSS
  after an expansion returns (`current_rss_bytes`).
- If the RSS exceeds `max_heap_bytes`, the server returns
  `Response::Error { code: ExpansionMemoryLimit, ... }`.
- A future phase can add a dylib-side allocator shim for tighter accounting.

#### 5.2.5 Output token limit

After deserializing the returned `WireExpansionResult`, `count_tokens` recurses
through the output stream. If the count exceeds `max_output_tokens`, the server
returns `Response::Error { code: ExpansionTooLarge, ... }`.

#### 5.2.6 Recursion depth limit

`MacroExpander::before_expand` now checks `expansion_stack.len()` against
`MAX_RECURSION_DEPTH` (128) and reports a `RecursionLimit` expansion error when
it is exceeded. This applies to both declarative and procedural macro expansion.

#### 5.2.7 Panic / crash handling

- The dylib-side wrapper in `yelang_proc_macro::bridge::run` catches panics and
  converts them to error diagnostics.
- The server wraps the FFI call in `catch_unwind` as a last resort.
- `ProcMacroClient` maps IO errors on stdin/stdout to `ServerDied`, exposes
  `restart()`, and auto-reconnects via `ensure_alive()` before each request.
- A new fixture macro `exit_macro` terminates the server process; tests verify
  that the client detects the death and restarts successfully.

#### 5.2.8 Filesystem / network sandboxing

For this phase we do not implement a full sandbox. The limits above prevent the
most common denial-of-service attacks. A future phase can add:

- Compilation to WASM for true capability-based sandboxing.
- OS-level seccomp / namespace isolation on Linux.
- A documented `--allow-proc-macro-io` flag.

### 5.3 Complete hygiene

#### 5.3.1 Hygiene semantics

Yelang follows the three-site model:

- `Span::call_site()` — resolves names at the macro invocation site.
- `Span::def_site()` — resolves names at the macro definition site.
- `Span::mixed_site()` — resolves items at the definition site, local
  variables/labels at the call site (like `macro_rules!`).

#### 5.3.2 What changed in this phase

1. **Proc-macro call-site span**
   - `yelang_proc_macro::Span::call_site()` now reads a thread-local span set
     by the server before invoking the macro. The span carries the true
     invocation file + byte offsets.
   - `def_site()` and `mixed_site()` are still aliases for `call_site()`; real
     semantics require plumbing the macro definition span and `ExpnData`.

2. **Compiler ↔ server span plumbing**
   - `Request::Expand*` carries a `call_site: WireSpan`.
   - The server converts this to a public `Span` and sets the thread-local
     value via `set_call_site_from_wire`.

3. **Wire protocol**
   - `WireSpan` carries `lo`, `hi`, `file`, `syntax_context`.
   - Context id 0 on the wire is normalized to the root context (id 1) because
     the internal `Id` type rejects 0.
   - Full `ExpnData` / parent-chain exchange is left for a future phase.

4. **Preserve returned spans**
   - `yelang_proc_macro::TokenStream::into_core_stream_with_interner` maps the
     public token tree directly back to `yelang_macro_core::TokenTree`,
     re-interning symbols in the compilation interner while preserving spans
     and syntax contexts.
   - Both the in-process and out-of-process proc-macro paths use this direct
     splice instead of rendering to text and re-tokenizing.

#### 5.3.3 Remaining hygiene work

- Real `def_site()` / `mixed_site()` semantics.
- Serializing `ExpnData` / parent chains across the server boundary.
- Parenting nested declarative `ExpnId`s to the active outer expansion.
- Integrating `SyntaxContextId` into name resolution.

### 5.4 Stable C ABI verification

Add layout tests in `yelang-proc-macro-bridge/tests/abi_layout_tests.rs`:

```rust
#[test]
fn yelang_proc_macro_exports_layout() {
    assert_eq!(mem::size_of::<YelangProcMacroExports>(), ...);
    assert_eq!(mem::offset_of!(YelangProcMacroExports, abi_version), 0);
    assert_eq!(mem::offset_of!(YelangProcMacroExports, macro_count), 4);
    assert_eq!(mem::offset_of!(YelangProcMacroExports, macros), ...);
    assert_eq!(mem::offset_of!(YelangProcMacroExports, alloc), ...);
    assert_eq!(mem::offset_of!(YelangProcMacroExports, free), ...);
}
```

Also verify the sizes/offsets of `YelangMacroDescriptor`, `YelangMacroInvoke`,
and `YelangProcMacroKind`. These tests prevent accidental ABI breaks when
fields are reordered or target pointer widths change.

### 5.5 Negative tests

| Scenario | Expected behavior |
|---|---|
| Proc-macro function without `#[macro_export]` | Not discoverable; using it is a name-resolution error. |
| Macro exceeding wall-clock limit | `ExpansionTimeout` with the macro name and limit. |
| Macro exceeding heap limit | `ExpansionTooLarge` / `MemoryLimitExceeded`. |
| Macro returning tokens that do not parse | Parser error pointing at the returned span. |
| Macro returning `1_000_001` tokens | `ExpansionTooLarge`. |
| Server process killed mid-expansion | Client restarts server and reports error. |
| Dylib with corrupted descriptor table | `LibraryLoadFailed` with reason. |
| ABI version mismatch | Clear error, no silent fallback. |
| Recursive proc macro beyond depth limit | `ExpansionDepthExceeded`. |

---

## 6. Exhaustive file tree

```text
crates/compiler/
├── yelang-quote/                          # MODIFIED
│   └── src/
│       ├── lib.rs                         # re-exports; router only
│       ├── parse.rs                       # Template parser
│       └── emit.rs                        # Code generator
│
├── yelang-proc-macro/                     # MODIFIED
│   ├── src/
│   │   ├── lib.rs                         # re-exports; router only
│   │   ├── api/
│   │   │   ├── span.rs                    # call_site + resolved_at; def_site/mixed_site stubbed
│   │   │   ├── ident.rs
│   │   │   ├── literal.rs
│   │   │   ├── punct.rs
│   │   │   ├── delimiter.rs
│   │   │   ├── token_tree.rs
│   │   │   ├── token_stream.rs            # into_core_stream_with_interner
│   │   │   ├── diagnostic.rs
│   │   │   └── mod.rs
│   │   ├── bridge/
│   │   │   ├── mod.rs
│   │   │   ├── run.rs                     # panic conversion
│   │   │   └── serialize.rs               # span hygiene round-trip
│   │   ├── parse/
│   │   │   ├── mod.rs
│   │   │   ├── parser.rs
│   │   │   ├── buffered.rs
│   │   │   ├── cursor.rs
│   │   │   └── error.rs
│   │   ├── introspect/                    # token introspection helpers
│   │   │   ├── mod.rs
│   │   │   └── token_walker.rs
│   │   └── to_tokens.rs
│   └── tests/
│       ├── quote_tests.rs                 # 33+ quote!/quote_spanned! cases
│       ├── api_tests.rs
│       ├── parse_tests.rs
│       └── introspect_tests.rs
│
├── yelang-proc-macro-bridge/              # MODIFIED
│   ├── src/
│   │   ├── lib.rs                         # re-exports; router only
│   │   ├── abi/
│   │   │   ├── mod.rs
│   │   │   ├── registrar.rs               # C structs
│   │   │   ├── symbols.rs
│   │   │   └── signature.rs
│   │   ├── protocol/
│   │   │   ├── mod.rs
│   │   │   ├── message.rs                 # Expand* requests carry Limits + call_site
│   │   │   ├── serialize.rs
│   │   │   ├── token.rs
│   │   │   └── version.rs
│   │   └── sandbox/
│   │       ├── mod.rs
│   │       ├── limits.rs                  # Limits struct
│   │       └── error.rs
│   └── tests/
│       ├── abi_layout_tests.rs            # C ABI layout verification
│       └── protocol_tests.rs              # protocol round-trip
│
├── yelang-proc-macro-server/              # MODIFIED
│   ├── src/
│   │   ├── lib.rs                         # re-exports; router only
│   │   ├── main.rs                        # server entry point
│   │   ├── executor/
│   │   │   ├── mod.rs
│   │   │   ├── invoke.rs                  # enforce time + output + memory limits
│   │   │   ├── limits.rs                  # limit enforcement helpers
│   │   │   ├── context.rs                 # per-expansion context
│   │   │   └── panic.rs                   # panic conversion
│   │   ├── protocol/
│   │   │   ├── mod.rs
│   │   │   └── io.rs
│   │   └── server/
│   │       ├── mod.rs
│   │       ├── library.rs                 # dylib loading
│   │       ├── run.rs                     # request loop + error mapping
│   │       └── session.rs                 # slotmap session
│   └── tests/
│       ├── fixtures/
│       │   └── test_macro/
│       │       └── src/lib.rs             # test_macro, slow_macro, huge_macro, exit_macro
│       ├── macro_fixture/
│       │   └── mod.rs
│       ├── server_integration.rs
│       ├── macro_server_integration.rs
│       ├── client_resilience.rs
│       └── macro_discovery.rs
│
├── yelang-macro-core/                     # MODIFIED
│   └── src/
│       ├── lib.rs                         # re-exports; router only
│       ├── id.rs                          # slotmap-based ExpnId / SyntaxContextId
│       ├── hygiene.rs                     # hygiene arena
│       └── token_tree/
│           ├── mod.rs
│           ├── tree.rs
│           ├── stream.rs
│           ├── span.rs
│           ├── ident.rs
│           ├── punct.rs
│           ├── literal.rs
│           ├── render.rs                  # token rendering
│           ├── codegen.rs
│           └── token_id.rs
│
└── yelang-macro/                          # MODIFIED
    └── src/
        ├── lib.rs                         # re-exports; router only
        ├── error.rs
        ├── expander.rs                    # depth limit, span plumbing
        ├── transcribe.rs                  # declarative macro transcription
        ├── eager.rs                       # eager macro expansion (cfg, include, env)
        ├── quote.rs                       # built-in quote!/quote_spanned!
        ├── paste.rs                       # built-in paste!
        ├── builtin_macros.rs              # built-in fn-like macros
        ├── builtin_decorators.rs          # built-in attribute macros
        ├── resolver.rs                    # macro name resolution
        ├── proc_macro/                    # procedural macro subsystem
        │   ├── mod.rs
        │   ├── client.rs                  # server client + restart
        │   ├── expand.rs                  # direct token splice, no re-tokenize
        │   ├── resolver.rs
        │   ├── manifest.rs
        │   ├── discovery.rs
        │   ├── registry.rs
        │   ├── export.rs
        │   └── executor.rs
        └── matcher/                       # declarative macro matcher
            ├── mod.rs
            ├── types.rs
            ├── parser.rs
            ├── engine.rs
            ├── cursor.rs
            ├── bindings.rs
            ├── fragment.rs
            ├── fragment_fields.rs
            └── follow.rs
```

---

## 7. Test strategy

### 7.1 Unit tests

- `yelang-quote`: parse every template shape; verify generated code compiles
  and produces expected token stream.
- `yelang-proc-macro`: `Span` API, `ToTokens`, allocator shim.
- `yelang-proc-macro-bridge`: ABI layout, protocol round-trip, version
  negotiation, limits serialization.
- `yelang-proc-macro-server`: limit enforcement, panic conversion, dylib
  load/unload.

### 7.2 Integration tests

- End-to-end expansion through server for fn-like / attr / derive macros.
- Hygiene: generated names do not collide; `def_site` definitions are
  definition-scoped; `mixed_site` behaves like `macro_rules!`.
- Diagnostics: emitted error reaches user with span.
- Panic recovery.
- Invalid returned tokens.

### 7.3 Negative / adversarial tests

- Timeout macro fixture.
- Memory-hungry macro fixture.
- Huge-output macro fixture.
- Bad-output macro fixture.
- Recursive depth limit.
- Protocol corruption.
- Server death.
- ABI version mismatch.

### 7.4 Required new tests checklist

See `macro_phase7_completion_checklist.md` for the exhaustive list.

---

## 8. Adversarial review

| Attack / failure | Current behavior | Target behavior after this phase |
|---|---|---|
| Infinite loop in proc macro | Hangs server until killed. | Returns `ExpansionTimeout`; server restarts. |
| Unbounded allocation | Can OOM the server host. | Allocator shim + RSS guard catch it; error returned. |
| Huge token stream returned | No limit. | `ExpansionTooLarge` after token count. |
| Deep recursive macro expansion | Depth limit exists? Verify. | Hard ceiling with `ExpansionDepthExceeded`. |
| Panic in proc macro | Caught by dylib/server. | Still caught, plus server restart on crash. |
| Server process death | Compiler may fail. | Client detects and restarts server. |
| Malicious `quote!` template | Parser may loop or ICE. | Fails with span-preserving `compile_error!`. |
| `quote!` with no iterable in repetition | Not handled. | Clear compile error. |
| Hygiene leak across macros | Re-tokenization destroys spans. | Direct splice preserves contexts. |
| `def_site` used as `call_site` | Currently stubbed. | Real semantics. |

---

## 9. Implementation order

1. **`[done]` C ABI layout tests** — prevents accidental breakage.
2. **`[done]` `quote!` rewrite** — real Template AST; multiple interpolations,
   nested repetitions, `quote_spanned!`.
3. **`[done]` Server limits and crash safety** — time, output, memory guards,
   panic conversion, server restart.
4. **`[open]` Hygiene completion** — real `def_site`/`mixed_site`, `ExpnData`
   serialization across wire, nested declarative parent chain, syntax-context
   integration in name resolution.
5. **`[open]` Remaining negative tests** — missing `macro_export`, malformed
   dylib load, invalid returned tokens, ABI version mismatch.
6. **`[open]` Final verification** — `cargo fmt`, `cargo check --workspace`,
   `cargo test --workspace`, adversarial review.

---

## 10. Design checklist (status)

- `[x]` `quote!` implemented with a real Template AST.
- `[x]` `#(...)*`, `#(...)+`, multiple interpolations per repetition, nested
      repetitions, and `quote_spanned!` supported.
- `[ ]` `##` escape intentionally not supported; literal `#` via interpolation.
- `[x]` Server limit model (time, output, memory, recursion) implemented.
- `[ ]` Dylib-side allocator shim for precise memory limits deferred.
- `[x]` Hygiene data structures and call-site plumbing implemented.
- `[ ]` Real `def_site` / `mixed_site` semantics still stubbed.
- `[x]` Direct token splice (no render-and-re-tokenize) for proc-macro output.
- `[x]` C ABI layout tests implemented.
- `[x]` Exhaustive file tree in section 6 matches current source tree.
