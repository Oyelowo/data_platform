# Macro System Phase 3 Design: Macros in Every Position

## Overview

Phase 3 extends the declarative macro system so that macro invocations of the
form `name! { ... }` (or `name!(...)` / `name![...]`) are valid in **type**,
**pattern**, and **item** positions in addition to the expression position that
was already supported. This matches the expressive power of Rust's
`macro_rules!` while keeping the implementation position-agnostic at the parser
level and context-aware during expansion.

## Motivation

- **Type aliases / wrapper types**: `type MyVec<T> = vec_wrapper!(T);`
- **Pattern helpers**: `let some!(x) = opt;`
- **Item generators**: `generate_impls!(Foo);`
- **Composability**: Macros can appear inside generic arguments, function
  signatures, match arms, and modules.

## Syntactic design

A macro invocation is always parsed as a **path immediately followed by `!` and
a single delimited group**. The same rule applies uniformly:

```text
path ! delimiter ... delimiter
```

Examples:

```rust
// Expression position
assert!(true);

// Type position
let x: MyType!() = 1;

// Pattern position
let MyPat!() = value;

// Item position
my_item_macro! { }
```

The parser does **not** try to interpret the contents of the delimited group;
it preserves the raw tokens as a `MacroTokenStream` for the expansion phase.

## AST representation

Each syntactic category that can host a macro invocation gets a new variant:

- `TypeKind::MacroInvocation(MacroInvocation)`
- `PatternKind::MacroInvocation(MacroInvocation)`
- `ItemKind::MacroInvocation(MacroInvocation)`

`MacroInvocation` is already defined in `yelang-ast::expr` and reused across
all three positions:

```rust
pub struct MacroInvocation {
    pub path: Path,
    pub args: MacroTokenStream,
    pub span: Span,
}
```

Sharing the same structure keeps the AST small and avoids duplicating
path/span/argument handling.

## Parser details

### Type position

`parse_type_atom` and `TypeAtom::parse` first try to parse a `Path`. If the
next token is `!`, they consume it and call `parse_macro_args`, producing a
`TypeKind::MacroInvocation`.

### Pattern position

`parse_path_led_pattern` parses an `ExprPath` (which yields a `Path`). Before
considering tuple-struct `(...)` or struct `{...}` continuations, it checks for
`!` and produces a `PatternKind::MacroInvocation`.

### Item position

`ItemKind::parse` handles all keyword-led items first. As a fallback, it
parses a `Path`; if the path is immediately followed by `!`, it consumes the
`!` and `parse_macro_args` and produces an `ItemKind::MacroInvocation`.

## Expansion pipeline

The macro expander operates **iteratively**: expanding a macro may produce new
macro invocations, so the engine loops until the AST stabilizes.

### Expected fragments

When the expander encounters a macro invocation, it knows what syntactic
category the surrounding context expects:

- Expression context → parse result as `Expr`
- Type context → parse result as `Type`
- Pattern context → parse result as `Pattern`
- Item context → parse result as `Vec<Item>`

Built-in macros (e.g. `assert!`, `todo!`, `vec!`) currently only produce
expressions, so they are only tried in expression context. User-defined
function-like macros are tried in every context.

### Expansion helpers

1. `expand_macro_invocation(inv: &MacroInvocation) -> Result<TokenStream, ExpandError>`
   - Resolves the macro name.
   - Matches against function-like rules.
   - Transcribes the matched rule with hygiene.
   - Returns the raw expanded token stream.

2. Fragment re-parsers
   - `parse_expr_from_token_stream`
   - `parse_type_from_token_stream`
   - `parse_pattern_from_token_stream`
   - `parse_items_from_token_stream`

3. Position-specific walkers
   - `expand_type` recursively expands `TypeKind::MacroInvocation` and descends
     into all type constructors.
   - `expand_pattern` recursively expands `PatternKind::MacroInvocation` and
     descends into all pattern constructors.
   - `expand_item_deep` now returns `Vec<Item>` so that an item-position macro
     can expand to multiple items.
   - `expand_fn_sig` expands parameter patterns/types and return types.

### Wiring

- `expand_expr` expands macro invocations and recursively walks into embedded
  types and patterns.
- `expand_stmt` expands `let` patterns and type annotations.
- `expand_item_deep` handles item-position macros and recurses through modules,
  function signatures, struct/enum fields, impl/trait items, etc.

## Hygiene and follow sets

- Hygiene is applied during transcription exactly as in Phase 2.
- `FragmentKind::Stmt` already exists and shares the same follow-set as `Expr`
  (`=>`, `,`, `;`).
- Follow-set validation for `pat`, `ty`, `expr`, and `stmt` prevents ambiguous
  macro rules from being accepted.

## Downstream handling

If a macro invocation cannot be expanded (unknown macro, no matching rule, or
malformed output), the original invocation node is preserved and an error is
recorded. Downstream phases treat these residual nodes gracefully:

- **Name resolution** (`yelang-resolve`) ignores unexpanded macro invocations.
- **HIR lowering** (`yelang-hir`) skips unexpanded item macros and lowers
  unexpanded type macros to `TyKind::Err`.

This avoids cascading errors and lets later phases continue.

## Testing strategy

Tests live in `yelang-macro/tests/declarative_macros_phase3.rs` and cover:

1. Each position in isolation (type, pattern, item).
2. Nested positions (generic arguments, function parameters, match arms).
3. Nested macro expansion (`A!()` expands to `B!()`).
4. Error cases (unknown macro, invalid expansion output).
5. Multi-item expansion and module-local expansion.

All tests assert that expansion either succeeds and leaves no macro
invocations in the target position, or fails with a specific `ExpandError`
variant.

## Future work (not in Phase 3)

- Statement-position macro invocation as a distinct AST node (currently
  statement macros are parsed as expression macros in `StmtKind::Expr` /
  `StmtKind::TermExpr`).
- Attribute and derive macros are already supported in earlier phases; Phase 3
  does not change them.
- Proc-macro support (quote/syn-style) is out of scope for the declarative
  macro system.
