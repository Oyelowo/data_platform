# Yelang Built-in Derives & Attributes — Design Document

**Status:** Implemented.  
**Scope:** Compiler-native support for `@derive(...)` and built-in attributes (`@test`, `@repr(...)`, `@packed`, etc.) without any user-defined macro expansion.  
**Archive:** The previous macro-based approach lives on `archive/proc-macro-full`.

---

## 1. Executive Summary

Instead of a macro expansion phase, the Yelang compiler recognizes a fixed set of built-in attributes and derives. Each built-in is implemented as a **compiler intrinsic**: the compiler inspects the annotated item and directly emits the corresponding HIR (impl blocks, marker trait registrations, test metadata, etc.).

This avoids token streams, hygiene, expansion engines, and proc-macro runtimes while still covering the common use cases that make Rust ergonomic (`Clone`, `Debug`, `PartialEq`, etc.).

### Derives in scope (MVP)

| Derive | Generated conformance | Notes |
|---|---|---|
| `Copy` | `trait Copy {}` marker | Only for types whose fields are `Copy`. |
| `Clone` | `trait Clone { fn clone(&self) -> Self; }` | Structs and enums; field-by-field clone. |
| `Debug` | `trait Debug { fn fmt(&self, f: &mut Formatter) -> Result; }` | Structural formatter output. |
| `PartialEq` | `trait PartialEq { fn eq(&self, other: &Self) -> bool; }` | Structural equality. |
| `Eq` | `trait Eq {}` marker | Only when `PartialEq` is structural and all fields are `Eq`. |

### Attributes in scope (MVP)

| Attribute | Effect |
|---|---|
| `#[test]` | Marks a function as a unit test; driver collects and runs it. |
| `#[ignore]` | Paired with `#[test]`; skipped by default. |
| `#[repr(C)]` | Requests C-compatible layout (layout hint only for now). |
| `#[packed]` | Requests packed layout (layout hint only for now). |

### Deferred

- `Hash`, `Default`, `Ord`, `PartialOrd` — easy additions after the pattern is proven.
- `Serialize` / `Deserialize` — likely built-in once the design for native serialization is settled.
- User-defined derive attributes — will be provided by `comptime`, not macros.

---

## 2. Design Principles

1. **No token-based expansion.** Built-ins operate on the typed HIR representation of the annotated item.
2. **Direct HIR construction.** Generated code is built as HIR nodes, not parsed from source text. This gives precise spans, avoids parser re-invocation, and reuses the existing HIR pipeline.
3. **Readable helper library.** A small internal HIR construction DSL keeps new derives short and maintainable.
4. **Fail fast with diagnostics.** If a derive cannot be applied (e.g., `Copy` on a struct with a non-`Copy` field), emit a clear diagnostic at the derive site.
5. **Opt-in only.** A type must explicitly request a derived conformance; the compiler never silently synthesizes one.
6. **No legacy patterns.** No `macro_rules!`, no proc-macro2-style token trees, no dylib/WASM runtime.

---

## 3. Architecture

### 3.1 Pipeline

```text
Parse AST
  ↓
Early resolution
  ↓
Late resolution
  ↓
HIR lowering
  - Lower each AST item to HIR.
  - Built-in derive expansion (NEW) runs per item immediately after the item
    is lowered, producing additional `ItemKind::Impl` HIR nodes.
  ↓
Type checking / trait resolution
```

Derive expansion runs **after name resolution** so that trait names and field types are already resolved, and **inside HIR lowering** so generated impls live in the same crate and are visible to type checking.

### 3.2 Crate placement

Built-in derives live inside `yelang-hir` under a new `derive` module. They need full access to HIR types and to the resolver results (to know field types and trait DefIds), so placing them in `yelang-hir` avoids circular dependencies.

```text
yelang-hir/src/
  derive/
    mod.rs           # registry and pass orchestration
    context.rs       # DeriveContext: item, fields, generics, resolver
    helpers.rs       # HIR construction DSL
    copy.rs          # Copy derive
    clone.rs         # Clone derive
    debug.rs         # Debug derive
    partial_eq.rs    # PartialEq derive
    eq.rs            # Eq derive
    test.rs          # #[test] attribute
    repr.rs          # #[repr(...)] attribute
    error.rs         # derive-specific diagnostics
```

### 3.3 Derive registry

```rust
// yelang-hir/src/derive/mod.rs
pub type DeriveFn = fn(&mut DeriveContext<'_, '_>, &[Symbol]) -> Option<Item>;

pub fn register_builtins(
    registry: &mut FxHashMap<Symbol, DeriveFn>,
    interner: &Interner,
) {
    let names: &[(&str, DeriveFn)] = &[
        ("Copy", copy::derive_copy),
        ("Clone", clone::derive_clone),
        ("Debug", debug::derive_debug),
        ("PartialEq", partial_eq::derive_partial_eq),
        ("Eq", eq::derive_eq),
    ];
    for (name, func) in names {
        registry.insert(interner.get_or_intern(name), *func);
    }
}
```

The second argument carries the other derives listed in the same `@derive(...)` attribute (used by `Eq` to confirm `PartialEq` is also requested). The function returns the generated `Item` (usually an `ItemKind::Impl`) or `None` on error.

Attributes like `@test` and `@repr(...)` are handled by separate expansion functions that validate and emit diagnostics but do not emit new items for the MVP.

### 3.4 `DeriveContext`

```rust
pub struct DeriveContext<'a, 'b: 'a> {
    /// The lowered HIR item being derived.
    pub hir_item: &'a HirItem,
    /// The original AST item.
    pub ast_item: &'a yelang_ast::Item,
    /// Lowering context: interner, resolver, crate HIR, ID allocators.
    pub ctx: &'a mut LoweringContext<'b>,
    /// Span of the derive attribute (for diagnostics).
    pub derive_span: Span,
    /// Name of the derive being expanded.
    pub derive_name: Symbol,
}
```

Lookup helpers on `DeriveContext` first check the current module's namespace and then fall back to the built-in prelude, because prelude items are **not** inserted into module namespace tables (they are resolved as a final fallback during name resolution). This keeps glob imports from re-exporting prelude items and prevents qualified paths like `crate::Option` from resolving to prelude entries.

### 3.5 HIR construction helpers

A small, typed helper surface makes derive implementations readable:

```rust
// helpers.rs
fn ident(name: &str) -> Ident;
fn path(segments: &[&str]) -> Path;
fn self_path() -> Path;
fn field_access(receiver: Expr, field: Ident) -> Expr;
fn struct_literal(path: Path, fields: &[(Ident, Expr)]) -> Expr;
fn enum_literal(path: Path, variant: Ident, fields: &[(Ident, Expr)]) -> Expr;
fn method_call(receiver: Expr, method: &str, args: Vec<Expr>) -> Expr;
fn bin_op(lhs: Expr, op: BinaryOp, rhs: Expr) -> Expr;
fn bool_lit(value: bool) -> Expr;
fn string_lit(value: &str) -> Expr;
fn impl_block(trait_path: Path, for_type: Ty, items: Vec<ImplItem>) -> Item;
fn fn_item(name: &str, params: Vec<Param>, ret: Ty, body: Expr) -> ImplItem;
fn self_param() -> Param;
fn ref_expr(expr: Expr) -> Expr;
fn deref_expr(expr: Expr) -> Expr;
```

These helpers construct HIR nodes with proper spans derived from the annotated item.

### 3.6 Prelude interaction and `DefId` allocation

Because the prelude is resolved as a fallback rather than being injected into every module's namespace table, derive implementations cannot rely on `module.get_item(...)` to find prelude traits or types. `DeriveContext::resolve_in_module_or_prelude` first checks the current module (so user-defined shadowing works) and then checks `ResolvedCrate::prelude`.

Generated items need their own `DefId`s. `LoweringContext` initializes `next_def_id` to one greater than the highest `DefId` allocated by `yelang-resolve::def_collector`, ensuring that derived impl blocks never collide with IDs produced during name resolution.

---

## 4. Per-Derive Specification

### 4.1 `Copy`

**Applicability:** Structs and enums whose fields/variant payloads are all `Copy`.

**Generated HIR:**

```rust
impl Copy for Name {}
```

**Validation:**
- Error if any field type does not implement `Copy`.
- Error if the item has generic parameters without appropriate bounds (deferred: generic bounds are handled by trait resolution).

### 4.2 `Clone`

**Applicability:** Structs and enums whose fields/variant payloads are all `Clone`.

**Generated HIR for struct:**

```rust
impl Clone for Name {
    fn clone(&self) -> Self {
        Self {
            field1: self.field1.clone(),
            field2: self.field2.clone(),
        }
    }
}
```

**Generated HIR for enum:**

```rust
impl Clone for Name {
    fn clone(&self) -> Self {
        match self {
            Self::A { x } => Self::A { x: x.clone() },
            Self::B(y) => Self::B(y.clone()),
            Self::C => Self::C,
        }
    }
}
```

**Validation:**
- Error if any field type does not implement `Clone`.

### 4.3 `Debug`

**Applicability:** Structs and enums whose fields/variant payloads are all `Debug`.

**Generated HIR:**

```rust
impl Debug for Name {
    fn fmt(&self, f: &mut Formatter) -> Result {
        f.debug_struct("Name")
            .field("field1", &self.field1)
            .field("field2", &self.field2)
            .finish()
    }
}
```

For enums, use `f.debug_variant("VariantName")` / `f.debug_tuple_variant(...)` style helpers.

**Validation:**
- Error if any field type does not implement `Debug`.
- Require `Formatter` and `Result` to be available in the prelude or as lang items.

### 4.4 `PartialEq`

**Applicability:** Structs and enums whose fields/variant payloads are all `PartialEq`.

**Generated HIR for struct:**

```rust
impl PartialEq for Name {
    fn eq(&self, other: &Self) -> bool {
        self.field1 == other.field1 && self.field2 == other.field2
    }
}
```

**Generated HIR for enum:**

```rust
impl PartialEq for Name {
    fn eq(&self, other: &Self) -> bool {
        match (self, other) {
            (Self::A { x: x1 }, Self::A { x: x2 }) => x1 == x2,
            (Self::B(y1), Self::B(y2)) => y1 == y2,
            (Self::C, Self::C) => true,
            _ => false,
        }
    }
}
```

**Validation:**
- Error if any field type does not implement `PartialEq`.

### 4.5 `Eq`

**Applicability:** Any type that already implements `PartialEq` structurally.

**Generated HIR:**

```rust
impl Eq for Name {}
```

**Validation:**
- Error if `PartialEq` is not also derived or manually implemented for this type.
- Error if any field type is `f32` or `f64` (they are not `Eq`).

### 4.6 `#[test]`

**Effect:**
- Adds the function to a crate-level test registry.
- Emits a lang-item marker `#[test]` on the function so the test runner can discover it.
- Optionally wraps the function body to catch panics and report results.

**Validation:**
- Error if applied to anything other than a zero-argument function returning unit (or a generic result type).

### 4.7 `#[repr(C)]` / `#[packed]`

**Effect:**
- Stores a layout hint on the ADT definition in HIR.
- The layout backend uses the hint when computing field offsets.

**Validation:**
- Error on unknown repr strings.
- Error if conflicting repr hints are combined.

---

## 5. Exhaustive File Tree

```text
crates/compiler/
├── notes/architectures/
│   ├── builtin_derives_design.md       # this document
│   └── adr_no_user_defined_macros.md   # decision record
│
├── yelang-hir/src/
│   ├── lib.rs
│   ├── hir.rs
│   ├── hir_item.rs
│   ├── hir_expr.rs
│   ├── hir_ty.rs
│   ├── hir_pat.rs
│   ├── hir_struct.rs
│   ├── lowering.rs
│   ├── lowering_item.rs
│   ├── lowering_expr.rs
│   ├── lowering_ty.rs
│   ├── crate_hir.rs
│   ├── derive/                         # NEW
│   │   ├── mod.rs                      # registry + pass
│   │   ├── context.rs                  # DeriveContext
│   │   ├── helpers.rs                  # HIR construction DSL
│   │   ├── error.rs                    # DeriveError + diagnostics
│   │   ├── copy.rs
│   │   ├── clone.rs
│   │   ├── debug.rs
│   │   ├── partial_eq.rs
│   │   ├── eq.rs
│   │   ├── test.rs
│   │   └── repr.rs
│   └── tests/
│       └── derive_tests.rs             # integration tests
│
└── yelang-ast/src/
    └── item/
        └── attribute.rs                # attribute parsing already exists
```

---

## 6. Implementation Checklist

### Phase 1 — Infrastructure

- [x] Add `yelang-hir/src/derive/` module.
- [x] Define `DeriveContext` and `DeriveError`.
- [x] Implement HIR construction helpers (`helpers.rs`).
- [x] Add derive registry in `derive/mod.rs`.
- [x] Wire derive lowering into HIR lowering after each item.

### Phase 2 — Marker derives

- [x] Implement `Copy` derive for structs and enums.
- [x] Implement `Eq` derive for structs and enums.
- [x] Add diagnostics for invalid applications.

### Phase 3 — Method derives

- [x] Implement `Clone` derive for structs, tuple structs, unit structs, and enums.
- [x] Implement `PartialEq` derive for structs and enums.
- [x] Implement `Debug` derive for structs and enums.

### Phase 4 — Attributes

- [x] Validate `@test` / `@ignore` on functions.
- [x] Validate `@repr("C")` and `@packed` on structs.

### Phase 5 — Validation & polish

- [x] Ensure all generated items are visible to trait resolution.
- [x] Verify spans point at the derive attribute for generated-code errors.
- [x] Allocate fresh `DefId`s in lowering that do not collide with resolution IDs.
- [x] Run `cargo fmt` and `cargo test --workspace`.

---

## 7. Exhaustive Test Matrix

### Unit tests per derive

| Derive | Struct | Tuple struct | Unit struct | Enum | Tuple variant | Record variant | Unit variant | Generic | Error cases |
|---|---|---|---|---|---|---|---|---|---|
| `Copy` | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | deferred | non-Copy field (tested) |
| `Clone` | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | deferred | — |
| `Debug` | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | deferred | — |
| `PartialEq` | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | deferred | — |
| `Eq` | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | deferred | float field (tested), missing PartialEq (tested) |

### Attribute tests

| Attribute | Valid target | Invalid target | Combined with derive |
|---|---|---|---|
| `@test` | zero-arg `fn` | non-function (tested) | ✓ |
| `@ignore` | paired with `@test` | without `@test` (tested) | ✓ |
| `@repr("C")` | struct | unknown repr (tested) | ✓ |
| `@packed` | struct | combined with `@repr("C")` (tested) | ✓ |

### Integration tests

| Scenario | Expected |
|---|---|
| `#[derive(Clone)] struct Foo { x: i32 }` | `Foo { x: 1 }.clone()` works |
| `#[derive(PartialEq)] enum E { A, B(i32) }` | `E::A == E::A`, `E::B(1) == E::B(1)` |
| `#[derive(Copy, Clone, PartialEq, Eq, Debug)] struct Point { x: i32, y: i32 }` | All traits usable |
| `#[derive(Copy)] struct Bad { s: String }` | Compile error: `String` is not `Copy` |
| `#[test] fn my_test() { assert_eq!(1, 1); }` | Registered as test |
| Multiple derives on one item | All generated impls present |
| Derived impl coexists with manual impl | Error on duplicate conformance |

### Adversarial tests

| Attack | Mitigation tested |
|---|---|
| Derive on empty struct | Generates correct unit-like impl |
| Derive on enum with many variants | Match arms cover all variants |
| Field named `other` or `self` | No shadowing: generated bindings use fresh names |
| Generic type without needed bounds | Trait resolution reports the missing bound |
| Nested ADTs | Generated code recursively uses derived traits |

---

## 8. Risks & Mitigations

| Risk | Mitigation |
|---|---|
| HIR construction is verbose and error-prone | Helper DSL + property tests on generated HIR shape |
| Generated code errors are hard to debug | Spans on generated nodes point back to the derive attribute |
| Trait resolution doesn't see generated impls | Generate and inject impls before type checking |
| Adding new derives requires compiler changes | Stable helper DSL + documented pattern |
| `Debug` needs `Formatter` API | Define minimal `Formatter` lang item for MVP |

---

## 9. References

- Rust built-in macros design: [`rustc_builtin_macros`](https://doc.rust-lang.org/beta/nightly-rustc/rustc_builtin_macros/index.html)
- Rust compiler pipeline overview: [Resolving Rust Symbols](https://blog.shrirambalaji.com/posts/resolving-rust-symbols)
- Swift derived conformances: [SE-0185](https://github.com/apple/swift-evolution/blob/main/proposals/0185-synthesize-equatable-hashable.md)
- Decision record: `adr_no_user_defined_macros.md`
