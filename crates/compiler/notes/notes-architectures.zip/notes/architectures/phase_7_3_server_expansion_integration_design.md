# Phase 7.3 — Server-Based Procedural Macro Expansion Integration

This document describes how the out-of-process `yelang-proc-macro-server` is
wired into the compiler's macro expansion engine.

The design is informed by Rust's proc-macro architecture: proc macros run in a
separate process for isolation ([JetBrains analysis](https://blog.jetbrains.com/rust/2022/07/07/procedural-macros-under-the-hood-part-ii/),
[rust-analyzer proc-macro server](https://fasterthanli.me/articles/proc-macro-support-in-rust-analyzer-for-nightly-rustc-versions)),
use a stable wire protocol over stdin/stdout, and serialize token streams fully
rather than exposing compiler-internal types across the boundary. Because Yelang
is a greenfield project we avoid the unstable handle-based bridge that rustc
uses and instead use a self-contained, versioned, postcard-based protocol.

---

## 1. Goals

- Make out-of-process procedural macros actually expand during compilation.
- Reuse the existing, working wire-serialization path instead of the broken
  placeholder `ast_to_wire` in `yelang-macro/src/proc_macro/expand.rs`.
- Surface proc-macro diagnostics (errors, warnings, notes, help) to the user
  instead of dropping them.
- Preserve correct symbol interning when tokens cross the process boundary.
- Provide a clean, testable API for loading proc-macro libraries and resolving
  macro names.
- Handle all failure modes with clear expansion errors rather than panics or
  silent mis-expansion.

---

## 2. Core concepts

### 2.1 Token pipeline

The compiler works with `yelang_macro_core::TokenStream`. The proc-macro public
API works with `yelang_proc_macro::TokenStream`. The server protocol works with
`WireTokenStream`. The established, robust conversions are:

```text
yelang_macro_core::TokenStream
  │  from_core_stream(interner)
  ▼
yelang_proc_macro::TokenStream
  │  bridge::into_wire
  ▼
WireTokenStream ────────► server ────────► WireTokenStream
  │  bridge::from_wire
  ▼
yelang_proc_macro::TokenStream
  │  render_source(interner) + tokenize + from_lexer_tokens
  ▼
yelang_macro_core::TokenStream
```

The render/retokenize step is necessary because the proc-macro API carries
interned symbols that are not valid in the compiler's interner. Retokenizing
through the expander's interner makes every symbol local and valid.

### 2.2 Why not fix `ast_to_wire`?

`yelang-macro/src/proc_macro/expand.rs` contains a direct
`yelang_macro_core::TokenStream → WireTokenStream` converter that emits
`<symbol:N>` placeholders for identifiers because it lacks interner access.
That path is dead code and is removed by this phase. The indirect path above is
already tested in `yelang-proc-macro` and correctly resolves symbols.

### 2.3 Proc-macro runtime

A `ProcMacroRuntime` owns:

- a `ProcMacroClient` (the spawned server connection),
- a `ProcMacroResolver` (name → metadata),
- a cache of loaded library paths → `LibraryHandle`.

Libraries are loaded lazily on first use. If a library fails to load, the error
is recorded once and the macros in that library become unavailable.

### 2.4 Resolver behaviour

`ProcMacroRuntime::resolve(name)` returns one of:

- `None` — no proc macro with that name is known.
- `Some(Ok(ResolvedProcMacro))` — the macro is loaded and ready.
- `Some(Err(ProcMacroClientError))` — the macro is known but its library could
  not be loaded.

### 2.5 Expander integration

`MacroExpander` gains an optional `proc_macro_runtime: Option<ProcMacroRuntime>`.
At each macro dispatch point the order is:

1. In-process proc macros (existing).
2. Out-of-process proc macros via the runtime.
3. Declarative macros.

For server-based expansion the flow is:

1. Convert input `yelang_macro_core::TokenStream` to `WireTokenStream`.
2. Call the appropriate client method (`expand_fn_like`, `expand_attr`,
   `expand_derive`).
3. Convert the returned `WireTokenStream` back to
   `yelang_macro_core::TokenStream`.
4. Convert returned diagnostics to expansion errors with level preserved in the
   message.
5. Parse the returned tokens into the expected syntactic category (items,
   expressions, statements, types, patterns).

### 2.6 Diagnostics

Server diagnostics are returned as out-of-band `Response::Diagnostic` messages
followed by a final `Response::Expanded`. The client now collects them and
returns them alongside the output. The expander converts each diagnostic to an
`ExpandError::MalformedMacroArgs` carrying the diagnostic level, message, and
macro backtrace. When the compiler's diagnostic system supports levels natively
we can introduce a dedicated `ExpandError` variant without changing the wire
protocol.

### 2.7 Span handling

Spans are transmitted as opaque `(lo, hi, file, syntax_context)` tuples. They
round-trip correctly for tokens that originate in the compiler and are only
manipulated by the macro. Spans created inside the server (e.g. `Span::call_site`)
carry server-local file/hygiene IDs; these are currently accepted but may not
map to meaningful source locations after retokenization. This is a known
limitation shared with Phase 7.7 (full hygiene). For Phase 7.3 we guarantee
that the byte offsets and file IDs are preserved on the wire and used during
retokenization.

---

## 3. Exhaustive file tree

```text
crates/compiler/yelang-macro/src/proc_macro/
├── mod.rs              # re-exports
├── client.rs           # ProcMacroClient (collects diagnostics)
├── discovery.rs        # ProcMacroDiscovery (static metadata, unchanged)
├── executor.rs         # InProcessExecutor / InProcessProcMacro (unchanged)
├── expand.rs           # server-based expand_proc_macro, core/wire conversion
├── registry.rs         # ProcMacroRegistry / ProcMacroDef (metadata, no handle)
├── resolver.rs         # ProcMacroResolver + ProcMacroRuntime + lazy loading
└── export.rs           # #[macro_export] codegen (unchanged)

crates/compiler/yelang-macro/src/expander.rs
├── MacroExpander
│   └── proc_macro_runtime: Option<ProcMacroRuntime>
├── with_proc_macro_runtime(...)
├── expand_server_fn_like
├── expand_server_attr
└── expand_server_derive

crates/compiler/yelang-macro/tests/
├── proc_macro_integration.rs        # existing in-process tests
└── proc_macro_server_integration.rs # new end-to-end server tests

notes/architectures/
├── phase_7_3_server_expansion_integration_design.md
└── phase_7_3_server_expansion_integration_checklist.md
```

---

## 4. API changes

### 4.1 `yelang-macro/src/proc_macro/registry.rs`

```rust
pub struct ProcMacroDef {
    pub id: ProcMacroId,
    pub name: String,
    pub kind: ProcMacroKind,
    pub macro_index: u32,
    pub library_path: String,
}
```

`library: LibraryHandle` is removed from `ProcMacroDef`; handles are runtime
state owned by the runtime.

### 4.2 `yelang-macro/src/proc_macro/resolver.rs`

```rust
pub struct ResolvedProcMacro {
    pub name: String,
    pub kind: ProcMacroKind,
    pub library: LibraryHandle,
    pub macro_index: u32,
}

pub struct ProcMacroRuntime {
    client: RefCell<ProcMacroClient>,
    resolver: ProcMacroResolver,
    loaded: RefCell<HashMap<String, LibraryHandle>>,
}

impl ProcMacroRuntime {
    pub fn new(client: ProcMacroClient, resolver: ProcMacroResolver) -> Self;
    pub fn resolve(&self, name: &str) -> Option<Result<ResolvedProcMacro, ProcMacroClientError>>;
    pub fn load_library(&self, path: &str) -> Result<LibraryHandle, ProcMacroClientError>;
}
```

### 4.3 `yelang-macro/src/proc_macro/client.rs`

`expand_fn_like`, `expand_attr`, and `expand_derive` now return
`Result<(WireTokenStream, Vec<WireDiagnostic>), ProcMacroClientError>`.

`read_expanded` collects `Response::Diagnostic` messages instead of dropping
 them.

### 4.4 `yelang-macro/src/proc_macro/expand.rs`

```rust
pub fn core_to_wire(
    stream: &yelang_macro_core::TokenStream,
    interner: &Interner,
) -> WireTokenStream;

pub fn wire_to_core(
    stream: WireTokenStream,
    interner: &Interner,
    span: yelang_lexer::Span,
) -> Result<yelang_macro_core::TokenStream, ExpandError>;

pub fn expand_proc_macro(
    client: &mut ProcMacroClient,
    macro_def: &ResolvedProcMacro,
    args: Option<WireTokenStream>,
    item: Option<WireTokenStream>,
    span: yelang_lexer::Span,
) -> Result<(WireTokenStream, Vec<WireDiagnostic>), ExpandError>;
```

The broken `ast_to_wire` / `ast_tree_to_wire` / `ast_span_to_wire` helpers are
removed.

### 4.5 `yelang-macro/src/expander.rs`

```rust
pub struct MacroExpander<'a> {
    // ... existing fields ...
    proc_macro_runtime: Option<ProcMacroRuntime>,
}

impl<'a> MacroExpander<'a> {
    pub fn with_proc_macro_runtime(mut self, runtime: ProcMacroRuntime) -> Self;
}
```

A new free function is added for callers that need proc macros:

```rust
pub fn expand_program_with_proc_macros(
    program: &Program,
    interner: &Interner,
    runtime: ProcMacroRuntime,
) -> ExpandResult;
```

`expand_program` remains as a convenience that calls the above with no runtime.

---

## 5. Examples

### 5.1 Configuring the expander with server-based proc macros

```rust
use yelang_macro::proc_macro::{ProcMacroClient, ProcMacroDiscovery, ProcMacroRegistry, ProcMacroRuntime};

let client = ProcMacroClient::spawn("yelang-proc-macro-server")?;
let mut registry = ProcMacroRegistry::new();
let discovery = ProcMacroDiscovery::new();
discovery.discover_static(&mut registry, &[
    StaticEntry {
        name: "my_derive".to_string(),
        kind: ProcMacroKind::Derive,
        path: "target/debug/libmy_macro.dylib".to_string(),
    },
]);
let runtime = ProcMacroRuntime::new(client, ProcMacroResolver::new(registry));

let result = yelang_macro::expand_program_with_proc_macros(&program, &interner, runtime);
```

### 5.2 Internal expansion flow (function-like)

```rust
if let Some(runtime) = self.proc_macro_runtime.as_ref() {
    if let Some(result) = runtime.resolve(&name) {
        let mac = result.map_err(|e| /* expansion error */)?;
        let wire_args = core_to_wire(&macro_args, self.interner);
        let (wire_output, diags) = self.expand_server_fn_like(&mac, wire_args, span)?;
        self.push_server_diagnostics(&diags, &name, span);
        let core_output = wire_to_core(wire_output, self.interner, span)?;
        return parse_result(core_output);
    }
}
```

---

## 6. Design decisions

- **No direct AST → wire converter.** We deliberately go through the public
  `yelang_proc_macro::TokenStream` API because it already resolves symbols and
  maps delimiters/spacing/literals correctly. This avoids duplicating the
  conversion logic and eliminates the `<symbol:N>` placeholder bug.
- **Lazy library loading.** Libraries are loaded on first macro use rather than
  eagerly when the runtime is constructed. This keeps compile times low when a
  crate declares many proc macros but only a few are used.
- **Runtime owns the client.** `ProcMacroRuntime` wraps the client in a
  `RefCell` so that the otherwise immutable resolver can perform lazy loading.
  The expander only needs `&self` access for reads and `&mut self` for actual
  expansion, matching the existing API.
- **Diagnostics are errors for now.** The expander converts server diagnostics
  to `ExpandError::MalformedMacroArgs` with the level in the message. A future
  phase can introduce a level-preserving `ExpandError` variant without changing
  the wire protocol.
- **`expand_program` stays unchanged.** Adding a new `expand_program_with_proc_macros`
  function avoids breaking the many existing call sites and tests.
- **No `util` modules.** New code lives in named domain modules; `mod.rs` files
  remain routers.

---

## 7. Adversarial considerations

| Threat | Mitigation |
|--------|------------|
| Server binary missing or unexecutable | `ProcMacroClient::spawn` returns `Spawn` error; expander reports it as `MalformedMacroArgs`. |
| Server handshake fails | Client returns `Server`/`Protocol` error; expander reports it. |
| Library path does not exist or is not a dylib | `LoadLibrary` returns `LibraryNotFound`; cached as failed; macro unavailable. |
| Wrong ABI version | Server rejects at load time; error propagated. |
| Macro index out of bounds | Server returns `MacroNotFound`; error propagated. |
| Server panic | `catch_unwind` in server converts to `Response::Panic`; client returns `Panic` error. |
| Server returns invalid tokens | `wire_to_core` retokenizes; parse failure becomes `MalformedMacroArgs`. |
| Server returns diagnostics | Collected and pushed as expansion errors. |
| Server process dies mid-request | `read_response` returns IO/EOF error; client returns `Protocol`/`Io` error. |
| Server returns huge output | `serialize.rs` has 64 MiB frame limit; oversized responses become protocol errors. |
| Name collision between in-process and server macro | In-process takes priority (existing behaviour). |
| Name collision between server macro and declarative macro | Server macro takes priority when runtime is configured. |
| Lazy-load race | Runtime uses `RefCell`; only one expansion runs per expander at a time. |
