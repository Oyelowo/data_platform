# ADR: No User-Defined Macros — Built-in Derives + Comptime

**Status:** Approved and implemented on `cleanup/no-macros`.  
**Date:** 2026-07-17  
**Archive:** Full macro implementation preserved on `archive/proc-macro-full`.

## Context

The project previously pursued a complete Rust-style macro system: declarative `macro name { ... }`, function-like/attribute/derive proc macros, a `proc_macro` standard-library module, a built-in `quote!` macro, and a planned WASM backend for proc-macro crates. Phases A and B of that design were implemented and tested.

After review, we concluded that the macro system was adding substantial complexity and technical debt before the core compiler (HIR, type checking, trait resolution, backend) was complete.

## Decision

1. **Remove all user-defined macro support** from the active codebase.
   - Deleted crates: `yelang-macro-core`, `yelang-macro`, `yelang-proc-macro`, `yelang-proc-macro-bridge`, `yelang-proc-macro-server`, `yelang-quote`.
   - Removed `MacroDef`/`MacroInvocation` from `yelang-ast` and `yelang-hir`.
   - Removed the hygiene system (`HygieneData`, `SyntaxContextId`, `Transparency`) from `yelang-resolve`.

2. **Implement built-in attributes/derives as compiler intrinsics.**
   - `#[derive(Copy)]`, `#[derive(Clone)]`, `#[derive(Debug)]`, `#[derive(Eq)]`, `#[derive(PartialEq)]`, `#[test]`, `#[repr(C)]`, etc. are recognized by the compiler and lowered directly to HIR.
   - They can be implemented by generating Yelang source text and parsing it, or by constructing HIR nodes directly.

3. **Defer user-extensible compile-time code generation to `comptime`.**
   - `comptime { ... }` will operate on typed AST/HIR and return values/types/generated items.
   - It does not require token streams, hygiene, expansion engines, or proc-macro runtimes.

## Rationale

| Concern | Macro approach | Built-in + comptime approach |
|---|---|---|
| Backend required | Yes (WASM or dylib for proc macros) | No for built-ins; yes for comptime, but it reuses the same backend as normal code |
| Hygiene complexity | High | None for built-ins; ordinary name resolution for comptime |
| Token representation | Requires canonical token tree shared across crates | Only lexer tokens needed |
| Build-system complexity | `proc-macro` crate type, artifact discovery, sandboxing | None beyond normal crates |
| Common use cases (`Copy`/`Clone`/`Debug`) | Must go through expansion | Direct compiler support |
| User extensibility | Proc macros | Comptime (typed, debuggable, no token pitfalls) |

This aligns with the broader language-design trend: Rust is investing in const generics, inline const, const traits, and compile-time reflection. A greenfield project should adopt the simpler, typed foundation from the start.

## Consequences

- The workspace is smaller and the core compiler path is free of macro-related indirection.
- `yelang-ast` no longer depends on `yelang-macro-core`.
- `yelang-resolve` no longer carries a hygiene subsystem.
- Built-in derives must be added by modifying the compiler, not by writing a macro.
- The archived branch `archive/proc-macro-full` preserves the full implementation if we ever revisit it.

## Non-goals

- Re-adding declarative macros (`macro name { ... }`) in the near term.
- Re-adding proc-macro runtime/bridge/server before the backend is mature.
- Supporting user-defined `derive` macros before `comptime` is available.

## Verification

After the cleanup:

```bash
cargo test --workspace
```

passes with 780 tests and no failures.

## References

- Superseded design doc: `yelang_proc_macro_design.md`
- Archive branch: `archive/proc-macro-full`
