//! Reference Implementation: Type Checker & Next-Gen Trait Solver
//! For a Rust-like language without lifetimes.
//!
//! This is a single-file architectural reference showing the core data structures
//! and algorithms. In a real project, split this into `compiler_middle`,
//! `compiler_typeck`, etc.

use std::collections::{HashMap, HashSet};
use std::sync::Arc;

// =============================================================================
// 1. COMPILER_MIDDLE: Core Type Representation & Interning
// =============================================================================

/// A unique identifier for definitions (functions, structs, traits, impls).
#[derive(Copy, Clone, Debug, PartialEq, Eq, Hash)]
pub struct DefId {
    pub krate: u32,
    pub index: u32,
}

/// Source span for error reporting.
#[derive(Copy, Clone, Debug)]
pub struct Span {
    pub start: usize,
    pub end: usize,
}

// ---------------------------------------------------------------------------
// Interning & Type Context (TyCtxt)
// ---------------------------------------------------------------------------

/// Types are interned so that equality is pointer equality.
#[derive(Clone, Debug)]
pub struct Ty {
    pub kind: Arc<TyKind>,
    /// Pre-computed flags for fast queries (e.g., has inference variables?).
    pub flags: TypeFlags,
}

impl PartialEq for Ty {
    fn eq(&self, other: &Self) -> bool {
        Arc::ptr_eq(&self.kind, &other.kind)
    }
}
impl Eq for Ty {}

impl std::hash::Hash for Ty {
    fn hash<H: std::hash::Hasher>(&self, state: &mut H) {
        Arc::as_ptr(&self.kind).hash(state);
    }
}

bitflags::bitflags! {
    #[derive(Clone, Copy, Debug, PartialEq, Eq)]
    pub struct TypeFlags: u32 {
        const HAS_TY_INFER     = 1 << 0;
        const HAS_CONST_INFER  = 1 << 1;
        const HAS_PLACEHOLDER  = 1 << 2;
        const HAS_ALIAS        = 1 << 3;
        const HAS_PARAMS       = 1 << 4;
        const HAS_ERROR        = 1 << 5;
    }
}

#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub enum TyKind {
    Bool,
    Int(IntTy),
    Float(FloatTy),
    String,
    Char,
    Adt(DefId, GenericArgs),
    Tuple(Vec<Ty>),
    Array(Ty, Const),
    Slice(Ty),
    FnDef(DefId, GenericArgs),
    FnPtr(PolyFnSig),
    /// Type parameter `T`.
    Param(ParamTy),
    /// Inference variable `?0`.
    Infer(InferTy),
    /// Placeholder for higher-ranked instantiations.
    Placeholder(PlaceholderTy),
    /// Associated type projection `<T as Trait>::Assoc`.
    Alias(AliasTy),
    /// Error type for recovery.
    Error,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq, Hash)]
pub enum IntTy { I8, I16, I32, I64, I128, Isize, U8, U16, U32, U64, U128, Usize }

#[derive(Copy, Clone, Debug, PartialEq, Eq, Hash)]
pub enum FloatTy { F32, F64 }

#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub struct GenericArgs {
    pub types: Vec<Ty>,
    pub consts: Vec<Const>,
}

#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub struct Const {
    pub kind: ConstKind,
}

#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub enum ConstKind {
    Param(ParamConst),
    Infer(InferConst),
    Value(u128, Ty), // (value, type)
    Unevaluated(DefId, GenericArgs),
    Error,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq, Hash)]
pub struct ParamTy { pub index: u32, pub name: Symbol }

#[derive(Copy, Clone, Debug, PartialEq, Eq, Hash)]
pub struct ParamConst { pub index: u32, pub name: Symbol }

#[derive(Copy, Clone, Debug, PartialEq, Eq, Hash)]
pub struct InferTy { pub vid: TyVid }

#[derive(Copy, Clone, Debug, PartialEq, Eq, Hash)]
pub struct TyVid(pub u32);

#[derive(Copy, Clone, Debug, PartialEq, Eq, Hash)]
pub struct InferConst { pub vid: ConstVid }

#[derive(Copy, Clone, Debug, PartialEq, Eq, Hash)]
pub struct ConstVid(pub u32);

#[derive(Copy, Clone, Debug, PartialEq, Eq, Hash)]
pub struct PlaceholderTy { pub universe: UniverseIndex, pub bound: BoundVar }

#[derive(Copy, Clone, Debug, PartialEq, Eq, Hash)]
pub struct PlaceholderConst { pub universe: UniverseIndex, pub bound: BoundVar }

#[derive(Copy, Clone, Debug, PartialEq, Eq, Hash)]
pub struct UniverseIndex(pub u32);

#[derive(Copy, Clone, Debug, PartialEq, Eq, Hash)]
pub struct BoundVar(pub u32);

#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub struct AliasTy {
    pub def_id: DefId,           // trait + associated item
    pub args: GenericArgs,
}

#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub struct PolyFnSig {
    pub bound_vars: Vec<BoundVariableKind>,
    pub sig: FnSig,
}

#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub struct FnSig {
    pub inputs: Vec<Ty>,
    pub output: Ty,
}

#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub enum BoundVariableKind {
    Ty(ParamTy),
    Const(ParamConst),
}

/// A simple symbol type for identifiers.
#[derive(Copy, Clone, Debug, PartialEq, Eq, Hash)]
pub struct Symbol(pub &'static str);

// ---------------------------------------------------------------------------
// Predicates & ParamEnv
// ---------------------------------------------------------------------------

#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub struct Predicate {
    pub kind: PredicateKind,
}

#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub enum PredicateKind {
    /// `T: Trait`
    Trait(TraitRef),
    /// `<T as Trait>::Assoc == U`
    Projection(ProjectionPredicate),
    /// `T == U` (type equality, used for normalization)
    Eq(Ty, Ty),
    /// Subtype relation `T <: U` (if your language has subtyping)
    Subtype(Ty, Ty),
    /// Well-formedness predicate
    WellFormed(Ty),
}

#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub struct TraitRef {
    pub def_id: DefId,
    pub args: GenericArgs,
}

#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub struct ProjectionPredicate {
    pub projection_ty: AliasTy,
    pub term: Ty,
}

/// The environment in which a goal is proven. Contains assumptions.
#[derive(Clone, Debug)]
pub struct ParamEnv {
    pub caller_bounds: Vec<Predicate>,
}

impl ParamEnv {
    pub fn empty() -> Self {
        ParamEnv { caller_bounds: vec![] }
    }
}

// ---------------------------------------------------------------------------
// TyCtxt: The Global Type Context
// ---------------------------------------------------------------------------

pub struct TyCtxt {
    interner: std::sync::Mutex<HashSet<Ty>>,
    // In a real compiler: definitions, queries, etc.
}

impl TyCtxt {
    pub fn new() -> Self {
        TyCtxt {
            interner: std::sync::Mutex::new(HashSet::new()),
        }
    }

    pub fn mk_ty(&self, kind: TyKind) -> Ty {
        let flags = compute_flags(&kind);
        let ty = Ty {
            kind: Arc::new(kind),
            flags,
        };
        // In a real implementation, we'd intern and return the interned copy.
        // Here we just return the new one for simplicity.
        ty
    }

    pub fn mk_param(&self, index: u32, name: &'static str) -> Ty {
        self.mk_ty(TyKind::Param(ParamTy { index, name: Symbol(name) }))
    }

    pub fn mk_infer(&self, vid: TyVid) -> Ty {
        self.mk_ty(TyKind::Infer(InferTy { vid }))
    }

    pub fn mk_bool(&self) -> Ty { self.mk_ty(TyKind::Bool) }
    pub fn mk_int(&self, ity: IntTy) -> Ty { self.mk_ty(TyKind::Int(ity)) }
    pub fn mk_adt(&self, def_id: DefId, args: GenericArgs) -> Ty {
        self.mk_ty(TyKind::Adt(def_id, args))
    }
    pub fn mk_tuple(&self, tys: Vec<Ty>) -> Ty { self.mk_ty(TyKind::Tuple(tys)) }
    pub fn mk_fn_ptr(&self, sig: PolyFnSig) -> Ty { self.mk_ty(TyKind::FnPtr(sig)) }
    pub fn mk_alias(&self, def_id: DefId, args: GenericArgs) -> Ty {
        self.mk_ty(TyKind::Alias(AliasTy { def_id, args }))
    }
    pub fn mk_error(&self) -> Ty { self.mk_ty(TyKind::Error) }
}

fn compute_flags(kind: &TyKind) -> TypeFlags {
    let mut f = TypeFlags::empty();
    match kind {
        TyKind::Infer(_) => f |= TypeFlags::HAS_TY_INFER,
        TyKind::Error => f |= TypeFlags::HAS_ERROR,
        TyKind::Param(_) => f |= TypeFlags::HAS_PARAMS,
        TyKind::Placeholder(_) => f |= TypeFlags::HAS_PLACEHOLDER,
        TyKind::Alias(_) => f |= TypeFlags::HAS_ALIAS,
        TyKind::Tuple(ts) => for t in ts { f |= t.flags; },
        TyKind::Array(t, c) => { f |= t.flags; f |= const_flags(c); }
        TyKind::Slice(t) => f |= t.flags,
        TyKind::FnDef(_, args) => f |= args_flags(args),
        TyKind::FnPtr(sig) => {
            for inp in &sig.sig.inputs { f |= inp.flags; }
            f |= sig.sig.output.flags;
        }
        TyKind::Adt(_, args) => f |= args_flags(args),
        _ => {}
    }
    f
}

fn args_flags(args: &GenericArgs) -> TypeFlags {
    let mut f = TypeFlags::empty();
    for t in &args.types { f |= t.flags; }
    for c in &args.consts { f |= const_flags(c); }
    f
}

fn const_flags(c: &Const) -> TypeFlags {
    match &c.kind {
        ConstKind::Infer(_) => TypeFlags::HAS_CONST_INFER,
        ConstKind::Error => TypeFlags::HAS_ERROR,
        _ => TypeFlags::empty(),
    }
}

// =============================================================================
// 2. INFERENCE ENGINE (rustc_infer equivalent)
// =============================================================================

/// Unification table using union-find.
pub struct UnificationTable<T: UnifyValue> {
    values: Vec<VarValue<T>>,
}

pub trait UnifyValue: Clone + PartialEq {
    fn unify_values(a: &Self, b: &Self) -> Result<Self, UnifyError>;
}

#[derive(Clone, Debug)]
enum VarValue<T> {
    Known(T),
    Unknown { parent: u32, rank: u32 },
}

#[derive(Debug)]
pub struct UnifyError;

impl<T: UnifyValue> UnificationTable<T> {
    pub fn new() -> Self {
        UnificationTable { values: Vec::new() }
    }

    pub fn new_key(&mut self) -> u32 {
        let idx = self.values.len() as u32;
        self.values.push(VarValue::Unknown { parent: idx, rank: 0 });
        idx
    }

    fn find(&mut self, idx: u32) -> (u32, u32) {
        match self.values[idx as usize] {
            VarValue::Unknown { parent, .. } if parent != idx => {
                let (root, rank) = self.find(parent);
                // Path compression
                self.values[idx as usize] = VarValue::Unknown { parent: root, rank };
                (root, rank)
            }
            VarValue::Unknown { parent, rank } => (parent, rank),
            VarValue::Known(_) => (idx, 0),
        }
    }

    pub fn probe_value(&mut self, idx: u32) -> Option<T> {
        let (root, _) = self.find(idx);
        match &self.values[root as usize] {
            VarValue::Known(v) => Some(v.clone()),
            VarValue::Unknown { .. } => None,
        }
    }

    pub fn unify(&mut self, a: u32, b: u32) -> Result<(), UnifyError> {
        let (ra, rank_a) = self.find(a);
        let (rb, rank_b) = self.find(b);
        if ra == rb { return Ok(()); }

        let val_a = self.values[ra as usize].clone();
        let val_b = self.values[rb as usize].clone();

        match (&val_a, &val_b) {
            (VarValue::Known(v1), VarValue::Known(v2)) => {
                let merged = T::unify_values(v1, v2)?;
                // Union by rank: attach smaller rank under larger
                let (new_root, child) = if rank_a >= rank_b { (ra, rb) } else { (rb, ra) };
                self.values[new_root as usize] = VarValue::Known(merged);
                self.values[child as usize] = VarValue::Unknown { parent: new_root, rank: 0 };
            }
            (VarValue::Known(v), VarValue::Unknown { .. }) |
            (VarValue::Unknown { .. }, VarValue::Known(v)) => {
                let known_root = if matches!(val_a, VarValue::Known(_)) { ra } else { rb };
                let other = if known_root == ra { rb } else { ra };
                self.values[other as usize] = VarValue::Unknown { parent: known_root, rank: 0 };
            }
            (VarValue::Unknown { .. }, VarValue::Unknown { .. }) => {
                let (new_root, child) = if rank_a >= rank_b { (ra, rb) } else { (rb, ra) };
                let new_rank = if rank_a == rank_b { rank_a + 1 } else { rank_a.max(rank_b) };
                self.values[new_root as usize] = VarValue::Unknown { parent: new_root, rank: new_rank };
                self.values[child as usize] = VarValue::Unknown { parent: new_root, rank: 0 };
            }
        }
        Ok(())
    }

    pub fn assign(&mut self, idx: u32, val: T) -> Result<(), UnifyError> {
        let (root, _) = self.find(idx);
        match &self.values[root as usize] {
            VarValue::Known(existing) => {
                let _ = T::unify_values(existing, &val)?;
                self.values[root as usize] = VarValue::Known(val);
            }
            VarValue::Unknown { .. } => {
                self.values[root as usize] = VarValue::Known(val);
            }
        }
        Ok(())
    }
}

// ---------------------------------------------------------------------------
// Type Unification Value
// ---------------------------------------------------------------------------

#[derive(Clone, Debug, PartialEq)]
pub struct TypeValue {
    pub ty: Ty,
}

impl UnifyValue for TypeValue {
    fn unify_values(a: &Self, b: &Self) -> Result<Self, UnifyError> {
        if a.ty == b.ty {
            Ok(a.clone())
        } else {
            Err(UnifyError)
        }
    }
}

// ---------------------------------------------------------------------------
// InferCtxt: Inference Context
// ---------------------------------------------------------------------------

pub struct InferCtxt<'tcx> {
    pub tcx: &'tcx TyCtxt,
    pub type_table: UnificationTable<TypeValue>,
    pub int_table: UnificationTable<TypeValue>, // for integer literals
    pub float_table: UnificationTable<TypeValue>, // for float literals
    pub const_table: UnificationTable<ConstValue>,
    pub type_var_counter: u32,
    pub int_var_counter: u32,
    pub float_var_counter: u32,
    pub const_var_counter: u32,
    /// Pending obligations that need to be proven.
    pub obligations: Vec<Obligation>,
}

#[derive(Clone, Debug)]
pub struct Obligation {
    pub cause: ObligationCause,
    pub predicate: Predicate,
}

#[derive(Clone, Debug)]
pub struct ObligationCause {
    pub span: Span,
    pub code: ObligationCauseCode,
}

#[derive(Clone, Debug)]
pub enum ObligationCauseCode {
    ExprCheck,
    ReturnType,
    Assignment,
    BuiltinOp,
    WhereClause,
    ItemObligation(DefId),
}

#[derive(Clone, Debug, PartialEq)]
pub struct ConstValue {
    pub val: Const,
}

impl UnifyValue for ConstValue {
    fn unify_values(a: &Self, b: &Self) -> Result<Self, UnifyError> {
        if a.val == b.val {
            Ok(a.clone())
        } else {
            Err(UnifyError)
        }
    }
}

impl<'tcx> InferCtxt<'tcx> {
    pub fn new(tcx: &'tcx TyCtxt) -> Self {
        InferCtxt {
            tcx,
            type_table: UnificationTable::new(),
            int_table: UnificationTable::new(),
            float_table: UnificationTable::new(),
            const_table: UnificationTable::new(),
            type_var_counter: 0,
            int_var_counter: 0,
            float_var_counter: 0,
            const_var_counter: 0,
            obligations: Vec::new(),
        }
    }

    /// Create a fresh type inference variable.
    pub fn new_ty_var(&mut self) -> Ty {
        let vid = self.type_var_counter;
        self.type_var_counter += 1;
        self.type_table.new_key();
        self.tcx.mk_infer(TyVid(vid))
    }

    /// Create a fresh integer variable (for unconstrained integer literals).
    pub fn new_int_var(&mut self) -> Ty {
        let vid = self.int_var_counter;
        self.int_var_counter += 1;
        self.int_table.new_key();
        // We return a special "int variable" type; in a real impl this would be a distinct TyKind.
        self.tcx.mk_infer(TyVid(100000 + vid)) // simplified
    }

    /// Shallow resolve: if `ty` is an infer var, look up its value.
    pub fn shallow_resolve(&mut self, ty: &Ty) -> Ty {
        match &*ty.kind {
            TyKind::Infer(InferTy { vid }) => {
                match self.type_table.probe_value(vid.0) {
                    Some(TypeValue { ty: resolved }) => self.shallow_resolve(&resolved),
                    None => ty.clone(),
                }
            }
            _ => ty.clone(),
        }
    }

    /// Full resolve: recursively resolve all inference variables.
    pub fn fully_resolve(&mut self, ty: &Ty) -> Ty {
        let ty = self.shallow_resolve(ty);
        match &*ty.kind {
            TyKind::Tuple(ts) => {
                let resolved: Vec<Ty> = ts.iter().map(|t| self.fully_resolve(t)).collect();
                self.tcx.mk_tuple(resolved)
            }
            TyKind::Array(t, c) => {
                let rt = self.fully_resolve(t);
                // resolve const too if needed
                self.tcx.mk_ty(TyKind::Array(rt, c.clone()))
            }
            TyKind::Slice(t) => self.tcx.mk_slice(self.fully_resolve(t)),
            TyKind::FnPtr(sig) => {
                let inputs: Vec<Ty> = sig.sig.inputs.iter().map(|t| self.fully_resolve(t)).collect();
                let output = self.fully_resolve(&sig.sig.output);
                self.tcx.mk_fn_ptr(PolyFnSig {
                    bound_vars: sig.bound_vars.clone(),
                    sig: FnSig { inputs, output },
                })
            }
            // ... other variants
            _ => ty,
        }
    }

    /// Unify two types.
    pub fn eq_types(&mut self, a: &Ty, b: &Ty) -> Result<(), TypeError> {
        let a = self.shallow_resolve(a);
        let b = self.shallow_resolve(b);

        if a == b { return Ok(()); }

        match (&*a.kind, &*b.kind) {
            (TyKind::Infer(InferTy { vid: a_vid }), _) => {
                self.type_table.assign(a_vid.0, TypeValue { ty: b.clone() })
                    .map_err(|_| TypeError::Mismatch(a.clone(), b.clone()))?;
                Ok(())
            }
            (_, TyKind::Infer(InferTy { vid: b_vid })) => {
                self.type_table.assign(b_vid.0, TypeValue { ty: a.clone() })
                    .map_err(|_| TypeError::Mismatch(a.clone(), b.clone()))?;
                Ok(())
            }
            (TyKind::Tuple(a_ts), TyKind::Tuple(b_ts)) if a_ts.len() == b_ts.len() => {
                for (a_t, b_t) in a_ts.iter().zip(b_ts.iter()) {
                    self.eq_types(a_t, b_t)?;
                }
                Ok(())
            }
            (TyKind::Adt(a_def, a_args), TyKind::Adt(b_def, b_args)) if a_def == b_def => {
                self.eq_generic_args(a_args, b_args)
            }
            (TyKind::FnPtr(a_sig), TyKind::FnPtr(b_sig)) => {
                if a_sig.sig.inputs.len() != b_sig.sig.inputs.len() {
                    return Err(TypeError::ArgCount);
                }
                for (a_in, b_in) in a_sig.sig.inputs.iter().zip(b_sig.sig.inputs.iter()) {
                    self.eq_types(a_in, b_in)?;
                }
                self.eq_types(&a_sig.sig.output, &b_sig.sig.output)
            }
            // ... more cases
            _ => Err(TypeError::Mismatch(a.clone(), b.clone())),
        }
    }

    fn eq_generic_args(&mut self, a: &GenericArgs, b: &GenericArgs) -> Result<(), TypeError> {
        if a.types.len() != b.types.len() || a.consts.len() != b.consts.len() {
            return Err(TypeError::ArgCount);
        }
        for (a_t, b_t) in a.types.iter().zip(b.types.iter()) {
            self.eq_types(a_t, b_t)?;
        }
        // const equality omitted for brevity
        Ok(())
    }

    /// Register a trait obligation to be proven later.
    pub fn register_obligation(&mut self, cause: ObligationCause, predicate: Predicate) {
        self.obligations.push(Obligation { cause, predicate });
    }
}

#[derive(Debug)]
pub enum TypeError {
    Mismatch(Ty, Ty),
    ArgCount,
    CyclicType(Ty),
}

// =============================================================================
// 3. NEXT-GEN TRAIT SOLVER (rustc_trait_selection::solve equivalent)
// =============================================================================

// ---------------------------------------------------------------------------
// Goals & Responses
// ---------------------------------------------------------------------------

#[derive(Clone, Debug)]
pub struct Goal {
    pub param_env: ParamEnv,
    pub predicate: Predicate,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Certainty {
    Yes,
    Maybe,
    No,
}

#[derive(Clone, Debug)]
pub struct CanonicalResponse {
    pub certainty: Certainty,
    /// Existential constraints: mapping from canonical vars to their values.
    pub var_values: Vec<Option<Ty>>,
    /// External constraints (e.g., outlives — omitted without lifetimes).
    pub external_constraints: ExternalConstraints,
}

#[derive(Clone, Debug, Default)]
pub struct ExternalConstraints {
    pub region_constraints: Vec<()>, // empty without lifetimes
}

#[derive(Clone, Debug)]
pub struct Canonical<T> {
    pub value: T,
    pub binders: Vec<CanonicalVarInfo>,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum CanonicalVarInfo {
    Ty(UniverseIndex),
    Const(UniverseIndex),
}

// ---------------------------------------------------------------------------
// Candidates
// ---------------------------------------------------------------------------

#[derive(Clone, Debug)]
pub enum CandidateSource {
    /// User-written impl.
    Impl(DefId),
    /// Assumption from the param env (where clause).
    ParamEnv(usize),
    /// Built-in trait (e.g., tuples are Clone).
    BuiltIn,
    /// Auto-trait (e.g., Send/Sync — if applicable).
    AutoTrait,
}

#[derive(Clone, Debug)]
pub struct Candidate {
    pub source: CandidateSource,
    /// Nested goals that must be proven for this candidate to apply.
    pub nested_goals: Vec<Goal>,
    /// Instantiated generic args for the impl.
    pub impl_args: GenericArgs,
}

// ---------------------------------------------------------------------------
// EvalCtxt: The Solver Context
// ---------------------------------------------------------------------------

pub struct EvalCtxt<'tcx> {
    pub tcx: &'tcx TyCtxt,
    /// Local inference context for this goal evaluation.
    pub infcx: InferCtxt<'tcx>,
    /// Search graph for cycle detection and provisional caching.
    pub search_graph: SearchGraph,
    /// Global cache for canonical goals.
    pub global_cache: GlobalCache,
    /// Current recursion depth.
    pub recursion_depth: usize,
    pub max_depth: usize,
}

/// A node in the search graph for coinductive cycle detection.
#[derive(Clone, Debug)]
pub struct SearchGraphNode {
    pub goal: Canonical<Goal>,
    pub response: Option<CanonicalResponse>,
    pub stack_depth: usize,
}

pub struct SearchGraph {
    pub stack: Vec<SearchGraphNode>,
}

impl SearchGraph {
    pub fn new() -> Self {
        SearchGraph { stack: Vec::new() }
    }

    pub fn contains(&self, goal: &Canonical<Goal>) -> Option<usize> {
        self.stack.iter().position(|n| n.goal == *goal)
    }
}

pub struct GlobalCache {
    pub entries: HashMap<Canonical<Goal>, CanonicalResponse>,
}

impl GlobalCache {
    pub fn new() -> Self {
        GlobalCache { entries: HashMap::new() }
    }
}

impl<'tcx> EvalCtxt<'tcx> {
    pub fn new(tcx: &'tcx TyCtxt) -> Self {
        EvalCtxt {
            tcx,
            infcx: InferCtxt::new(tcx),
            search_graph: SearchGraph::new(),
            global_cache: GlobalCache::new(),
            recursion_depth: 0,
            max_depth: 100,
        }
    }

    /// Entry point: evaluate a root goal.
    pub fn evaluate_root_goal(&mut self, goal: Goal) -> Result<CanonicalResponse, NoSolution> {
        let canonical = self.canonicalize_goal(goal);
        self.evaluate_canonical_goal(&canonical)
    }

    // -----------------------------------------------------------------------
    // Canonicalization
    // -----------------------------------------------------------------------

    fn canonicalize_goal(&mut self, goal: Goal) -> Canonical<Goal> {
        // Simplified: in a real implementation, replace all inference vars
        // with existential canonical vars and placeholders with universal vars.
        let mut binders = Vec::new();
        let canonical_pred = self.canonicalize_predicate(&goal.predicate, &mut binders);
        Canonical {
            value: Goal {
                param_env: goal.param_env,
                predicate: canonical_pred,
            },
            binders,
        }
    }

    fn canonicalize_predicate(&self, pred: &Predicate, binders: &mut Vec<CanonicalVarInfo>) -> Predicate {
        // Simplified: just clone. Real impl would map infer vars to bound vars.
        pred.clone()
    }

    // -----------------------------------------------------------------------
    // Core evaluation
    // -----------------------------------------------------------------------

    fn evaluate_canonical_goal(&mut self, canonical_goal: &Canonical<Goal>) -> Result<CanonicalResponse, NoSolution> {
        // Check global cache
        if let Some(resp) = self.global_cache.entries.get(canonical_goal) {
            return Ok(resp.clone());
        }

        // Check for cycles
        if let Some(stack_idx) = self.search_graph.contains(canonical_goal) {
            // Coinductive cycle: return ambiguous (provisional)
            return Ok(CanonicalResponse {
                certainty: Certainty::Maybe,
                var_values: vec![],
                external_constraints: ExternalConstraints::default(),
            });
        }

        if self.recursion_depth > self.max_depth {
            return Err(NoSolution);
        }

        // Push onto search graph
        self.search_graph.stack.push(SearchGraphNode {
            goal: canonical_goal.clone(),
            response: None,
            stack_depth: self.recursion_depth,
        });
        self.recursion_depth += 1;

        // Instantiate the canonical goal into the local InferCtxt
        let goal = self.instantiate_canonical_goal(canonical_goal);

        let result = self.compute_goal(&goal);

        self.recursion_depth -= 1;
        self.search_graph.stack.pop();

        let response = result?;

        // Cache successful results
        if response.certainty != Certainty::No {
            self.global_cache.entries.insert(canonical_goal.clone(), response.clone());
        }

        Ok(response)
    }

    fn instantiate_canonical_goal(&mut self, canonical: &Canonical<Goal>) -> Goal {
        // Simplified: in a real impl, instantiate bound vars with fresh infer vars/placeholders.
        canonical.value.clone()
    }

    fn compute_goal(&mut self, goal: &Goal) -> Result<CanonicalResponse, NoSolution> {
        match &goal.predicate.kind {
            PredicateKind::Trait(trait_ref) => {
                self.compute_trait_goal(goal, trait_ref)
            }
            PredicateKind::Projection(proj) => {
                self.compute_projection_goal(goal, proj)
            }
            PredicateKind::Eq(a, b) => {
                match self.infcx.eq_types(a, b) {
                    Ok(()) => Ok(self.make_response(Certainty::Yes)),
                    Err(_) => Err(NoSolution),
                }
            }
            PredicateKind::WellFormed(ty) => {
                self.compute_wf_goal(ty)
            }
            PredicateKind::Subtype(a, b) => {
                // Simplified: treat as equality for now
                match self.infcx.eq_types(a, b) {
                    Ok(()) => Ok(self.make_response(Certainty::Yes)),
                    Err(_) => Err(NoSolution),
                }
            }
        }
    }

    // -----------------------------------------------------------------------
    // Trait Goal
    // -----------------------------------------------------------------------

    fn compute_trait_goal(&mut self, goal: &Goal, trait_ref: &TraitRef) -> Result<CanonicalResponse, NoSolution> {
        let candidates = self.assemble_candidates(goal, trait_ref)?;

        if candidates.is_empty() {
            return Err(NoSolution);
        }

        // Evaluate each candidate in a probe (isolated inference context)
        let mut responses = Vec::new();
        for candidate in candidates {
            match self.probe(|| self.evaluate_candidate(goal, &candidate)) {
                Some(resp) => responses.push(resp),
                None => {}
            }
        }

        self.merge_responses(responses)
    }

    fn assemble_candidates(&mut self, goal: &Goal, trait_ref: &TraitRef) -> Result<Vec<Candidate>, NoSolution> {
        let mut candidates = Vec::new();

        // 1. ParamEnv candidates (where clauses)
        for (idx, bound) in goal.param_env.caller_bounds.iter().enumerate() {
            if let PredicateKind::Trait(bound_trait) = &bound.kind {
                if self.trait_refs_match(bound_trait, trait_ref) {
                    candidates.push(Candidate {
                        source: CandidateSource::ParamEnv(idx),
                        nested_goals: vec![], // where clauses are assumptions
                        impl_args: GenericArgs { types: vec![], consts: vec![] },
                    });
                }
            }
        }

        // 2. Impl candidates (user-written)
        // In a real compiler, look up impls in the trait impl database.
        // Here we simulate finding an impl.
        let self_ty = self.infcx.shallow_resolve(&trait_ref.args.types[0]);
        if let Some(impl_candidate) = self.find_impl_for(trait_ref, &self_ty) {
            candidates.push(impl_candidate);
        }

        // 3. Built-in candidates (e.g., tuples, fn ptrs)
        if self.is_builtin_trait(trait_ref.def_id) {
            if let Some(built_in) = self.try_builtin_candidate(trait_ref, &self_ty) {
                candidates.push(built_in);
            }
        }

        Ok(candidates)
    }

    fn trait_refs_match(&mut self, a: &TraitRef, b: &TraitRef) -> bool {
        if a.def_id != b.def_id { return false; }
        if a.args.types.len() != b.args.types.len() { return false; }
        for (a_t, b_t) in a.args.types.iter().zip(b.args.types.iter()) {
            let a_r = self.infcx.shallow_resolve(a_t);
            let b_r = self.infcx.shallow_resolve(b_t);
            if a_r != b_r { return false; }
        }
        true
    }

    fn find_impl_for(&mut self, trait_ref: &TraitRef, self_ty: &Ty) -> Option<Candidate> {
        // STUB: In a real compiler, query the impl database:
        // `tcx.find_impls(trait_ref.def_id, self_ty)`
        // For demonstration, we simulate a hardcoded `Clone for Vec<T>`.
        None
    }

    fn is_builtin_trait(&self, def_id: DefId) -> bool {
        // STUB: check if def_id is a built-in trait like Sized, Clone, etc.
        false
    }

    fn try_builtin_candidate(&mut self, trait_ref: &TraitRef, self_ty: &Ty) -> Option<Candidate> {
        // STUB: Built-in logic for tuples, arrays, fn ptrs, etc.
        None
    }

    // -----------------------------------------------------------------------
    // Probing & Candidate Evaluation
    // -----------------------------------------------------------------------

    fn probe<F, R>(&mut self, f: F) -> Option<R>
    where
        F: FnOnce(&mut Self) -> Result<R, NoSolution>,
    {
        // Save inference state
        let saved_type_counter = self.infcx.type_var_counter;
        let saved_obligations = self.infcx.obligations.len();
        let saved_depth = self.recursion_depth;

        let result = f(self);

        match result {
            Ok(r) => Some(r),
            Err(_) => {
                // Rollback inference state
                self.infcx.type_var_counter = saved_type_counter;
                self.infcx.obligations.truncate(saved_obligations);
                self.recursion_depth = saved_depth;
                None
            }
        }
    }

    fn evaluate_candidate(&mut self, _goal: &Goal, candidate: &Candidate) -> Result<CanonicalResponse, NoSolution> {
        // Prove all nested goals
        for nested in &candidate.nested_goals {
            let nested_canonical = self.canonicalize_goal(nested.clone());
            self.evaluate_canonical_goal(&nested_canonical)?;
        }
        Ok(self.make_response(Certainty::Yes))
    }

    // -----------------------------------------------------------------------
    // Merging Responses
    // -----------------------------------------------------------------------

    fn merge_responses(&mut self, responses: Vec<CanonicalResponse>) -> Result<CanonicalResponse, NoSolution> {
        if responses.is_empty() {
            return Err(NoSolution);
        }

        // If any response is Yes and all others are Yes with the same constraints, succeed.
        // If all are Maybe, return Maybe.
        // If conflicting Yes responses, that's an ambiguity (or error in coherence).

        let all_yes = responses.iter().all(|r| r.certainty == Certainty::Yes);
        let all_maybe = responses.iter().all(|r| r.certainty == Certainty::Maybe);

        if all_yes {
            // Check if constraints agree (simplified)
            Ok(self.make_response(Certainty::Yes))
        } else if all_maybe {
            Ok(self.make_response(Certainty::Maybe))
        } else {
            // Mixed: ambiguous
            Ok(self.make_response(Certainty::Maybe))
        }
    }

    fn make_response(&self, certainty: Certainty) -> CanonicalResponse {
        CanonicalResponse {
            certainty,
            var_values: vec![],
            external_constraints: ExternalConstraints::default(),
        }
    }

    // -----------------------------------------------------------------------
    // Projection Goal (Normalization)
    // -----------------------------------------------------------------------

    fn compute_projection_goal(&mut self, _goal: &Goal, proj: &ProjectionPredicate) -> Result<CanonicalResponse, NoSolution> {
        // Normalize `<T as Trait>::Assoc` to a concrete type.
        // Steps:
        // 1. Find the applicable impl for the trait.
        // 2. Substitute the associated type from the impl.
        // 3. Recursively normalize the result.

        let alias = &proj.projection_ty;
        let normalized = self.normalize_alias(alias)?;
        self.infcx.eq_types(&normalized, &proj.term)?;
        Ok(self.make_response(Certainty::Yes))
    }

    fn normalize_alias(&mut self, alias: &AliasTy) -> Result<Ty, NoSolution> {
        // STUB: Look up the impl and extract the associated type.
        // In a real compiler, this queries the trait system for the
        // `type Assoc = ConcreteType;` from the selected impl.
        Err(NoSolution)
    }

    // -----------------------------------------------------------------------
    // Well-formedness
    // -----------------------------------------------------------------------

    fn compute_wf_goal(&mut self, ty: &Ty) -> Result<CanonicalResponse, NoSolution> {
        match &*ty.kind {
            TyKind::Adt(def_id, args) => {
                // Check that args satisfy the ADT's bounds
                // STUB: look up ADT definition and check constraints
                Ok(self.make_response(Certainty::Yes))
            }
            TyKind::Tuple(ts) => {
                for t in ts {
                    self.compute_wf_goal(t)?;
                }
                Ok(self.make_response(Certainty::Yes))
            }
            _ => Ok(self.make_response(Certainty::Yes)),
        }
    }
}

#[derive(Debug)]
pub struct NoSolution;

// =============================================================================
// 4. HIR TYPE CHECKER (rustc_hir_typeck equivalent)
// =============================================================================

/// Simplified HIR nodes.
pub mod hir {
    use super::*;

    #[derive(Clone, Debug)]
    pub enum ExprKind {
        Lit(Lit),
        Path(Path),
        Call(Box<Expr>, Vec<Expr>),
        MethodCall(Box<Expr>, Symbol, Vec<Expr>), // receiver, method_name, args
        Binary(BinOp, Box<Expr>, Box<Expr>),
        Unary(UnOp, Box<Expr>),
        Block(Vec<Stmt>, Option<Box<Expr>>),
        If(Box<Expr>, Box<Expr>, Option<Box<Expr>>),
        Tuple(Vec<Expr>),
        Index(Box<Expr>, Box<Expr>),
        Field(Box<Expr>, Symbol),
        Assign(Box<Expr>, Box<Expr>),
        Return(Option<Box<Expr>>),
        Break,
        Continue,
        Loop(Box<Expr>),
        Let(Box<Pat>, Option<Box<Expr>>),
    }

    #[derive(Clone, Debug)]
    pub struct Expr {
        pub kind: ExprKind,
        pub span: Span,
        pub ty: Option<Ty>, // filled in by type checker
    }

    #[derive(Clone, Debug)]
    pub enum Stmt {
        Expr(Box<Expr>),
        Let(Box<Pat>, Option<Box<Expr>>),
    }

    #[derive(Clone, Debug)]
    pub enum PatKind {
        Wild,
        Binding(Symbol, Mutability),
        Tuple(Vec<Pat>),
        Struct(DefId, Vec<(Symbol, Pat)>),
        Lit(Lit),
    }

    #[derive(Clone, Debug)]
    pub struct Pat {
        pub kind: PatKind,
        pub span: Span,
        pub ty: Option<Ty>,
    }

    #[derive(Clone, Debug)]
    pub enum Lit {
        Bool(bool),
        Int(u128, IntTy), // type may be inferred
        Float(f64, FloatTy),
        Str(String),
    }

    #[derive(Clone, Debug)]
    pub struct Path {
        pub segments: Vec<PathSegment>,
    }

    #[derive(Clone, Debug)]
    pub struct PathSegment {
        pub ident: Symbol,
        pub args: Option<GenericArgs>,
    }

    #[derive(Copy, Clone, Debug)]
    pub enum BinOp { Add, Sub, Mul, Div, Eq, Ne, Lt, Le, Gt, Ge, And, Or }

    #[derive(Copy, Clone, Debug)]
    pub enum UnOp { Neg, Not, Deref }

    #[derive(Copy, Clone, Debug)]
    pub enum Mutability { Mut, Not }
}

use hir::*;

// ---------------------------------------------------------------------------
// FnCtxt: Per-function type checking context
// ---------------------------------------------------------------------------

pub struct FnCtxt<'tcx> {
    pub tcx: &'tcx TyCtxt,
    pub infcx: InferCtxt<'tcx>,
    /// Expected return type of the current function.
    pub ret_ty: Ty,
    /// Types for local variables and patterns.
    pub locals: HashMap<Symbol, Ty>,
    /// The type of each expression node (filled in during checking).
    pub node_types: HashMap<Span, Ty>,
}

impl<'tcx> FnCtxt<'tcx> {
    pub fn new(tcx: &'tcx TyCtxt, ret_ty: Ty) -> Self {
        FnCtxt {
            tcx,
            infcx: InferCtxt::new(tcx),
            ret_ty,
            locals: HashMap::new(),
            node_types: HashMap::new(),
        }
    }

    /// Main entry: type check an expression.
    pub fn check_expr(&mut self, expr: &mut Expr) -> Ty {
        let ty = self.check_expr_kind(&mut expr.kind);
        expr.ty = Some(ty.clone());
        self.node_types.insert(expr.span, ty.clone());
        ty
    }

    fn check_expr_kind(&mut self, kind: &mut ExprKind) -> Ty {
        match kind {
            ExprKind::Lit(lit) => self.check_lit(lit),
            ExprKind::Path(path) => self.check_path(path),
            ExprKind::Call(func, args) => self.check_call(func, args),
            ExprKind::MethodCall(receiver, method, args) => {
                self.check_method_call(receiver, *method, args)
            }
            ExprKind::Binary(op, lhs, rhs) => self.check_binary(*op, lhs, rhs),
            ExprKind::Unary(op, expr) => self.check_unary(*op, expr),
            ExprKind::Block(stmts, tail) => self.check_block(stmts, tail.as_deref_mut()),
            ExprKind::If(cond, then_expr, else_expr) => {
                self.check_expr(cond);
                let then_ty = self.check_expr(then_expr);
                if let Some(else_expr) = else_expr {
                    let else_ty = self.check_expr(else_expr);
                    self.infcx.eq_types(&then_ty, &else_ty).unwrap_or_else(|_| {
                        // emit error: if branches must match
                        self.tcx.mk_error()
                    });
                }
                then_ty
            }
            ExprKind::Tuple(exprs) => {
                let tys: Vec<Ty> = exprs.iter_mut().map(|e| self.check_expr(e)).collect();
                self.tcx.mk_tuple(tys)
            }
            ExprKind::Index(base, index) => {
                let base_ty = self.check_expr(base);
                let idx_ty = self.check_expr(index);
                // Check idx_ty is integer
                self.check_index(&base_ty, &idx_ty)
            }
            ExprKind::Field(base, field) => {
                let base_ty = self.check_expr(base);
                self.check_field(&base_ty, *field)
            }
            ExprKind::Assign(lhs, rhs) => {
                let lhs_ty = self.check_expr(lhs);
                let rhs_ty = self.check_expr(rhs);
                self.infcx.eq_types(&lhs_ty, &rhs_ty).unwrap_or_else(|_| self.tcx.mk_error());
                self.tcx.mk_tuple(vec![]) // unit
            }
            ExprKind::Return(expr) => {
                if let Some(e) = expr {
                    let ty = self.check_expr(e);
                    self.infcx.eq_types(&ty, &self.ret_ty).unwrap_or_else(|_| {
                        // emit error: return type mismatch
                    });
                } else {
                    self.infcx.eq_types(&self.tcx.mk_tuple(vec![]), &self.ret_ty).unwrap_or_else(|_| {});
                }
                self.tcx.mk_error() // diverging
            }
            ExprKind::Break | ExprKind::Continue => self.tcx.mk_error(), // diverging
            ExprKind::Loop(body) => {
                self.check_expr(body);
                self.tcx.mk_error() // diverging unless break-with-value
            }
            ExprKind::Let(pat, init) => {
                let init_ty = if let Some(e) = init { self.check_expr(e) } else { self.tcx.mk_error() };
                self.check_pat(pat, &init_ty);
                self.tcx.mk_tuple(vec![]) // unit
            }
        }
    }

    fn check_lit(&mut self, lit: &Lit) -> Ty {
        match lit {
            Lit::Bool(_) => self.tcx.mk_bool(),
            Lit::Int(_, ity) => self.tcx.mk_int(*ity),
            Lit::Float(_, fty) => self.tcx.mk_ty(TyKind::Float(*fty)),
            Lit::Str(_) => self.tcx.mk_ty(TyKind::String),
        }
    }

    fn check_path(&mut self, path: &Path) -> Ty {
        // Look up local, then item.
        if path.segments.len() == 1 {
            let name = path.segments[0].ident;
            if let Some(ty) = self.locals.get(&name) {
                return ty.clone();
            }
        }
        // STUB: resolve to item type from global context
        self.infcx.new_ty_var()
    }

    fn check_call(&mut self, func: &mut Expr, args: &mut [Expr]) -> Ty {
        let func_ty = self.check_expr(func);
        let func_ty = self.infcx.shallow_resolve(&func_ty);

        match &*func_ty.kind {
            TyKind::FnPtr(sig) => {
                if sig.sig.inputs.len() != args.len() {
                    // emit arg count error
                    return self.tcx.mk_error();
                }
                for (arg, expected) in args.iter_mut().zip(sig.sig.inputs.iter()) {
                    let arg_ty = self.check_expr(arg);
                    self.infcx.eq_types(&arg_ty, expected).unwrap_or_else(|_| {});
                }
                sig.sig.output.clone()
            }
            TyKind::FnDef(def_id, generic_args) => {
                // STUB: look up fn signature and instantiate generics
                self.infcx.new_ty_var()
            }
            TyKind::Infer(_) => {
                // Create expected fn type and unify
                let arg_tys: Vec<Ty> = args.iter_mut().map(|a| self.check_expr(a)).collect();
                let ret_ty = self.infcx.new_ty_var();
                let expected_fn = self.tcx.mk_fn_ptr(PolyFnSig {
                    bound_vars: vec![],
                    sig: FnSig { inputs: arg_tys, output: ret_ty.clone() },
                });
                self.infcx.eq_types(&func_ty, &expected_fn).unwrap_or_else(|_| {});
                ret_ty
            }
            _ => {
                // emit error: not callable
                self.tcx.mk_error()
            }
        }
    }

    fn check_method_call(&mut self, receiver: &mut Expr, method: Symbol, args: &mut [Expr]) -> Ty {
        let recv_ty = self.check_expr(receiver);
        let recv_ty = self.infcx.shallow_resolve(&recv_ty);

        // Method probe: find trait methods that could apply.
        // In a real compiler, this queries the method resolution algorithm.
        // For now, we create a fresh var and register a trait obligation.
        let ret_ty = self.infcx.new_ty_var();

        // STUB: Register a trait obligation like `recv_ty: MethodTrait(method, args..., ret_ty)`
        // self.infcx.register_obligation(...);

        ret_ty
    }

    fn check_binary(&mut self, op: BinOp, lhs: &mut Expr, rhs: &mut Expr) -> Ty {
        let lhs_ty = self.check_expr(lhs);
        let rhs_ty = self.check_expr(rhs);

        match op {
            BinOp::Add | BinOp::Sub | BinOp::Mul | BinOp::Div => {
                self.infcx.eq_types(&lhs_ty, &rhs_ty).unwrap_or_else(|_| {});
                // STUB: check that the type supports the operator (via trait or builtin)
                lhs_ty
            }
            BinOp::Eq | BinOp::Ne | BinOp::Lt | BinOp::Le | BinOp::Gt | BinOp::Ge => {
                self.infcx.eq_types(&lhs_ty, &rhs_ty).unwrap_or_else(|_| {});
                self.tcx.mk_bool()
            }
            BinOp::And | BinOp::Or => {
                self.infcx.eq_types(&lhs_ty, &self.tcx.mk_bool()).unwrap_or_else(|_| {});
                self.infcx.eq_types(&rhs_ty, &self.tcx.mk_bool()).unwrap_or_else(|_| {});
                self.tcx.mk_bool()
            }
        }
    }

    fn check_unary(&mut self, op: UnOp, expr: &mut Expr) -> Ty {
        let ty = self.check_expr(expr);
        match op {
            UnOp::Neg => {
                // STUB: check numeric
                ty
            }
            UnOp::Not => {
                self.infcx.eq_types(&ty, &self.tcx.mk_bool()).unwrap_or_else(|_| {});
                self.tcx.mk_bool()
            }
            UnOp::Deref => {
                // STUB: deref coercion / overloaded deref
                self.infcx.new_ty_var()
            }
        }
    }

    fn check_block(&mut self, stmts: &mut [Stmt], tail: Option<&mut Expr>) -> Ty {
        for stmt in stmts.iter_mut() {
            match stmt {
                Stmt::Expr(e) => { self.check_expr(e); }
                Stmt::Let(pat, init) => {
                    let init_ty = if let Some(e) = init { self.check_expr(e) } else { self.tcx.mk_error() };
                    self.check_pat(pat, &init_ty);
                }
            }
        }
        if let Some(tail) = tail {
            self.check_expr(tail)
        } else {
            self.tcx.mk_tuple(vec![]) // unit type
        }
    }

    fn check_pat(&mut self, pat: &mut Pat, expected: &Ty) {
        let ty = match &mut pat.kind {
            PatKind::Wild => expected.clone(),
            PatKind::Binding(name, _mut) => {
                self.locals.insert(*name, expected.clone());
                expected.clone()
            }
            PatKind::Tuple(pats) => {
                if let TyKind::Tuple(tys) = &*expected.kind {
                    if pats.len() == tys.len() {
                        for (p, t) in pats.iter_mut().zip(tys.iter()) {
                            self.check_pat(p, t);
                        }
                    }
                } else {
                    // create expected tuple and unify
                    let expected_tys: Vec<Ty> = (0..pats.len()).map(|_| self.infcx.new_ty_var()).collect();
                    let tuple_ty = self.tcx.mk_tuple(expected_tys.clone());
                    self.infcx.eq_types(expected, &tuple_ty).unwrap_or_else(|_| {});
                    for (p, t) in pats.iter_mut().zip(expected_tys.iter()) {
                        self.check_pat(p, t);
                    }
                }
                expected.clone()
            }
            PatKind::Struct(def_id, fields) => {
                // STUB: look up struct fields and match
                expected.clone()
            }
            PatKind::Lit(lit) => self.check_lit(lit),
        };
        pat.ty = Some(ty);
    }

    fn check_index(&mut self, base_ty: &Ty, idx_ty: &Ty) -> Ty {
        // STUB: check base_ty is array or slice, idx_ty is integer
        self.infcx.new_ty_var()
    }

    fn check_field(&mut self, base_ty: &Ty, field: Symbol) -> Ty {
        // STUB: look up field in ADT
        self.infcx.new_ty_var()
    }

    /// Finalize: resolve all inference variables and check obligations.
    pub fn resolve_body(&mut self) -> Result<(), Vec<TypeError>> {
        let mut errors = Vec::new();

        // Resolve all pending obligations using the trait solver
        let obligations = std::mem::take(&mut self.infcx.obligations);
        for obl in obligations {
            let mut solver = EvalCtxt::new(self.tcx);
            let goal = Goal {
                param_env: ParamEnv::empty(), // simplified
                predicate: obl.predicate,
            };
            match solver.evaluate_root_goal(goal) {
                Ok(resp) if resp.certainty == Certainty::Yes => {}
                _ => {
                    // emit trait error
                    // errors.push(...);
                }
            }
        }

        // Resolve all node types
        for (_span, ty) in self.node_types.iter_mut() {
            *ty = self.infcx.fully_resolve(ty);
        }

        if errors.is_empty() { Ok(()) } else { Err(errors) }
    }
}

// =============================================================================
// 5. COHERENCE (Simplified)
// =============================================================================

pub struct CoherenceChecker<'tcx> {
    pub tcx: &'tcx TyCtxt,
}

impl<'tcx> CoherenceChecker<'tcx> {
    pub fn new(tcx: &'tcx TyCtxt) -> Self {
        CoherenceChecker { tcx }
    }

    /// Check that all impls for the same trait are disjoint.
    pub fn check_impl_overlap(&self, impls: &[TraitImpl]) -> Result<(), CoherenceError> {
        for i in 0..impls.len() {
            for j in (i + 1)..impls.len() {
                if self.impls_overlap(&impls[i], &impls[j])? {
                    return Err(CoherenceError::OverlappingImpls(impls[i].def_id, impls[j].def_id));
                }
            }
        }
        Ok(())
    }

    fn impls_overlap(&self, a: &TraitImpl, b: &TraitImpl) -> Result<bool, CoherenceError> {
        // Simplified: try to unify the Self types of both impls.
        // If they unify and the where clauses don't exclude each other, they overlap.
        let mut infcx = InferCtxt::new(self.tcx);

        let a_self = &a.trait_ref.args.types[0];
        let b_self = &b.trait_ref.args.types[0];

        if infcx.eq_types(a_self, b_self).is_ok() {
            // Check if where clauses are mutually exclusive (negative reasoning)
            // STUB: simplified
            Ok(true)
        } else {
            Ok(false)
        }
    }
}

pub struct TraitImpl {
    pub def_id: DefId,
    pub trait_ref: TraitRef,
    pub where_clauses: Vec<Predicate>,
}

#[derive(Debug)]
pub enum CoherenceError {
    OverlappingImpls(DefId, DefId),
    OrphanRuleViolation(DefId),
}

// =============================================================================
// 6. VARIANCE (Simplified)
// =============================================================================

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Variance {
    Covariant,
    Invariant,
    Contravariant,
    Bivariant,
}

pub struct VarianceSolver;

impl VarianceSolver {
    pub fn solve_for_adt(&self, _def_id: DefId) -> Vec<Variance> {
        // Simplified: most type parameters are invariant unless proven otherwise.
        vec![]
    }
}
