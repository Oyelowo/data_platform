# Macro System Phase 3 Checklist

## Goal
Enable declarative macro invocations in every syntactic position where Rust-like
macros are expected: expression, type, pattern, and item position. Ensure the
implementation is robust, exhaustively tested, and integrated with the rest of
the compiler pipeline.

## Parser support

- [x] `TypeKind::MacroInvocation` variant in `yelang-ast/src/types/type_enum.rs`
- [x] `PatternKind::MacroInvocation` variant in `yelang-ast/src/pattern/types.rs`
- [x] `ItemKind::MacroInvocation` variant in `yelang-ast/src/item/item.rs`
- [x] `Type` parser detects `path!` and produces `TypeKind::MacroInvocation`
- [x] `TypeAtom` parser detects `path!` and produces `TypeKind::MacroInvocation`
- [x] `Pattern` parser detects `path!` and produces `PatternKind::MacroInvocation`
- [x] `Item` parser detects `path!` and produces `ItemKind::MacroInvocation`
- [x] All three delimiters `()`, `[]`, `{}` are accepted after `!`

## Codegen / pretty-printing

- [x] `codegen/types.rs` renders `TypeKind::MacroInvocation` as `path!args`
- [x] `codegen/pattern.rs` renders `PatternKind::MacroInvocation` as `path!args`
- [x] `codegen/items_core.rs` renders `ItemKind::MacroInvocation` as `path!args`

## AST traversal (fold/walk)

- [x] `visit/walk/item.rs` walks `MacroInvocation` in item, type, and pattern position
- [x] `visit/fold/item.rs` folds `MacroInvocation` in item, type, and pattern position

## Macro expansion engine

- [x] `FragmentKind::Stmt` already exists in `yelang-macro/src/matcher/types.rs`
- [x] Follow set for `Stmt` shares the same restrictions as `Expr`
- [x] `expand_macro_invocation` helper returns the raw expanded `TokenStream`
- [x] Fragment re-parsers added:
  - [x] `parse_type_from_token_stream`
  - [x] `parse_pattern_from_token_stream`
  - [x] `parse_items_from_token_stream` (already existed)
  - [x] `parse_expr_from_token_stream` (already existed)
- [x] `expand_type` recursively expands macros inside types
- [x] `expand_pattern` recursively expands macros inside patterns
- [x] `expand_item_deep` returns `Vec<Item>` and expands item-position macros
- [x] `expand_fn_sig` expands parameter patterns/types and return types
- [x] `expand_expr` expands macros inside type casts, ascriptions, `is` tests,
      lambdas, `let` expressions, `for` loops, `match` arm patterns, and
      comprehensions
- [x] `expand_stmt` expands `let` patterns and type annotations
- [x] Module items are recursively expanded through `expand_item`

## Downstream compiler pipeline

- [x] `yelang-resolve` ignores unexpanded `MacroInvocation` nodes in
  `def_collector.rs` and `late.rs`
- [x] `yelang-hir` lowers unexpanded type macros to `TyKind::Err` and skips
  unexpanded item macros

## Tests

- [x] `yelang-macro/tests/declarative_macros_phase3.rs` created
- [x] Type-position tests:
  - [x] let annotation
  - [x] function return type
  - [x] function parameter type
  - [x] generic argument
  - [x] nested expansion
  - [x] type cast position
- [x] Pattern-position tests:
  - [x] let binding
  - [x] function parameter
  - [x] tuple pattern
  - [x] match arm pattern
- [x] Item-position tests:
  - [x] expands to a single function
  - [x] expands to multiple items
  - [x] works inside an inline module
- [x] Error tests:
  - [x] unknown macro in type position
  - [x] macro producing invalid type
  - [x] macro producing invalid pattern
  - [x] macro producing invalid item

## Verification

- [x] `cargo fmt`
- [x] `cargo test -p yelang-ast` passes
- [x] `cargo test -p yelang-macro` passes
- [x] `cargo test` (workspace) passes
