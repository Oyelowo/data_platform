# Query Language — End-to-End Design (HIR → Result)

**Status:** Accepted master plan. Inputs: `notes/syntax_grammar/{complex_query.sql, select.md, pipelining.md, semantics.md}` (+ `native-collection-query-surface.md` for selector extensions). Governs every stage from HIR to execution. Companion docs: `query_language_and_execution_design.md` (principles/decisions D1–D27), `PHASEJ_QIR_STRUCTURE_DESIGN.md` (QIR internals), `PHASEJ_QIR_CHECKLIST.md` (J0–J7), `thir_mir_qir_layering.md` (IR boundaries).

**How to read this doc:** §1 is the full picture. §2 is every surface construct and where it stands. §3 follows one query through every stage with real artifacts. §4 is the per-construct rule matrix (the "how"). §5 is the exhaustive file tree (the "where"). §6 is the consolidated checklist (the "what/why/when").

---

## 1. The full picture

```
┌─ yelang-ast ───────────────────────────────────────────────────────────┐
│ select/from/links/where/group/order/range · create/update/upsert/      │
│ delete/link/unlink · selectors [*][**][where][order][n][slices]        │
└──────────────────────────────┬─────────────────────────────────────────┘
                               ▼  (no query desugaring, ever — D21)
┌─ yelang-hir ───────────────────────────────────────────────────────────┐
│ Expr::Query(QueryId) + side tables (SelectQuery, links, …)             │
│ selectors → Expr::Comprehension (uniform: [*]/[**]/[where])            │
│ Query = opaque leaf in the expr tree → bypasses THIR later             │
└──────────────────────────────┬─────────────────────────────────────────┘
                               ▼
┌─ yelang-tycheck ───────────────────────────────────────────────────────┐
│ result type = type(projection)   · root-label scope in projection (D24)│
│ links → virtual nested fields    · Seq/Coll distinction (D1)           │
│ method resolutions (DefIds)      · volatility checks (D4)              │
└──────────────────────────────┬─────────────────────────────────────────┘
                               ▼
┌─ yelang-qir ── LIR ────────────────────────────────────────────────────┐
│ core methods → operators (lang items, D23) · sugar inlined (D23)       │
│ aggregate impl bodies extracted (D26) · links → Traversal/nest         │
│ REWRITES: normalize → elide → fold → pushdown → decorrelate(BTW'25)    │
│          → groupjoin → distinct                                        │
└──────────────────────────────┬─────────────────────────────────────────┘
                               ▼
┌─ yelang-qir ── PIR ────────────────────────────────────────────────────┐
│ Cascades memo · props(order/partition/location/bounded) · cost ← stats │
│ capabilities asked in-workspace: memory | embedded store | remote      │
└──────────────────────────────┬─────────────────────────────────────────┘
                               ▼
┌─ yelang-qir ── exec ───────────────────────────────────────────────────┐
│ reference interpreter (oracle) · push batches · morsels · spill        │
│ partial/final aggs by class · exchanges (single-node: none)            │
└──────────────────────────────┬─────────────────────────────────────────┘
                               ▼
              one value, typed by the projection — always (D2)
```

Every stage exists to make one guarantee: **the surface grammar is sugar with a
small, closed, optimizable meaning** — and every construct in §2 reduces to it
without special cases.

---

## 2. Surface construct inventory and status

Source: exhaustive extraction of `pipelining.md` (P) and `semantics.md` (S)
with section citations; `native-collection-query-surface.md` (NCQ) flagged
where a construct lives only there. Status: **AST** = parsed today · **TY** =
type-checked today · **LIR** = lowering path designed (this doc/PHASEJ) ·
**DEF** = deferred by design decision.

### 2.1 Query skeleton
| construct | example | status | §4 rule |
|---|---|---|---|
| `select <proj> from … [links] [where] [group by … into] [order by] [range]` | — | AST, TY | R0 |
| mandatory `from` (no rootless `select 1`) | `select 1 from users@u:User` → `1` | AST, TY | R0 |
| collection label vs item binder | `users` (many) vs `u` (one) | TY | R1 |
| single-root scan + from-filter | `from (users@u:User where u.age > 50)` | AST, TY | R2 |
| parenthesized FROM modifiers (pre-links shaping) | `from (users@u:User order by u.name range 0..=10)` | AST, TY | R2 |
| multi-root facets (no implicit product) | `from users@u:User, books@b:Book` | AST, TY | R3 |
| per-root tails | `for users { order by u.id asc range ..10 }` | AST, TY | R3 |
| projection subqueries (facets) | `users: (select … from …)` | AST, TY | R3 |

### 2.2 Selectors (operand must be a *many* value)
| construct | meaning | status | §4 rule |
|---|---|---|---|
| `@u[*]` iterate/map | `users@u[*].expr` ≈ `map(\|u\| expr)` | AST, TY | R4 |
| `@u[**]`, `[***]`… | flat_map, depth = stars−1 | AST, TY | R4 |
| `[where pred]` | filter, keeps `Array<T>` | AST, TY | R4 |
| `[n]` index | scalar; OOB = **runtime error**; bare `[n]` on unordered = nondeterministic by design | AST, TY | R4 |
| slices `[a..b]`, `[..b]`, `[a..]`, `[a..=b]` | many value, same order rule | AST, TY | R4 |
| `[order by …]` selector | value-level order | AST | R4 |
| `[distinct]`, `[enumerate]`, `[group by …]` selector | NCQ only | **not in P/S** | R4 (later) |
| `[*]` elision after collection-preserving selectors | `users@u[where …].id` ≡ `[*].id` | NCQ only | R4 (later) |

### 2.3 LINKS (correlated traversal → virtual nested fields)
| construct | rule | status | §4 rule |
|---|---|---|---|
| `(users)->[writes@w:E]->(books@b:B)` | attaches `writes` per user, `books` per edge (strict locality) | AST, TY | R5 |
| anchor = reference only | `links (users)->…` ✓; `links (users@u:User)->…` ✗ rejected | AST, TY | R5 |
| directions `->`, `<-`, `<->` | endpoint matching `_from`/`_to`; `<->` either-direction | AST, TY | R5 |
| segment predicates | `(users where u.age>50)->[w where w.date > u.dob]->` gates traversal per parent; never removes parents | AST, TY | R5 |
| multiple comma paths | left-to-right; later paths may anchor on earlier sibling labels | AST, TY | R5 |
| sibling merge rule | empty contribution never overwrites non-empty; non-empty+non-empty merge union-like | AST | R5 |
| node-to-node hop `(a)->(b)` | broadcast/attachment, **not** id-correlation | AST | R5 |
| union edge `[e:(A \| B)]` | union-typed binder; split via `is(e, A)` type guard | AST, TY | R5 |
| `links inner` | clause-wide required-match; no mixed optional/required | AST, TY | R5 |
| `hops 1..=3` (bounded recursion) | NCQ + one `unlink` example in S | **partial** | R5 (later) |
| variable-length/recursive | P §10 deferred | **DEF** | R5 (v2) |

### 2.4 WHERE / predicates
| construct | rule | status | §4 rule |
|---|---|---|---|
| pipeline `where` | stage-affecting: filters roots before group/order/range | AST, TY | R6 |
| selector `[where]` | value-level: never retroactively constrains earlier stages | AST, TY | R6 |
| `.any/.all/.none/.is_empty` | existential idioms; closure param = element; short-circuit observable with erroring predicates | AST, TY | R6 |

### 2.5 GROUP BY … INTO
| construct | rule | status | §4 rule |
|---|---|---|---|
| `group by { k: expr, … } into <label>` | group objects: keys + members under root label | AST, TY | R7 |
| having | none — filter groups in projection: `groups@g[where len(g.users) > 10]` | TY | R7 |
| multiple specs, one clause | `group by {…} into a, {…} into b` | AST, TY | R7 |
| target inference | keys reference exactly one root binder → that root; constant keys → first root; mixed roots → error | TY | R7 |
| computed keys / linked keys | `decade: (u.age/10)*10`, `wrote_any: len(u.writes@w[*]…)>0` | TY | R7 |
| key scoping | keys use pre-group binders; `g` exists only after | TY | R7 |
| key type restriction | orderable primitives (i64/bool/string/unit) — placeholder limit | TY | R7 (lift) |

### 2.6 ORDER / RANGE
| construct | rule | status | §4 rule |
|---|---|---|---|
| `order by … [asc\|desc]` | only explicit order is guaranteed; ties → **stable sort** | AST, TY | R8 |
| `range a..b` | Seq only (D1); doesn't change types; literal bounds pipeline-native | AST, TY | R8 |
| top-level tails on multi-root | **rejected ambiguous** — use `for <root>{}` | TY | R3/R8 |
| global order on distributed | coordination barrier: Exchange Gather/Merge | plan note | R8 |

### 2.7 Projections & paths
| construct | rule | status | §4 rule |
|---|---|---|---|
| `.field` / `.{…}` on *one* value only | `array.field` = type error; use `array@t[*].field` | TY | R9 |
| object projection `.{ a, b: expr, c: block }` | shorthand/rename/computed; block values allowed | AST, TY | R9 |
| nested projections | `u.writes@w[*].books@b[**].{ … }` | AST, TY | R9 |
| optional chaining `?.` | stays Option-level; not SQL null-rewriting | AST, TY | R9 |
| mid-path binders | `users@u[*].writes@w[**].books@b[**]` | AST, TY | R9 |

### 2.8 Aggregates & predicates (ordinary functions, no DSL)
`len/count/sum/avg/min/max` + user UDAs via `Aggregate` (D26) — see R10.

### 2.9 Mutations (S §7–§8, locked)
| construct | default result | status | §4 rule |
|---|---|---|---|
| `create x@b:T {…}` / `[{…}]` | `T` / `[T]` | AST, TY | R11 |
| `upsert` (same shape) | `T` / `[T]` | AST, TY | R11 |
| `update … set …` / `{ patch }` | `i64` count | AST, TY | R11 |
| `delete … where …` | `i64` count | AST, TY | R11 |
| `link (a)->[e:E {}]->(b)` / `unlink` | `i64` count | AST, TY | R11 |
| block form `{ <mutation>; <tail-expr> }` | tail type; `@binder` NOT in tail | AST, TY | R11 |

### 2.10 Explicitly deferred (P §10 — keep deferred)
fork blocks in links · `distinct(array)`/`unique_by` as stdlib fns (no syntax) ·
dedicated semi-join syntax · variable-length recursive traversal · `expect_one`.

---

## 3. One query, every stage (the running example)

From the real grammar — links + group-by + nested selector chains + having:

```rust
// ── SOURCE (yelang) ────────────────────────────────────────────
select groups@g[where len(g.users) > 2][*].{
  city: g.city,
  writers: g.users@u[*].{
    id: u.id,
    tech_titles: u.writes@w[*].books@b[**][where b.genre == "Tech"].title,
  },
}
from users@u:User
links (users)->[writes@w:UserWritesBook]->(books@b:Book)
where u.age > 18
group by { city: u.city } into groups
```

**① AST (`yelang-ast/query/select/types.rs`)** — surface structure, nothing
desugared:

```rust
SelectQ {
  projection: Object([ city: g.city, writers: g.users@u[*].{…} ]),
  from: [FromNode { source: users, bind: u, ty: User }],
  links: [ (users) ->[writes@w:UserWritesBook]-> (books@b:Book) ],
  where_clause: u.age > 18,
  group_by: GroupByClause { keys: { city: u.city }, into: groups },
}
```

**② HIR (`yelang-hir/hir/query.rs`)** — `Expr::Query(id)`; selectors become
uniform `Expr::Comprehension`:

```rust
// g.users@u[*].{…}              → Comprehension { element: u, map: {…} }
// u.writes@w[*].books@b[**]     → Comprehension { element: w, flat_map: books, flatten: 1 }
// [where b.genre == "Tech"]     → Comprehension { condition: b.genre == "Tech" }
```

**③ tycheck** — the facts that drive everything later:

```rust
scope(projection)   = { users, groups }              // root labels only (D24)
scope(where, keys)  = { users, u }                   // element context
links               = virtual fields: User.writes: Coll[UserWritesBook],
                                       UserWritesBook.books: Coll[Book]
result type         = Coll<{ city: String,
                        writers: Coll<{ id: UserId, tech_titles: Coll[String]> } }>
                    // = type(projection). group by/where/links influence nothing else.
```

**④ LIR (before rewrites)** — correlation is explicit:

```rust
Map {
  proj: |g| { city: g.city,
              writers: Map(g.users, |u| { id: u.id,
                tech_titles: DependentPlan(u) /* per-user traversal */ }) },
  input: GroupBy {
    input: AttachField {                          // links materialization
      input: Filter { pred: |u| u.age > 18, input: Scan(users) },
      field: writes,                              // per-user nested Coll
      value_plan: Traversal { edge: UserWritesBook, then: AttachField(books) },
    },
    keys: { city: |u| u.city }, members: users,
  },
}
// the having filter [where len(g.users) > 2] is a Filter on the groups Coll
```

**⑤ LIR (after normalize + decorrelate)** — the per-user nested traversal is a
dependent plan; BTW'25 turns it into one flat pass + nest:

```rust
GroupBy { keys: { city }, members: users,
  input: AttachField {                            // books per write-edge:
    input: AttachField {                          // writes per user:
      input: Filter(Scan(users), |u| u.age > 18),
      field: writes,
      value_plan: Nest(                           // decorrelated: ONE join, not per-user loops
        Join { Scan(users'), EdgeIndexScan(UserWritesBook),
               on: w._from == u.id },
        by: u.id ) },
    field: books, value_plan: Nest( Join(writes, books, on: b.id == w._to), by: w.id ),
  },
}
// then Map(groups, |g| {…}) unchanged — projection is never restructured (D2)
```

**⑥ PIR (single node vs 3 shards)** — same LIR, location decides:

```rust
// single node:  Scan → Filter → EdgeIndexExpand×2 → HashGroupBy(city) → Project
// 3 shards:     Fragment@shard: Filter → expand → PartialGroupBy(city)
//               Exchange::Shuffle(by: city)         // bounded, credit-controlled
//               Final: HashGroupBy-merge → Project → result
// having-filter (len(g.users) > 2) rides along as a post-group Filter;
// [where b.genre == "Tech"] pushes into the edge/book expansion (pushdown).
```

**⑦ exec → result** — push batches, one hash table for the group-by, nested
collections built by `Nest` (sorted-run materialization, no N+1):

```rust
Coll[{
  city: "Lagos",
  writers: Coll[
    { id: User:1, tech_titles: Coll["Advanced SQL", "Introduction to AI"] },
    …
  ],
}, …]
```

Each stage contributed exactly one thing: AST = fidelity, HIR = uniform
comprehensions, tycheck = the type/scoping truth, LIR = the closed algebra,
rewrites = correlation removal + fusion, PIR = location/physical choice,
exec = batches. No stage re-does another's job.

---

## 4. Per-construct rule matrix (the "how")

### R0 — skeleton & the projection rule
- `select` requires `from` (parse-level). Result type = `type(projection)`;
  pipeline introduces names only. `select 1 from users@u:User` : `Int`.
- Elision: bindings the projection doesn't consume are dead at physical time
  (`select 1` reads zero rows) but fully type-checked (D2).

### R1 — labels vs binders (scope truth)
- **Collection labels** (`users`, `writes`, `groups`): in scope in the
  projection and whole-collection positions (`len(users)`, slices).
- **Item binders** (`u`, `w`, `b`): element contexts ONLY — `[where]`, `[*]`-or-
  `[**]`-right-of, `where`, `order by` keys, `group by` keys, `from`-filters,
  links segment predicates, `for`-blocks. **Never the bare projection** (D24):
  `select u from users@u` = compile error suggesting `users[*]`.
- Statement-wide identity: one introduction per label/binder identity;
  redeclaring a binder = compile error (P:321-323).
- Segment binders never leak into outer clauses (P:560) — enforced by scope
  popping at clause boundaries in tycheck.

### R2 — from
- Root filter = base-scan predicate: `from (users@u:User where u.age > 50)` →
  `Filter` directly on `Scan` (pushdown's best case).
- Parenthesized modifiers (`order by`, `range`) shape the base scan BEFORE
  links/group — distinct phase from `for`-blocks (P:825-836). Lower to
  `TopN`/`Limit` wrapping the `Scan`.

### R3 — multi-root & facets
- Multi-root = **independent** sources; NO implicit cross product (P:145-164).
  Correlation only via `links` or explicit expressions. LIR: `Construct {
  fields: [(users, plan₁), (books, plan₂)] }` — not `CrossJoin`.
  (An explicit `cross(a, b)` stdlib fn may exist later; never implicit.)
- Top-level `where/order/range` on multi-root = **compile error, ambiguous**;
  `for <root> { where? order? range? }` only, root-local, post-links, each
  root ≤ once (P:801-836).
- Facet subqueries in projections: independent nested selects, each typed by
  its own projection; lowering treats them as independent plan branches.

### R4 — selectors
| selector | LIR | legality notes |
|---|---|---|
| `xs@x[*].f` | `Map(xs, \|x\| f)` | operand must be many |
| `xs@x[**]` (n stars) | `FlatMap(xs, levels = n−1)` | n≥2; final-projection `[**]` sets `PhysStreamUnit::Leaf` hint |
| `xs@x[where p]` | `Filter(xs, \|x\| p)` | value-level: no retroactive constraint |
| `xs[order by k]` | `OrderBy` | value-level order |
| `xs[n]` | scalar index; OOB = **runtime error** (D3: no implicit Option) | bare `[n]` on `Coll` = nondeterministic *by spec* (S:264-283); on `Seq` deterministic. `.get(n)` → `Option` (NCQ) |
| slices | `Limit`/`Range` | `Seq` preferred; bare slice on `Coll` inherits nondeterminism |
| `[distinct]`/`[enumerate]`/`[group by]`/`[*]`-elision | NCQ forms — land with J4/J5 (`Distinct`, `Window/Enumerate`, sugar→`group_by`) | later |

### R5 — links (the graph surface)
Grounded in ISO/IEC 39075:2024 (GQL) and the GQL/SQL-PGQ formalization
(Deutsch et al., Bayreuth): pattern matching compiles to joins; nested
materialization is the property-graph "group-by-parent" — our two strategies:

- **LIR:** each segment = `Traversal { edge, direction, hops }` producing a
  per-parent nested collection; attached to the parent plan via
  `AttachField`. This is the *logical* form — strict locality is structural,
  never a rewrite concern.
- **Physical choice 1 (edge index present):** `TraversalExpand` operator —
  adjacency lookup per parent key, morsel-parallel, no join.
- **Physical choice 2 (no edge index):** rewrite to `Join + Nest(by: parent)`
  (as in §3⑤). Same results, different strategy — the select.md contract
  ("execution strategy choice must not change the observed result").
- **Correlated alternative:** when a traversal appears only inside a
  per-element context (projection/any), it may instead lower as a
  `DependentJoin` and ride the BTW'25 decorrelator. The planner picks
  Traversal/Nest vs decorrelated join by cost + stats.
- **Anchor rule** (reference-only, no re-typing, no rotation): resolution
  rule in HIR/tycheck — rejected forms are compile errors (P:247-263,
  S:878-908).
- **Segment predicates:** gate the traversal per parent (predicate moves into
  the `Traversal`/join's parent side); never filter the parent collection
  itself (S:517-576).
- **Directions:** `->` = `_from == parent.id` reach `_to`; `<-` converse;
  `<->` = union of both (duplicates possible by spec; user dedups, S:466).
- **Union edge** `[e:(A|B)]`: binder has union type; `is(e, A)` type-guard in
  predicates; lowering = union of per-type expansions (`UnionAll`).
- **Multi-path merge:** per parent, later sibling paths merge into the same
  nested field union-like; empty never overwrites non-empty (P:414, S:567-570)
  — a full-outer-style merge at the nest level.
- **Node-to-node `(a)->(b)`:** broadcast attach (no id correlation).
- **`links inner`:** required-match → inner-join semantics for the whole
  chain; default optional → left-outer (empty arrays for missing).
- **`hops 1..=3` (later):** bounded unroll of the expansion; true
  variable-length = fixpoint operator, deferred (P §10, NCQ `RecursiveExpand`).

### R6 — where / any / all
- Pipeline `where` = `Filter` on the root plan (stage-affecting).
- `.any(|x| p)` / `.all` / `.none` / `.is_empty` on a correlated collection:
  candidates for Semi/Mark/Anti-join conversion during decorrelation
  (P:469-472, S:348-351).
- **Legality constraint (do not violate):** `any`/`all` short-circuit is
  *observable* when predicates can error (`b.tags[0]` on empty). Conversion
  to joins is only legal when the predicate is total/error-free for the
  evaluated candidates (P:467, S:345-346). Mark-join conversion carries an
  error-preservation proof obligation in its rule.
- Prefer segment predicates / selector filtering over pipeline-where for
  links-heavy conditions (P:474-476) — guidance, lints later.

### R7 — group by … into
- One `GroupBy` per spec; group records `{ keys…, <root label>: members }`.
- Multiple specs in one clause = independent `GroupBy` branches under
  `Construct` (P:588-600).
- Target inference (tycheck): keys reference exactly one root binder → group
  that root; zero → first root; ≥2 → compile error (P:576-586).
- `having` = `Filter` on the groups collection in the projection — no clause.
- Linked-value keys are fine when scalar per parent (`len(u.writes@w[*]…)`);
  many-valued keys must be flattened/re-rooted explicitly (P:740-742).
- Current key-type restriction (orderable primitives) is a placeholder —
  lifted to `Eq + Hash`/`Ord` trait bounds in J4 (D-series main doc §4.5).
- Members materialization is demand-driven: projection reads only
  `count(g.users)` → no member array built (§Case A earlier; elision).

### R8 — order / range
- `OrderBy` = Coll→Seq; stable sort (ties preserve input order, P:796).
- `OrderBy + Limit → TopN` fusion in normalize; decorrelation sees only TopN
  (per-group TopN via partition=correlation cols; ROW_NUMBER fallback).
- `range` requires `Seq` (type error on Coll); `a..b` → `Limit{offset:a,
  count:b−a}`; non-literal bounds allowed only at value level (P:76-103).
- Global order on distributed input = `Exchange::Gather` + merge (documented
  coordination barrier, P:797-800).
- Bare `[n]`/slice on unordered collections is **specified nondeterminism** —
  the docs and diagnostics must say so; `--shuffle-coll-batches` test mode
  keeps us honest (D1/main doc §14).

### R9 — projections & paths
- `.` / `.{…}` require a *one* value (type error on many) — enforced today.
- Object projections build `Record`; block-valued fields lower as ordinary
  let-blocks inside `QExpr::Closure` bodies (Froid-style inlining).
- `?.` stays Option-chaining in QExpr (`OptionSome/None`, `map`/`and_then`
  shapes) — never SQL null-propagation (D3).
- Mid-path binders (`a@x[*].b@y[**].c@z[**]`) chain comprehensions with
  explicit flatten levels; nested-array mistakes (`[[Book]].id`) are type
  errors with the flatten hint (S:159-195).

### R10 — aggregates
- Everything through `Queryable::aggregate` (core lang item) + `Aggregate`
  impl extraction (D23/D26). `len` is canonical; `math::count` acceptable
  alias (S:972-985).
- Aggregates over group members (`g.users@u[*].age.sum()`) extract into
  `GroupBy.aggs`; class drives partial/final/exchange (§5 PHASEJ).
- Empty-input = `finish(init())` per impl; `min/max` → `Option` (D3).

### R11 — mutations
- Statement + block forms; default results pinned: create/upsert → `T`/`[T]`,
  update/delete/link/unlink → `i64`; block tail = the value, `@binder` absent
  from tail scope (S:1006-1057).
- Lowering: read-side (where/match set) = normal query pipeline; write-side =
  storage-engine mutation operator applied per matched row, inside the
  statement's transaction (D20). Land with the storage engine (post-J7);
  until then tycheck validates them and QIR rejects with structured errors —
  never silent (J1.9).
- `link`/`unlink` node patterns are scans (anchor rule does not apply,
  S:550); `hops` on edge segments here lands with R5-hops.

### R12 — streaming hint
- Final-projection `[**]`+ sets `PhysStreamUnit::Leaf` (leaf-granularity
  streaming unit) — a planning hint only, never semantic (P:34-35, S:326-327).

---

## 5. Exhaustive file tree (HIR and beyond)

Status: ✅ working · ◐ partial · ☐ skeleton (doc-only) · ⛔ deleted in J0 ·
⊘ does not exist yet.

### 5.1 `yelang-ast` (surface — stable; one deletion)

```
yelang-ast/src/query/
├── mod.rs                 ✅ node exports
├── types.rs               ✅ shared query types
├── parse.rs               ✅ clause parsing helpers
├── select/{mod,parse,types,tests}.rs  ✅ full select grammar
├── create.rs update.rs upsert.rs delete.rs link.rs unlink.rs  ✅ mutations
├── insert.rs              ✅
└── desugar.rs             ⛔ J0.5 — deleted (aggregate AST desugar; D21)
```

### 5.2 `yelang-hir` (uniform comprehensions + side-tabled queries)

```
yelang-hir/src/
├── hir/query.rs           ✅ SelectQuery/FromNode/links/GroupByClause/…
├── hir/expr.rs            ✅ Expr::Query(QueryId), Expr::Comprehension
├── lowering/expr.rs       ◐ selectors → Comprehension; + J0.10 scope split
├── lowering/item.rs       ✅
├── derive/                ✅ built-in derives (Clone/Debug/Eq/…)
│   └── helpers.rs         ◐ J0.11 — generics/attrs params, arena DefIds
└── (no THIR here — it is a MIR-phase crate; see thir_mir_qir_layering.md)
```

### 5.3 `yelang-tycheck` (the truth about queries)

```
yelang-tycheck/src/
├── check.rs               ◐ check_query/check_select_query/…  + J0.10
│                              projection=root-label scope (D24)
├── array_builtins.rs      ✅ len/count/is_empty/any/all
├── fn_ctxt.rs             ✅ inference context
├── method.rs              ✅ method resolution → TypeckResults (drives J0.9)
└── typeck_results.rs      ✅ resolution facts consumed by QIR lowering
```

### 5.4 `yelang-qir` (full tree = PHASEJ §9; roles)

```
src/
├── lib.rs errors.rs ids.rs
├── expr/          ☐ QExpr (no Null, Option ctors, Volatility, Closure,
│                    Subplan) + visit/fold/binder/print
├── lir/           ◐ operator/aggregate/props/plan (+ legacy: shape,
│                    iterator, stdlib, aggregate_impl ⛔J0.6)
│   ├── lower/     ◐ mod(LoweringCtxt, J1.0 TypedView) query selector expr
│   │              method(J0.8/9) links closure aggregate(J0.6 extraction)
│   │              queryable ⛔(merged into method)
│   └── analyze/   ☐ demand correlation(LCA/accessing) keys
├── rewrite/       ◐ runner + normalize elision fold pushdown decorrelate(+)
│                    topn equiv groupjoin distinct (+ your 8 existing passes
│                    to be folded into these)
├── pir/           ☐ operator props plan memo tasks cost stats capability
│                    registry + rules/{scans,joins,aggregate,sort,exchange,
│                    window} (+ legacy planner/enforcers)
├── exec/          ☐ batch value pipeline morsel memory spill interpreter
│                    primitives/{arith,cmp,bool,str,cast}
│                    operators/{scan,filter,project,hash_table,hash_join,
│                    merge_join,nested_loop,hash_aggregate,group_join,sort,
│                    window,exchange,distinct,limit,traversal}
│                    (+ legacy: interface, memory_executor, plan, operator,
│                    exchange, kernels→primitives/mod)
├── backend/       ☐ memory remote (+ legacy storage/stream backends)
└── util/          ◐ arena graph(LCA/topo) explain (+ legacy print/subst/…)
tests/             ◐ 14 skeleton suites with case IDs + existing suites
```

### 5.5 `yelang-store` (⊘ new crate — the embedded storage engine)

```
yelang-store/src/
├── lib.rs               storage engine facade; registers as QIR backend
├── page/                columnar pages, zone maps (min/max), compression
├── mvcc.rs              snapshots (D20): every query reads one snapshot
├── index/               btree + edge index (adjacency: _from/_to → rows)
├── wal.rs               write-ahead log
├── mutation.rs          create/update/upsert/delete/link/unlink apply
├── capability.rs        impl yelang_qir::pir::BackendCapability
├── executor.rs          impl FragmentExecutor (scan/pushdown/traversal)
└── stats.rs             samples, cardinalities → planner
```

### 5.6 `yelang-driver` (pipeline + end-to-end tests)

```
yelang-driver/
├── src/{driver,error,stdlib}.rs  ✅ wiring parse→…→qir
└── tests/
    ├── end_to_end_query_tests.rs ✅
    ├── source_aggregate_tests.rs ◐ J0.5 migrate sum(x)→sum(users) forms
    └── query_semantics_tests.rs  ⊘ the §6 semantics matrix as e2e
```

---

## 6. Consolidated checklist — what / why / how

Aligned with PHASEJ J0–J7 (unchanged); this section adds the **surface-coverage**
items the grammar inventory makes mandatory. Each item: what → why → exit test.

### Stage S0 (lands inside J0) — semantics corrections
- ☐ S0.1 Projection scope = root labels only (`select u` → error + suggestion)
  → D24 → T-SCOPE-01…08.
- ☐ S0.2 `from` mandatory already at parse; keep rootless-select error message.
- ☐ S0.3 `sum(u)` (aggregate over element) → type error + `sum(users)` hint.

### Stage S1 (J1) — lowering of the full grammar
- ☐ S1.1 Selectors: `[*]`/`[**]` (n stars)/`[where]`/slices/`[order by]` →
  Map/FlatMap(levels)/Filter/Limit/OrderBy. → R4 → T-LOW-07.
- ☐ S1.2 `[n]` scalar index with OOB runtime error + nondeterministic-on-Coll
  contract (docs + diagnostics). → R4 → semantics.rs.
- ☐ S1.3 Links: all §2.3 forms except hops — anchor rule errors, directions,
  segment predicates (parent-gating), multi-path + sibling merge rule,
  node-to-node broadcast, union edges + `is(e,T)` guard, `links inner`.
  → R5 → lowering_query.rs golden plans.
- ☐ S1.4 Multi-root → `Construct` (no CrossJoin); top-level tails rejected;
  `for <root>{}` root-local post-links. → R3 → T-LOW-02.
- ☐ S1.5 Group-by: single/multi specs, target inference (0/1/≥2 roots),
  linked scalar keys, having-as-filter, `g.key()/g.items()` + root-label
  members. → R7 → T-LOW-04.
- ☐ S1.6 Facets/nested selects as independent branches; block-valued
  projection fields inline as closures. → R3/R9.
- ☐ S1.7 Mutations: tycheck-validated; QIR emits structured "storage engine
  not linked" errors. → R11 → T-LOW-10.

### Stage S2 (J2–J3) — rewrites honoring surface semantics
- ☐ S2.1 Value-level vs stage-affecting legality: never move `[where]`/
  `[order by]`/slice selectors across stage boundaries unless
  semantics-preserving (P:483-531). → normalize rules carry the check.
- ☐ S2.2 `any/all/none/is_empty` → Semi/Mark/Anti conversions ONLY with the
  error-preservation proof (short-circuit observability, P:467). →
  decorrelate.rs legality gate + T-DECOR-23/24.
- ☐ S2.3 Links-as-dependent-plans: traversal inside element contexts may
  lower as DependentJoin → BTW'25 (per-group TopN for `[order by]`+slice
  inside nested chains). → T-DECOR-12/21.
- ☐ S2.4 Sibling links merge preserved under rewrites (union-like,
  empty-never-overwrites). → T-DECOR-15 variant.
- ☐ S2.5 Elision respects links: unattached virtual fields demanded by
  nothing → traversal never executed. → T-ELIDE-02.

### Stage S3 (J4–J5) — grouping/aggregation/order complete
- ☐ S3.1 Group-member demand analysis (count-only → no member arrays). →
  T-AGG-18.
- ☐ S3.2 Key-type restriction lifted: orderable primitives → `Eq+Hash`/`Ord`
  bounds. → T-AGG-*.
- ☐ S3.3 Stable sort everywhere; determinism contract tests under
  `--shuffle-coll-batches`. → T-ORD-05.
- ☐ S3.4 `[distinct]`/`[enumerate]`/`[group by]` selector sugar + `[*]`-elision
  (NCQ) land here as lowering sugar → core ops. → lowering_method.rs.
- ☐ S3.5 `rank_by`/window surface (NCQ) → `Window` operator. → J5 follow-on.

### Stage S4 (J6–J7) — physical/exec honoring the grammar
- ☐ S4.1 TraversalExpand operator + Join+Nest fallback, chosen by capability
  (edge index present?) and cost. → T-EXEC-16.
- ☐ S4.2 Global order on distributed = Gather+Merge; documented in EXPLAIN.
  → T-PIR-07.
- ☐ S4.3 `PhysStreamUnit::Leaf` hint wired from final-projection `[**]`.
  → planner flag test.
- ☐ S4.4 Nondeterministic bare `[n]` on Coll honored by both executors
  (differential harness asserts *set* containment, not index position).
  → T-DIFF-02.
- ☐ S4.5 Mutations against yelang-store: matched-set pipeline + apply
  operator, one snapshot/tx per statement. → store integration tests.

### Stage S5 (⊘ yelang-store) — the embedded engine
- ☐ S5.1 columnar pages + zone maps · ☐ S5.2 MVCC snapshots ·
  ☐ S5.3 btree + edge index · ☐ S5.4 capability + fragment executor ·
  ☐ S5.5 stats feeding the planner · ☐ S5.6 WAL + statement tx.

---

## 7. References (this doc's claims)

Semantics/grammar: `pipelining.md`, `semantics.md`, `select.md`,
`native-collection-query-surface.md` (all local; section-cited above).

Graph surface grounding: ISO/IEC 39075:2024 (GQL) — pattern matching,
path modes; Deutsch et al., *Graph Pattern Matching in GQL and SQL/PGQ*
(Bayreuth, 2021) — patterns compile to joins (our R5 choice 2); Cypher 25 /
GQL conformance discussions (Nebula, ArcadeDB roadmaps — what a greenfield
should bake in early: path modes, union labels, inline predicates).

Comprehensions/algebra: Wong (Kleisli), Libkin & Wong JCSS'97, Cheney/
Lindley/Wadler, Fegaras & Maier, Fegaras *An Algebra for Distributed Big
Data Analytics* (MRQL algebra — merge-associativity law for distributed
aggregation = our `Aggregate.class` contract).

Decorrelation/optimization: Neumann BTW'25 + arXiv:2412.04294 (the §4
rule table; per-group TopN; window decorrelation; union-find substitution);
Fent & Neumann PVLDB'21 (groupjoin); Galindo-Legaria & Joshi SIGMOD'01;
Graefe Cascades; Moerkotte & Neumann DPccp; Leis et al. JOB VLDB'15.

Execution: Leis et al. SIGMOD'14 (morsels); Kersten et al. VLDB'18
(vectorized vs compiled); Birler et al. PVLDB'24 (diamond joins); Birler
et al. DaMoN'24 (unchained hash tables); Kuschewski et al. SIGMOD'25
(spilling); Akidau et al. VLDB'15 (Beam model, for streaming later);
Funke et al. VLDBJ'22 (Flounder IR — codegen latency, for the MIR bridge).

Language integration: LINQ postmortems (EF Core client-eval), Quill,
Links/Ferry/DSH (avalanche safety), EdgeQL/Gel (shapes, no-NULL,
cardinality), PartiQL/SQL++ (bag vs array typing — our Seq/Coll), SaneQL
(Neumann & Leis CIDR'24 — user-defined operators, first-class).
