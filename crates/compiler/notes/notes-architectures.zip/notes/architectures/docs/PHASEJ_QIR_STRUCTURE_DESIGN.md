# Phase J — QIR Structure Design: LIR / PIR / Exec

**Status:** Proposed. Governs the rebuild of `yelang-qir`.
**Canonical semantics:** `notes/architectures/query_language_and_execution_design.md`
(unchanged). This doc defines the *concrete structures, file layout, and
algorithms* for the logical IR (LIR), physical IR (PIR), and execution layer,
and corrects the architectural drift found in the current tree (see §2).

Primary algorithmic sources: Neumann, *Improving Unnesting of Complex
Queries* (BTW 2025) + its formalization (arXiv:2412.04294); Fent & Neumann,
*Groupjoin* (PVLDB'21, p2383); Birler, Kemper & Neumann, *Diamond Hardened
Joins* (PVLDB'24); Birler et al., *Simple, Efficient, and Robust Hash Tables
for Join Processing* (DaMoN'24); Kuschewski et al., *Spilling without Killing
Performance* (SIGMOD'25); Leis et al., *Morsel-Driven Parallelism*
(SIGMOD'14); Graefe, *Cascades*; Wong/Libkin comprehension normalization.

---

## 1. What this phase produces

A complete, principled `yelang-qir`: typed HIR → LIR → rewrite (normalize,
decorrelate, elide, fold) → PIR (Cascades memo, capability- and cost-driven)
→ exec (push-based vectorized engine + a dumb reference interpreter used as
the differential oracle). In-memory backend first; the structures below are
backend-general from the start.

## 2. Recognition architecture (the correction)

The current tree recognizes query operations by **name matching**
(`stdlib.rs::method_by_name`, `find_marker_def_by_name`), **AST desugaring**
(`yelang-ast/src/query/desugar.rs`), and **hand-built compiler aggregates**
(`logical/aggregate_impl.rs` with `Symbol::from(1000)` field hacks). All three
violate P3 (mechanisms, not vocabulary) and all three are deleted in J0. The
correct architecture has four parts:

### 2.1 Core methods carry their own lang items

Each `Queryable` trait method that corresponds to a logical operator is a lang
item **on the method**, e.g.:

```yed
@lang("queryable")
trait Queryable<T> {
    @lang("query_filter")  fn filter(self, pred: fn(T) -> bool) -> Self;
    @lang("query_map")     fn map<U>(self, f: fn(T) -> U) -> impl Queryable<U>;
    @lang("query_order_by") fn order_by<K: Ord>(self, key: fn(T) -> K) -> Seq<T>;
    @lang("query_aggregate") fn aggregate<A, Acc, Out>(self, agg: A) -> Out
        where A: Aggregate<T, Acc, Out>;
    // ... the full core set (see §3.2) ...
}
```

Requires: resolver scans attributes on *trait/impl items* (today it only
scans item-level attributes in `extract_lang_item_name`); `LangItem` gains
the query-core-method variants. The lowering maps `LangItem → Operator` — a closed,
mechanical table of ~12 entries that changes only when the operator algebra
changes, never when stdlib grows vocabulary.

### 2.2 Non-core (sugar) methods are invisible to the compiler

`sum()`, `avg()`, `count()`, `min()`, `max()`, `first()`, … are **ordinary
default methods** whose bodies reduce to core calls
(`self.aggregate(Sum {})`). Lowering rule for any call resolved through the
`Queryable` lang-item trait:

1. Resolved method is a core lang item → emit the corresponding operator.
2. Otherwise → inline the *resolved* method body (the impl's override if
   present, else the trait default) and lower that. Recursion terminates
   because default bodies bottom out in core calls.

No `QueryableMethod::Sum` variants, no `method_by_name`, no per-method code.
User overrides are respected for free because resolution has already chosen
the impl item. This also answers "methods desugar to functions, not the
reverse": the only desugaring in the pipeline is HIR's existing method-call →
resolved-call, which is the correct direction.

### 2.3 Aggregates: extract real impl bodies (Froid-lite)

`aggregate(Sum {})` lowering:

1. From typeck results, get the selected `Aggregate<T, Acc, Out>` impl for the
   marker type.
2. Read the type-checked HIR bodies of `init`, `step`, `merge`, `finish`,
   `class` from that impl.
3. Lower those bodies to `QExpr` closures (ordinary expression lowering; pure
   fn calls inline recursively).
4. `class` is a comptime-evaluable constant — evaluate it (it is a path to an
   enum variant today; general case: const-eval the body).

`AggregateOp` then carries real closures. `aggregate_impl.rs` (390 lines of
hand-built `Sum/Product/Count/Avg` closures, high-raw-id `Symbol` hacks,
name-matched dispatch) is **deleted**. New aggregates require zero compiler
changes — that is the acceptance test of this architecture.

### 2.4 No AST desugaring; `sum(x)` is a type error, not a rewrite

`yelang-ast/src/query/desugar.rs` is deleted. Consequences:

- Aggregates in projections are ordinary calls, resolved ordinarily:
  `select users.sum() …` or `select sum(users) …` (if stdlib also provides
  the free function over collections). Both resolve through the same impls.
- `select sum(u) from users@u` — applying an aggregate to an *element* — is a
  **type error** ("`sum` expects a collection; `u` is an element of
  `User`"), with a structured suggestion: `sum(users)` /
  `users.map(|u| …).sum()`.
- Recognition happens after name resolution, so a user function named `sum`
  is never mistaken for the stdlib aggregate (resolved identity, P3/P5).

### 2.5 Projection scoping rule (tycheck fix)

Today `check_select_query` checks the projection in the same scope that
`check_from_node` populated — so the element binder `u` leaks into the
projection and `select u from users@u` type-checks as returning one
indeterminate element. The rule (matches semantics.md §0.1):

> The projection is checked in the **root-label scope**: names bound by
> `from`/`links` *labels* (collections) and `group by … into` (group
> collections) are in scope; **element binders are not**. Element binders are
> in scope only in element contexts: `where`, `order by` keys, `group by`
> keys, `from`-filters, link-path modifiers, and selector/comprehension
> bodies (`users@u[*].{…}` re-binds `u` there).

`select u from users@u` → compile error: "element binder `u` is not in scope
in the projection; iterate the collection: `users[*]`". Enforcement is a
tycheck scope-structure change (pop binder scope before checking projection;
keep label scope), covered by the checklist's scoping tests.

### 2.6 Synthetic DefIds come from the definitions arena

`LoweringCtxt::next_synthetic_def_id` currently fabricates
`DefId(definitions.len() + counter + 1)` **without pushing a `Definition`**
— synthetic ids index past the arena, so any table keyed by real definitions
silently misses them, and any direct index can panic. Fix: synthetic items
(derived impls, synthesized `Array`, future `Table` derives) are allocated
**in** the definitions arena as ordinary `Definition`s flagged
`synthetic: bool`. One id space, uniform lookups, diagnostics can name them.
Derive helpers (`method_impl_item`, `impl_item`) take `generics` and `attrs`
as parameters instead of hardcoding empty ones — today's derives happen not
to need them; the helper must not bake that in.

### 2.7 Stdlib surface corrections

- Surface spelling of the array type is `[T]` (done in the parser; the `.ye`
  stdlib still writes `Array<T>`/`Vec<T>` — fix to `[T]`; `Array` remains
  only the internal lang-item name).
- `Queryable` is implemented for **query-source types** — `Table<T>` (storage
  handle), `Stream<T>`, and the explicit adapter `Querying<[T]>` (from
  `xs.query()`) — **never for `[T]` itself**. `[T]` implements `IntoIterator`
  (eager, local). `select` syntax over `[T]` lowers through the comprehension
  core directly (it never required `Queryable`). This is the
  IEnumerable/IQueryable seam done right: one core calculus, two entry
  surfaces, and an explicit, visible adapter between them.
- The full combinator surface returns to `Iterator`/`Queryable` as default
  methods (`collect`, `for_each`, `enumerate`, `zip`, `find`, `any`, `all`,
  `first`, `last`, `reduce`, …). Nothing is stripped "for the compiler":
  the compiler recognizes resolutions, not surface area.

---

## 3. LIR structures

### 3.1 Files: `yelang-qir/src/lir/`

```rust
// lir/operator.rs — the complete logical operator set.
pub enum Operator {
    // --- sources ---
    Scan { source: ScanSource, item_ty: TyId },          // named source or materialized expr
    Values { rows: Vec<QExprId>, item_ty: TyId },        // literal rows
    OneRow,                                              // single-unit row (decorrelation anchor)

    // --- unary pipeline ---
    Filter { input: LirId, predicate: QExprId },
    Map { input: LirId, projection: QExprId },           // renames/reshapes element
    FlatMap { input: LirId, projection: QExprId, levels: u32 },
    Distinct { input: LirId, by: Option<Vec<QExprId>> },
    OrderBy { input: LirId, keys: Vec<OrderKey> },       // Coll -> Seq
    TopN { input: LirId, keys: Vec<OrderKey>, limit: QExprId, offset: Option<QExprId> },
    Limit { input: LirId, count: Option<QExprId>, offset: Option<QExprId> }, // Seq only
    Window { input: LirId, funcs: Vec<WindowFn>, partition: Vec<QExprId>, order: Vec<OrderKey> },

    // --- grouping / aggregation ---
    GroupBy { input: LirId, keys: Vec<(Symbol, QExprId)>, members: Symbol, aggs: Vec<AggregateOp> },
    Aggregate { input: LirId, agg: AggregateOp },        // scalar (static) aggregation; may be correlated
    GroupJoin { outer: LirId, inner: LirId, predicate: QExprId, aggs: Vec<AggregateOp>, mode: GroupJoinMode },

    // --- joins ---
    Join { kind: JoinKind, left: LirId, right: LirId, predicate: QExprId },
    DependentJoin { kind: JoinKind, outer: LirId, inner: LirId, predicate: QExprId,
                    accessing: AccessingSet },           // decorrelation working node
    MarkJoin { left: LirId, right: LirId, predicate: QExprId, marker: Symbol },

    // --- multiset/set ---
    SetOp { op: SetOpKind, left: LirId, right: LirId },  // bag Union/Intersect/Except

    // --- graph ---
    Traversal { input: LirId, edge: EdgeSpec, hops: HopRange, direction: Direction },

    // --- shape / results ---
    Construct { kind: ConstructKind, fields: Vec<(Symbol, LirId)> },
    AttachField { input: LirId, field: Symbol, value_plan: LirId },
    Expr(QExprId),                                       // scalar root (projection determines result)
}

pub enum JoinKind { Inner, LeftOuter, RightOuter, FullOuter, Semi, Anti, Cross }
pub enum GroupJoinMode { Eager, Lazy }                   // Fent/Neumann: cost choice
pub struct OrderKey { pub expr: QExprId, pub dir: Direction, pub nulls: NullOrdering }
```

Design notes:
- `TopN` and `Limit` are distinct: `TopN` = order + limit + offset (the
  decorrelation and pushdown unit); `Limit` = position slice on an existing
  `Seq`. Surface `range a..b` lowers to `Limit { offset: a, count: b-a }`
  and requires `Seq` (type rule from the main doc, D1).
- `DependentJoin` carries `accessing`: the set of operators in `inner` that
  reference outer columns — computed by `lir/analyze/correlation.rs`, used by
  the BTW'25 algorithm (§4).
- `OneRow` is the decorrelation anchor for scalar contexts (SQL's `VALUES(1)`
  trick; keeps static aggregation semantics honest).

```rust
// lir/aggregate.rs
pub struct AggregateOp {
    pub agg_def: DefId,        // marker type (e.g. Sum) — the function-registry key
    pub impl_def: DefId,       // the selected Aggregate impl
    pub class: AggregateClass, // evaluated from the impl's `class()` body (const-eval)
    pub per_row: QExprId,      // element -> In   (closure)
    pub init: QExprId,         // () -> Acc
    pub step: QExprId,         // (Acc, In) -> Acc
    pub merge: QExprId,        // (Acc, Acc) -> Acc
    pub finish: QExprId,       // Acc -> Out
    pub config: QExprId,       // the marker value (config, e.g. Percentile{p})
    pub acc_ty: TyId,
    pub out_ty: TyId,
}
pub enum AggregateClass { Distributive, Algebraic, Holistic }  // planner mechanics
```

```rust
// lir/props.rs — logical properties, computed bottom-up, cached per node.
pub struct LogicalProps {
    pub output_ty: TyId,
    pub output_binder: Option<BinderId>,
    pub bounded: Boundedness,          // Bounded | Unbounded
    pub keys: KeySet,                  // proven-unique column sets (superkey inference)
    pub demand: DemandSet,             // fields/aggregates actually consumed downstream
    pub card: CardClass,               // Unknown | Small | Medium | Large (pre-stats estimate)
    pub constant: bool,                // no scans beneath (foldable region)
}
```

```rust
// expr/qexpr.rs — scalar IR shared by LIR and PIR (replaces expr.rs).
pub enum QExpr {
    Lit(QLit, TyId),                          // no Null variant (D3: Option is a type, not a lit)
    Column(BinderId, TyId),                   // unique binder ids, never names
    Field(QExprId, Symbol, TyId),
    Binary(QBinaryOp, QExprId, QExprId, TyId),
    Unary(QUnaryOp, QExprId, TyId),
    Call { fn_id: DefId, args: Vec<QExprId>, ty: TyId, volatility: Volatility },
    Cast(QExprId, CastKind, TyId),
    Record(Vec<(Symbol, QExprId)>, TyId),
    If { cond: QExprId, then: QExprId, else_: QExprId, ty: TyId },
    Case { scrutinee: QExprId, arms: Vec<(QExprId, QExprId)>, default: QExprId, ty: TyId },
    Closure { params: Vec<BinderId>, body: QExprId, captures: Vec<QExprId>, ty: TyId },
    Subplan(LirId, TyId),                     // pre-decorrelation nested plan
    OptionSome(QExprId, TyId) / OptionNone(TyId),  // explicit Option constructors
}
pub enum Volatility { Pure, Stable, Volatile }   // from fn declarations (§3.4 main doc)
```

### 3.2 Core lang items (complete, closed set)

| Lang item (on method) | Operator | Notes |
|---|---|---|
| `query_filter` | `Filter` | |
| `query_map` | `Map` | |
| `query_flat_map` | `FlatMap` | levels from return-type nesting |
| `query_distinct` | `Distinct` | |
| `query_order_by` | `OrderBy`/`TopN` | fused with a following take |
| `query_take` | `Limit{count}` / `TopN` | requires Seq, or fuses with order_by |
| `query_skip` | `Limit{offset}` | requires Seq |
| `query_group_by` | `GroupBy` | |
| `query_aggregate` | `Aggregate`/`GroupBy.aggs` | the only aggregation entry |
| `query_execute` | (materialization boundary) | forces Coll→Seq unspecified order |
| `query_window` | `Window` | when windows land |
| `query_join` | `Join` | method-form joins, later |

Everything else in `Queryable` (`sum`, `avg`, `first`, `enumerate`, `zip`,
`collect`, …) is default-method sugar over this core.

---

## 4. Decorrelation engine (`rewrite/decorrelate*.rs`)

Implements BTW'25 top-down unnesting with its correctness formalization, not
the 2015 bottom-up loop. One pass, single state, nested dependent joins merge.

### 4.1 Core data structures

```rust
struct Unnesting {
    domain: LirId,                 // D: distinct outer bindings currently in scope
    equalities: UnionFind,         // outer cols bound by conjunctive equalities
    repr: FxHashMap<ColumnRef, QExprId>, // substitution: outer col -> inner expr
    accessing: AccessingSet,       // ops below that touch outer columns (LCA analysis)
}
```

- **Domain computation** (`analyze/correlation.rs`): for each
  `DependentJoin`, D = `Distinct(Map(outer, <referenced outer cols>))`.
  `accessing` is computed by least-common-ancestor analysis over the operator
  DAG (which nodes reference outer binders).
- **Union-find substitution** (BTW'25 §3): when every outer reference is
  bound by an equality `outer.c = inner.e`, substitute `repr[c] = e` and drop
  the D-join entirely; otherwise keep the D-join (cost-based choice — NK'15
  had no such choice).

### 4.2 Pushdown rules (each a proven lemma in arXiv:2412.04294)

`D⧑` = dependent join with domain D. Rules push it through `inner` until no
outer references remain, then it degenerates to a regular `JoinKind`:

| Inner operator | Rule |
|---|---|
| `Filter(p)` | `D⧑(σ_p T)` → `σ_p(D⧑T)` |
| `Map(f)` | push through, extend `repr` with `f`'s computed cols |
| `Join(T,S)` | push into the accessing side(s); both sides accessing → push into both with care (formalization §4) |
| `Semi/Anti/Mark` | push with kind-specific variants |
| `Outer joins` | push only below null-extended side when predicate null-rejects; FullOuter correlation: evaluate predicate per binding over `D_R × D_S`, amend with `IS NOT DISTINCT FROM` (BTW'25 §4.1) |
| `GroupBy Γ_{A;f}` | `D⧑(Γ_{A;f} T)` → `Γ_{A ∪ cols(D); f}(D⧑T)` — keys gain correlation columns |
| `Aggregate` (static, ∅ grouping) | **must still produce a row on empty input** → rewrite to `LeftOuterJoin(D, …)` + per-aggregate empty defaults, or `GroupJoin` when profitable (§5.3) — the COUNT-bug guard |
| `Window w` | `D⧑(w(T))` → `w'(D⧑T)` where `partitionby' = partitionby ∪ cols(D)` (windows decorrelate like group-by) |
| `OrderBy` (no limit) | multiplicity-preserving → push freely |
| `TopN(order, l, o)` | route A: **native per-group TopN** — the sort operator takes a partition spec (`cols(D)`), so `D⧑(TopN T)` → `TopN_{partition=cols(D)}(D⧑T)`; route B (portable): rewrite `ORDER BY x LIMIT l OFFSET o` → `ROW_NUMBER() OVER (ORDER BY x)` + filter `rn ∈ (o, l+o]`, then window rule. Greenfield choice: implement route A in the sort operator, route B as a rewrite for backends without per-group TopN. |
| `Limit` (no order) | non-deterministic per group; only legal when the user accepted unordered semantics (Coll context) — then per-group Limit, same machinery |
| `SetOp` | push into all branches |
| `Distinct` | push through; D's own distinctness maintained |
| `OneRow`/constants | `D⧑R` with no accessing ops → `CrossJoin`/substitution |

Termination: each push strictly reduces the number of accessing operators
above the dependent join; nested dependent joins merge their `Unnesting`
state instead of re-running the algorithm (BTW'25's fix for the
cross-product-of-domains blowup: 120 GB → 33 ms on their demo query).

### 4.3 Range (limit/offset) semantics under decorrelation — explicit rules

Surface `range a..b` is `Limit` on `Seq`. Inside a correlated context
(nested projection with range over an outer-bound collection):

1. Type rule already forces `Seq` before `range` — so range decorrelation
   always has defined order (per-group), never ambiguous bag slicing.
2. The per-group TopN rewrite uses the *group key = correlation columns*, so
   `users@u[*].{ posts: u.posts@p[order by p.ts desc][*] range 0..5 }`
   becomes a partitioned TopN keyed by `u`, not a lateral loop.
3. OFFSET is carried through the same operator (`skip` within each
   partition); the ROW_NUMBER fallback encodes it as `rn > o`.

### 4.4 Ordering/sorting interactions

- `OrderBy` is multiplicity-preserving: decorrelation pushes it freely, but
  its *required property* (ordering) is recorded so the physical layer can
  reuse sortedness (avoid re-sort after the D-join degenerates).
- `TopN` fusion: `OrderBy` followed by `Limit` (from `range`) fuses to one
  `TopN` node in normalization, before decorrelation — so decorrelation only
  ever sees one construct.
- Sort-pushdown into scans (index order) happens in PIR via required
  ordering properties + enforcers, not in LIR.

---

## 5. Generalized aggregation

### 5.1 One trait, extraction-based (see §2.3)

Nothing about an aggregate is known to the compiler except: the `Aggregate`
lang-item trait shape, and the `AggregateClass` of the selected impl
(const-evaluated from its `class()` body). Everything else — init/step/
merge/finish — is user code lowered to QExpr.

### 5.2 Class-driven planning (physical)

| Class | Plan |
|---|---|
| Distributive | `PartialAggregate` per partition/shard → `FinalAggregate` (merge); freely parallel/distributed |
| Algebraic | same, with `Acc ≠ Out` (`avg = (sum,count)`); merge on Acc, finish once at the end |
| Holistic | repartition by group key (Exchange) → full aggregation per group; never partial-merged (e.g. exact median). Approximate variants (t-digest) are ordinary UDAs classified Distributive/Algebraic |

`GroupBy.aggs: Vec<AggregateOp>` shares one hash table across aggregates of
the same class family. Distinct-aggregation (`count(distinct x)`) is a
rewrite: group on `(keys, x)` first, then aggregate.

### 5.3 GroupJoin (eager vs lazy) — Fent & Neumann PVLDB'21

For `SELECT …, (SELECT agg FROM S WHERE S.k = R.k) … FROM R` shapes after
decorrelation leaves `Join(R, Γ(S))`:

- **Eager** (aggregate below join) is legal iff: join key == aggregation key,
  and that key is a **superkey of the left/build side** (duplicate-free; PK
  side of a PK/FK join — provenance from `props.keys`). Then: left-side
  aggregates are corrected by a `count(*)` multiplier; the final group-by is
  elided; empty groups get the aggregate's neutral element
  (`finish(init())`, COUNT→0).
- **Lazy** otherwise (join first, aggregate after, or per-group evaluation).
- Choice by cost using **aggregate estimates** (estimate the distribution of
  computed aggregate columns so downstream join ordering stays sane —
  freshly decorrelated plans with computed columns are exactly where CE is
  worst).
- Parallel: thread-local partitioned hash tables + partition exchange/merge
  (contention-free eager-right strategy).

### 5.4 Empty-input semantics

Scalar `Aggregate` over empty input returns `finish(init())` per impl —
evaluated once, statically, against `OneRow`. Grouped aggregation produces no
group for absent keys; outer-join-amended groups (decorrelation guard) get
`finish(init())` defaults. No NULLs anywhere (D3); `min/max` return
`Option`.

---

## 6. PIR structures (`yelang-qir/src/pir/`)

```rust
// pir/operator.rs
pub enum PhysOp {
    // scans (per location)
    MemoryScan { values: QExprId, item_ty: TyId },
    StorageScan { source: SourceId, projection: DemandSet, predicates: Vec<QExprId>,
                  index: Option<IndexChoice> },
    RemoteScan { fragment: FragmentId },
    Values { rows: Vec<QExprId> },

    // unary
    Filter { input: PirId, predicate: PrimitiveId },
    Project { input: PirId, core: PrimitiveId },          // fused expression core
    HashAggregate { input: PirId, mode: AggMode, keys: Vec<QExprId>, aggs: Vec<PhysAgg>,
                    spill: SpillPolicy },
    Sort { input: PirId, keys: Vec<OrderKey>, top_k: Option<usize>, partition: Option<Vec<QExprId>> },
    Window { input: PirId, ... },
    Distinct { input: PirId, mode: DistinctMode },
    Limit { input: PirId, count: Option<u64>, offset: Option<u64> },
    Traversal { input: PirId, edge: EdgeSpec, ... },

    // binary
    HashJoin { kind: JoinKind, build: PirId, probe: PirId, keys: Vec<(QExprId, QExprId)>,
               bloom: bool, spill: SpillPolicy },
    DiamondJoin { kind: JoinKind, left: PirId, right: PirId, ... }, // lookup/expand split (PVLDB'24)
    MergeJoin { kind: JoinKind, left: PirId, right: PirId, keys: ... },
    NestedLoopJoin { kind: JoinKind, outer: PirId, inner: PirId },  // unique-inner only (stats-gated)
    GroupJoin { outer: PirId, inner: PirId, aggs: Vec<PhysAgg>, mode: GroupJoinMode },
    UnionAll { inputs: Vec<PirId> }, Concat { inputs: Vec<PirId> }, SetOpMerge { ... },

    // distribution
    Exchange { input: PirId, kind: ExchangeKind },       // Local | Shuffle(key) | Broadcast(cap)
    Fragment { id: FragmentId, root: PirId },            // shippable unit
}

pub struct PhysicalProps {                              // pir/props.rs
    pub ordering: Option<Ordering>, pub partitioning: Partitioning,
    pub location: Location, pub bounded: Boundedness,
    pub rows: Estimate, pub bytes: Estimate,
}
```

- **Memo** (`pir/memo.rs`): Cascades groups; `GroupExpression`s carry
  `PhysicalProps` satisfaction + best-plan-so-far per required-property set.
- **Tasks** (`pir/tasks.rs`): OptimizeGroup / ExploreExpression / ApplyRule /
  OptimizeInputs, cost-limit branch-and-bound, per-(expr, rule) bitmaps.
- **Rules** (`pir/rules/*.rs`): implementation rules (LIR op → PhysOp
  candidates) + property enforcers (`Sort`, `Exchange`) inserted to satisfy
  required properties. Location is a physical property; network transfer is
  its enforcer (Calcite Convention generalized).
- **Cost** (`pir/cost.rs`): deliberately simple, tuple-driven; all
  sophistication goes to `stats.rs` (samples, zone maps, aggregate estimates,
  independence damping).
- **Capability** (`pir/capability.rs`): per-location `supports(PhysOp)`,
  `aggregate_support(class, fn registry)`, `stats(source)`, `exchange_kinds`.
- **Registry** (`pir/registry.rs`): versioned function registry; every
  function/aggregate referenced by a shippable `Fragment` is URI-anchored +
  semantics-versioned; unregistered → fragment boundary with explicit local
  execution (never silent client-eval).

---

## 7. Exec structures (`yelang-qir/src/exec/`)

- `batch.rs`: columnar batch (~1–4K values), Arrow-compatible layout,
  validity bitmaps; the universal unit (memory/disk/wire).
- `pipeline.rs`: push model — `Source::produce() → Operator::consume(batch)
  → Sink`; pipeline-breakers materialize; the same graph runs batch jobs,
  streams (batches = deltas), and remote stages.
- `morsel.rs`: work unit = (pipeline × fragment ~100K values); work-stealing
  dispatcher, pinned workers, elastic DoP.
- `memory.rs`: hierarchical pools (query→pipeline→operator), quantized
  reservations, cross-query arbitrator.
- `spill.rs`: `trait Spill { fn spill(&mut self, to: PartitionSet) }`;
  radix-partitioned state, adaptive materialization (any hash operator
  becomes out-of-memory with zero in-memory penalty — Spilly design).
- `operators/hash_table.rs`: the DaMoN'24 unchained hash table (build-side
  partitioning, adjacency-array layout, pipelined probes, bloom filters,
  software write-combine) — shared by `hash_join` and `hash_aggregate`.
- `operators/hash_join.rs`: build-side bloom + min/max filters pushed to
  probe-side scan at runtime (dynamic filter pushdown); skew handling via
  morsels; `DiamondJoin` lookup/expand split ready for n:m robustness.
- `operators/hash_aggregate.rs`: thread-local partitioned tables + merge;
  per-class partial/final; spillable.
- `operators/sort.rs`: external merge sort (spillable) + partitioned TopN
  (the decorrelation route-A primitive).
- `operators/exchange.rs`: local/shuffle/broadcast, credit-based flow
  control on every edge.
- `primitives/`: vectorized typed expression primitives (arith/cmp/bool/string/
  cast); `Project`/`Filter` fuse core chains.
- `interpreter.rs`: the **reference executor** — dumb, obviously correct,
  no rewrites, no vectorization. Written *first*; the differential oracle
  for everything else.
- `value.rs`: runtime values on the §7 (main doc) value-semantics model;
  query results arena-allocated, freed as one region.

---

## 8. Robustness from day one (greenfield advantages)

1. **Dumb-reference-first**: differential testing against `interpreter.rs`
   from the first operator (SQLancer NoREC-style, adapted to comprehensions).
2. **Spill-capable-by-interface**: every blocking operator implements `spill()`
   when first written — retrofitting is where cliffs come from.
3. **Dynamic filters**: build-side min/max+bloom pushed at runtime — cheap
   insurance against immature CE (DuckDB's measured 10×).
4. **Diamond-ready joins**: HashJoin factored as lookup+expand from the start
   so n:m robustness (PVLDB'24) is a strategy flag, not a rewrite.
5. **Explainability**: per-rule before/after dumps, `EXPLAIN` for LIR/PIR,
   per-pass disable flags — from day one (DuckDB/DataFusion debuggability
   lesson).
6. **No string identity**: interned ids everywhere below HIR (DataFusion's
   recurring alias bug class).
7. **Unorderedness honesty**: test-mode flag shuffles all `Coll` batches
   between operators; any test depending on unrequested order fails.
8. **Volatility-gated folding/pushdown/shipping** — wrong plans from folding
   volatile calls are a permanent bug class in other engines; ours is
   structurally impossible.

---

## 9. Exhaustive file tree

```
yelang-qir/
├── Cargo.toml
├── src/
│   ├── lib.rs                     # crate docs + public API (lower_query, optimize, execute)
│   ├── errors.rs                  # LoweringError, RewriteError, PlanError, ExecError
│   ├── ids.rs                     # LirId, PirId, QExprId, BinderId, GroupId, FragmentId, PrimitiveId
│   │
│   ├── expr/                      # scalar IR (shared LIR/PIR)
│   │   ├── mod.rs
│   │   ├── qexpr.rs               # QExpr, QLit, ops, CastKind, Volatility
│   │   ├── visit.rs               # visitor + transform_up/down (immutable rewrites)
│   │   ├── fold.rs                # volatility-aware constant folding
│   │   ├── binder.rs              # BinderId allocation, substitution, free-var analysis
│   │   └── print.rs               # pretty printing (EXPLAIN, goldens)
│   │
│   ├── lir/                       # logical plan (renamed from logical/)
│   │   ├── mod.rs
│   │   ├── operator.rs            # Operator (§3.1), JoinKind, OrderKey, ScanSource
│   │   ├── aggregate.rs           # AggregateOp, GroupByOp, AggregateClass
│   │   ├── window.rs              # WindowFn, frame specs
│   │   ├── props.rs               # LogicalProps + inference
│   │   ├── plan.rs                # LogicalPlan arena + builders
│   │   ├── lower/
│   │   │   ├── mod.rs             # LoweringCtxt (lang-item lookups only; no name tables)
│   │   │   ├── query.rs           # select + mutation queries
│   │   │   ├── selector.rs        # comprehensions, [*]/[where]/[**], object projections
│   │   │   ├── links.rs           # links paths -> Traversal/joins
│   │   │   ├── method.rs          # core lang-item -> operator; else inline resolved body
│   │   │   ├── aggregate.rs       # impl-body extraction (init/step/merge/finish/class)
│   │   │   ├── expr.rs            # HIR expr -> QExpr, pure-fn inlining (Froid-lite)
│   │   │   └── closure.rs         # closure capture/eta helpers
│   │   └── analyze/
│   │       ├── demand.rs          # demand sets from the projection (elision input)
│   │       ├── correlation.rs     # accessing sets, LCA, domain computation
│   │       └── keys.rs            # superkey/uniqueness inference
│   │
│   ├── rewrite/                   # logical rewrites, fixpoint batches, instrumented
│   │   ├── mod.rs                 # Rule trait, Batch runner, per-rule dump, disable flags
│   │   ├── normalize.rs           # map/filter fusion, identity elim, TopN fusion, dead-project elim
│   │   ├── elision.rs             # dead source/binding elision (projection demand)
│   │   ├── fold.rs                # batch: constant folding over pure regions
│   │   ├── pushdown.rs            # predicate/projection migration toward scans
│   │   ├── decorrelate.rs         # BTW'25 driver: single-pass top-down, state merge
│   │   ├── decorrelate_rules.rs   # per-operator pushdown lemmas (§4.2 table)
│   │   ├── decorrelate_agg.rs     # Γ rule, static-agg outer-join/GroupJoin guard
│   │   ├── decorrelate_window.rs  # PARTITION BY += correlation cols
│   │   ├── topn.rs                # per-group TopN + ROW_NUMBER fallback rewrite
│   │   ├── equiv.rs               # union-find equalities, repr substitution
│   │   ├── groupjoin.rs           # eager/lazy legality + rewrite
│   │   └── distinct.rs            # distinct rewrites, distinct-agg expansion
│   │
│   ├── pir/                       # physical plan (renamed from physical/)
│   │   ├── mod.rs
│   │   ├── operator.rs            # PhysOp (§6), ExchangeKind, SpillPolicy, AggMode
│   │   ├── props.rs               # PhysicalProps + requirement/satisfaction logic
│   │   ├── plan.rs                # PhysicalPlan, PlanFragment, FragmentId interning
│   │   ├── memo.rs                # Cascades memo: groups, expressions, winners
│   │   ├── tasks.rs               # task scheduler + cost bounds + applied bitmaps
│   │   ├── cost.rs                # simple tuple-driven cost model
│   │   ├── stats.rs               # samples, zone maps, aggregate estimates, damping
│   │   ├── capability.rs          # BackendCapability (per-location questions)
│   │   ├── registry.rs            # versioned function registry for shippable fragments
│   │   └── rules/
│   │       ├── mod.rs             # implementation-rule plumbing
│   │       ├── scans.rs           # scan choice incl. index + pushdown absorption
│   │       ├── joins.rs           # hash/merge/nested/diamond candidates, build-probe
│   │       ├── aggregate.rs       # partial/final decomposition, groupjoin physical
│   │       ├── sort.rs            # sort/topk enforcers, ordering reuse
│   │       ├── exchange.rs        # location enforcers: local/shuffle/broadcast
│   │       └── window.rs
│   │
│   ├── exec/
│   │   ├── mod.rs
│   │   ├── batch.rs               # columnar batch, Arrow layout, validity
│   │   ├── value.rs               # runtime values (value-semantics model), result arena
│   │   ├── pipeline.rs            # Source/Operator/Sink push model, assembly
│   │   ├── morsel.rs              # morsel scheduler, work stealing
│   │   ├── memory.rs              # pools, reservations, arbitrator
│   │   ├── spill.rs               # Spill trait, radix partition sets, spill files
│   │   ├── interpreter.rs         # REFERENCE executor (differential oracle) — first
│   │   ├── primitives/
│   │   │   ├── mod.rs             # primitive registry, fusion
│   │   │   ├── arithmetic.rs
│   │   │   ├── compare.rs
│   │   │   ├── boolean.rs
│   │   │   ├── strings.rs
│   │   │   └── cast.rs
│   │   └── operators/
│   │       ├── mod.rs
│   │       ├── scan.rs
│   │       ├── filter.rs
│   │       ├── project.rs
│   │       ├── hash_table.rs      # unchained table (DaMoN'24), shared join/agg
│   │       ├── hash_join.rs       # bloom+min/max dynamic filters, spill
│   │       ├── merge_join.rs
│   │       ├── nested_loop.rs
│   │       ├── hash_aggregate.rs  # partial/final, spillable
│   │       ├── group_join.rs
│   │       ├── sort.rs            # external sort, partitioned TopN
│   │       ├── window.rs
│   │       ├── exchange.rs        # local/shuffle/broadcast + credit flow control
│   │       ├── distinct.rs
│   │       ├── limit.rs
│   │       └── traversal.rs       # edge-index expansion
│   │
│   ├── backend/
│   │   ├── mod.rs                 # backend registry, location handles
│   │   ├── memory.rs              # in-memory [T]/Coll backend
│   │   └── remote.rs              # fragment shipping client (stub until Phase 3)
│   │
│   └── util/
│       ├── mod.rs
│       ├── arena.rs
│       ├── graph.rs               # DAG walks, LCA, topo (decorrelation support)
│       └── explain.rs             # EXPLAIN rendering for LIR/PIIR + rule dumps
│
└── tests/
    ├── common/mod.rs              # harness: parse→tycheck→lower→optimize→run both execs
    ├── lowering_query.rs          # golden LIR per surface feature
    ├── lowering_method.rs         # core recognition, sugar inlining, override respect
    ├── lowering_aggregate.rs      # impl-body extraction per built-in + a custom UDA
    ├── scoping.rs                 # projection/root-label scope, binder contexts (§2.5)
    ├── rewrite_normalize.rs
    ├── rewrite_elision.rs
    ├── rewrite_decorrelate.rs     # the §4.2 rule table, one family per case
    ├── rewrite_topn.rs
    ├── rewrite_groupjoin.rs
    ├── aggregation.rs             # classes × partial/final × empty-input × distinct
    ├── exec_operators.rs          # per-operator unit tests incl. spill paths
    ├── semantics.rs               # projection-determines-shape, elision, order honesty
    └── differential.rs            # property-based reference-vs-optimized, random schemas
```

Deletions in J0: `yelang-ast/src/query/desugar.rs`,
`yelang-qir/src/logical/aggregate_impl.rs`, the name tables in
`yelang-qir/src/logical/stdlib.rs` (keeping only the `class()`-body reader,
moved to `lir/lower/aggregate.rs`), `QueryableMethod::{Sum,Product,Avg,Count}`,
`exec/interface.rs`'s placeholder `Value` enum, `physical/operator.rs`'s
hardcoded `AggregateKind`/`WindowKind` remnants, `backend/capability.rs`'s
`supports_aggregation(kind)` (replaced by `aggregate_support(class, registry)`).
