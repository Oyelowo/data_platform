# Phase J — QIR Implementation Checklist

Companion to `PHASEJ_QIR_STRUCTURE_DESIGN.md`. One phase lands at a time, in
order, fully green before the next starts. Every item has tests named in the
matrix at the bottom. Nothing is "temporary": no name tables, no hand-built
aggregates, no placeholder enums.

Legend: ☐ todo · ☑ done

---

## J0 — Recognition rework (the correction; everything else builds on this)

**Goal:** delete every name-match/desugar/bootstrap hack; recognition is by
resolved identity + lang items only.

- ☐ J0.1 `LangItem` gains query-core-method variants (`query_filter`, `query_map`,
  `query_flat_map`, `query_distinct`, `query_order_by`, `query_take`,
  `query_skip`, `query_group_by`, `query_aggregate`, `query_execute`;
  `query_window`, `query_join` reserved).
- ☐ J0.2 Resolver scans attributes on trait/impl *items* (not just top-level
  items) when collecting `@lang`.
- ☐ J0.3 stdlib `.ye`: core methods annotated; full combinator surface
  restored as default methods (`collect`, `for_each`, `enumerate`, `zip`,
  `find`, `any`, `all`, `first`, `last`, `reduce`, …); sugar methods reduce
  to `aggregate(Marker {})`; `Array<T>`/`Vec<T>` spellings replaced by `[T]`.
- ☐ J0.4 `Queryable` impl for raw `[T]` removed; `Querying<[T]>` adapter type
  + `.query()` introduced; `select` syntax over `[T]` verified to lower
  through the comprehension core without any `Queryable` impl.
- ☐ J0.5 Delete `yelang-ast/src/query/desugar.rs` and its call site; migrate
  `yelang-driver/tests/source_aggregate_tests.rs`: `sum(users)`/`users.sum()`
  forms pass; `sum(u)` is a type error with suggestion.
- ☐ J0.6 Delete `yelang-qir/src/logical/aggregate_impl.rs`;
  `AggregateOp` is filled only by impl-body extraction.
- ☐ J0.7 `stdlib.rs` name tables deleted; the `class()`-body reader moves to
  `lir/lower/aggregate.rs`; the `"Sum"|"Count"|"Avg"` name fallback deleted.
- ☐ J0.8 `QueryableMethod` enum reduced to the core set, keyed by
  `LangItem`, produced by `tcx.lang_item(...)` lookups — no DefId tables
  populated by name.
- ☐ J0.9 Method-call lowering: core lang item → operator; otherwise inline
  the resolved method body (impl override or trait default) and recurse.
  Test: a user override of `sum` on a custom type is honored.
- ☐ J0.10 Projection scoping rule in tycheck: projection checked in
  root-label scope; element binders restricted to element contexts.
  `select u from users@u` → error suggesting `users[*]`.
- ☐ J0.11 Synthetic DefIds allocated in the definitions arena (flagged
  synthetic); derive helpers take `generics`/`attrs` parameters; audit all
  `next_synthetic_def_id` call sites for uniform lookup.
- ☐ J0.12 `QLit::Null` removed; Option constructors in QExpr; aggregate
  empty-input defaults per impl (`finish(init())`).

**J0 exit tests:** T-REC-01…12, T-SCOPE-01…08, T-DERIVE-01…04. All existing
tycheck/HIR suites stay green.

---

## J1 — LIR lowering complete

- ☐ J1.0 `lir/lower/typed.rs`: the typed-view facade — the ONLY module allowed
  to touch `TypeckResults`. All lowering reads types/method-resolutions/
  adjustments through this API (v1 impl: HIR + side tables; v2 impl at the MIR
  phase: real THIR nodes). This is what makes the future HIR→THIR migration a
  one-module swap instead of a lowering rewrite. See
  `notes/architectures/thir_mir_qir_layering.md` (queries bypass THIR).
- ☐ J1.1 New `expr/` module: QExpr per design (no Null, Option ctors,
  Volatility on calls, Closure, Subplan), visitor + transform, binder
  free-var analysis.
- ☐ J1.2 `lir/operator.rs` full set (incl. `TopN`, `Limit`, `OneRow`,
  `GroupJoin`, `DependentJoin{accessing}`, `Traversal`, `Values`).
- ☐ J1.3 `lir/props.rs`: output ty/binder, boundedness, keys, demand,
  card class — bottom-up inference.
- ☐ J1.4 Lower `select` fully: from (multi-root → product), links →
  Traversal/joins, where, group by → group records, order, range (Seq check
  already typed), projection as root expr.
- ☐ J1.5 Selectors/comprehensions lower to Map/FlatMap/Filter; nested
  projections → `Subplan` + `DependentJoin` (pre-decorrelation form).
- ☐ J1.6 Method chains: core ops; sugar inlining; `.query()` adapter;
  `execute()` materialization boundary.
- ☐ J1.7 Aggregate calls: impl-body extraction incl. `config` value and
  const-eval of `class()`; custom UDA end-to-end (user-defined marker +
  impl, zero compiler changes).
- ☐ J1.8 Local `let`-bound sources (existing `populate_local_values`
  behavior) ported to the new structures.
- ☐ J1.9 Mutation queries (`create/update/upsert/delete/link/unlink`):
  lowered to scan+mutate plans or explicitly rejected with structured
  errors pending the storage engine — no silent drops.

**J1 exit tests:** T-LOW-01…20, T-AGG-01…10.

---

## J2 — Rewrite engine + normalization + elision

- ☐ J2.1 `Rule` trait + batch runner to fixpoint + per-rule before/after
  dump + per-rule disable flags (`--dump-qir-rules`, `--disable-qir-rule`).
- ☐ J2.2 normalize.rs: map fusion, filter-through-map, flat-map
  associativity, identity/unit elimination, nested comprehension collapse,
  dead-field/project elimination, OrderBy+Limit → TopN fusion.
- ☐ J2.3 elision.rs: demand analysis from projection; dead sources/bindings
  removed; `select 1 from users` executes zero reads (verified with a
  counting scan).
- ☐ J2.4 fold.rs: constant folding over `pure` calls only; volatile calls
  never folded (unit test with a counter fn).
- ☐ J2.5 pushdown.rs: predicate migration toward scans through maps/joins
  (legality by referenced binders).
- ☐ J2.6 distinct.rs: distinct-agg expansion, distinct-through-union rules.

**J2 exit tests:** T-NORM-01…14, T-ELIDE-01…06, T-FOLD-01…04.

---

## J3 — Decorrelation (BTW'25)

- ☐ J3.1 analyze/correlation.rs: accessing sets via LCA on the operator
  DAG; domain computation `Distinct(Map(outer, cols))`.
- ☐ J3.2 equiv.rs: union-find of conjunctive equalities; repr substitution;
  cost-based keep-vs-substitute the D-join.
- ☐ J3.3 decorrelate.rs driver: single-pass top-down; nested dependent
  joins merge state (regression test: the BTW'25 blow-up shape — two levels
  of nesting over shared outer refs — plans in bounded time/memory).
- ☐ J3.4 Pushdown lemmas: filter, map, inner join, semi/anti/mark, outer
  joins (null-rejection cases), full-outer (IS NOT DISTINCT FROM amend),
  set ops, distinct, constants/OneRow.
- ☐ J3.5 decorrelate_agg.rs: Γ rule (keys += correlation cols); static
  aggregation (∅ grouping) → LeftOuterJoin + empty defaults or GroupJoin;
  COUNT-bug regression (`count` over empty correlated input = 0, not
  missing row).
- ☐ J3.6 decorrelate_window.rs: PARTITION BY += correlation cols.
- ☐ J3.7 topn.rs: OrderBy+Limit fusion already done; per-group TopN rewrite
  with partition = correlation cols; ROW_NUMBER fallback rewrite; OFFSET
  carried through both routes.
- ☐ J3.8 Post-condition: no `DependentJoin`/`Subplan` remains (assert pass
  at end of decorrelation).

**J3 exit tests:** T-DECOR-01…30 (see matrix), plus differential coverage of
every case against the reference interpreter.

---

## J4 — Generalized aggregation

- ☐ J4.1 Class-driven decomposition: Distributive/Algebraic → partial/final
  operators; Holistic → repartition-then-full.
- ☐ J4.2 Shared hash table across same-class aggregates in one GroupBy.
- ☐ J4.3 Distinct aggregation rewrite + direct support flag.
- ☐ J4.4 groupjoin.rs: eager legality (join key == agg key && superkey of
  build side, from props.keys), count(*) multiplier correction, empty-group
  neutral elements; lazy fallback; cost choice stub.
- ☐ J4.5 Aggregate estimates feeding stats.rs (computed-column cardinality).
- ☐ J4.6 Empty-input semantics: scalar agg over empty input =
  `finish(init())` (per impl, not hardcoded); grouped agg absent-key
  behavior; `min/max` → `Option`.

**J4 exit tests:** T-AGG-11…24, T-GJ-01…08.

---

## J5 — Ordering / range end-to-end

- ☐ J5.1 `range` on Coll rejected at type level (already D1; test the error).
- ☐ J5.2 TopN fusion + pushdown through decorrelation (all §4.3 cases).
- ☐ J5.3 Ordering property recorded through rewrites; physical layer reuses
  sortedness (no double sort — plan assertion).
- ☐ J5.4 Unorderedness honesty: `--shuffle-coll-batches` test mode; full
  suite green under it.

**J5 exit tests:** T-ORD-01…10.

---

## J6 — PIR (Cascades)

- ☐ J6.1 memo.rs + tasks.rs: groups, winners per required props,
  branch-and-bound, applied bitmaps.
- ☐ J6.2 props.rs: ordering/partitioning/location/boundedness requirement &
  satisfaction; enforcer insertion (Sort, Exchange).
- ☐ J6.3 rules/scans.rs, joins.rs (hash/merge/nested-gated/diamond),
  aggregate.rs (partial/final, groupjoin physical), sort.rs, exchange.rs.
- ☐ J6.4 cost.rs (simple) + stats.rs (samples, zone maps, aggregate
  estimates, damping).
- ☐ J6.5 capability.rs per-location; memory backend answers fully.
- ☐ J6.6 registry.rs: function registration + version anchoring;
  unregistered-fn error path (explicit local fallback, costed).
- ☐ J6.7 EXPLAIN for LIR and PIR with per-rule provenance.

**J6 exit tests:** T-PIR-01…16.

---

## J7 — Exec

- ☐ J7.1 interpreter.rs FIRST: the dumb reference executor over LIR (no
  rewrites, no batches). All semantics tests run against it alone.
- ☐ J7.2 batch.rs + primitives (arith/cmp/bool/string/cast) + Project/Filter
  fusion.
- ☐ J7.3 pipeline.rs + scan/filter/project/limit/distinct.
- ☐ J7.4 hash_table.rs (unchained) + hash_join (dynamic filters, spill) +
  hash_aggregate (partial/final, spill).
- ☐ J7.5 sort.rs external sort + partitioned TopN; group_join; merge_join.
- ☐ J7.6 morsel.rs scheduler; memory.rs pools+arbitrator; spill paths for
  join/agg/sort exercised under forced-low memory.
- ☐ J7.7 exchange.rs local flavor; credit flow control unit tests
  (shuffle/broadcast when remote lands).
- ☐ J7.8 value.rs: result arena, Option values, no Null.
- ☐ J7.9 Differential harness: random schemas/data/queries; reference vs
  optimized; bag-equality (seq-equality where ordered); runs in CI.

**J7 exit tests:** T-EXEC-01…20, T-DIFF-01…06.

---

## Test matrix (exhaustive case enumeration)

### Recognition (T-REC)
01 core lang item on trait method recognized via resolution ·
02 impl-item resolution recognized (not just trait-item) ·
03 sugar method inlines default body → Aggregate operator ·
04 user-overridden sugar method honored (no inlining of default) ·
05 user fn named `sum` NOT mistaken for aggregate (shadowing) ·
06 aggregate over element (`sum(u)`) → type error + suggestion ·
07 free-function `sum(users)` form (if stdlib provides it) ·
08 `.query()` adapter on `[T]` lowers identically to comprehension form ·
09 no `Queryable` impl for `[T]` (trait-bound error where expected) ·
10 custom UDA: zero compiler changes, full pipeline ·
11 `@lang` on trait items collected by resolver ·
12 `QueryableMethod` keyed by lang item only (no name table remains —
grep test).

### Scoping (T-SCOPE)
01 `select users[*] from users@u` ok · 02 `select u from users@u` error +
suggestion · 03 `where u.age > 1` ok · 04 `order by u.age` ok ·
05 `group by { c: u.city } into g` ok · 06 `select g[*].{…} … into g` ok ·
07 links binders usable in link modifiers, not bare in projection ·
08 nested selector re-binds `u` (`users@u[*].{…}`) independently of from-binder.

### Derive/synthetic ids (T-DERIVE)
01 synthetic DefId resolves through definitions arena (item lookup,
diagnostics naming) · 02 derived impl on generic ADT preserves generics +
bounds · 03 derive helper passes attrs through · 04 no id collision under
many derives (fuzz: 1000 derived impls).

### Lowering (T-LOW)
01 select/from/where/order/range golden LIR · 02 multi-root from ·
03 links traversal (1..n hops, directions) · 04 group-by group records ·
05 nested projection → Subplan+DependentJoin · 06 object projection
shorthand/rename/computed · 07 comprehension [*]/[**]/[where] ·
08 let-bound source inlining · 09 method chain → same LIR as clause form ·
10 mutation queries: structured result or structured error ·
11 Seq/Coll types on every node · 12 `execute()` boundary ·
13 `select 1` → Expr root with dead scan marked · 14 binder shadowing ·
15 datetime/other literals · 16 Option-typed fields through joins ·
17 empty from-collection edge cases · 18 deeply nested queries (depth 8) ·
19 query in fn args/returns · 20 query over Querying adapter.

### Aggregates (T-AGG)
01–06 each built-in (sum/product/count/avg/min/max) over i32/i64/f64 ·
07 avg on empty input · 08 min/max → Option (empty → None) ·
09 count over empty → 0 · 10 custom UDA (e.g. StringConcat) end-to-end ·
11 class read from `class()` body (not name) · 12 config aggregate
(Percentile{p}) config shipped to closures · 13 distributive partial+final
≡ full (random partitions) · 14 algebraic (avg) partial+final ≡ full ·
15 holistic forces repartition (plan assertion) · 16 shared hash table
across mixed-class group-by (plan assertion) · 17 count(distinct x) ·
18 aggregate in projection of grouped query · 19 aggregate over nested
collection (per-group members) · 20 aggregate estimates present in stats ·
21 volatility: volatile fn inside per_row rejected for remote, allowed local ·
22 `sum(u)` error path · 23 generic UDA impl (Count over T) extraction ·
24 UDA with user-defined Acc struct type.

### GroupJoin (T-GJ)
01 eager legal: PK/FK + key match → final group-by elided ·
02 eager illegal: non-superkey → lazy · 03 count(*) multiplier correction
exact on duplicated right side · 04 empty group neutral elements ·
05 cost choice picks lazy on selective right · 06 parallel merge correct ·
07 HAVING-as-filter on group records · 08 differential vs reference on
random PK/FK data.

### Decorrelation (T-DECOR)
01 filter pushdown · 02 map/repr extension · 03 inner join both-side
accessing · 04 semi/anti · 05 mark join (EXISTS shape) · 06 left-outer
null-rejecting vs not · 07 full-outer IS NOT DISTINCT FROM ·
08 static agg empty-input guard (COUNT bug) · 09 grouped agg Γ rule ·
10 window PARTITION BY amendment · 11 order-only pushdown ·
12 per-group TopN · 13 ROW_NUMBER fallback · 14 OFFSET through both
routes · 15 set-op branches · 16 distinct · 17 OneRow/constants ·
18 nested 2-level with shared outer refs (state merge; bounded memory —
the BTW'25 blow-up shape) · 19 union-find substitution drops D-join ·
20 keep-D-join when selective (cost flag) · 21 correlated links traversal ·
22 scalar subquery in projection · 23 EXISTS/NOT EXISTS ·
24 `IN` (semi) and `NOT IN` with Option semantics (anti + three-valued
guard → compile error or explicit) · 25 correlated aggregate in HAVING
position · 26 decorrelation after elision ordering (pass order fixed,
documented) · 27 post-pass assert: no DependentJoin/Subplan remains ·
28–30 differential: every case above against reference executor on
random data.

### Normalization/elision/folding (T-NORM / T-ELIDE / T-FOLD)
NORM 01 map fusion · 02 filter through map · 03 flat-map assoc ·
04 identity elim · 05 nested comprehension collapse · 06 dead-field elim ·
07 TopN fusion · 08 double-order-by collapse · 09 filter conjunction split ·
10 limit 0 elim · 11 redundant distinct elim under keys ·
12 idempotence of the full batch (fixpoint stable) · 13 per-rule dump
snapshot · 14 disable-flag honored.
ELIDE 01 dead source elided · 02 dead link elided · 03 `select 1` zero
reads (counting scan) · 04 demanded field subset reaches scan ·
05 group-by dead key elim · 06 elision never changes type of result.
FOLD 01 pure folded · 02 stable folded within query boundary only ·
03 volatile never folded · 04 folding respects Option semantics.

### Ordering (T-ORD)
01 range on Coll type error · 02 range on Seq ok · 03 TopN pushdown post
decorrelation · 04 ordering reuse (no double sort) · 05 order honesty
under `--shuffle-coll-batches` (whole suite) · 06 desc/asc mixed keys ·
07 range with open ends · 08 range on group members ·
09 order-by key referencing computed col · 10 limit+offset semantics exact.

### PIR (T-PIR)
01 memo group equivalence · 02 winner per required props ·
03 enforcer insertion (sort/exchange) · 04 hash vs merge join choice by
props · 05 nested-loop gated by unique-inner stats · 06 partial/final
decomposition by class · 07 exchange kinds per capability ·
08 unregistered fn → explicit local boundary error ·
09 broadcast cap respected · 10 cost pruning keeps optimal on
hand-computed cases · 11 DPccp join order on 6-way join ·
12 EXPLAIN golden outputs · 13 pass determinism (same plan twice) ·
14 disable-rule flag · 15 aggregate estimates feed join order ·
16 diamond strategy flag available on n:m.

### Exec (T-EXEC)
01 batch validity bitmaps · 02 core per type/op (exhaustive numeric
combinations, overflow policy) · 03 filter/project fusion ≡ unfused ·
04 hash join correct on skew · 05 dynamic filter pushed (instrumented) ·
06 hash agg partial/final · 07 spill join/agg/sort under 1 MB pool ·
08 sort stability + TopN partition correctness · 09 morsel work-stealing
terminates under straggler injection · 10 memory arbitrator forces spill,
no OOM, results identical · 11 exchange local credit: no unbounded buffer ·
12 group_join operator · 13 merge_join on sorted inputs ·
14 distinct hash vs sort · 15 limit short-circuit (early termination
counted) · 16 traversal expansion · 17 Option through every operator ·
18 result arena freed (leak check) · 19 empty-input every operator ·
20 single-row every operator.

### Differential (T-DIFF)
01 random schemas (1–6 sources, PK/FK, Option columns) × random queries
from the full grammar × reference-vs-optimized — 100k cases ·
02 bag-equality for Coll, seq-equality for Seq ·
03 same for grouped+aggregated queries ·
04 same under forced spill · 05 same under shuffled Coll batches ·
06 same at parallelism 1 and 8.

### Semantics invariants (T-SEM)
01 projection determines shape: `select 1` ≡ 1; `select [1,2]` ≡ [1,2] ·
02 group-by variant of 01 · 03 links variant of 01 ·
04 range doesn't change shape · 05 projection typing: query type ==
projection type (tycheck unit) · 06 elision preserves semantics ·
07 no implicit row mapping (SQL-style `SELECT u.*` has no equivalent — error) ·
08 aggregate-free projection never aggregates ·
09 element binders never leak to projection scope (compile-fail suite) ·
10 `from` required (rootless select parse error).

---

## Pass order (fixed, documented in rewrite/mod.rs)

```
lower → normalize(fixpoint) → elision → fold → pushdown
      → decorrelate(+agg/window/topn/equiv) → groupjoin → distinct
      → normalize(fixpoint, again) → props recompute → PIR search
```

Rationale: decorrelation runs on a normalized plan (single TopN form,
fused maps) so its lemmas stay small; elision runs before decorrelation so
dead correlated regions vanish early; a second normalize cleans up what
decorrelation exposes.
