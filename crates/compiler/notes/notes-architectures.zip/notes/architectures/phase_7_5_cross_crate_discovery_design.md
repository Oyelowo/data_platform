# Phase 7.5 — Cross-Crate Procedural Macro Discovery

Status: design approved-in-principle, implementation in this phase.
Depends on: Phase 7.3 (server-based expansion integration).

This phase replaces the hand-written `StaticEntry` registration stub with real,
metadata-driven discovery of procedural macros across crate boundaries, and
fixes the latent correctness bugs the adversarial review found in the stub.

## 1. Goals

- Discover which proc macros a compiled crate exports **without hand-written
  name/kind/index tables**.
- Read macro metadata **without `dlopen`** whenever possible (rustc `rmeta`
  lesson: `CrateRoot.proc_macro_data` is decoded from a metadata section, the
  dylib is only loaded at first expansion). Fall back to server introspection
  (rust-analyzer `ListMacros` lesson) when no metadata exists.
- Correct `macro_index` provenance: indices come from the dylib's actual
  export order (validated), never from the position of an entry in a
  caller-supplied slice.
- Crate-attributed, kind-aware registry with early duplicate detection.
- Freshness validation: content hash + size at discovery, protocol/triple
  checks before any load, descriptor cross-check at first load.
- A driver-facing public API: given proc-macro crate sources, produce a ready
  `MacroExpander`.

## 2. Core concepts

### 2.1 Proc-macro crate manifest (`*.ypm.json`)

A JSON sidecar emitted by the build system next to the compiled dylib.
Readable without loading any code. Versioned from day one.

```json
{
  "format_version": 1,
  "crate_name": "test_macro",
  "crate_version": "0.1.0",
  "host_triple": "aarch64-apple-darwin",
  "protocol_version": 1,
  "dylib": {
    "path": "libtest_macro.dylib",
    "content_hash": "blake3:9f2c...",
    "size": 4123304
  },
  "macros": [
    { "name": "make_answer", "kind": "FunctionLike" },
    { "name": "trace", "kind": "Attribute" },
    { "name": "answer", "kind": "Derive" }
  ]
}
```

Field semantics:

| Field | Meaning | Validation |
|---|---|---|
| `format_version` | Manifest schema version (`1`). | Must equal `MANIFEST_FORMAT_VERSION`; anything else → `UnsupportedFormatVersion`. |
| `crate_name` | Origin crate, recorded on every registered macro. | Non-empty. |
| `crate_version` | Informational (future SVH-style checks). | Non-empty. |
| `host_triple` | Target triple the dylib was built for. Proc macros always run on the host. | Must equal the compiler's own `YELANG_HOST_TRIPLE` → `TripleMismatch`. |
| `protocol_version` | Bridge protocol version the dylib speaks. | Must equal `CURRENT_PROTOCOL_VERSION` → `ProtocolMismatch`. Checked **before** any `dlopen`; the server re-checks at load (belt and braces). |
| `dylib.path` | Dylib location. Relative paths resolve against the manifest's directory; absolute paths are used as-is. | File must exist and be readable at discovery. |
| `dylib.content_hash` | `blake3:<hex>` of the dylib bytes. | Recomputed at discovery → `HashMismatch`. Content-based (not mtime), so `touch` does not fool it and real rebuilds always fail closed. |
| `dylib.size` | Byte size. | Cheap pre-check before hashing → `SizeMismatch`. |
| `macros` | Exported macros **in dylib export order**. Position in the array **is** the `macro_index` used in `ExpandFnLike`/`ExpandAttr`/`ExpandDerive` requests. | Non-empty (`EmptyLibrary`); cross-checked against the dylib's real descriptors at first load. |

Manifest files are capped at 64 KiB on read — a manifest is small by
definition; anything larger is rejected (`ManifestTooLarge`) instead of being
parsed unboundedly.

### 2.2 Discovery sources

```rust
pub enum ProcMacroSource {
    /// Explicit manifest path. No probing, no dlopen.
    Manifest(PathBuf),
    /// Dylib path. If a `<dylib-file-stem>.ypm.json` sidecar exists next to
    /// it, it is used (manifest path). Otherwise the dylib is introspected
    /// through the server.
    Dylib(PathBuf),
}
```

### 2.3 Introspection fallback

The server protocol already enumerates a library's exports:
`Request::LoadLibrary` → `Response::LibraryLoaded { library, macros:
Vec<MacroDescriptor> }`, where **the position in `macros` is the
`macro_index`** (`yelang-proc-macro-server/src/server/library.rs` builds
`descriptors` and the dispatch table in the same loop). The client previously
discarded this vector; it now returns it.

Introspecting discovery:

1. Loads the dylib through the server (the only `dlopen` in discovery, and it
   happens inside the sandboxed server process).
2. Synthesizes in-memory metadata: `crate_name` = dylib file stem with the
   `lib` prefix stripped, `provenance = Introspected`, fingerprint computed
   from the file.
3. Registers macros with the introspected indices.
4. Pre-seeds the runtime's load cache with the returned handle and marks the
   entry `validated = true`, so the first expansion of an introspected macro
   does **not** load the library twice and skips the descriptor cross-check.

Manifest-based discovery performs no load at all; the runtime's load cache is
populated lazily at first expansion with `validated = false`, and the
descriptor cross-check runs at that point.

### 2.4 Registry: crate attribution, kind-aware lookup, duplicates

`ProcMacroDef` gains `crate_name: String`. Lookup becomes kind-aware, matching
Rust's macro namespaces: a function-like macro and a derive may share a name,
but two registrations with the same `(name, kind)` are a hard error at
discovery time, naming both crates (`DuplicateMacro { name, kind, first_crate,
second_crate }`). rustc defers this to an ambiguity error at the use site;
failing early at discovery is strictly better DX and we have no back-compat
reason to copy the deferred behaviour.

`find_by_name` is removed (kind-blind lookup was a stub shortcut, not an API
worth keeping).

### 2.5 Runtime: canonicalized cache, load-time validation

- Cache keys are canonicalized paths (`std::fs::canonicalize`, falling back to
  the raw path if canonicalization fails), so `a/lib.dylib` and
  `/abs/a/lib.dylib` load once.
- On a **fresh** load (not a cache hit), the runtime cross-checks the server's
  returned descriptors against the registry entries for that library (sorted
  by `macro_index`, compared as a `(name, kind)` sequence). A mismatch means
  the manifest and the dylib disagree — reported as
  `ProcMacroClientError::Validation`, cached like any other load failure so it
  is reported once.
- `ProcMacroRuntime::discover(&mut self, source)` and
  `discover_all(&mut self, sources) -> DiscoveryReport { discovered, errors }`
  are the entry points. `discover_all` continues past individual failures so a
  driver sees every bad extern in one pass.

### 2.6 Host triple capture

`yelang-macro/build.rs` forwards Cargo's `TARGET` (the triple the compiler
itself is built for — proc macros run on the host, so this is the correct
reference) as `YELANG_HOST_TRIPLE`. Manifest validation compares against it.
This mirrors rustc's `CrateLocator::for_proc_macro` retargeting the search to
`sess.host`, designed in from day one instead of retrofitted.

### 2.7 Server discovery

`ProcMacroClient::spawn_default()` resolves the server executable in order:

1. `YELANG_PROC_MACRO_SERVER` environment variable.
2. `yelang-proc-macro-server[.exe]` next to `std::env::current_exe()`.
3. `ProcMacroClientError::Spawn` explaining both lookup rules.

Tests keep using `CARGO_BIN_EXE_yelang-proc-macro-server` via `spawn`.

### 2.8 Freshness layers (summary)

| Layer | When | Catches |
|---|---|---|
| `size` + `content_hash` | Discovery (manifest) | Stale/tampered dylib behind an unchanged manifest. |
| `protocol_version`, `host_triple` | Discovery, pre-dlopen | Incompatible artifacts rejected before code runs. |
| Descriptor cross-check | First load | Manifest/dylib macro-list skew (renamed, reordered, removed exports). |
| Server ABI check (existing) | Load | Hand-built/foreign dylibs with wrong entry ABI. |

## 2.9 Adversarial-review hardening

The original implementation was functionally complete but had several
robustness gaps. The following changes close them.

### 2.9.1 Manifest I/O and validation

- **Bounded reads.** `read` caps the file at `MAX_MANIFEST_BYTES + 1` bytes
  during the read itself, so a manifest that grows between `stat` and `read`
  cannot be parsed unboundedly.
- **Streaming blake3.** `fingerprint_dylib` hashes the file in 64 KiB chunks,
  avoiding a one-shot allocation of the whole dylib.
- **Atomic manifest writes.** `write` emits to a sibling `.ypm.json.tmp` file
  and renames it into place, so concurrent readers never see a partially
  written manifest.
- **Op-annotated I/O errors.** Every `Io` variant carries `op: &'static str`
  (`"stat manifest"`, `"open dylib"`, etc.) so diagnostics name exactly what
  failed.
- **Intra-manifest duplicate rejection.** `read` rejects a manifest that lists
  the same `(name, kind)` twice, catching malformed generator output early.

### 2.9.2 Discovery invariants

- **One dylib per registration.** `discovery.rs` rejects a second source that
  would register the same canonical dylib under a different crate name as
  `DuplicateLibrary`. This prevents cache-key collisions and descriptor-skew
  confusion.
- **All-or-nothing per source.** Duplicate checks run before any registration,
  so a failed source leaves the registry untouched.

### 2.9.3 Resolver cache

- **`CacheEntry { result, validated }`.** Loads are cached with a separate
  `validated` flag. Introspection pre-seeds the cache with `validated = true`
  because the descriptors came directly from the server. Manifest-based
  discovery seeds `validated = false`; the first expansion (or a later
  re-validation) runs the descriptor cross-check and flips the flag.
- **`resolver_mut()`** allows tests and drivers to mutate the registry after
  the runtime is constructed (e.g., to pre-register macros for unit tests).

### 2.9.4 Registry canonicalization

`ProcMacroRegistry::register` canonicalizes `library_path` when the file
exists, with a fallback to the raw path. This guarantees that cache keys,
`expected_descriptors` lookups, and the one-dylib-per-registration invariant all
see the same path spelling.

### 2.9.5 Server lookup

`ProcMacroClient::spawn_default` treats an empty or whitespace-only
`YELANG_PROC_MACRO_SERVER` value as unset, falling through to the sibling lookup
instead of trying to spawn an empty path.

### 2.9.6 Panic isolation

Proc macros run inside the server process, so a panicking macro must not crash
the compiler. Two layers handle this:

1. **In-dylib panic capture.** `yelang-proc-macro/src/bridge/run.rs` installs a
   chained panic hook (once, thread-safe) that captures the panic message in a
   thread-local while an active macro is running, then converts the panic into
   an error diagnostic in the `WireExpansionResult`. This works reliably because
   the fixture crate type is `dylib` (shares the panic runtime with the server),
   not `cdylib`.
2. **`C-unwind` ABI + server `catch_unwind`.** The macro entry functions are
   `extern "C-unwind"`. The server wraps calls in `catch_unwind`; if the dylib's
   own capture somehow fails, the server still returns `Response::Panic` instead
   of aborting. This is a belt-and-braces last resort.

### 2.9.7 Test infrastructure

- **Tests moved to `yelang-proc-macro-server/tests`.** The integration tests
  need the server binary (`CARGO_BIN_EXE_...`) and the fixture dylib, neither of
  which is available to tests inside `yelang-macro` without a circular
  dev-dependency. Moving the tests removes the circular dependency and ensures
  the fixture is rebuilt before tests run.
- **Isolated manifest temp dirs.** The shared fixture helper writes each test
  manifest into a unique temp directory (keyed by process id and an atomic
  counter) with an absolute dylib path. Parallel tests no longer race over files
  in `target/`.
- **Fixture macro renamed.** The panic-testing macro was renamed from `panic`
  to `explode` to avoid shadowing the builtin `panic!` macro.

## 3. Exhaustive file tree

```
crates/compiler/
├── Cargo.toml                                  [+blake3 workspace dep]
├── yelang-macro/
│   ├── build.rs                                [new: YELANG_HOST_TRIPLE]
│   ├── Cargo.toml                              [+serde, +serde_json, +blake3]
│   └── src/
│       ├── lib.rs                              [re-export expand_program_with_proc_macros]
│       ├── expander.rs                         [kind-aware attribute macro detection now
│       │                                         also consults the out-of-process runtime
│       │                                         resolver; 3 resolve() call sites pass ProcMacroKind]
│       └── proc_macro/
│           ├── mod.rs                          [router only: +manifest, +discovery types,
│           │                                     -ProcMacroDiscovery, -StaticEntry]
│           ├── manifest.rs                     [bounded reads, streaming blake3, atomic writes,
│           │                                     op-annotated Io errors, intra-manifest duplicate
│           │                                     rejection]
│           ├── discovery.rs                    [ProcMacroSource, DiscoveryError, DiscoveredCrate,
│           │                                     DuplicateLibrary, one-dylib-per-registration]
│           ├── registry.rs                     [+crate_name, kind-aware find, canonicalized
│           │                                     library_path, duplicate query]
│           ├── resolver.rs                     [kind-aware resolve; runtime discover;
│           │                                     CacheEntry { result, validated };
│           │                                     resolver_mut; load-time validation]
│           ├── client.rs                       [load_library → LoadedLibrary; spawn_default treats
│           │                                     empty YELANG_PROC_MACRO_SERVER as unset]
│           ├── expand.rs                       [unchanged]
│           ├── executor.rs                     [unchanged]
│           └── export.rs                       [unchanged]
└── yelang-proc-macro-server/
    └── tests/
        ├── server_integration.rs               [raw server protocol tests; 1-based wire IDs;
        │                                         panic fixture renamed to explode; panic returns
        │                                         Error diagnostic]
        ├── macro_discovery.rs                  [migrated from yelang-macro/tests; manifest and
        │                                         introspection discovery, freshness, duplicates]
        ├── macro_server_integration.rs         [migrated from yelang-macro/tests; end-to-end
        │                                         expansion through discovery]
        ├── macro_fixture/mod.rs                [shared: server/dylib location, fixture build,
        │                                         isolated temp-dir manifests with absolute dylib
        │                                         paths, atomic counter for test isolation]
        └── fixtures/test_macro/                [fixture proc-macro dylib]
            ├── Cargo.toml                      [crate-type = ["dylib"]]
            └── src/lib.rs                      [six macros incl. explode (was panic)]
```

Changes outside `yelang-macro`:
- `yelang-proc-macro/src/bridge/run.rs`: panic capture via chained panic hook +
  thread-local storage, converting macro panics into error diagnostics inside the
  dylib before they reach the server.
- `yelang-proc-macro-test-fixture`: crate-type changed from `cdylib` to `dylib`
  so the fixture shares the panic runtime with the server and panics can be
  caught reliably; macro ABI functions are `extern "C-unwind"`.

No changes to `yelang-proc-macro-bridge` protocol (it already carries descriptors).

## 4. API changes

### 4.1 `manifest.rs` (new)

```rust
pub const MANIFEST_FORMAT_VERSION: u32 = 1;
pub const MANIFEST_EXTENSION: &str = "ypm.json";
pub const MAX_MANIFEST_BYTES: u64 = 64 * 1024;

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct ProcMacroCrateManifest {
    pub format_version: u32,
    pub crate_name: String,
    pub crate_version: String,
    pub host_triple: String,
    pub protocol_version: u32,
    pub dylib: DylibSection,
    pub macros: Vec<ManifestMacro>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct DylibSection {
    pub path: PathBuf,
    pub content_hash: String, // "blake3:<hex>"
    pub size: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct ManifestMacro {
    pub name: String,
    pub kind: ProcMacroKind,
}

impl ProcMacroCrateManifest {
    /// Parse + structural checks (format version, non-empty fields,
    /// non-empty macros, no duplicate (name, kind) within the manifest).
    /// Reads at most MAX_MANIFEST_BYTES + 1 bytes.
    pub fn read(path: &Path) -> Result<Self, DiscoveryError>;
    /// Serialize as pretty JSON. Writes atomically via a temp file + rename.
    pub fn write(&self, path: &Path) -> Result<(), DiscoveryError>;
    /// Absolute dylib path (relative paths resolve against the manifest dir).
    pub fn dylib_path(&self, manifest_path: &Path) -> PathBuf;
    /// Environment checks: size, blake3 hash, protocol version, host triple.
    /// Returns the canonicalized dylib path on success. No code is loaded.
    pub fn validate_environment(&self, manifest_path: &Path)
        -> Result<PathBuf /*canonical dylib path*/, DiscoveryError>;
}

/// Compute `("blake3:<hex>", size)` for a dylib incrementally — used by build
/// systems and tests when emitting manifests, and by discovery when validating.
pub fn fingerprint_dylib(path: &Path) -> Result<(String, u64), DiscoveryError>;

/// `<dylib dir>/<dylib file stem>.ypm.json`
pub fn sidecar_manifest_path(dylib_path: &Path) -> PathBuf;

/// Crate name synthesized for an introspected dylib: file stem with `lib`
/// prefix stripped (`libtest_macro.dylib` → `test_macro`).
pub fn crate_name_from_dylib_path(dylib_path: &Path) -> String;
```

### 4.2 `discovery.rs` (rewritten)

```rust
pub enum ProcMacroSource {
    Manifest(PathBuf),
    Dylib(PathBuf),
}

#[derive(Debug, Error)]
pub enum DiscoveryError {
    Io { path: PathBuf, source: String },
    ManifestTooLarge { path: PathBuf, size: u64 },
    ManifestParse { path: PathBuf, source: String },
    UnsupportedFormatVersion { path: PathBuf, found: u32, expected: u32 },
    InvalidManifest { path: PathBuf, reason: String },
    ProtocolMismatch { crate_name: String, found: u32, expected: u32 },
    TripleMismatch { crate_name: String, manifest: String, host: String },
    SizeMismatch { path: PathBuf, expected: u64, found: u64 },
    HashMismatch { path: PathBuf },
    EmptyLibrary { crate_name: String },
    DuplicateMacro {
        name: String,
        kind: ProcMacroKind,
        first_crate: String,
        second_crate: String,
    },
    DuplicateLibrary {
        path: PathBuf,
        first_crate: String,
        second_crate: String,
    },
    Introspection(ProcMacroClientError),
}

pub enum Provenance {
    Manifest,
    Introspected,
}

pub struct DiscoveredCrate {
    pub crate_name: String,
    pub provenance: Provenance,
    pub macro_ids: Vec<ProcMacroId>,
}

pub struct DiscoveryReport {
    pub discovered: Vec<DiscoveredCrate>,
    pub errors: Vec<DiscoveryError>,
}
```

The engine is one function used by `ProcMacroRuntime`:

```rust
/// Register every macro from `source` into `registry`.
///
/// `load` performs a server load (the runtime's caching loader); it is only
/// invoked for the introspection fallback. Manifest discovery never loads.
pub(crate) fn discover_source(
    registry: &mut ProcMacroRegistry,
    load: &mut dyn FnMut(&Path) -> Result<LoadedLibrary, ProcMacroClientError>,
    source: &ProcMacroSource,
) -> Result<DiscoveredCrate, DiscoveryError>;
```

Duplicate check happens before any registration of that source's macros, so a
failed discovery leaves the registry untouched (all-or-nothing per source).

`ProcMacroDiscovery` and `StaticEntry` are deleted.

### 4.3 `registry.rs`

```rust
pub struct ProcMacroDef {
    pub id: ProcMacroId,
    pub name: String,
    pub kind: ProcMacroKind,
    pub macro_index: u32,
    pub library_path: String,
    pub crate_name: String, // new
}

impl ProcMacroRegistry {
    /// Register a new macro. The `library_path` is canonicalized if the file
    /// exists (fallback to raw path), so cache keys and descriptor lookups are
    /// consistent across different spellings.
    pub fn register(
        &mut self,
        name: String,
        kind: ProcMacroKind,
        macro_index: u32,
        library_path: String,
        crate_name: String, // new
    ) -> ProcMacroId;

    /// Kind-aware lookup (macro namespaces: fn-like / attr / derive).
    pub fn find(&self, name: &str, kind: ProcMacroKind) -> Option<&ProcMacroDef>;

    /// Expected (name, kind) sequence for a library, ordered by macro_index.
    /// Used by the runtime's load-time descriptor cross-check.
    pub fn expected_descriptors(&self, library_path: &str)
        -> Vec<(String, ProcMacroKind)>;

    pub fn iter(&self) -> impl Iterator<Item = &ProcMacroDef>;

    // find_by_name: removed.
}
```

### 4.4 `client.rs`

```rust
pub struct LoadedLibrary {
    pub handle: LibraryHandle,
    pub descriptors: Vec<MacroDescriptor>, // position == macro_index
}

impl ProcMacroClient {
    pub fn load_library(&mut self, path: &str)
        -> Result<LoadedLibrary, ProcMacroClientError>; // was LibraryHandle

    /// Resolve the server from $YELANG_PROC_MACRO_SERVER (ignored if empty or
    /// whitespace-only) or next to the current executable.
    pub fn spawn_default() -> Result<Self, ProcMacroClientError>;
}

// New error variant:
// ProcMacroClientError::Validation(String) — manifest/dylib descriptor skew.
```

### 4.5 `resolver.rs`

```rust
impl ProcMacroResolver {
    pub fn resolve(&self, name: &str, kind: ProcMacroKind) -> Option<&ProcMacroDef>;
    pub fn registry(&self) -> &ProcMacroRegistry;
    pub fn registry_mut(&mut self) -> &mut ProcMacroRegistry;
}

impl ProcMacroRuntime {
    pub fn discover(&mut self, source: &ProcMacroSource)
        -> Result<DiscoveredCrate, DiscoveryError>;

    /// Continues past failures; the report carries every error.
    pub fn discover_all(&mut self, sources: &[ProcMacroSource]) -> DiscoveryReport;

    pub fn resolve(&self, name: &str, kind: ProcMacroKind)
        -> Option<Result<ResolvedProcMacro, ProcMacroClientError>>;

    pub fn resolver(&self) -> &ProcMacroResolver;
    pub fn resolver_mut(&mut self) -> &mut ProcMacroResolver;

    pub fn loaded_library_count(&self) -> usize;
}
```

Internal changes:
- Cache entries are `CacheEntry { result, validated }`; introspection pre-seeds
  with `validated = true`, manifest discovery with `validated = false` until the
  first expansion runs the descriptor cross-check.
- Cache keys are canonicalized.
- Fresh loads run the descriptor cross-check; mismatches are cached as a
  validation error.

### 4.6 `expander.rs` / `lib.rs`

- The three `self.proc_macro_runtime...resolve(name)` sites pass their kind
  (`FunctionLike` at the bang-macro site, `Attribute` at the attribute site, `Derive` at
  the derive site).
- `is_user_attribute_macro` now consults the out-of-process runtime resolver
  (in addition to declarative and in-process proc macros), so attribute macros
  discovered through manifests or introspection are recognized and expanded.
- `expand_program_with_proc_macros` loses `#[allow(dead_code)]` and is
  re-exported from `lib.rs` — it is the driver-facing entry point.

## 5. Examples

### 5.1 Build system / test emitting a manifest

```rust
let dylib = Path::new("target/debug/libtest_macro.dylib");
let (content_hash, size) = fingerprint_dylib(dylib)?;
let manifest = ProcMacroCrateManifest {
    format_version: MANIFEST_FORMAT_VERSION,
    crate_name: "test_macro".into(),
    crate_version: "0.1.0".into(),
    host_triple: env!("YELANG_HOST_TRIPLE").into(),
    protocol_version: CURRENT_PROTOCOL_VERSION,
    dylib: DylibSection {
        path: dylib.file_name().unwrap().into(), // relative to manifest dir
        content_hash,
        size,
    },
    macros: vec![
        ManifestMacro { name: "make_answer".into(), kind: ProcMacroKind::FunctionLike },
        ManifestMacro { name: "trace".into(), kind: ProcMacroKind::Attribute },
        ManifestMacro { name: "answer".into(), kind: ProcMacroKind::Derive },
    ],
};
manifest.write(Path::new("target/debug/test_macro.ypm.json"))?;
```

### 5.2 Driver flow

```rust
let client = ProcMacroClient::spawn_default()?;
let registry = ProcMacroRegistry::new();
let mut runtime = ProcMacroRuntime::new(client, ProcMacroResolver::new(registry));

let report = runtime.discover_all(&[
    ProcMacroSource::Manifest("target/debug/test_macro.ypm.json".into()),
    ProcMacroSource::Dylib("target/debug/libother_macros.so".into()), // probes sidecar, else introspects
]);
if !report.errors.is_empty() { /* report all, abort */ }

let mut expander = MacroExpander::new(interner).with_proc_macro_runtime(runtime);
let result = expander.expand_program_with_proc_macros(&mut program);
```

### 5.3 What the resolver sees

After 5.2, `resolve("make_answer", FunctionLike)` returns the def registered by
either source with the correct `macro_index`; `resolve("answer", FunctionLike)`
returns `None` even though a *derive* named `answer` exists — kind namespaces
are separate.

## 6. Design decisions

1. **JSON manifest, not postcard.** Build-system metadata should be
   human-inspectable and diff-able (rust-analyzer's protocol being opaque
   bytes is a recurring debugging complaint). `format_version` gives us schema
   evolution; the performance cost of JSON is irrelevant at this size.
2. **blake3 for content hashing.** Fast, single small crate, the modern
   default for content addressing in build tooling. mtime-only staleness
   (rust-analyzer) is cheap but silently wrong under `touch`, artifact
   copying, and clock skew; content hash + size fails closed. The descriptor
   cross-check at load covers anything the hash somehow misses.
3. **Discovery ≠ loading, with a contained exception.** Manifest discovery
   performs zero `dlopen` — mirrors rustc reading `proc_macro_data` from
   rmeta. The introspection fallback does load, but inside the server process
   (crash-isolated), mirrors rust-analyzer's `ListMacros`, and pre-seeds the
   cache so it never costs a second load.
4. **Hard error on duplicate `(name, kind)` at discovery.** rustc reports
   ambiguity at the use site; early failure names both crates and aborts
   before any expansion silently dispatches to the wrong macro.
5. **`macro_index` = dylib export order, always validated.** The stub's
   slice-position index dispatched to the wrong macro whenever the caller's
   table disagreed with the dylib. Now the index either comes from
   introspection (correct by construction) or from a manifest whose entire
   macro list is cross-checked against the dylib at first load.
6. **Canonicalized cache keys.** Cheap, removes the double-load class of
   bugs; failures remain cached per-session (a single compile's correct
   behaviour).
7. **Kind-aware registry namespaces now, not with 7.6.** Declarative
   attr/derive macros (7.6) need the same namespacing; doing it once here
   avoids a second migration.
8. **No crate-graph / name-resolution integration in this phase.**
   `yelang-resolve` has no extern-crate concept yet; discovery registers
   macros into the expansion-time registry and records crate attribution so
   that import-scoped resolution can be layered on later without changing the
   manifest format or the registry schema.
9. **Remove `discover_static`/`StaticEntry` outright.** Greenfield: the only
   caller was the integration test, which migrates to manifest discovery —
   the tests then exercise the same path a driver uses.

## 7. Adversarial considerations

| Attack / failure | Behaviour |
|---|---|
| Manifest newer/older than dylib (real rebuild) | `HashMismatch` at discovery — never loads stale code. |
| `touch`ed dylib, unchanged bytes | Content hash still matches; load proceeds. mtime games are irrelevant. |
| Manifest lists a macro the dylib doesn't export | Load-time descriptor cross-check → `Validation` error naming expected vs found. |
| Dylib exports reordered, manifest not regenerated | Same cross-check catches order skew (position = index). |
| Two crates export `derive(Foo)` | `DuplicateMacro` at discovery naming both crates; nothing registered from the second source. |
| Fn-like `foo` + derive `Foo` from different crates | Allowed — separate kind namespaces, as in Rust. |
| Same dylib passed as relative and absolute path | Canonicalized cache key → single server load, no double registration (duplicate check runs per registry, not per path spelling). |
| Introspected library expanded later | Cache pre-seeded with the introspection handle → no second `dlopen`. |
| Manifest `protocol_version` from the future/past | `ProtocolMismatch` before any `dlopen`. |
| Dylib built for another triple | `TripleMismatch` before any `dlopen`. |
| 2 GiB "manifest" | `ManifestTooLarge` (64 KiB cap) — no unbounded parse. |
| Manifest with empty `macros` | `EmptyLibrary` — mirrors rust-analyzer's `NoProcMacros`; catches mis-pointed paths early. |
| Dylib deleted between discovery and expansion | Load fails at expansion with the server's IO error, cached once. |
| Server binary missing | `spawn_default` error message documents both lookup rules. |
| Malformed sidecar JSON next to a valid dylib | `ManifestParse` — a broken explicit signal beats silently introspecting and registering the wrong thing. |
| Introspection of a dylib with zero exports | `EmptyLibrary`. |
| Same dylib registered under two crate names | `DuplicateLibrary` at discovery; the second source is rejected all-or-nothing. |
| Concurrent manifest read/write | Atomic rename write + bounded read; readers never see a torn manifest and never read unbounded bytes. |
| Huge manifest | `ManifestTooLarge` (64 KiB cap) — no unbounded parse. |
| Huge dylib | Streaming blake3 hashes in 64 KiB chunks; no whole-file allocation. |
| Manifest lists the same `(name, kind)` twice | `InvalidManifest` at read time, before any registration. |
| Empty `YELANG_PROC_MACRO_SERVER` env var | Treated as unset; falls back to sibling lookup instead of spawning an empty path. |
| Macro panics inside the server | Captured inside the dylib by `yelang_proc_macro::bridge::run` and converted to an error diagnostic; `C-unwind` + server `catch_unwind` is the last-resort belt. |
| `cdylib` panic-runtime incompatibility | Fixture uses `dylib` so panics share the server's runtime and can be caught reliably. |
| Integration tests racing on fixture manifests | Each test call writes its manifest into an isolated temp dir keyed by pid + atomic counter. |
| Cache poisoning across recompiles within one driver process | Failures are cached per `ProcMacroRuntime` instance; a long-lived driver recreates the runtime per compilation session (documented on `discover`). |
