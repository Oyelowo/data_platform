# Yelang Macro System — Production-Ready Design

**Status:** design draft for agreement before implementation.  
**Scope:** complete declarative and procedural macro subsystem, including the
public API (`quote!`, parse helper, diagnostics), out-of-process server,
compiler integration, cross-crate discovery, and a clean extension point for
future comptime/introspection.

This document is based on the current Yelang codebase, Rust RFCs and official
guidance, the rust-analyzer proc-macro server redesign, and the 2025 Kangrejos
paper on declarative macro improvements. Nothing in this document is considered
implemented unless explicitly marked `[implemented]`.

---

## 1. Design principles

1. **Token-based boundary.** Macros consume and produce token streams. The
   compiler grammar can evolve without breaking macro dylibs.
2. **Crash isolation.** Procedural macros run in a separate OS process
   (`yelang-proc-macro-server`). A panicking macro cannot crash the compiler.
3. **Single public API.** `yelang_proc_macro` is the only crate a macro author
   needs. There is no `proc-macro2` split and no mandatory `syn`/`quote` split.
4. **Hygiene by default.** Every identifier carries a `Span` with a syntax
   context. Macros cannot accidentally shadow user names.
5. **Structured diagnostics.** Macros emit `Diagnostic` values with spans, not
   raw strings.
6. **No legacy.** Because Yelang is greenfield, we adopt the best known design
   immediately rather than carrying historical workarounds.
7. **No `util` modules.** Every module has a concrete name.
8. **`lib.rs`/`mod.rs` are routers.** Implementation lives in named submodules.
9. **SlotMap-style IDs.** Server session handles use `slotmap`. The same pattern
   is recommended for HIR/type-checking IDs, but that is outside this subsystem.
10. **Declarative and procedural macros are peers.** Both resolve through
    `MacroNS`, both support function-like, attribute, and derive forms, and both
    can be mixed in the same crate.

### 1.1 Lessons from Rust

| Rust pain point | Root cause | Yelang choice |
|---|---|---|
| `proc-macro2` + `syn` + `quote` are effectively mandatory | `proc_macro` API was too low-level and tied to rustc internals | `yelang_proc_macro` ships `quote!`, a lightweight `parse` helper, and diagnostics in one crate. |
| Proc macros run in-process and can crash rustc | Dynamic linking into the compiler process | Out-of-process `yelang-proc-macro-server`. |
| rust-analyzer uses an organic JSON RPC that cannot support backcalls | Grew organically | Versioned binary protocol (postcard) from the start, designed for nested request/response channels. |
| Rust ABI is unstable, so rustc uses a complex handle-table/vtable bridge | No stable ABI across compiler versions | Stable C ABI passing versioned postcard-serialized token streams. The dylib deserializes into its own copy of `yelang_proc_macro`. |
| Helper attributes for derives have no namespacing | Historical accident | Derive helper attributes are resolved through normal name resolution and carry syntax-context hygiene. |
| String round-tripping loses spans in early macros 1.1 | Token API was not rich enough | Full token trees with spans are sent over the wire from day one. |
| Declarative macros cannot be attributes or derives | Original design limited to function-like | Adopt `attr()` and `derive()` rule prefixes from RFC 3697 / RFC 3698. |

### 1.2 Key references

- [RFC 1566 — Procedural Macros](https://rust-lang.github.io/rfcs/1566-proc-macros.html)
- [RFC 1681 — Macros 1.1](https://rust-lang.github.io/rfcs/1681-macros-1.1.html)
- [RFC 3697 — Declarative Attribute Macros](https://rust-lang.github.io/rfcs/3697-declarative-attribute-macros.html)
- [RFC 3698 — Declarative Derive Macros](https://rust-lang.github.io/rfcs/3698-declarative-derive-macros.html)
- [RFC 3714 — Fragment Fields](https://github.com/rust-lang/rfcs/pull/3714)
- [RFC 3715 — Unsafe Derives and Attributes](https://github.com/rust-lang/rfcs/pull/3715)
- [JetBrains — Procedural macros under the hood, part II](https://blog.jetbrains.com/rust/2022/07/07/procedural-macros-under-the-hood-part-ii/)
- [Little Book of Rust Macros — Hygiene](https://lukaswirth.dev/tlborm/proc-macros/hygiene.html)
- [Rustc Dev Guide — Macro Expansion](https://rustc-dev-guide.rust-lang.org/macro-expansion.html)
- [rust-analyzer proc-macro server redesign](https://github.com/rust-lang/rust-analyzer/issues/19205)
- [Kangrejos 2025 — Declarative Macro Improvements](https://kangrejos.com/2025/Rust%20Declarative%20Macro%20Improvements:%20A%20Step%20Forward%20for%20Rust%20Macros%20Usability.pdf)

---

## 2. Macro taxonomy

```text
Macros
├── Declarative (macro_rules!)
│   ├── function-like   my_macro! { ... }
│   ├── attribute       #[my_macro] fn foo() {}
│   └── derive          #[derive(MyDerive)] struct S;
├── Procedural
│   ├── function-like   my_proc! { ... }
│   ├── attribute       #[my_attr] fn foo() {}
│   └── derive          #[derive(MyDerive)] struct S;
└── comptime / introspection (Phase 8)
    ├── comptime { ... } blocks
    ├── comptime fn
    └── @comptime item attribute
```

All six macro forms resolve through `MacroNS`. Declarative and procedural macros
can share a name in the same namespace if and only if one is shadowed by an
explicit import; the normal name-resolution rules apply.

`comptime` is a separate compile-time code-evaluation system, not a macro form.
It is designed in `notes/architectures/comptime_design.md` and scheduled for
Phase 8 implementation.

---

## 3. Architectural overview

```text
┌─────────────────────────────────────────────────────────────────────────────┐
│ Compiler (yelang-driver / yelang-macro)                                      │
│  - parses source                                                             │
│  - resolves macro names in MacroNS                                           │
│  - expands declarative macros                                                │
│  - dispatches procedural macros to server                                    │
│  - integrates returned TokenStream back into the AST                         │
└──────────────────────────────┬──────────────────────────────────────────────┘
                               │ binary IPC (postcard over stdin/stdout)
                    ┌──────────▼──────────┐
                    │ yelang-proc-macro-  │
                    │ server              │
                    │  - loads .so/.dll   │
                    │  - executes macro   │
                    │  - enforces limits  │
                    │  - catches panics   │
                    └──────────┬──────────┘
                               │ stable C ABI: versioned postcard buffers
                    ┌──────────▼──────────┐
                    │ proc-macro crate    │
                    │ (compiled dylib)    │
                    │  uses               │
                    │  yelang_proc_macro  │
                    └─────────────────────┘
```

### 3.1 Why serialized token streams across the dylib boundary?

Rust has no stable ABI, and Yelang will not have one for a long time. Rust
solves this with a complex handle-table/vtable bridge. For Yelang's greenfield
implementation we use a simpler, equally robust approach for the current feature
set:

- The server serializes the input `WireTokenStream` to a postcard byte buffer.
- It calls the dylib through a small stable C ABI that takes/returns byte
  buffers.
- The dylib deserializes the buffer into its own `yelang_proc_macro::TokenStream`,
  runs the user-defined macro, and serializes a `WireExpansionResult` back.
- Macro functions use the `C-unwind` ABI so panics can be caught by the server.

If future features (backcalls from the dylib into the compiler, or huge token
streams where serialization is a bottleneck) require a vtable model, the
protocol can be extended without breaking the existing ABI.

---

## 4. Exhaustive file tree

```text
crates/compiler/
├── yelang-macro-core/                     # shared TokenTree, Span, HygieneData, IDs
│   ├── Cargo.toml
│   └── src/
│       ├── lib.rs                         # re-exports only
│       ├── hygiene.rs                     # SyntaxContext, ExpnId, hygiene operations
│       ├── id.rs                          # MacroId, SyntaxContextId newtypes
│       └── token_tree/
│           ├── mod.rs                     # re-exports
│           ├── codegen.rs                 # TokenStream → source string
│           ├── ident.rs                   # Ident, raw flag
│           ├── literal.rs                 # Literal, LitKind
│           ├── punct.rs                   # Punct, Spacing
│           ├── render.rs                  # rendering helpers
│           ├── span.rs                    # Span (file/lo/hi/ctx)
│           ├── stream.rs                  # TokenStream
│           ├── token_id.rs                # stable token id newtype
│           └── tree.rs                    # TokenTree, Group, Delimiter
│
├── yelang-macro/                          # declarative + procedural expansion
│   ├── Cargo.toml
│   ├── src/
│   │   ├── lib.rs                         # re-exports only
│   │   ├── builtin_decorators.rs          # built-in attributes used by expansion
│   │   ├── builtin_macros.rs              # built-in macros (file!, line!, etc.)
│   │   ├── eager.rs                       # eager macro expansion helpers
│   │   ├── error.rs                       # ExpandError kinds
│   │   ├── expander.rs                    # main MacroExpander loop
│   │   ├── paste.rs                       # token pasting
│   │   ├── quote.rs                       # compiler-side quote! (for builtins)
│   │   ├── resolver.rs                    # macro name resolution in MacroNS
│   │   ├── transcribe.rs                  # macro_rules! transcription
│   │   ├── matcher/
│   │   │   ├── mod.rs                     # re-exports
│   │   │   ├── bindings.rs                # metavar bindings
│   │   │   ├── cursor.rs                  # matcher cursor
│   │   │   ├── engine.rs                  # macro_rules! matching engine
│   │   │   ├── follow.rs                  # follow-set validation
│   │   │   ├── fragment.rs                # fragment specifiers
│   │   │   ├── fragment_fields.rs         # RFC 3714-style field access
│   │   │   ├── parser.rs                  # matcher parser
│   │   │   └── types.rs                   # matcher types
│   │   └── proc_macro/
│   │       ├── mod.rs                     # re-exports
│   │       ├── client.rs                  # ProcMacroClient, talk to server
│   │       ├── discovery.rs               # find proc macros in crate graph
│   │       ├── executor.rs                # in-process trait-object executor
│   │       ├── expand.rs                  # AST ↔ WireTokenStream conversion
│   │       ├── export.rs                  # #[macro_export] codegen
│   │       └── registry.rs                # ProcMacroRegistry, ProcMacroId
│   └── tests/
│       ├── declarative_macros.rs
│       ├── declarative_macros_exhaustive.rs
│       ├── declarative_macros_hygiene.rs
│       ├── declarative_macros_phase2.rs
│       ├── declarative_macros_phase3.rs
│       ├── declarative_macros_phase4.rs
│       ├── declarative_macros_phase5.rs
│       ├── declarative_macros_phase6.rs
│       └── proc_macro_integration.rs
│
├── yelang-proc-macro/                     # public API for macro authors
│   ├── Cargo.toml
│   └── src/
│       ├── lib.rs                         # re-exports only
│       ├── api/
│       │   ├── mod.rs                     # re-exports
│       │   ├── delimiter.rs               # Delimiter enum
│       │   ├── diagnostic.rs              # Diagnostic, Level, DiagnosticSpan
│       │   ├── ident.rs                   # Ident constructors
│       │   ├── literal.rs                 # Literal constructors (string, int, float, byte, ...)
│       │   ├── punct.rs                   # Punct, Spacing
│       │   ├── span.rs                    # Span, SourceFile, LineColumn
│       │   ├── token_stream.rs            # TokenStream, IntoIterator, Display
│       │   └── token_tree.rs              # TokenTree, Group
│       ├── bridge/
│       │   ├── mod.rs                     # re-exports
│       │   ├── run.rs                     # run_fn_like_macro, run_attr_macro, run_derive_macro
│       │   └── serialize.rs               # WireTokenStream ↔ TokenStream conversion
│       ├── introspect/
│       │   ├── mod.rs                     # re-exports
│       │   └── token_walker.rs            # high-level visitor over TokenStream
│       ├── parse/
│       │   ├── mod.rs                     # re-exports
│       │   ├── buffered.rs                # lookahead / fork support
│       │   ├── cursor.rs                  # low-level Peekable token cursor
│       │   ├── error.rs                   # ParseError with span
│       │   └── parser.rs                  # Parse trait, Parser combinators
│       └── to_tokens.rs                   # ToTokens trait + impls
│
├── yelang-quote/                          # the `quote!` procedural macro
│   ├── Cargo.toml
│   └── src/
│       ├── lib.rs                         # re-exports `quote!` proc macro
│       ├── parse.rs                       # quote! template parser
│       └── emit.rs                        # quote! code generation
│
├── yelang-proc-macro-bridge/              # stable ABI/protocol types
│   ├── Cargo.toml
│   └── src/
│       ├── lib.rs                         # re-exports only
│       ├── abi/
│       │   ├── mod.rs                     # re-exports
│       │   ├── registrar.rs               # macro registration table layout
│       │   ├── signature.rs               # ProcMacroKind, function signatures
│       │   └── symbols.rs                 # exported symbol names
│       ├── protocol/
│       │   ├── mod.rs                     # re-exports
│       │   ├── message.rs                 # Request / Response enums
│       │   ├── serialize.rs               # postcard encode/decode helpers
│       │   ├── token.rs                   # wire representation of TokenStream/Span
│       │   └── version.rs                 # protocol version negotiation
│       └── sandbox/
│           ├── mod.rs                     # re-exports
│           ├── error.rs                   # SandboxError
│           └── limits.rs                  # memory / time / output limits
│
└── yelang-proc-macro-server/              # executable server
    ├── Cargo.toml
    ├── tests/
    │   ├── server_integration.rs
    │   └── fixtures/
    │       └── test_macro/
    │       │   ├── Cargo.toml
    │       │   └── src/lib.rs
    └── src/
        ├── lib.rs                         # re-exports only
        ├── main.rs                        # CLI entry point
        ├── executor/
        │   ├── mod.rs                     # re-exports
        │   ├── context.rs                 # thread-local MacroContext
        │   ├── invoke.rs                  # call a macro function across the C ABI
        │   ├── limits.rs                  # per-expansion limit enforcement
        │   └── panic.rs                   # panic payload → message
        ├── protocol/
        │   ├── mod.rs                     # re-exports
        │   └── io.rs                      # framed read/write over stdin/stdout
        └── server/
            ├── mod.rs                     # re-exports
            ├── library.rs                 # dylib loading / unloading
            ├── run.rs                     # request loop
            └── session.rs                 # per-client session state (slotmap)
```

---

## 5. Public API (`yelang_proc_macro`)

### 5.1 Types

```rust
// yelang-proc-macro/src/api/token_stream.rs
pub struct TokenStream { ... }

impl TokenStream {
    pub fn new() -> Self;
    pub fn is_empty(&self) -> bool;
    pub fn len(&self) -> usize;
    pub fn iter(&self) -> Iter<'_, TokenTree>;
    pub fn push(&mut self, tree: TokenTree);
    pub fn extend(&mut self, other: TokenStream);
}

impl From<TokenTree> for TokenStream { ... }
impl FromIterator<TokenTree> for TokenStream { ... }
impl Display for TokenStream { ... }
```

```rust
// yelang-proc-macro/src/api/token_tree.rs
pub enum TokenTree {
    Group(Group),
    Ident(Ident),
    Punct(Punct),
    Literal(Literal),
}
```

```rust
// yelang-proc-macro/src/api/delimiter.rs
pub enum Delimiter {
    Parenthesis,
    Brace,
    Bracket,
    None,            // invisible group, used by macro expansion
}
```

```rust
// yelang-proc-macro/src/api/span.rs
pub struct Span { ... }

impl Span {
    pub fn call_site() -> Self;
    pub fn mixed_site() -> Self;
    pub fn def_site() -> Self;
    pub fn source_file(&self) -> SourceFile;
    pub fn start(&self) -> LineColumn;
    pub fn end(&self) -> LineColumn;
    pub fn resolved_at(self, other: Span) -> Self;
}
```

### 5.2 Literal constructors

`Literal` must support:

- `string`
- `raw_string`
- `character`
- `integer`
- `float`
- `boolean`
- `byte_string`  ← missing
- `byte`         ← missing

### 5.3 Macro entry points

A proc-macro crate defines exported functions with stable symbol names:

```rust
// function-like
#[yelang_proc_macro::macro_export]
pub fn my_macro(input: TokenStream) -> TokenStream { ... }

// attribute
#[yelang_proc_macro::macro_export_attribute]
pub fn my_attr(args: TokenStream, item: TokenStream) -> TokenStream { ... }

// derive
#[yelang_proc_macro::macro_export_derive]
pub fn my_derive(input: TokenStream) -> TokenStream { ... }
```

The attribute:

1. Validates the function signature based on return type and argument count.
2. Registers the macro in the dylib's export table under
   `yelang_proc_macro_entry`.
3. Generates a safe wrapper that delegates to `yelang_proc_macro::bridge`.

### 5.4 `quote!`

```rust
use yelang_proc_macro::{quote, Ident, TokenStream};

let name: Ident = ...;
let expanded: TokenStream = quote! {
    impl Clone for #name {
        fn clone(&self) -> Self { *self }
    }
};
```

`quote!` must support:

- Literal tokens.
- Interpolation of `Ident`, `TokenStream`, `TokenTree`, `Literal`, `Group`,
  `Punct`, and any type implementing `ToTokens`.
- Repetition `#(...)*`, `#(...),*`, `#(...);*`, `#(...)+` with separator
  inference.
- Nested repetitions.
- `##` for escaping `#`.

**Current state:** a bootstrap `quote!` exists that supports literal tokens and
`#ident` interpolation. Full repetitions and `##` are missing.

### 5.5 Lightweight parsing helper

```rust
use yelang_proc_macro::parse::{Parser, Parse, Cursor};

struct Field { name: Ident, colon: Token![:], ty: TokenStream }
impl Parse for Field { ... }
```

Provided:

- `Cursor` for low-level peek/consume.
- `Parser` trait for combinators (`parse`, `peek`, `step`, `fork`).
- `Parse` trait for user types.
- `ParseError` with span and message.
- Lookahead / fork support through `BufferedCursor`.

**Current state:** `Cursor` and a minimal `Parser`/`Parse` skeleton exist. The
combinator surface is not yet complete.

### 5.6 Diagnostics

```rust
use yelang_proc_macro::Diagnostic;

Diagnostic::error()
    .with_message("expected a struct")
    .with_span(input.span())
    .emit();
```

Diagnostics are returned to the compiler through the bridge, not printed by the
macro.

---

## 6. Bridge ABI (`yelang_proc_macro_bridge`)

### 6.1 Stable C ABI entry point

The server loads a dylib and looks up:

```c
const YelangProcMacroExports* yelang_proc_macro_entry(uint32_t abi_version);
```

The returned structure contains:

- `abi_version`: the ABI version the dylib was compiled against.
- `macro_count`: number of exported macros.
- `macros`: pointer to the array of descriptors.

Each macro descriptor contains the macro name, kind, and a function pointer
with one of these stable C signatures:

```c
typedef void (*YelangFnLikeMacro)(
    const uint8_t* input,
    size_t input_len,
    uint8_t** output,
    size_t* output_len
);

typedef void (*YelangAttrMacro)(
    const uint8_t* args,
    size_t args_len,
    const uint8_t* item,
    size_t item_len,
    uint8_t** output,
    size_t* output_len
);

typedef void (*YelangDeriveMacro)(
    const uint8_t* item,
    size_t item_len,
    uint8_t** output,
    size_t* output_len
);
```

`YelangMacroInvoke` is a `#[repr(C)]` struct with three function-pointer fields
(not a C union), so Yelang code can initialize it without union syntax. The
unused pointers for a given kind are set to a null stub function rather than a
null pointer cast.

### 6.2 Wire protocol

The compiler spawns `yelang-proc-macro-server` and communicates over framed
messages on stdin/stdout.

```rust
pub enum Request {
    Handshake { protocol_version: u32, capabilities: Capabilities },
    LoadLibrary { path: String },
    ExpandFnLike { library: LibraryHandle, macro_index: u32, input: WireTokenStream },
    ExpandAttr { library: LibraryHandle, macro_index: u32, args: WireTokenStream, item: WireTokenStream },
    ExpandDerive { library: LibraryHandle, macro_index: u32, item: WireTokenStream },
    UnloadLibrary { library: LibraryHandle },
    Shutdown,
}

pub enum Response {
    HandshakeAck { protocol_version: u32 },
    LibraryLoaded { library: LibraryHandle, macros: Vec<MacroDescriptor> },
    Expanded { output: WireTokenStream },
    Diagnostic { diagnostic: WireDiagnostic },
    Panic { message: String },
    Error { code: ErrorCode, message: String },
}
```

Serialization: **postcard**. Framing: 4-byte little-endian length prefix.

### 6.3 Versioning

- Major protocol version bumps break compatibility.
- The server and compiler negotiate the highest shared version.
- Proc-macro crates declare the `yelang_proc_macro` API version they were
  compiled against; the server rejects mismatches.
- The dylib ABI version is checked at `yelang_proc_macro_entry` time.

---

## 7. Server (`yelang_proc_macro_server`)

### 7.1 Responsibilities

1. Accept one compiler connection on stdin/stdout.
2. Load/unload proc-macro dynamic libraries.
3. Dispatch expansion requests to the correct function.
4. Catch panics and convert them to `Response::Panic`.
5. Enforce memory and CPU limits per expansion.
6. Maintain a thread-local `MacroContext` for span/diagnostic callbacks.

### 7.2 Session state (SlotMap)

```rust
use slotmap::{SlotMap, DefaultKey};

slotmap::new_key_type! { pub struct LibraryHandle; }

pub struct Session {
    libraries: SlotMap<LibraryHandle, LoadedLibrary>,
}
```

### 7.3 Resource limits

Per-expansion:

- Max heap size (default 512 MiB).
- Max CPU time (default 30 s).
- Max output token count (default 1M tokens).

Server-level:

- Max concurrent libraries loaded.
- Max total memory.

Violations produce `Response::Error` with a clear code.

---

## 8. Compiler integration (`yelang_macro`)

### 8.1 Discovery

During crate graph construction, any crate with `crate-type = ["proc-macro"]`
is flagged. The compiler loads its metadata, finds exported macro symbols, and
records `(crate, name, kind, library_path, macro_index)`.

**Current state:** `ProcMacroDiscovery` is a stub that only supports a static
list for testing.

### 8.2 Resolution

Macro names are resolved in `MacroNS`. A name can resolve to:

- a declarative macro (`MacroDefId`), or
- a procedural macro (`ProcMacroId` → `(LibraryHandle, macro_index)`).

### 8.3 Expansion

When the expander encounters a proc-macro invocation:

1. Convert the invocation args/item from `yelang_macro_core::TokenStream` to
   `WireTokenStream` using the expander's interner.
2. Send the expansion request to the server.
3. Receive `Response::Expanded` (and any `Response::Diagnostic`s).
4. Convert the `WireTokenStream` back to `yelang_macro_core::TokenStream` using
   the expander's interner.
5. Parse the resulting items/expressions/statements.
6. Continue expansion iteratively.

**Current state:** in-process proc macros are wired into the expander.
Out-of-process conversion functions exist (`ast_to_wire`) but are not yet
invoked by `MacroExpander`.

### 8.4 In-process fallback

`yelang_macro::proc_macro::InProcessExecutor` registers trait objects
implementing `InProcessProcMacro`. This lets the compiler exercise proc macros
without a separate server process or dylib build.

---

## 9. Hygiene model

Yelang hygiene follows the three-hierarchy model from the Rustc Dev Guide:

1. **Expansion order hierarchy**: tracks when a macro invocation is in the
   output of another macro.
2. **Macro definition hierarchy**: tracks when one macro definition is revealed
   in the output of another.
3. **Call-site hierarchy**: tracks the location of macro invocations.

For this phase:

- Every `Span` carries a `SyntaxContextId`.
- `Span::call_site()` uses the invocation's syntax context.
- `Span::def_site()` uses the macro definition's syntax context.
- `Span::mixed_site()` uses a context that behaves like `macro_rules!` `$crate`.
- Syntax contexts are serialized opaquely across the server boundary.

Full cross-crate hygiene (serializing hygiene tables in rlib metadata) is a
future phase, but the design leaves a clean extension point.

---

## 10. Declarative macro improvements

Adopt RFC 3697 / RFC 3698 / RFC 3714 / RFC 3715:

```rust
macro_rules! main {
    attr() ($func:item) => { make_async_main!($func) };
    attr(threads = $threads:literal) ($func:item) => { make_async_main!($threads, $func) };
}

macro_rules! Answer {
    derive() (struct $name:ident $_:tt) => {
        impl Answer for $name {
            fn answer(&self) -> u32 { 42 }
        }
    };
    unsafe derive() ($item:item) => { ... };
}
```

This lets simple attribute/derive macros stay declarative, avoiding the
proc-macro server overhead for common cases.

---

## 11. Error handling

| Failure | Behavior |
|---|---|
| Server fails to start | Compiler error: "could not start procedural macro server" |
| Dylib fails to load | Error points to the dependency with the load failure reason |
| ABI version mismatch | Clear error, no silent fallback |
| Macro panics | Caught by server, returned as `Response::Panic` |
| Macro returns invalid tokens | Parser error pointing at the returned span |
| Macro emits diagnostics | Rendered with original spans |
| Timeout / OOM | Error with code and hint to increase limit |
| Protocol version mismatch | Clear error, no silent fallback |

---

## 12. Testing strategy

Tests must be exhaustive.

### 12.1 Unit tests

- `yelang-proc-macro`: TokenStream construction, iteration, quote! expansion,
  Diagnostic formatting, byte literals.
- `yelang-proc-macro-bridge`: postcard round-trip for every `Request` and
  `Response` variant, version negotiation, C ABI layout.
- `yelang-proc-macro-server`: session slotmap reuse after unload, panic
  conversion, limit enforcement, dylib load/unload.

### 12.2 Integration tests

- Out-of-process server that loads a tiny dylib and expands fn-like / attr /
  derive macros.
- Hygiene: generated names do not collide.
- Diagnostics: emitted error reaches user with span.
- Panic recovery.
- Invalid returned tokens.

### 12.3 Negative tests

- Missing `macro_export`.
- Wrong signature.
- Returning tokens that do not parse.
- Recursive expansion depth limit.
- Protocol corruption / server death.
- Timeout / OOM.

---

## 13. Phased implementation roadmap

| Phase | Goal | Deliverable |
|---|---|---|
| 7.1 | Foundational proc-macro bridge | `macro_export` codegen, C ABI, server, in-process integration. **Mostly implemented.** |
| 7.2 | Complete public API | byte literals, full `quote!`, complete `parse` helper, `TokenWalker`. |
| 7.3 | Server-based expansion | wire `ast_to_wire` / `wire_to_ast` integration into `MacroExpander`, diagnostics surfaced end-to-end. |
| 7.4 | Resource limits | heap/time/output enforcement in server. |
| 7.5 | Cross-crate discovery | proc-macro crate metadata, `ProcMacroDiscovery` from build system. |
| 7.6 | Declarative attr/derive | `attr()` / `derive()` / `unsafe attr()` / `unsafe derive()` macro rules. **Implemented.** |
| 7.7 | Full hygiene | cross-crate syntax-context serialization. |
| 8.x | Comptime/introspection | design complete in `comptime_design.md`; implementation pending. |

---

## 14. Design checklist (for agreement)

- [ ] Approve overall architecture and crate graph.
- [ ] Approve serialized-token ABI across dylib boundary (vs vtable).
- [ ] Approve out-of-process server model.
- [ ] Approve single public API crate (`yelang_proc_macro`) with built-in
      `quote!` and `parse` helper.
- [ ] Approve declarative attr/derive macro direction (RFC 3697/3698/3714/3715).
- [ ] Approve phased roadmap above.
- [ ] Approve exhaustive file tree in section 4.

---

## 15. Known bugs in the current skeleton

The following must be fixed during implementation; they are documented here so
they are not lost:

1. `yelang-macro/src/proc_macro/export.rs` generates `0 as YelangFnLikeMacro`
   casts for unused `YelangMacroInvoke` fields. These must be replaced by null
   stub functions (as already done in the server test fixture) because Rust does
   not allow integer-to-function-pointer casts.
2. `yelang-macro/src/proc_macro/expand.rs` contains `#[allow(dead_code)]`
   conversion functions that are not yet wired into `MacroExpander`.
3. `yelang-proc-macro/src/quote/mod.rs` was a bootstrap macro-rules `quote!`;
   it has been replaced by the `yelang-quote` proc-macro crate, re-exported as
   `yelang_proc_macro::quote!`. The compiler-hosted built-in quote will reuse
   the same syntax and interpolation semantics.
4. `yelang-proc-macro/src/parse/parser.rs` only has a skeleton `Parse`/`Parser`.
