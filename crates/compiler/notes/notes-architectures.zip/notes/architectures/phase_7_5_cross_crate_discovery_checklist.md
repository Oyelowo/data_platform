# Phase 7.5 — Cross-Crate Discovery Checklist

Design doc: `phase_7_5_cross_crate_discovery_design.md`.

## Manifest (`manifest.rs`, new)

- [x] `MANIFEST_FORMAT_VERSION = 1`, `MANIFEST_EXTENSION = "ypm.json"`,
      `MAX_MANIFEST_BYTES = 64 KiB`.
- [x] `ProcMacroCrateManifest` / `DylibSection` / `ManifestMacro` serde model
      (`ProcMacroKind` serializes by its bridge derive).
- [x] `read`: bounded read up to `MAX_MANIFEST_BYTES + 1` bytes, JSON parse,
      structural validation (format version, non-empty crate name/version,
      non-empty macros, no intra-manifest duplicate `(name, kind)`).
- [x] `write`: pretty JSON, atomic temp-file + rename so readers never see a
      partial manifest.
- [x] `dylib_path`: relative → manifest dir join; absolute → as-is.
- [x] `validate_environment`: file exists, size match, blake3 hash match,
      protocol version match, host triple match; returns canonical dylib path.
- [x] `fingerprint_dylib`: streaming blake3 in 64 KiB chunks →
      `("blake3:<hex>", size)`; no whole-file allocation.
- [x] `sidecar_manifest_path` → `<dir>/<file-stem>.ypm.json`.
- [x] `crate_name_from_dylib_path` strips `lib` prefix from dylib stem.
- [x] `Io` errors carry `op: &'static str` naming the failing operation.
- [x] Unit tests: roundtrip, too-large, bad JSON, bad format version, empty
      fields, empty macros, intra-manifest duplicate, relative/absolute dylib
      path resolution, sidecar naming, `lib` prefix handling, fingerprint
      determinism, validate-environment branches.

## Discovery (`discovery.rs`, rewritten)

- [x] `ProcMacroSource::{Manifest, Dylib}`.
- [x] `DiscoveryError` with every variant from the design doc, including
      `DuplicateLibrary`.
- [x] `DiscoveredCrate` / `Provenance` / `DiscoveryReport`.
- [x] Manifest path: no server load invoked (asserted by
      `loaded_library_count() == 0` after discovery).
- [x] Dylib path: sidecar probe → manifest path; else introspection.
- [x] Introspection: crate name from file stem (`lib` prefix stripped),
      indices = descriptor positions, provenance = `Introspected`, handle
      cached for expansion (asserted by `loaded_library_count() == 1` staying
      1 across `resolve`).
- [x] Duplicate `(name, kind)` check across the whole registry before
      registering a source's macros; all-or-nothing per source.
- [x] Same name across different kinds allowed.
- [x] One-dylib-per-registration invariant: `DuplicateLibrary` if a second
      source tries to register the same canonical dylib under a different crate
      name.
- [x] `discover_static` / `StaticEntry` deleted (zero references remain).

## Registry (`registry.rs`)

- [x] `ProcMacroDef.crate_name`.
- [x] `register` takes `crate_name`; canonicalizes `library_path` when the file
      exists (fallback to raw path).
- [x] `find(name, kind)`; `find_by_name` removed.
- [x] `expected_descriptors(library_path)` ordered by `macro_index`.
- [x] `iter()` for whole-registry inspection (used by duplicate-library check).
- [x] Unit tests: kind namespaces, expected_descriptors ordering.

## Client (`client.rs`)

- [x] `LoadedLibrary { handle, descriptors }`; `load_library` returns it.
- [x] `ProcMacroClientError::Validation(String)`.
- [x] `spawn_default`: env var (ignored if empty/whitespace) → exe sibling →
      documented error.

## Runtime / resolver (`resolver.rs`)

- [x] `resolve(name, kind)` on resolver and runtime.
- [x] `resolver()` and `resolver_mut()` accessors.
- [x] Canonicalized cache keys (fallback to raw path).
- [x] Cache stores `CacheEntry { result, validated }`; introspection pre-seeds
      with `validated = true`.
- [x] Fresh-load descriptor cross-check → `Validation` error, cached once.
- [x] `discover` / `discover_all` (continues past errors, full report).
- [x] `loaded_library_count()` introspection accessor.

## Expander / lib

- [x] Three `resolve` call sites pass `ProcMacroKind::{FunctionLike,
      Attribute, Derive}`; redundant post-resolve kind checks removed.
- [x] `is_user_attribute_macro` consults the out-of-process runtime resolver,
      so discovered attribute macros are expanded.
- [x] `expand_program_with_proc_macros` un-`allow(dead_code)`, re-exported.

## Build / deps

- [x] Workspace `Cargo.toml`: `blake3`.
- [x] `yelang-macro/Cargo.toml`: `serde`, `serde_json`, `blake3`.
- [x] `yelang-macro/build.rs`: `YELANG_HOST_TRIPLE` from `TARGET`.

## Integration tests (`yelang-proc-macro-server/tests/`, migrated)

Tests moved from `yelang-macro/tests/` to `yelang-proc-macro-server/tests/`
because they need the server binary (`CARGO_BIN_EXE_...`) and the fixture dylib.
The circular dev-dependency was removed; `yelang-macro`, `yelang-ast`, and
`yelang-interner` are now dev-dependencies of `yelang-proc-macro-server`.

- [x] `macro_discovery.rs`:
  - Manifest discovery from the fixture dylib (manifest written at test time
    with real fingerprint) → registers all 6 macros with correct
    kind/index/crate; expands fn-like, attr, derive end-to-end.
  - Introspection fallback (no sidecar) → provenance `Introspected`, crate
    name `test_macro`, cache pre-seeded (`loaded_library_count` stays 1 across
    resolve), expansion works.
  - Sidecar probe: `Dylib` source with sidecar present uses the manifest path
    (provenance `Manifest`, distinctive crate name, zero loads).
  - `HashMismatch` on tampered manifest hash.
  - `SizeMismatch` on tampered size.
  - `ProtocolMismatch`, `TripleMismatch` (doctored manifests).
  - Load-time validation: manifest with swapped macro order (hash recomputed to
    match the real dylib) → expansion fails with `Validation`.
  - `DuplicateMacro` from two manifests exporting the same `(name, kind)`,
    naming both crates; registry untouched by the rejected source.
  - `DuplicateLibrary` when the same dylib is registered under two crate names.
  - Cross-kind same-name from two sources → both registered, both resolvable.
  - Non-canonical dylib path (`..` segments) canonicalized; both macros share
    one cached handle.
  - Missing dylib → `Io` error at discovery.
  - `EmptyLibrary` from a manifest with no macros (unit test).
  - Introspection of a zero-export dylib: not feasible without a second fixture
    dylib — deferred.
  - `ManifestTooLarge` (unit test).
  - `discover_all` collects multiple errors and still registers the good
    sources; good source expands.
  - `spawn_default` finds the server via `YELANG_PROC_MACRO_SERVER`.
  - Driver API `expand_program_with_proc_macros` end-to-end.

- [x] `macro_server_integration.rs`:
  - Function-like, attribute, and derive macros expand through discovery.
  - Invalid derive output is reported.
  - Server diagnostics are reported as expansion errors.
  - Server panic is reported as an expansion error (fixture macro `explode`).
  - Missing library path is reported as an expansion error.
  - Runtime caches loaded libraries.
  - Resolution is kind-aware.
  - `unsafe` attribute wrapper is recognized.

- [x] `server_integration.rs`:
  - Handshake, load-library errors, descriptor enumeration.
  - Function-like, attribute, derive expansion at the wire protocol level.
  - Panic returns an `Error` diagnostic containing the original panic message.
  - Macro index out of bounds and wrong kind return `MacroNotFound`.
  - Diagnostic propagation and unload-library behaviour.
  - Wire tokens use 1-based `file`/`syntax_context` IDs.

- [x] Shared `macro_fixture/mod.rs`:
  - Locates/built the fixture `dylib` (crate-type `dylib`, not `cdylib`).
  - Emits manifests with a live fingerprint.
  - Writes manifests into isolated temp dirs keyed by pid + atomic counter,
    using absolute dylib paths to avoid races in `target/`.

## Migration

- [x] `yelang-macro/tests/proc_macro_discovery.rs` and
      `yelang-macro/tests/proc_macro_server_integration.rs` removed; equivalent
      tests now live under `yelang-proc-macro-server/tests/`.
- [x] Fixture panic macro renamed to `explode` to avoid shadowing builtin
      `panic!`.
- [x] No remaining references to `StaticEntry` / `discover_static` /
      `find_by_name` anywhere (grep-verified).

## Adversarial review findings addressed

- [x] Test infrastructure runs non-vacuously: tests moved to the server package
      where the server binary and fixture dylib are available.
- [x] Builtin `panic!` no longer shadows the fixture panic macro (renamed to
      `explode`).
- [x] Manifest reads are bounded; writes are atomic; hashes are streaming.
- [x] I/O errors carry an `op` annotation.
- [x] Intra-manifest duplicate `(name, kind)` rejected at read time.
- [x] `DuplicateLibrary` invariant prevents the same dylib from being
      registered under two crate names.
- [x] Resolver cache tracks `validated` per entry; introspection is
      pre-validated.
- [x] Registry canonicalizes `library_path`.
- [x] `spawn_default` ignores empty `YELANG_PROC_MACRO_SERVER`.
- [x] `is_user_attribute_macro` consults the out-of-process runtime resolver.
- [x] Fixture crate type is `dylib` (shares panic runtime with server); macro
      ABI functions are `extern "C-unwind"`.
- [x] Macro panics are captured inside the dylib and converted to error
      diagnostics before reaching the server.
- [x] Test manifests are isolated in per-call temp dirs with absolute dylib
      paths.

## Verification

- [x] `cargo fmt`.
- [x] `cargo check --workspace` (only pre-existing warnings in other crates).
- [x] `cargo test -p yelang-proc-macro-server -p yelang-proc-macro-test-fixture`
      — 17 macro_discovery + 10 macro_server_integration + 12 server_integration
      tests pass.
- [x] `cargo test -p yelang-macro` — 95 unit tests pass.
- [x] Main checklist `macro_system_production_ready_checklist.md` §6 updated.
