# HIR Lowering Design Document

## Overview

HIR (High-level Intermediate Representation) lowering transforms the AST into a
simplified, name-resolved IR where all syntax sugar is desugared and all names
are resolved to `DefId`s or `HirId`s.

## Goals

1. **Complete lowering**: Every valid AST construct must lower to HIR.
2. **Name resolution integration**: Use the real `yelang_resolve::ResolvedCrate`
   instead of stubs.
3. **Desugaring**: `while`, `for`, `?`, `async`, `await`, `ternary`, `assign_op`
   are desugared into simpler HIR constructs.
4. **DefId consistency**: HIR items reuse the `DefId`s assigned during name
   resolution.
5. **Exhaustive tests**: Every lowering path has tests.

## Architecture

### Data Flow

```
Source -> Parse -> AST -> Name Resolution -> ResolvedCrate
                                           |
                                           v
                                    HIR Lowering -> HIR Crate
                                           |
                                           v
                                    Type Check -> Typed HIR
```

### Key Types

- `yelang_resolve::ResolvedCrate` — output of name resolution
- `yelang_hir::Crate` — output of HIR lowering
- `yelang_hir::LoweringContext` — stateful lowering driver

### ResolvedCrate Extensions

`ResolvedCrate` needs to carry enough state for HIR lowering to resolve paths
without re-running the full resolver. We extend it with:

```rust
pub struct ResolvedCrate {
    pub module_tree: ModuleTree,
    pub definitions: FxHashMap<DefId, Definition>,
    pub errors: Vec<ResolutionError>,
    // NEW: maps path span -> resolved DefId for non-local paths
    pub def_resolutions: FxHashMap<Span, DefId>,
    // NEW: maps pattern/let span -> local binding HirId (populated during lowering)
    // (not in ResolvedCrate; handled by LoweringContext::local_map)
}
```

During `LateResolver`, every time a path resolves to a `Def` (not a local),
we store `(path.span, def_id)` in `Resolver::def_resolutions`.  This map is
merged into `ResolvedCrate` at the end.

### LoweringContext

```rust
pub struct LoweringContext<'a> {
    pub interner: &'a Interner,
    pub resolved: &'a ResolvedCrate,
    pub crate_hir: Crate,
    pub next_hir_id: u32,
    pub next_body_id: u32,
    pub current_module: DefId,   // current module for path resolution
    pub current_item: DefId,     // current item owner
    pub local_map: FxHashMap<Symbol, HirId>,
    pub errors: Vec<LoweringError>,
}
```

### Item Lowering

`lower_item` now looks up the item's `DefId` from `resolved.definitions` by
matching `(parent_module, name, kind)` instead of allocating a new `DefId`.

```rust
fn lookup_item_def_id(ctx: &LoweringContext, item: &AstItem) -> Option<DefId> {
    let expected_kind = item_def_kind(&item.kind);
    let expected_name = item_name(&item.kind)?;
    ctx.resolved.definitions.iter()
        .find(|(_, def)| {
            def.parent == Some(ctx.current_module)
                && def.name == expected_name
                && def.kind == expected_kind
        })
        .map(|(id, _)| *id)
}
```

If lookup fails (e.g., the item wasn't in the original AST, like generated items),
fall back to allocating a fresh `DefId`.

### Path Resolution in HIR

```rust
pub(crate) fn resolve_ast_path(ctx: &LoweringContext, path: &AstPath) -> Res {
    // 1. Single-segment local variable?
    if let Some(ident) = path.standalone_ident() {
        if let Some(hir_id) = ctx.local(ident.symbol) {
            return Res::Local { hir_id };
        }
    }

    // 2. Check pre-computed def resolutions from name resolution
    if let Some(&def_id) = ctx.resolved.def_resolutions.get(&path.span) {
        return Res::Def { def_id };
    }

    // 3. Fallback: resolve via module tree
    if let Some(def_id) = resolve_via_module_tree(ctx, path) {
        return Res::Def { def_id };
    }

    Res::Err
}
```

### Expression Desugarings

| AST Construct | HIR Form |
|---------------|----------|
| `while cond { body }` | `loop { if cond { body } else { break } }` |
| `for pat in iter { body }` | `loop { match iter.next() { Some(pat) => body, None => break } }` |
| `expr?` | `match expr { Ok(v) => v, Err(e) => return Err(e) }` |
| `cond ? a : b` | `if cond { a } else { b }` |
| `expr.await` | `match expr { Ready(v) => v, Pending => return Pending }` (future: poll-based) |
| `a += b` | `a = a + b` |
| `a -= b` | `a = a - b` | etc. |
| `async { block }` | Desugared to generator/closure (future work) |
| `(expr)` | transparent: `expr` |
| `obj { k: v }` | `Struct` with path to anonymous struct type |

### Item Lowerings (Complete)

All AST item kinds lower to HIR:

- `Fn` -> `ItemKind::Fn`
- `Struct` -> `ItemKind::Struct`
- `Enum` -> `ItemKind::Enum`
- `Trait` -> `ItemKind::Trait`
- `Impl` -> `ItemKind::Impl` + added to `crate_hir.impls`
- `TypeAlias` -> `ItemKind::TyAlias`
- `Const` -> `ItemKind::Const`
- `Static` -> `ItemKind::Static`
- `Module` -> `ItemKind::Mod` + recurse into items
- `Use` -> `ItemKind::Use`

### Generics Lowering (Complete)

`lower_generics` now lowers actual generic parameters, trait bounds, and where clauses:

```rust
fn lower_generics(ctx: &mut LoweringContext, generics: &AstGenerics) -> Generics {
    Generics {
        params: generics.params.iter().map(|p| lower_generic_param(ctx, p)).collect(),
        where_clause: generics.where_clause.as_ref().map(|w| lower_where_clause(ctx, w)),
        span: generics.span,
    }
}
```

`lower_where_predicate` handles all three `WherePredicate` variants including HRTB `ForAll`.

### Type Lowerings (Complete)

All AST `TypeKind` variants now lower to HIR:

| AST TypeKind | HIR TyKind |
|--------------|------------|
| `Named(Path)` | `Path { res: Res }` |
| `Tuple(Vec<Type>)` | `Tuple { tys: Vec<Ty> }` |
| `Array(Box<Type>, Box<Expr>)` | `Array { ty: Box<Ty>, len: Const }` |
| `Slice(Box<Type>)` | `Slice { ty: Box<Ty> }` |
| `Ref { ty, is_mut }` | `Ref { mutability, ty: Box<Ty> }` |
| `Function(FunctionType)` | `FnPtr { sig: Box<FnSig> }` |
| `ForAll { params, ty }` | `ForAll { params: Vec<GenericParam>, ty: Box<Ty> }` |
| `Literal(Literal)` | `TypeLit { variants: Vec<Lit> }` |
| `Structural(Vec<StructuralField>)` | `AnonStruct { fields: Vec<AnonField> }` |
| `Union(Vec<Type>)` | `Union { tys: Vec<Ty> }` |
| `Operator(TypeOperator)` | `Utility { kind: UtilityKind, args: Vec<Ty> }` |
| `ImplTrait(Path)` | `ImplTrait { path: Res }` |
| `DynTrait(Path)` | `DynTrait { path: Res }` |
| `Infer` | `Infer` |
| `Never` | `Tuple { tys: vec![] }` |
| `Error` | `Err` |

Utility types map as follows:
- `typeof expr` -> `Utility { kind: ReturnType, args: [] }` (placeholder; evaluated by type-checker)
- `ReturnType<T>` -> `Utility { kind: ReturnType, args: [T] }`
- `Parameters<T>` -> `Utility { kind: Params, args: [T] }`
- `Pick<T, K>` -> `Utility { kind: Pick, args: [T, K] }`
- `Omit<T, K>` -> `Utility { kind: Omit, args: [T, K] }`

### HRTB Where Predicate Lowering

`WherePredicate::ForAll { params, predicate }` is lowered by:
1. Lowering `params` into `Vec<GenericParam>` via `lower_type_binder_params`
2. Lowering the inner predicate recursively
3. Wrapping the bound type in `TyKind::ForAll { params, ty }`

Example: `where for<T> U: Into<T>` becomes a `TraitBound` whose type is `ForAll { params: [T], ty: U }`.

### Generics Lowering

Currently `lower_generics` returns empty params. Fix to lower actual params:

```rust
fn lower_generics(ctx: &mut LoweringContext, generics: &AstGenerics) -> Generics {
    Generics {
        params: generics.params.iter().map(|p| lower_generic_param(ctx, p)).collect(),
        where_clause: generics.where_clause.as_ref().map(|w| lower_where_clause(ctx, w)),
        span: generics.span,
    }
}
```

## File Tree

```
yelang-hir/src/
  lib.rs                    -- public API, re-exports
  ids.rs                    -- DefId, HirId, BodyId, LocalId
  crate_hir.rs              -- Crate root struct
  map.rs                    -- HIR node lookup map
  visitor.rs                -- HIR visitor pattern

  hir.rs                    -- core HIR types (Block, Stmt, Arm, FnSig, Generics, etc.)
  hir_expr.rs               -- Expr, ExprKind
  hir_item.rs               -- Item, ItemKind
  hir_pat.rs                -- Pat, PatKind
  hir_ty.rs                 -- Ty, TyKind, Const
  hir_body.rs               -- Body, Param
  hir_struct.rs             -- VariantData, FieldDef, StructField

  res.rs                    -- Res, PrimTy, IntTy, FloatTy
                            -- REMOVED: stub ResolvedCrate (now uses yelang_resolve::ResolvedCrate)

  lowering.rs               -- LoweringContext, lower_crate entry point
  lowering_item.rs          -- lower_item, lower_fn_item, lower_struct_item, lower_enum_item,
                            -- lower_trait_item, lower_impl_item, lower_type_alias_item,
                            -- lower_const_item, lower_static_item, lower_module_item, lower_use_item
  lowering_expr.rs          -- lower_expr, resolve_ast_path, all desugarings
  lowering_body.rs          -- lower_block_as_body
  lowering_pat.rs           -- lower_pat
  lowering_ty.rs            -- lower_ty
  lowering_err.rs           -- LoweringError variants

  tests/
    mod.rs                  -- test module declarations
    common.rs               -- shared test helpers (parse_program, stub_resolved)
    lowering.rs             -- basic lowering correctness tests
    desugaring.rs           -- desugaring-specific tests
    visitor.rs              -- visitor tests
    items.rs                -- exhaustive item lowering tests (15 tests)
    exprs.rs                -- exhaustive expression lowering tests (20+ tests)
    types.rs                -- exhaustive type lowering tests (18 tests)
    paths.rs                -- path resolution tests (5 tests)
```

## Test Plan

### Item Tests
- [x] `fn` lowering preserves signature + body
- [x] `struct` named fields
- [x] `struct` tuple fields
- [x] `struct` unit
- [x] `enum` with unit/tuple/struct variants
- [x] `trait` with methods, consts, associated types
- [x] `impl` inherent with methods, consts, associated types
- [x] `impl Trait for Type`
- [x] `type alias`
- [x] `const`
- [x] `static` (mutable and immutable)
- [x] `mod` inline with nested items
- [x] `use` single

### Expression Tests
- [x] Literal (int, string, bool)
- [x] Path (local + non-local)
- [x] Binary, Unary
- [x] Call
- [x] MethodCall
- [x] Field access
- [x] Index
- [x] Assignment (simple and compound)
- [x] Block
- [x] Loop
- [x] Break / Continue
- [x] Return
- [x] Match
- [x] If / If-else
- [x] Closure
- [x] Struct literal
- [x] Tuple
- [x] Array
- [x] While desugaring
- [x] For desugaring
- [x] Try (`?`) desugaring
- [x] Await (simplified)
- [x] Range (desugared to Call)

### Type Tests
- [x] Named path
- [x] Tuple
- [x] Array
- [x] Slice
- [x] Ref (mut/immut)
- [x] Function pointer
- [x] Infer
- [x] Never
- [x] ForAll (HRTB)
- [x] ImplTrait / DynTrait
- [x] Type operators (ReturnType, Parameters, Pick, Omit)
- [x] Structural (anonymous struct)
- [x] Union
- [x] Literal type

### Path Resolution Tests
- [x] Local variable resolves to `Res::Local`
- [x] Module item resolves to `Res::Def`
- [x] Absolute path (`::`)
- [x] `crate::` path
- [x] `self::` path
- [x] `super::` path
- [x] Unresolved path produces `Res::Err`

## Implementation Order

All phases are complete.

1. **Foundation** ✅
   - Remove stub `ResolvedCrate`, use `yelang_resolve::ResolvedCrate`
   - Add `def_resolutions` to `Resolver` and `ResolvedCrate`
   - Populate `def_resolutions` during late resolution
   - Update `LoweringContext` to use real `ResolvedCrate`
   - Fix `lower_crate` to use resolved DefIds for items
   - Fix `resolve_ast_path` to use `def_resolutions` + module tree

2. **Missing Items** ✅
   - Implement `lower_trait_item`
   - Implement `lower_impl_item`
   - Implement `lower_type_alias_item`
   - Implement `lower_const_item`
   - Implement `lower_static_item`
   - Implement `lower_module_item`
   - Implement `lower_use_item`

3. **Missing Expressions** ✅
   - MethodCall, Await, Async, Gen, Try, Comprehension
   - Ternary, Grouped, Object, DocumentAccess, BindAt
   - Query, TypeAscription, IsType, AssignOp, DestructureAssign, Range

4. **Missing Types** ✅
   - ForAll, Literal, Structural, Union, Operator, ImplTrait, DynTrait

5. **Generics** ✅
   - Fix `lower_generics` to lower actual params
   - Fix `lower_where_predicate` to handle HRTB `ForAll`

6. **Tests** ✅
   - Add exhaustive tests for all new lowerings
   - Verify all existing tests still pass

## Verification

Run:
```bash
cargo test -p yelang-hir
cargo test -p yelang-resolve -p yelang-macro -p yelang-hir
```

All tests must pass.
