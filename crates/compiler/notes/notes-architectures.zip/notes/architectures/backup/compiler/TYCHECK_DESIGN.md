# yelang-tycheck Design Document & Checklist

Based on rustc `hir_typeck` architecture (rustc-dev-guide.rust-lang.org/hir-typeck).

## Architecture

```
TypeckResults                    -- Maps HirId -> Ty for expressions, patterns
    |
    v
FnCtxt (per function body)       -- Inference context + local scopes
    |-- InferCtxt                 -- Unification tables (yelang-infer)
    |-- local_types: HirId -> Ty  -- Types of local variables
    |-- expr_tys: HirId -> Ty     -- Inferred types of expressions
    |-- pat_tys: HirId -> Ty      -- Inferred types of patterns
    |-- return_ty: Ty             -- Expected return type
    |-- breakable_scopes          -- For break/continue type checking
    |
    v
Collector (interprocedural)      -- Item signatures before body checking
    |-- DefId -> Ty               -- Function signatures, ADT defs
```

## Phase 1: Type Collection (collector.rs)

- [ ] Collect function signatures (inputs, output, generics)
- [ ] Collect struct definitions (fields, generics)
- [ ] Collect enum definitions (variants, generics)
- [ ] Collect trait definitions (items, generics)
- [ ] Collect impl blocks (self type, trait ref, items)
- [ ] Collect type aliases
- [ ] Collect const/static types
- [ ] Lower HIR `hir::Ty` to `yelang_ty::Ty`
- [ ] Handle generics and where clauses

## Phase 2: Body Type Checking (check.rs)

### FnCtxt Structure
- [ ] `InferCtxt` for unification
- [ ] `TypeckResults` for storing inferred types
- [ ] Local variable scope stack
- [ ] Breakable scope stack (for break/continue)

### Expression Checking (all ExprKind variants)
- [ ] `Lit` - integer (infers IntVar), float (FloatVar), bool, char, string
- [ ] `Path` - local variables, items, constants
- [ ] `Binary` - arithmetic (+,-,*,/,%), comparison (==,!=,<,>,<=,>=), logical (&&,||), bitwise
- [ ] `Unary` - negation (-), not (!), dereference (*), reference (&)
- [ ] `Call` - function calls (check callee, check args, unify)
- [ ] `MethodCall` - method calls (method lookup, check receiver, check args)
- [ ] `Field` - field access (struct fields, tuple fields)
- [ ] `Index` - array/slice index
- [ ] `Assign` - assignment (lhs must be place, types must match)
- [ ] `Block` - blocks (statements + trailing expr)
- [ ] `Loop` - infinite loops (type is Never/! unless break with value)
- [ ] `Break` - break expressions (must be inside loop, value type must match loop type)
- [ ] `Continue` - continue expressions (must be inside loop)
- [ ] `Return` - return expressions (value type must match fn return type)
- [ ] `Match` - match expressions (scrutinee, arms must have same type)
- [ ] `If` - if expressions (cond must be bool, branches must have same type)
- [ ] `Let` - let expressions (inside if let, pattern + expr)
- [ ] `Closure` - closures (infer params, check body)
- [ ] `Struct` - struct literals (path, fields, rest)
- [ ] `Tuple` - tuple literals
- [ ] `Array` - array literals
- [ ] `Cast` - type casts
- [ ] `Err` - error recovery (use TyKind::Error)

### Statement Checking
- [ ] `Expr` statements
- [ ] `Let` statements (pattern + init + type annotation)
- [ ] `Item` statements (nested items)

## Phase 3: Pattern Checking (pat.rs)

- [ ] `Wild` - matches any type
- [ ] `Binding` - introduces variable of expected type
- [ ] `Struct` - struct patterns (field names, types)
- [ ] `Tuple` - tuple patterns (element count, types)
- [ ] `TupleStruct` - tuple struct patterns
- [ ] `Path` - enum variants, constants
- [ ] `Lit` - literal patterns (type must match literal)
- [ ] `Range` - range patterns
- [ ] `Or` - or patterns (all alternatives same type)
- [ ] `Slice` - slice patterns

## Phase 4: Coercion (coerce.rs)

- [ ] Exact match
- [ ] Never type coercion (`!` -> any type)
- [ ] Deref coercion (`&T` -> `&U` where `T: Deref<Target=U>`)
- [ ] Function item to function pointer
- [ ] Width subtyping for anonymous structs
- [ ] Integer literal fallback (IntVar -> i32 if unconstrained)
- [ ] Float literal fallback (FloatVar -> f64 if unconstrained)

## Phase 5: Method Lookup (method.rs)

- [ ] Inherent method lookup
- [ ] Trait method lookup
- [ ] Deref coercion for method lookup
- [ ] Autoref for method lookup

## Phase 6: Writeback (writeback.rs)

- [ ] Resolve all inference variables
- [ ] Report unresolved variable errors
- [ ] Store final types in TypeckResults
- [ ] Integer/float fallback

## Tests

Each expression kind, pattern kind, coercion, and method lookup case
must have at least one happy-path test and one error test.
