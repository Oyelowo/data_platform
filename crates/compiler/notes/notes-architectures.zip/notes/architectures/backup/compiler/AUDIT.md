# Yelang Compiler Audit: Name Resolution & Macro Expansion

## Executive Summary

| Crate | Tests | Status | Coverage |
|-------|-------|--------|----------|
| yelang-resolve | 36 | Core logic implemented | ~60% of rustc-equivalent features |
| yelang-macro | 18 | Built-in macros + decorators | ~35% of rustc-equivalent features |

**Verdict**: Both crates have solid foundations but are **not yet exhaustive**. Significant gaps remain in hygiene, macro definition syntax, privacy/visibility, associated items, label resolution, and token-based macro expansion.

---

## 1. yelang-resolve — Gap Analysis

### 1.1 What Works (36 tests)

| Category | Tests | Description |
|----------|-------|-------------|
| Basic value resolution | 6 | `fn`, `let`, struct literals, module paths, type aliases, enum variants |
| Type namespace | 6 | Struct, enum, trait, module, type alias, type-vs-value dual names |
| Shadowing | 6 | Local shadowing, param shadowing, block scopes, pattern bindings, for loops |
| Imports | 5 | `use`, `use as`, `use *`, `use {a, b}`, unresolved import error |
| Generics | 6 | Type params in fn, struct, enum, trait, impl, type alias |
| Errors | 5 | Not found, duplicate definition, ambiguous glob, wrong namespace, missing path |
| Imports (errors) | 2 | Unresolved import, duplicate import |

### 1.2 What's Missing (from rustc-dev-guide and rustc_resolve)

#### A. Privacy & Visibility (0 tests)

Rustc resolves names **and** checks visibility. We resolve names but never check `pub`/`pub(crate)`/`pub(super)`.

**Missing tests:**
- Private fn accessed from sibling module → error
- Private struct field accessed from outside module → error
- `pub(super)` accessible from parent, not from sibling
- `pub(crate)` accessible everywhere in crate
- `pub(in path)` restricted visibility
- Re-export of private item via `pub use`

**New files needed:**
```
yelang-resolve/src/
  privacy.rs          # PrivacyVisitor, check visibility paths
  visibility.rs       # Visibility enum helpers (already exists in yelang-ast)
```

#### B. Macro Namespace Resolution (0 tests)

We have `MacroNS` in `namespaces.rs` but never use it in `LateResolver`. Macros are resolved during expansion, not during late resolution. This means:
- No macro name shadowing detection
- No `use my_macro;` resolution for macros
- No macro-vs-value ambiguity errors

**Missing tests:**
- Macro name shadowed by local variable
- `use some_macro;` resolves in MacroNS
- Macro exported from module via `pub macro`

#### C. Label Resolution (0 tests)

No `LabelNS` or `RibKind::Label`. Break/continue with labels are not resolved.

**Missing tests:**
- `break 'a` resolves to matching `'a: loop`
- `break 'a` outside `'a` scope → error
- Label shadowing in nested loops

**New files needed:**
```
yelang-resolve/src/
  label.rs            # Label resolution pass
```

#### D. Const Generics (0 tests)

We handle `GenericParam::Type` but not `GenericParam::Const`. The `Const` variant exists in yelang-ast but is never resolved in `LateResolver`.

**Missing tests:**
- `fn foo<const N: usize>() -> [i32; N]`
- Const generic param used in expression position
- Const generic default value resolution

#### E. Associated Items (0 tests)

No resolution for:
- `<T as Trait>::AssocType`
- `T::method` (inherent associated fn call)
- Trait method calls via dot notation (`value.method()` where `method` is from a trait)

**Missing tests:**
- `impl Trait for T { fn method(&self) {} }` → `T::method()` resolves
- `<Vec<i32> as Deref>::Target` resolves to `i32`
- `String::from` (inherent associated fn) resolves

#### F. Import Resolution Fixed-Point (partial)

Current imports are resolved in a single pass. Complex import graphs (e.g., `use a::b; use b::c;`) may fail.

**Missing tests:**
- Chained imports: `mod a { pub mod b { pub fn c() {} } } use a::b; use b::c;`
- Self-referential import with `use self::foo;`
- Import shadowing resolution order

#### G. Prelude Injection (0 tests)

No prelude is automatically injected. All standard items must be explicitly imported.

**Missing tests:**
- `fn main() { panic!("hi"); }` resolves without explicit `use`
- `Option::Some` resolves without explicit `use`

#### H. Cross-Crate Resolution (0 tests)

Only single-crate resolution is supported. No `extern crate` or crate dependency resolution.

### 1.3 Proposed yelang-resolve File Tree (Complete)

```
yelang-resolve/src/
  lib.rs                    # Public API, resolve_crate entry point
  def_collector.rs          # First pass: collect all definitions (existing)
  early.rs                  # Early resolution: imports, macros (existing)
  late.rs                   # Late resolution: exprs, types, patterns (existing)
  imports.rs                # Import resolution logic (existing)
  module_tree.rs            # Module hierarchy (existing)
  namespaces.rs             # Namespace enum (existing)
  path.rs                   # Path resolution helpers (existing)
  rib.rs                    # Rib stack implementation (existing)
  scope.rs                  # Resolver state (existing)
  error.rs                  # ResolutionError enum (existing)
  errors.rs                 # Error formatting/reporting
  
  # NEW MODULES:
  privacy.rs                # Visibility checking
  label.rs                  # Label resolution for break/continue
  associated.rs             # Associated item resolution (T::Assoc, <T as Trait>::Assoc)
  const_generics.rs         # Const generic parameter resolution
  prelude.rs                # Prelude injection logic
  
  tests/
    mod.rs                  # Test harness (existing)
    basic.rs                # 10 tests (existing 6 + 4 new)
    errors.rs               # 12 tests (existing 5 + 7 new)
    imports.rs              # 12 tests (existing 5 + 7 new)
    shadowing.rs            # 10 tests (existing 6 + 4 new)
    generics.rs             # 10 tests (existing 6 + 4 new)
    namespaces.rs           # 8 tests (existing 6 + 2 new)
    privacy.rs              # 10 new tests
    label.rs                # 6 new tests
    associated.rs           # 8 new tests
    const_generics.rs       # 6 new tests
    prelude.rs              # 4 new tests
```

### 1.4 Target Test Count: yelang-resolve

Current: 36 tests
Target: **100+ tests** (recommended for production-grade name resolution)

---

## 2. yelang-macro — Gap Analysis

### 2.1 What Works (18 tests)

| Category | Tests | Description |
|----------|-------|-------------|
| Built-in bang macros | 7 | assert!, assert_eq!, panic!, todo!, unreachable!, format!, builtin_macro_from_path |
| Built-in decorators | 5 | @derive, @repr, @test, @inline, @lang |
| Hygiene basics | 2 | ExpnId freshness, SyntaxContext distinctness |
| Expansion | 4 | assert! → if, todo! → panic!, nested expansion, unknown macro error |

### 2.2 What's Missing (from rustc_expand, rustc_span/hygiene)

#### A. Real Hygiene System (0 tests)

Our `SyntaxContext` is a flat u32 counter. Real rustc hygiene is a **chain of marks** with:
- `outer_expn: ExpnId` — last expansion that produced this context
- `parent: SyntaxContext` — previous context in chain
- `opaque: SyntaxContext` — chain with transparent expansions filtered out
- `opaque_and_semitransparent: SyntaxContext` — chain with only transparent filtered
- Transparency levels: `Opaque`, `SemiTransparent`, `Transparent`

This means macros from different scopes can accidentally collide with user names.

**Missing tests:**
- Macro-generated `let x = 1;` does not shadow user's `x`
- Nested macro expansion preserves hygiene across levels
- `macro_rules! m { () => { let x = 1; } }` + user `let x = 2;` → both valid

**New files needed:**
```
yelang-macro/src/
  hygiene.rs              # Rewrite with SyntaxContextData chain (existing is stub)
```

#### B. User-Defined Macros (0 tests)

No `macro_rules!` or `macro` syntax support. Only hardcoded built-in macros.

**Missing tests:**
- `macro_rules! say_hello { () => { println!("hello"); } }`
- `macro_rules! with_expr { ($e:expr) => { $e + 1 } }`
- Token repetition: `macro_rules! vec { ($($x:expr),*) => { ... } }`
- `macro m() {}` (Rust 2.0 style macro)

**New files needed:**
```
yelang-macro/src/
  macro_rules.rs          # macro_rules! parser and expander
  macro_def.rs            # Macro definition storage (pattern -> template)
  token_tree.rs           # Token tree representation for macro matching
  matcher.rs              # Pattern matching: $e:expr against tokens
  transcribe.rs           # Template transcription with captures
```

#### C. Token-Based Macro Expansion (0 tests)

Current macros expand AST nodes directly. Real macros expand **token trees** (`tt`), which preserves whitespace, comments, and raw tokens. This is critical for:
- `stringify!` macro
- `include!` macro
- `concat!` macro
- Procedural macros

**New files needed:**
```
yelang-macro/src/
  token_tree.rs           # TokenTree, TokenStream, Delimiter
  proc_macro.rs           # Procedural macro bridge (future)
```

#### D. Macro-Generated Items in Module Tree (0 tests)

After macro expansion, newly generated items (e.g., `@derive` producing `impl Show for Foo`) must be integrated into the module tree for name resolution. Currently, `DecoratorResult` just returns items but they're not fed back into the resolver.

**Missing tests:**
- `@derive(Debug)` generates `impl Debug for Foo` that is visible to other code
- Macro-generated `mod` is visible in module path resolution

#### E. `$crate` (0 tests)

No support for `$crate` in macros, which is needed for macros that reference items from their defining crate.

#### F. Macro Expansion in Patterns & Types (0 tests)

Only expression-level macro expansion is tested. No tests for:
- `let macro!() = value;` in patterns
- `let x: macro!() = value;` in type position
- `macro!() { ... }` in item position

#### G. cfg and cfg_attr (0 tests)

No conditional compilation support. `#[cfg(...)]` and `#[cfg_attr(...)]` are not implemented.

**New files needed:**
```
yelang-macro/src/
  cfg.rs                  # cfg evaluation, cfg_attr expansion
```

#### H. Doc Comments and Attributes on Macro-Generated Items (0 tests)

When `@derive` generates an impl, the generated impl should preserve relevant attributes.

### 2.3 Proposed yelang-macro File Tree (Complete)

```
yelang-macro/src/
  lib.rs                    # Public API, expand_program entry point
  expander.rs               # Main MacroExpander (existing, needs expansion)
  builtin_macros.rs         # Built-in bang macros (existing)
  builtin_decorators.rs     # Built-in decorators (existing)
  hygiene.rs                # SyntaxContext, ExpnId, HygieneData (needs rewrite)
  
  # NEW MODULES:
  token_tree.rs             # TokenTree, TokenStream, Delimiter
  macro_rules.rs            # macro_rules! definition and invocation
  macro_def.rs              # MacroDef storage and lookup
  matcher.rs                # Token pattern matching ($e:expr, etc.)
  transcribe.rs             # Template transcription with bindings
  macro_invocation.rs       # Macro invocation parsing and dispatch
  cfg.rs                    # Conditional compilation cfg/cfg_attr
  item_integrator.rs        # Feed macro-generated items back into module tree
  
  tests/
    mod.rs                  # Test harness
    expander.rs             # Existing tests + new ones
    builtin_macros.rs       # Existing tests + new ones
    builtin_decorators.rs   # Existing tests + new ones
    hygiene.rs              # Existing tests + real hygiene tests
    macro_rules.rs          # 15 new tests for macro_rules!
    matcher.rs              # 12 new tests for token pattern matching
    transcribe.rs           # 10 new tests for template transcription
    cfg.rs                  # 6 new tests for conditional compilation
    item_integrator.rs      # 6 new tests for generated item visibility
```

### 2.4 Target Test Count: yelang-macro

Current: 18 tests
Target: **80+ tests** (recommended for production-grade macro expansion)

---

## 3. Integration Test Harness

We need a cross-crate integration test that runs the full pipeline:

```
parse → expand → resolve → lower
```

### Proposed File Tree

```
tests/
  integration/
    mod.rs              # Shared harness
    fixtures/           # .ye source files
      basic.ye
      macros.ye
      generics.ye
      modules.ye
    test_basic.rs       # End-to-end basic programs
    test_macros.rs      # End-to-end macro expansion
    test_modules.rs     # End-to-end module resolution
    test_errors.rs      # End-to-end error reporting
```

### Test Harness API

```rust
fn compile(src: &str) -> Result<TypedCrate, Vec<Diagnostic>> {
    let (program, interner) = parse(src);
    let expanded = yelang_macro::expand_program(&program, &interner);
    let resolved = yelang_resolve::resolve_crate(&expanded.program, &interner);
    let hir = yelang_hir::lower_crate(&resolved);
    // ... type check ...
    Ok(typed_crate)
}
```

---

## 4. Implementation Priority

### Phase 1: yelang-resolve (Complete the gaps)
1. Privacy/visibility checking (highest priority — affects all cross-module code)
2. Label resolution (medium — needed for loop control flow)
3. Associated item resolution (high — needed for traits and methods)
4. Const generics (medium — modern Rust feature)
5. Prelude injection (medium — developer experience)
6. Import fixed-point (low — edge case, can defer)

### Phase 2: yelang-macro (Complete the gaps)
1. Real hygiene system (highest priority — correctness critical)
2. Token tree representation (high — foundation for user macros)
3. macro_rules! support (high — most common macro type)
4. cfg/cfg_attr (medium — needed for conditional compilation)
5. Item integrator (medium — needed for derive macros)
6. Procedural macros (low — can defer to later)

### Phase 3: Integration
1. Cross-crate integration test harness
2. Stdlib prelude integration
3. End-to-end fixture tests

---

## 5. Design Decisions to Lock In

### 5.1 Decorators: Compile-Time Only

Decision: **Compile-time only, erased before HIR.**

Rationale:
- Runtime decorators require reflection metadata, which conflicts with "no borrow checker, no runtime overhead" goal.
- Rust's `#[derive]` is compile-time; Python's `@decorator` is runtime. We follow Rust.
- If runtime annotation is needed, use a separate `#[meta(...)]` attribute that is preserved in HIR but not executed.

### 5.2 Macros: Compile-Time Only, Token-Based

Decision: **Macros expand token trees at compile time.**

Rationale:
- Runtime macros (Lisp-style `eval`) are incompatible with AOT compilation and distributed systems goals.
- Token-based expansion (Rust style) preserves hygiene and allows `stringify!`/`include!`.
- AST-based expansion (our current approach) is a shortcut for built-ins; user macros use tokens.

### 5.3 Named Struct Variants for Enums

Decision: **Yes, all enum variants with >0 fields use named structs.**

Rationale:
- Already applied in yelang-ast (`VariantKind::Struct { fields: Vec<FieldDef> }`).
- Improves readability and allows future extension without breaking changes.
- Rust-analyzer and IDEs work better with named fields.

### 5.4 Anonymous Structs & Type Literals

Decision: **Supported in HIR and type checker, parsed as AST extensions.**

Syntax:
```rust
// Anonymous struct
let point: { x: i32, y: i32 } = { x: 1, y: 2 };

// Type literal (union type)
let status: 200 | 404 | 500 = 200;

// Utility types
type PublicUser = Omit<User, "password">;
type NameOnly = Pick<User, "name" | "email">;
type MainReturn = ReturnType<typeof(main)>;
type MainArgs = Params<typeof(main)>;
```

Rationale:
- TypeScript's utility types are proven to be extremely useful.
- Row polymorphism (`{ x: i32 }` is a subtype of `{ x: i32, y: i32 }`) aligns with structural typing goals.
- Type literals (`200 | 404`) are just singleton types / union types, well-understood in type theory.

---

## 6. Recommended Next Steps

1. **Read this audit document** and confirm priorities
2. **Implement Phase 1: yelang-resolve gaps** with TDD (add tests first, then code)
3. **Implement Phase 2: yelang-macro gaps** with TDD
4. **Build integration test harness** as Phase 3
5. **Only then proceed to yelang-tc** (type checker)

**Want me to start implementing Phase 1 (yelang-resolve privacy + label + associated items) right now?**
