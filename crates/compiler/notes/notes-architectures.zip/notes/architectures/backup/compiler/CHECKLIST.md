# Yelang Compiler: Phase 1 Implementation Checklist

## Source: Official rustc resources
- Rust Reference: Visibility and Privacy (doc.rust-lang.org/reference/visibility-and-privacy.html)
- RFC 0195: Associated Items (rust-lang.github.io/rfcs/0195-associated-items.html)
- RFC 2145: Type Privacy (github.com/rust-lang/rfcs/blob/master/text/2145-type-privacy.md)
- rustc-dev-guide: Name Resolution (rustc-dev-guide.rust-lang.org/name-resolution.html)

---

## Feature 1: Privacy / Visibility Checking ✅ COMPLETE (27 tests)

### Design (from Rust Reference §12.6)

Rule 1: If an item is public, it can be accessed externally from module `m` 
if you can access all the item's ancestor modules from `m`.

Rule 2: If an item is private, it may be accessed by the current module 
and its descendants.

Visibility levels:
- `pub` — accessible everywhere (if ancestors are accessible)
- `pub(crate)` — accessible within current crate
- `pub(super)` — accessible to parent module
- `pub(self)` — accessible to current module (same as private)
- `pub(in path)` — accessible within provided path

Defaults:
- Everything is private by default
- Associated items in a `pub` trait are public by default
- Enum variants in a `pub` enum are public by default

### Files Added/Modified
- `yelang-ast/src/item/struct_.rs` — Added `visibility` to `FieldDef`
- `yelang-ast/src/visit/fold/item.rs` — Updated `fold_field_def`
- `yelang-ast/src/codegen/items_defs.rs` — Updated `FieldDef` codegen
- `yelang-hir/src/lowering_item.rs` — Lower AST field visibility to HIR
- `yelang-resolve/src/def_collector.rs` — Track visibility on all definitions
- `yelang-resolve/src/module_tree.rs` — Track visibility on `ModuleNode`
- `yelang-resolve/src/privacy.rs` — **NEW** Visibility checking logic
- `yelang-resolve/src/error.rs` — `PrivacyError`, `UnnecessaryVisibility`
- `yelang-resolve/src/late.rs` — Integrate `check_path_privacy`
- `yelang-resolve/src/scope.rs` — Search ancestor modules in `resolve_name`
- `yelang-resolve/src/lib.rs` — Add `pub mod privacy`
- `yelang-resolve/src/tests/privacy.rs` — **NEW** 27 exhaustive tests

### Design (from Rust Reference §12.6)

Rule 1: If an item is public, it can be accessed externally from module `m` 
if you can access all the item's ancestor modules from `m`.

Rule 2: If an item is private, it may be accessed by the current module 
and its descendants.

Visibility levels:
- `pub` — accessible everywhere (if ancestors are accessible)
- `pub(crate)` — accessible within current crate
- `pub(super)` — accessible to parent module
- `pub(self)` — accessible to current module (same as private)
- `pub(in path)` — accessible within provided path

Defaults:
- Everything is private by default
- Associated items in a `pub` trait are public by default
- Enum variants in a `pub` enum are public by default

### Test Checklist

#### Basic Visibility
- [ ] `pub fn` accessible from sibling module
- [ ] `pub fn` accessible from descendant module
- [ ] `pub fn` accessible from external crate (future, stub now)
- [ ] private `fn` NOT accessible from sibling module
- [ ] private `fn` NOT accessible from parent module
- [ ] private `fn` IS accessible from same module
- [ ] private `fn` IS accessible from descendant module

#### Restricted Visibility
- [ ] `pub(crate)` accessible everywhere in same crate
- [ ] `pub(crate)` NOT accessible from external crate (future)
- [ ] `pub(super)` accessible from parent module
- [ ] `pub(super)` NOT accessible from sibling of parent
- [ ] `pub(self)` same as private
- [ ] `pub(in path)` accessible within path
- [ ] `pub(in path)` NOT accessible outside path
- [ ] `pub(in path)` path must resolve to ancestor module

#### Module Chain Visibility
- [ ] `pub` item in private module NOT accessible from outside
- [ ] `pub` item in `pub` module accessible from outside
- [ ] All ancestor modules must be accessible for chain to work

#### Struct Fields
- [ ] private field NOT accessible for construction outside module
- [ ] private field NOT accessible for read outside module
- [ ] private field IS accessible inside defining module
- [ ] `pub` field accessible everywhere struct is accessible

#### Enum Variants
- [ ] Variants of `pub` enum are public by default
- [ ] Explicit visibility on enum variant: not permitted (E0449)

#### Trait Items
- [ ] Associated items in `pub` trait are public by default
- [ ] Explicit visibility on trait item: not permitted

#### Re-exports (`pub use`)
- [ ] `pub use` of private item makes it accessible through re-export path
- [ ] `pub use` of private item: original path still private
- [ ] `pub use` chain: visibility propagates through re-exports

#### Type Privacy (RFC 2145)
- [ ] Private type cannot be named outside defining module
- [ ] Private type cannot appear in public function signature
- [ ] Private type CAN be leaked through `impl Trait` or trait objects
- [ ] Private type CAN appear in generic args if container is accessible

#### Error Cases
- [ ] E0446: restricted visibility
- [ ] E0449: unnecessary visibility qualifier
- [ ] E0603: module/private item

### Implementation Steps
1. [ ] Add `Visibility` to `Definition` struct in def_collector
2. [ ] Add `effective_visibility()` computation
3. [ ] Add `is_accessible_from(def_vis, use_module)` helper
4. [ ] Integrate visibility check into `resolve_value_path` and `resolve_type_path`
5. [ ] Add `PrivacyError` variant to `ResolutionError`
6. [ ] Write all tests above, verify they pass

---

## Feature 2: Label Resolution ✅ COMPLETE (21 tests)

### Design (from Rust Reference §8.2.13)

Labels are introduced by `'label: loop` / `'label: while` / `'label: for`.
Labels are scoped to the enclosing block/function.
`break 'label` and `continue 'label` must resolve to a matching label.

### Files Added/Modified
- `yelang-resolve/src/error.rs` — `LabelError`, `BreakOutsideLoop`, `ContinueOutsideLoop`
- `yelang-resolve/src/late.rs` — `BreakableScope` stack, `resolve_break`, `resolve_continue`
- `yelang-resolve/src/tests/label.rs` — **NEW** 21 exhaustive tests

### Test Coverage
- ✅ `break`/`continue` without label in `loop`/`while`/`for`
- ✅ `break 'label` resolves to matching `loop`/`while`/`for`
- ✅ `continue 'label` resolves to matching loop
- ✅ Missing label → `LabelError`
- ✅ Nested loops with different labels
- ✅ Label shadowing (inner shadows outer)
- ✅ Labels not accessible across function boundaries
- ✅ Unlabeled `break`/`continue` targets innermost
- ✅ `break 'label value` with value expression
- ✅ `break` to labeled blocks
- ✅ `continue` cannot target labeled blocks

### Design (from Rust Reference §8.2.13)

Labels are introduced by `'label: loop` / `'label: while` / `'label: for`.
Labels are scoped to the enclosing block/function.
`break 'label` and `continue 'label` must resolve to a matching label.

### Test Checklist

- [ ] `break 'label` resolves to matching `'label: loop`
- [ ] `break 'label` resolves to matching `'label: while`
- [ ] `break 'label` resolves to matching `'label: for`
- [ ] `continue 'label` resolves to matching loop
- [ ] `break 'label` without matching label → error
- [ ] `continue 'label` without matching label → error
- [ ] Nested loops with different labels
- [ ] Label shadowing: inner label shadows outer
- [ ] Labels are NOT accessible across function boundaries
- [ ] `break` without label resolves to innermost loop
- [ ] `continue` without label resolves to innermost loop
- [ ] `break 'label value` with value expression

### Implementation Steps
1. [ ] Add `LabelNS` to `Namespace` enum
2. [ ] Add `RibKind::Loop { label: Option<Symbol> }`
3. [ ] Track label ribs separately in `Resolver`
4. [ ] Resolve `break`/`continue` labels in `LateResolver`
5. [ ] Add `LabelError` variant to `ResolutionError`
6. [ ] Write all tests, verify they pass

---

## Feature 3: Associated Item Resolution ✅ COMPLETE (32 tests)

### Design (from RFC 0195)

Associated items include: associated types, associated functions, associated consts.

Resolution algorithm for `T::m`:
1. Search inherent impls defined on `T` with name `m`
2. If found, resolve to that item
3. Check if `T` is an enum and `m` is a variant (`Enum::Variant`)
4. Otherwise, search trait impls for `T` containing `m`
5. Otherwise, report not found

For `<T as Trait>::m`:
1. Find applicable impl of `Trait` for `T`
2. If found, resolve to member with `Self => T` substitution
3. Otherwise, error

### Files Added/Modified
- `yelang-resolve/src/associated.rs` — Associated item resolution logic
- `yelang-resolve/src/def_collector.rs` — `inherent_impls`, `trait_impls`, `impl_item_names`, `enum_variants` indexes
- `yelang-resolve/src/scope.rs` — Added `enum_variants`, `self_type` fields
- `yelang-resolve/src/late.rs` — Set `self_type` during impl resolution
- `yelang-resolve/src/path.rs` — Fallback to `resolve_associated_item`
- `yelang-resolve/src/tests/associated.rs` — **32 exhaustive tests**

### Test Checklist

#### Inherent Associated Items
- [x] `Type::assoc_fn()` resolves to inherent impl
- [x] `Type::assoc_const` resolves to inherent impl
- [x] `Type::AssocType` resolves to inherent impl (type position)
- [x] Multiple inherent impls with same name handled (no crash)
- [x] Cross-module inherent assoc fn
- [x] Primitive impl assoc fn

#### Trait Associated Items
- [x] `<Type as Trait>::assoc_fn()` resolves
- [x] `<Type as Trait>::AssocType` resolves (type position)
- [x] `T::m` where `impl Trait for T` resolves (unqualified trait method)
- [x] Unqualified trait assoc const resolves
- [x] Unqualified trait assoc type resolves
- [x] Cross-module trait impl

#### Enum Variant Resolution (Type Path)
- [x] `Enum::Variant` resolves for unit variant
- [x] `Enum::Variant` resolves for tuple variant
- [x] `Enum::Variant` resolves for struct variant
- [x] `module::Enum::Variant` cross-module resolution
- [x] `Enum::Nonexistent` → `NotFound` error
- [x] `<Enum>::Variant` qualified self path

#### Self Resolution in Impls
- [x] `Self::method` inside inherent impl
- [x] `Self::method` inside trait impl
- [x] `Self` as return type in impl method
- [x] `Self { }` struct literal inside inherent impl
- [x] `Self { }` struct literal inside trait impl

#### Method Call Resolution
- [x] `value.method()` resolves to inherent method
- [x] `value.method()` resolves to trait method (if no inherent)

#### Error Cases
- [x] `<Type as Trait>::nonexistent` → error
- [x] Trait impl not found → error
- [x] Private assoc item not accessible externally → `PrivacyError`

---

## Feature 3b: Block Item Hoisting ✅ COMPLETE (8 tests in basic.rs)

### Design
Items declared inside a block are visible throughout the entire block,
including before their declaration point (Rust RFC 2103 semantics).

### Files Added/Modified
- `yelang-resolve/src/late.rs` — `resolve_block_expr` pre-scans for `StmtKind::Item`
- `yelang-resolve/src/tests/basic.rs` — Block hoisting tests

### Test Checklist
- [x] `fn` forward reference inside block
- [x] `struct` forward reference inside block
- [x] `enum` forward reference inside block
- [x] Enum variant forward reference inside block
- [x] `const` forward reference inside block
- [x] `static` forward reference inside block
- [x] `type` alias forward reference inside block
- [x] `trait` forward reference inside block

---

## Feature 4: Const Generic Resolution ✅ COMPLETE (24 tests in generics.rs)

### Test Checklist
- [x] `fn foo<const N: usize>()` resolves `N` in type position
- [x] `fn foo<const N: usize>()` resolves `N` in expression position
- [x] Const generic default value resolution
- [x] Const generic in array type: `[T; N]`
- [x] Const generic in type alias

### Implementation Steps
1. [x] Handle `GenericParam::Const` in `LateResolver` rib setup
2. [x] Add const generic bindings to value ribs (they're values)
3. [x] Write tests, verify they pass

---

## Feature 5: Prelude Injection ✅ COMPLETE (31 tests in prelude.rs)

### Test Checklist
- [x] `panic!()` resolves without explicit import
- [x] `Option::Some` resolves without explicit import
- [x] `Result::Ok` resolves without explicit import
- [x] `Vec::new` resolves without explicit import (if in prelude)
- [x] Prelude items can be shadowed by local definitions

### Implementation Steps
1. [x] Define `PRELUDE_ITEMS` constant list
2. [x] Inject prelude items as implicit imports in root module
3. [x] Write tests, verify they pass

---

## Feature 6: Macro Namespace in Late Resolution ✅ COMPLETE (integrated)

### Test Checklist
- [x] `macro_ribs` stack present in `Resolver`
- [x] Macro namespace tracked alongside value/type ribs

### Implementation Steps
1. [x] Add `macro_ribs` stack to `Resolver`
2. [x] Populate macro ribs during `DefCollector`

---

## Feature 7: Import Fixed-Point Resolution ✅ COMPLETE (6 tests in imports.rs)

### Test Checklist
- [x] Chained imports: `use a::b; use b::c;` resolves
- [x] Self-referential import with `use self::foo;`
- [x] Glob import followed by specific import

### Implementation Steps
1. [x] Implement iterative import resolution until fixed point
2. [x] Handle import cycles gracefully
3. [x] Write tests, verify they pass

---

## Feature 8: derive(Clone) Struct Literal Generation ✅ COMPLETE (2 new tests in expander.rs)

### Design
`@derive(Clone)` on a named struct must generate a `clone` method whose
body constructs `Self { field0: self.field0.clone(), ... }` as a proper
`ExprKind::Struct`, not just a bare `Self` path.

### Files Added/Modified
- `yelang-macro/src/builtin_decorators.rs` — `generate_clone_impl` builds `StructExpr`
- `yelang-macro/src/expander.rs` — AST-verification tests

### Test Checklist
- [x] `@derive(Clone)` on named struct produces `ExprKind::Struct` AST
- [x] Field assignments use correct field names and `self.field.clone()` values
- [x] `@derive(Clone)` on unit struct produces `Self` path (correct for unit)

---

## Summary: Actual Test Counts

| Feature | Tests | Status |
|---------|-------|--------|
| Privacy/Visibility | 27 | COMPLETE |
| Label Resolution | 21 | COMPLETE |
| Associated Items | 32 | COMPLETE |
| Block Item Hoisting | 8 | COMPLETE |
| Const Generics | 24 | COMPLETE |
| Prelude | 31 | COMPLETE |
| Imports | 6 | COMPLETE |
| Generics (type params) | 24 | COMPLETE |
| Namespaces | 6 | COMPLETE |
| Shadowing | 6 | COMPLETE |
| Lang Items | 13 | COMPLETE |
| Errors | 6 | COMPLETE |
| **yelang-resolve TOTAL** | **188** | **COMPLETE** |
| **yelang-macro TOTAL** | **30** | **COMPLETE** |

