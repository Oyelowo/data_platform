# Yelang Type Checking & Next-Gen Trait Solver — Design Document

## 1. Overview & Goals

This document specifies the complete type-checking architecture for Yelang, including type inference, trait solving, and coherence checking. It is designed to be **exhaustive** — every construct, edge case, and error condition is accounted for before implementation begins.

### Design Axioms (in order of priority)

1. **Soundness** — The type system must reject all invalid programs. No unsoundness is acceptable.
2. **Completeness** — Every valid Yelang program must type-check successfully.
3. **Maintainability** — The solver must be approachable to new contributors. Clear separation of concerns.
4. **Performance** — Aggressive caching, canonicalization, and incremental-friendly structures.

### Key Decisions

- **Next-generation trait solver**: We implement the *recursive goal-driven* solver (matching rustc's `rustc_next_trait_solver`), **not** the legacy `select`/`fulfill` approach.
- **No lifetimes/borrow checker**: Yelang is lifetime-free. No region variables, no NLL, no borrow checking.
- **No subtyping** (except width subtyping for structural types): This simplifies unification to equality.
- **Hindley-Milner + let-polymorphism**: For general type inference, extended with trait bounds.
- **Bidirectional type checking** for explicit annotations where HM is insufficient.

---

## 2. Architecture

### Crate Structure

```
yelang-ty/              -- Core type system IR
  src/
    lib.rs
    ty.rs               -- Ty, TyKind (canonical type representation)
    ty_kind.rs          -- All type constructors (Adt, FnDef, Tuple, etc.)
    generic.rs          -- Generics, GenericArg, Substitution
    fold.rs             -- TypeFolder, TypeFoldable, TypeSuperFoldable
    visit.rs            -- TypeVisitor
    binder.rs           -- Binder<T>, bound/free variables
    list.rs             -- TyList<T> (interned slices)
    canonical.rs        -- Canonical<T>, CanonicalVarKinds, Canonicalization
    predicate.rs        -- Predicate, TraitPredicate, ProjectionPredicate
    const.rs            -- Const, ConstKind, ConstValue
    interner.rs         -- Interner trait (for Ty, Predicate, etc.)
    tests/
      mod.rs
      fold.rs
      canonical.rs

yelang-infer/           -- Inference engine (variables + unification)
  src/
    lib.rs
    context.rs          -- InferCtxt, InferCtxtBuilder
    type_variable.rs    -- TypeVariableTable, TypeVariableOrigin
    const_variable.rs   -- ConstVariableTable
    unify.rs            -- UnificationTable, eq(), try_eq()
    snapshot.rs         -- Snapshot, rollback, commit
    freshen.rs          -- Freshening (for hashing)
    error.rs            -- TypeError, InferError
    resolve.rs          -- Opportunistic resolution, full resolution
    tests/
      mod.rs
      unify.rs
      resolve.rs

yelang-trait-solver/    -- Next-generation recursive trait solver
  src/
    lib.rs
    eval_ctxt.rs        -- EvalCtxt, compute_goal, evaluate_goal
    goal.rs             -- Goal, GoalKind, NestedGoal
    candidate.rs        -- Candidate, CandidateSource, assemble_candidates
    response.rs         -- CanonicalResponse, Certainty, NoSolution
    canonicalize.rs     -- Canonicalizer, canonicalize_goal, instantiate_canonical
    search_graph.rs     -- SearchGraph, CycleKind, provisional results
    fulfill.rs          -- FulfillmentContext, pending obligations
    probe.rs            -- Probe, try_merge_responses
    builtin.rs          -- Built-in impls (Sized, Copy, Clone, etc.)
    normalize.rs        -- Normalization of associated types
    coherence.rs        -- Coherence checking (overlap, orphan)
    special.rs          -- Specialization graph, specialization checks
    delegate.rs         -- SolverDelegate, InferCtxtLike trait
    tests/
      mod.rs
      solver.rs
      coherence.rs
      normalize.rs

yelang-typeck/          -- Type checking function bodies & items
  src/
    lib.rs
    collector.rs        -- Type collection from HIR items
    check.rs            -- TypeChecker, check_expr, check_stmt
    inference.rs        -- Expression type inference (HM + traits)
    coerce.rs           -- Coercion logic
    demand.rs           -- Demand analysis (expected vs actual types)
    method.rs           -- Method lookup and resolution
    pat.rs              -- Pattern type checking
    closure.rs          -- Closure inference
    cast.rs             -- Cast checking
    ops.rs              -- Operator overload resolution
    autoderef.rs        -- Auto-deref sequence
    writeback.rs        -- Write inferred types back to HIR
    diagnostics.rs      -- Type error reporting
    item.rs             -- Check item signatures
    lib_types.rs        -- Well-known types (Option, Result, etc.)
    tests/
      mod.rs
      check_expr.rs
      check_item.rs
      inference.rs
      method.rs
      coherence.rs

yelang-stdlib/          -- Standard library (if needed separately)
  src/
    lib.rs
    prelude.ye
    core/
      option.ye
      result.ye
      vec.ye
      iter.ye
```

### Data Flow

```
HIR Crate
    |
    v
+----------------------------------+
| yelang-typeck::collect           |  <-- Collect item signatures into Ty
+----------------------------------+
    |
    v
+----------------------------------+
| yelang-typeck::check             |  <-- Check function bodies
|   - InferCtxt (yelang-infer)     |
|   - Trait solver (yelang-trait-solver)
+----------------------------------+
    |
    v
+----------------------------------+
| yelang-typeck::writeback         |  <-- Write inferred types to HIR
+----------------------------------+
    |
    v
Typed HIR (HIR + inferred types)
    |
    v
MIR lowering
```

---

## 3. Core Type System (`yelang-ty`)

### 3.1 Type Representation

Types are interned and arena-allocated. Every `Ty` is a pointer to an interned `TyKind`.

```rust
/// A type in the compiler.
pub struct Ty<'tcx>(pub &'tcx TyKind<'tcx>);

/// Kinds of types.
pub enum TyKind<'tcx> {
    /// Primitive types.
    Bool,
    Char,
    Int(IntTy),      // i8, i16, i32, i64, i128, isize
    Uint(UintTy),    // u8, u16, u32, u64, u128, usize
    Float(FloatTy),  // f32, f64
    /// Type parameters (both early and late bound).
    Param(ParamTy),
    /// Bound type variables (from binders like `for<T>`).
    Bound(DebruijnIndex, BoundTy),
    /// Inference variable.
    Infer(InferTy),
    /// A concrete type definition (struct, enum, union).
    Adt(AdtDef<'tcx>, GenericArgsRef<'tcx>),
    /// Function pointer: `fn(i32) -> i32`.
    FnPtr(PolyFnSig<'tcx>),
    /// Function item (monomorphic): `foo` where `fn foo()`.
    FnDef(DefId, GenericArgsRef<'tcx>),
    /// Tuple.
    Tuple(GenericArgsRef<'tcx>),
    /// Array `[T; N]`.
    Array(Ty<'tcx>, Const<'tcx>),
    /// Slice `[T]`.
    Slice(Ty<'tcx>),
    /// Raw pointer `*mut T` or `*const T`.
    RawPtr(TypeAndMut<'tcx>),
    /// Reference `&T` or `&mut T` (no lifetime).
    Ref(Ty<'tcx>, Mutability),
    /// Never type `!`.
    Never,
    /// Anonymous struct type `{ x: i32, y: i32 }`.
    AnonStruct(AnonStructDef<'tcx>),
    /// Union type `A | B`.
    Union(Ty<'tcx>, Ty<'tcx>),
    /// Type literal `"pending"`.
    TypeLit(Literal),
    /// Utility type: `Omit<T, K>`, `Pick<T, K>`, etc.
    Utility(UtilityKind, GenericArgsRef<'tcx>),
    /// Opaque type: `impl Trait`.
    Alias(AliasTy<'tcx>),
    /// Trait object: `dyn Trait`.
    Dynamic(Binder<'tcx, ExistentialPredicate<'tcx>>),
    /// Placeholder type (used during canonicalization).
    Placeholder(PlaceholderType),
    /// Error recovery type.
    Error,
}
```

### 3.2 Inference Variables

```rust
/// An inference variable for types.
pub enum InferTy {
    /// General type variable: `?T`.
    TyVar(TyVid),
    /// Integral type variable: from integer literals.
    IntVar(IntVid),
    /// Floating-point type variable: from float literals.
    FloatVar(FloatVid),
}

/// Variable IDs (interned in the inference context).
pub struct TyVid(pub u32);
pub struct IntVid(pub u32);
pub struct FloatVid(pub u32);
pub struct ConstVid<'tcx>(pub u32);
```

### 3.3 Generic Arguments & Substitutions

```rust
/// A single generic argument (type, const, or lifetime).
pub enum GenericArg<'tcx> {
    Type(Ty<'tcx>),
    Const(Const<'tcx>),
}

/// A list of generic arguments (interned).
pub type GenericArgsRef<'tcx> = &'tcx List<GenericArg<'tcx>>;

/// A substitution maps parameter indices to concrete arguments.
pub struct Substitution<'tcx> {
    pub args: GenericArgsRef<'tcx>,
}
```

### 3.4 Predicates

```rust
/// A predicate is something that must be proven to hold.
pub enum Predicate<'tcx> {
    /// Trait bound: `T: Clone`.
    Trait(TraitPredicate<'tcx>),
    /// Projection (associated type equality): `<T as Iterator>::Item == U`.
    Projection(ProjectionPredicate<'tcx>),
    /// Type outlives (no-op in Yelang, but kept for uniformity).
    TypeOutlives(TypeOutlivesPredicate<'tcx>),
    /// Const evaluatable.
    ConstEvaluatable(Const<'tcx>),
}

pub struct TraitPredicate<'tcx> {
    pub trait_ref: TraitRef<'tcx>,
    pub polarity: ImplPolarity,  // Positive or Negative
}

pub struct TraitRef<'tcx> {
    pub def_id: DefId,  // The trait's DefId
    pub args: GenericArgsRef<'tcx>,
}
```

### 3.5 Binders & Higher-Ranked Types

```rust
/// A value bound by a `for<...>` quantifier.
pub struct Binder<'tcx, T> {
    pub value: T,
    pub bound_vars: &'tcx List<BoundVariableKind>,
}

pub enum BoundVariableKind {
    Ty(BoundTy),
    Const(BoundConst),
}
```

### 3.6 Canonicalization

Canonicalization removes inference variables and replaces them with bound variables. This is the key to the solver's caching strategy.

```rust
/// A canonicalized value: all inference vars replaced with bound vars.
pub struct Canonical<'tcx, V> {
    pub value: V,
    pub max_universe: UniverseIndex,
    pub variables: CanonicalVarKinds<'tcx>,
}

pub enum CanonicalVarKind {
    /// An existential type variable: `exists<T>`.
    Ty(CanonicalTyVarKind),
    /// A placeholder type variable: `!T_N`.
    PlaceholderTy(PlaceholderType),
    /// An integral variable.
    Int,
    /// A float variable.
    Float,
    /// A const variable.
    Const,
}

pub enum CanonicalTyVarKind {
    General(UniverseIndex),
    Int,
    Float,
}
```

---

## 4. Inference Engine (`yelang-infer`)

### 4.1 Unification Table

The heart of type inference. Uses union-find with rollback.

```rust
/// The unification table for type variables.
pub struct UnificationTable<'tcx> {
    type_vars: ena::UnificationTable<TyVid>,
    int_vars: ena::UnificationTable<IntVid>,
    float_vars: ena::UnificationTable<FloatVid>,
    const_vars: ena::UnificationTable<ConstVid<'tcx>>,
}

impl<'tcx> UnificationTable<'tcx> {
    /// Create a new general type variable.
    pub fn new_type_var(&mut self, origin: TypeVariableOrigin) -> Ty<'tcx>;

    /// Create a new integral type variable.
    pub fn new_int_var(&mut self) -> Ty<'tcx>;

    /// Create a new float type variable.
    pub fn new_float_var(&mut self) -> Ty<'tcx>;

    /// Unify two types. Returns `Ok(())` on success, `Err(TypeError)` on failure.
    pub fn eq(&mut self, a: Ty<'tcx>, b: Ty<'tcx>) -> Result<(), TypeError>;

    /// Check if two types *can* be unified without side effects.
    pub fn can_eq(&mut self, a: Ty<'tcx>, b: Ty<'tcx>) -> bool;

    /// Get the root (resolved) type of a variable, if known.
    pub fn probe(&mut self, vid: TyVid) -> Option<Ty<'tcx>>;
}
```

### 4.2 Snapshots & Rollback

```rust
/// A snapshot of the unification state.
pub struct Snapshot {
    type_snapshot: ena::Snapshot<TyVid>,
    // ...
}

impl<'tcx> InferCtxt<'tcx> {
    /// Create a snapshot.
    pub fn snapshot(&self) -> Snapshot;

    /// Rollback to a snapshot (undo all changes since).
    pub fn rollback_to(&mut self, snapshot: Snapshot);

    /// Commit changes since a snapshot.
    pub fn commit(&mut self, snapshot: Snapshot);

    /// Convenience: probe without permanent side effects.
    pub fn probe<R>(&mut self, f: impl FnOnce(&mut Self) -> R) -> R {
        let snapshot = self.snapshot();
        let result = f(self);
        self.rollback_to(snapshot);
        result
    }
}
```

### 4.3 Type Error Kinds

```rust
pub enum TypeError<'tcx> {
    /// Mismatched types: expected `expected`, found `found`.
    Mismatch { expected: Ty<'tcx>, found: Ty<'tcx> },
    /// Cyclic type: `?T = Vec<?T>`.
    CyclicTy(Ty<'tcx>),
    /// Unsolved inference variable.
    UnresolvedInferenceVariable(Ty<'tcx>),
    /// Invalid projection: `<T as Trait>::Item` not found.
    ProjectionNotFound(ProjectionPredicate<'tcx>),
    /// Trait not implemented: `T: Trait` not satisfied.
    TraitNotImplemented(TraitPredicate<'tcx>),
    /// Ambiguous trait bound.
    AmbiguousTrait(TraitPredicate<'tcx>),
    /// Invalid field access.
    NoSuchField { ty: Ty<'tcx>, field: Symbol },
    /// Invalid method call.
    NoSuchMethod { ty: Ty<'tcx>, method: Symbol },
    /// Arity mismatch in call.
    ArgCount { expected: usize, found: usize },
    /// Generic argument count mismatch.
    GenericArgCount { expected: usize, found: usize },
    /// Custom error message.
    Custom(String),
}
```

---

## 5. Next-Generation Trait Solver (`yelang-trait-solver`)

This is the **recursive goal-driven solver**, matching rustc's `rustc_next_trait_solver` design. It replaces the old `select`/`fulfill` approach.

### 5.1 Core Concepts

- **Goal**: Something to prove, e.g. `Vec<i32>: Clone`.
- **ParamEnv**: The set of assumptions available, e.g. `T: Clone`.
- **Candidate**: A way to prove a goal, e.g. an impl or a param-env assumption.
- **Response**: The result of trying to prove a goal: `Yes`, `Maybe` (ambiguous), or `No`.

### 5.2 Goal Representation

```rust
/// A goal to prove.
pub struct Goal<'tcx, P> {
    pub param_env: ParamEnv<'tcx>,
    pub predicate: P,
}

/// The environment of assumptions.
pub struct ParamEnv<'tcx> {
    pub caller_bounds: &'tcx List<Predicate<'tcx>>,
}

/// A nested goal with a source (for diagnostics).
pub struct NestedGoal<'tcx> {
    pub source: GoalSource,
    pub goal: Goal<'tcx, Predicate<'tcx>>,
}

pub enum GoalSource {
    /// Required for correctness.
    Impl,
    /// From a where clause on an impl.
    WhereClause,
    /// From a bound on a type parameter.
    Bound,
    /// From a projection normalization.
    Normalize,
    /// From a coercion.
    Coerce,
}
```

### 5.3 EvalCtxt — The Solver Engine

```rust
/// The evaluation context for the trait solver.
pub struct EvalCtxt<'a, 'tcx, D> {
    delegate: &'a D,
    /// The search graph for detecting cycles and caching.
    search_graph: &'a mut SearchGraph,
    /// Currently accumulated nested goals.
    nested_goals: Vec<NestedGoal<'tcx>>,
    /// The highest universe index visible to the caller.
    max_input_universe: UniverseIndex,
    /// Whether the result is tainted (encountered an error).
    tainted: Result<(), NoSolution>,
}

/// The solver delegate abstracts over rustc/rust-analyzer specifics.
pub trait SolverDelegate<'tcx> {
    type Infcx: InferCtxtLike<'tcx>;
    fn infcx(&self) -> &Self::Infcx;
    fn tcx(&self) -> TyCtxt<'tcx>;
}
```

### 5.4 Main Solver Loop

```rust
impl<'a, 'tcx, D: SolverDelegate<'tcx>> EvalCtxt<'a, 'tcx, D> {
    /// Entry point: evaluate a root goal.
    pub fn evaluate_root_goal(
        delegate: &D,
        goal: Goal<'tcx, Predicate<'tcx>>,
    ) -> Result<(bool, Certainty, Vec<ExternalConstraint<'tcx>>), NoSolution> {
        let mut search_graph = SearchGraph::new();
        let mut ecx = EvalCtxt::new(delegate, &mut search_graph);
        ecx.evaluate_goal(goal)
    }

    /// Evaluate a single goal.
    pub fn evaluate_goal(
        &mut self,
        goal: Goal<'tcx, Predicate<'tcx>>,
    ) -> Result<(bool, Certainty, Vec<ExternalConstraint<'tcx>>), NoSolution> {
        // 1. Canonicalize the goal for caching.
        let canonical_goal = self.canonicalize_goal(goal);

        // 2. Check the cache / search graph.
        if let Some(result) = self.search_graph.try_get(&canonical_goal) {
            return self.instantiate_canonical_response(result);
        }

        // 3. Insert provisional result into search graph.
        self.search_graph.insert_provisional(&canonical_goal);

        // 4. Compute the goal.
        let result = self.compute_goal(canonical_goal);

        // 5. Update search graph and return.
        self.search_graph.finalize(&canonical_goal, &result);
        result
    }

    /// The actual solver behavior: match on predicate kind.
    fn compute_goal(&mut self, goal: CanonicalGoal<'tcx>) -> SolverResult<'tcx> {
        match goal.predicate {
            Predicate::Trait(trait_pred) => self.compute_trait_goal(trait_pred),
            Predicate::Projection(proj_pred) => self.compute_projection_goal(proj_pred),
            Predicate::ConstEvaluatable(ct) => self.compute_const_eval_goal(ct),
            // ...
        }
    }
}
```

### 5.5 Trait Goal Solving

```rust
impl<'a, 'tcx, D> EvalCtxt<'a, 'tcx, D> {
    fn compute_trait_goal(
        &mut self,
        goal: Goal<'tcx, TraitPredicate<'tcx>>,
    ) -> SolverResult<'tcx> {
        // 1. Assemble all possible candidates.
        let candidates = self.assemble_and_evaluate_candidates(goal)?;

        // 2. Try to merge candidates.
        match candidates.len() {
            0 => Err(NoSolution),
            1 => Ok(candidates.into_iter().next().unwrap().response),
            _ => self.try_merge_responses(candidates),
        }
    }

    /// Assemble candidates from all sources.
    fn assemble_and_evaluate_candidates(
        &mut self,
        goal: Goal<'tcx, TraitPredicate<'tcx>>,
    ) -> Result<Vec<Candidate<'tcx>>, NoSolution> {
        let mut candidates = Vec::new();

        // Candidate 1: ParamEnv assumption.
        if let Some(param_env_candidate) = self.assemble_param_env_candidate(goal) {
            candidates.push(param_env_candidate);
        }

        // Candidate 2: User-written impl.
        for impl_def_id in self.tcx().all_impls(goal.predicate.trait_ref.def_id) {
            if let Some(impl_candidate) = self.assemble_impl_candidate(goal, impl_def_id) {
                candidates.push(impl_candidate);
            }
        }

        // Candidate 3: Built-in traits (Sized, Copy, Clone, etc.).
        if let Some(builtin) = self.assemble_builtin_candidate(goal) {
            candidates.push(builtin);
        }

        // Candidate 4: Auto traits.
        if let Some(auto) = self.assemble_auto_trait_candidate(goal) {
            candidates.push(auto);
        }

        Ok(candidates)
    }
}
```

### 5.6 Candidate Sources

```rust
pub struct Candidate<'tcx> {
    pub source: CandidateSource,
    pub response: CanonicalResponse<'tcx>,
}

pub enum CandidateSource {
    /// From a user-written impl block.
    Impl(DefId),
    /// From a param-env assumption.
    ParamEnv(usize), // index into caller_bounds
    /// From a built-in rule (Sized, Copy, etc.).
    Builtin,
    /// From an auto-trait derivation.
    AutoTrait,
    /// From a blanket impl.
    Blanket,
}
```

### 5.7 Search Graph & Cycle Handling

The search graph is the key to handling coinductive cycles and caching.

```rust
/// The search graph tracks in-progress and completed goals.
pub struct SearchGraph {
    /// Stack of currently evaluating goals (for cycle detection).
    stack: Vec<StackEntry>,
    /// Cache of completed goals.
    cache: FxHashMap<CanonicalGoalKey, CacheEntry>,
}

struct StackEntry {
    goal: CanonicalGoalKey,
    /// Whether this entry has been used to prove itself (coinductive cycle).
    coinductive: bool,
    /// The provisional result.
    provisional: Option<CanonicalResponse>,
}

struct CacheEntry {
    result: CanonicalResponse,
    /// The depth at which this was proven.
    depth: usize,
}
```

**Cycle semantics**: If a goal depends on itself coinductively (e.g. `Link<T>: Debug` depends on `T: Debug` which eventually depends on `Link<T>: Debug`), the provisional result is used. If all remaining obligations are provisional, they are upgraded to `Yes`.

### 5.8 Normalization

Associated type normalization: `<Vec<i32> as Iterator>::Item` → `i32`.

```rust
impl<'a, 'tcx, D> EvalCtxt<'a, 'tcx, D> {
    fn compute_projection_goal(
        &mut self,
        goal: Goal<'tcx, ProjectionPredicate<'tcx>>,
    ) -> SolverResult<'tcx> {
        // 1. Find an impl that defines the associated type.
        // 2. Substitute and return the normalized type.
        // 3. Add nested goals from the impl's where clauses.
        todo!("detailed in implementation")
    }

    /// Try to normalize a type by one step.
    pub fn try_normalize_ty(&mut self, ty: Ty<'tcx>) -> Option<Ty<'tcx>> {
        match ty.kind() {
            TyKind::Alias(alias) => {
                // Look up the impl and compute the projection.
                self.normalize_projection(alias)
            }
            _ => None,
        }
    }
}
```

### 5.9 Coherence Checking

Coherence ensures that for any trait and type, there is at most one applicable impl.

```rust
/// Check that all impls for a trait are non-overlapping.
pub fn check_coherence(tcx: TyCtxt<'_>) -> Result<(), Vec<CoherenceError>> {
    let mut errors = Vec::new();

    for trait_def_id in tcx.all_traits() {
        let impls = tcx.all_impls(trait_def_id);
        for (i, impl1) in impls.iter().enumerate() {
            for impl2 in impls.iter().skip(i + 1) {
                if let Some(overlap) = check_impl_overlap(tcx, *impl1, *impl2) {
                    errors.push(CoherenceError::OverlappingImpls {
                        impl1: *impl1,
                        impl2: *impl2,
                        overlap,
                    });
                }
            }
        }
    }

    if errors.is_empty() { Ok(()) } else { Err(errors) }
}

/// Check if two impls can apply to the same type.
fn check_impl_overlap(
    tcx: TyCtxt<'_>,
    impl1: DefId,
    impl2: DefId,
) -> Option<OverlapResult> {
    // 1. Check if the self types could unify.
    let self_ty1 = tcx.impl_self_ty(impl1);
    let self_ty2 = tcx.impl_self_ty(impl2);

    // 2. Use the trait solver to check if both could apply simultaneously.
    // This is done by creating a goal that requires both impls.
    todo!("use solver to check overlap")
}
```

### 5.10 Specialization

```rust
/// A partial order on impls: impl A is "more specific" than impl B if
/// A applies to a subset of the types that B applies to.
pub struct SpecializationGraph {
    pub trait_def_id: DefId,
    /// Root impls (most general).
    pub roots: Vec<DefId>,
    /// Children of each impl (more specific).
    pub children: FxHashMap<DefId, Vec<DefId>>,
}

/// Check if `impl1` specializes `impl2`.
pub fn specializes(tcx: TyCtxt<'_>, impl1: DefId, impl2: DefId) -> bool {
    // impl1 specializes impl2 if:
    // 1. impl1's self type is a subtype of impl2's self type, AND
    // 2. impl1's where clauses imply impl2's where clauses.
    todo!("implement specialization check")
}
```

---

## 6. Type Checking (`yelang-typeck`)

### 6.1 Type Collection

Before checking bodies, we collect the types of all items from HIR.

```rust
/// Collect the type of an item from its HIR declaration.
pub fn collect_item(tcx: &mut TyCtxt<'_>, item: &hir::Item) -> Result<(), TypeError> {
    match item.kind {
        hir::ItemKind::Fn { sig, generics, .. } => {
            let fn_sig = lower_fn_sig(tcx, sig, generics);
            tcx.set_fn_sig(item.def_id, fn_sig);
        }
        hir::ItemKind::Struct { data, generics } => {
            let adt_def = lower_struct_def(tcx, item.def_id, data, generics);
            tcx.set_adt_def(item.def_id, adt_def);
        }
        // ... enum, trait, impl, type alias, const, static
    }
    Ok(())
}
```

### 6.2 Expression Type Checking

```rust
/// Check an expression and return its inferred type.
pub fn check_expr(
    tcx: TyCtxt<'_>,
    infcx: &mut InferCtxt<'_>,
    expr: &hir::Expr,
    expected: Expectation<'_>,
) -> Ty<'_> {
    match expr.kind {
        hir::ExprKind::Lit { lit } => check_literal(infcx, lit),
        hir::ExprKind::Path { res } => check_path(tcx, infcx, res),
        hir::ExprKind::Binary { op, left, right } => {
            check_binary(tcx, infcx, op, left, right)
        }
        hir::ExprKind::Call { func, args } => {
            check_call(tcx, infcx, func, args)
        }
        hir::ExprKind::Struct { path, fields, rest } => {
            check_struct_literal(tcx, infcx, path, fields, rest)
        }
        hir::ExprKind::Block { block } => {
            check_block(tcx, infcx, block)
        }
        hir::ExprKind::If { cond, then_branch, else_branch } => {
            check_if(tcx, infcx, cond, then_branch, else_branch)
        }
        hir::ExprKind::Match { expr, arms } => {
            check_match(tcx, infcx, expr, arms)
        }
        hir::ExprKind::Closure { params, body, capture_clause } => {
            check_closure(tcx, infcx, params, body, capture_clause)
        }
        // ... all other expression kinds
    }
}
```

### 6.3 Method Lookup

```rust
/// Look up a method on a type.
pub fn lookup_method(
    tcx: TyCtxt<'_>,
    infcx: &mut InferCtxt<'_>,
    self_ty: Ty<'_>,
    method_name: Symbol,
    args: &[hir::Expr],
) -> Option<MethodCallee<'_>> {
    // 1. Try inherent methods (methods defined directly on the type).
    if let Some(method) = lookup_inherent_method(tcx, self_ty, method_name) {
        return Some(method);
    }

    // 2. Try trait methods (via deref autoref coercion).
    // This may require proving trait bounds.
    if let Some(method) = lookup_trait_method(tcx, infcx, self_ty, method_name) {
        return Some(method);
    }

    None
}
```

### 6.4 Coercion

```rust
/// Coerce `source` to `target` type.
pub fn coerce(
    tcx: TyCtxt<'_>,
    infcx: &mut InferCtxt<'_>,
    source: Ty<'_>,
    target: Ty<'_>,
) -> Result<Ty<'_>, TypeError> {
    // Coercion rules (in order):
    // 1. Exact match.
    // 2. Subtyping (width subtyping for anon structs).
    // 3. Deref coercion: `&T` → `&U` where `T: Deref<Target=U>`.
    // 4. Pointer weakening: `&T` → `*const T`, `&mut T` → `*mut T`.
    // 5. Never type: `!` → any type.
    // 6. Int/float literal: `i32` → `u32` if no overflow (not in Rust, but we may allow).
    todo!("implement coercion")
}
```

### 6.5 Pattern Type Checking

```rust
pub fn check_pat(
    tcx: TyCtxt<'_>,
    infcx: &mut InferCtxt<'_>,
    pat: &hir::Pat,
    expected: Ty<'_>,
) -> Result<(), TypeError> {
    match pat.kind {
        hir::PatKind::Wild => Ok(()),
        hir::PatKind::Binding { name, .. } => {
            // Introduce a local variable of the expected type.
            infcx.add_local(name, expected);
            Ok(())
        }
        hir::PatKind::Struct { path, fields } => {
            check_struct_pat(tcx, infcx, path, fields, expected)
        }
        hir::PatKind::Tuple { pats } => {
            check_tuple_pat(tcx, infcx, pats, expected)
        }
        hir::PatKind::Or { pats } => {
            // All alternatives must have the same type.
            for pat in pats {
                check_pat(tcx, infcx, pat, expected)?;
            }
            Ok(())
        }
        // ...
    }
}
```

---

## 7. Exhaustive Checklist

### 7.1 Type System (`yelang-ty`)

- [ ] `Ty` and `TyKind` definitions
- [ ] All primitive types (bool, char, int variants, float variants)
- [ ] ADT types (struct, enum, union) with generic args
- [ ] Tuple types
- [ ] Array and slice types
- [ ] Function pointer and function item types
- [ ] Raw pointer and reference types
- [ ] Never type
- [ ] Anonymous struct types
- [ ] Union types (`A | B`)
- [ ] Type literal types
- [ ] Utility types (Omit, Pick, ReturnType, Parameters)
- [ ] `impl Trait` and `dyn Trait`
- [ ] Inference variables (TyVar, IntVar, FloatVar)
- [ ] Bound variables (`BoundTy`, placeholders)
- [ ] Param types (generic parameters)
- [ ] Error type
- [ ] `GenericArg` and `GenericArgsRef`
- [ ] `Substitution` and application
- [ ] `Predicate` kinds (Trait, Projection, ConstEvaluatable)
- [ ] `TraitRef`, `ProjectionPredicate`
- [ ] `Binder<T>` for higher-ranked types
- [ ] `Canonical<T>` and canonicalization
- [ ] `TypeFolder` and `TypeFoldable` traits
- [ ] `TypeVisitor` trait
- [ ] Type interning
- [ ] List interning

### 7.2 Inference (`yelang-infer`)

- [ ] `InferCtxt` creation and configuration
- [ ] Type variable creation (general, int, float)
- [ ] Const variable creation
- [ ] Unification (`eq`, `sub`)
- [ ] Occurs check (cycle detection)
- [ ] Int/float variable fallback (default to i32/f64)
- [ ] Snapshot creation
- [ ] Rollback to snapshot
- [ ] Commit snapshot
- [ ] `probe` (temporary exploration)
- [ ] `commit_if_ok`
- [ ] Type resolution (full, opportunistic)
- [ ] Freshening
- [ ] All `TypeError` variants

### 7.3 Trait Solver (`yelang-trait-solver`)

- [ ] `Goal` and `ParamEnv` definitions
- [ ] `EvalCtxt` creation
- [ ] `evaluate_root_goal` entry point
- [ ] `evaluate_goal` with canonicalization
- [ ] `compute_goal` dispatch
- [ ] `compute_trait_goal`
- [ ] `compute_projection_goal` (normalization)
- [ ] `compute_const_eval_goal`
- [ ] `assemble_and_evaluate_candidates`
- [ ] `assemble_param_env_candidate`
- [ ] `assemble_impl_candidate`
- [ ] `assemble_builtin_candidate` (Sized, Copy, Clone)
- [ ] `assemble_auto_trait_candidate`
- [ ] `assemble_blanket_candidate`
- [ ] `try_merge_responses`
- [ ] `flounder` (ambiguity)
- [ ] `probe` for candidate isolation
- [ ] Search graph creation
- [ ] Provisional result insertion
- [ ] Cycle detection
- [ ] Coinductive cycle resolution
- [ ] Cache lookup
- [ ] Cache finalization
- [ ] Canonicalization of goals
- [ ] Canonicalization of responses
- [ ] Instantiation of canonical goals
- [ ] Instantiation of canonical responses
- [ ] `ExternalConstraints` extraction
- [ ] `NoSolution` error
- [ ] `Certainty` (Yes, Maybe, No)
- [ ] Normalization of associated types
- [ ] Normalization of opaque types (`impl Trait`)
- [ ] Higher-ranked goal handling (placeholders)
- [ ] Built-in `Sized` impl
- [ ] Built-in `Copy` / `Clone` impls for primitives
- [ ] Built-in `Unsize` (if applicable)
- [ ] Coherence: overlap detection
- [ ] Coherence: orphan rule
- [ ] Coherence: negative impls
- [ ] Specialization: graph construction
- [ ] Specialization: `specializes` check
- [ ] Specialization: default impls

### 7.4 Type Checking (`yelang-typeck`)

#### Item Collection
- [ ] Collect function signatures
- [ ] Collect struct definitions
- [ ] Collect enum definitions
- [ ] Collect trait definitions
- [ ] Collect impl blocks
- [ ] Collect type aliases
- [ ] Collect const/static types
- [ ] Lower HIR generics to `ty::Generics`
- [ ] Lower HIR where clauses to `ty::Predicates`

#### Expression Checking
- [ ] Literal expressions (int, float, string, bool, char)
- [ ] Path expressions (local, non-local, Self)
- [ ] Binary expressions (+, -, *, /, %, &&, ||, ==, !=, <, >, <=, >=)
- [ ] Unary expressions (-, !, *, &)
- [ ] Call expressions (function calls)
- [ ] Method calls (inherent + trait methods)
- [ ] Field access (named fields, tuple indices)
- [ ] Index expressions (`arr[i]`)
- [ ] Assignment expressions (=)
- [ ] Block expressions
- [ ] If / if-else expressions
- [ ] If-let expressions
- [ ] Match expressions
- [ ] Loop / while / for expressions
- [ ] Break / continue expressions
- [ ] Return expressions
- [ ] Closure expressions (parameter inference, capture analysis)
- [ ] Struct literal expressions
- [ ] Tuple expressions
- [ ] Array expressions
- [ ] Await expressions
- [ ] Try (`?`) expressions
- [ ] Range expressions
- [ ] Cast expressions (`as`)
- [ ] Type ascription expressions
- [ ] Is-type expressions

#### Statement Checking
- [ ] Expression statements
- [ ] Let statements (pattern + init + type annotation)
- [ ] Item statements (nested items)

#### Pattern Checking
- [ ] Wild patterns
- [ ] Binding patterns (by value, by ref, mut)
- [ ] Struct patterns
- [ ] Tuple patterns
- [ ] Array/slice patterns
- [ ] Or patterns
- [ ] Rest patterns (`..`)
- [ ] Literal patterns
- [ ] Path patterns (enum variants, constants)

#### Method Lookup
- [ ] Inherent method lookup
- [ ] Trait method lookup
- [ ] Deref coercion for method lookup
- [ ] Autoref for method lookup
- [ ] Method resolution with generics

#### Coercion
- [ ] Exact match
- [ ] Subtyping (width subtyping for anon structs)
- [ ] Deref coercion
- [ ] Pointer weakening
- [ ] Never type coercion
- [ ] Int/float literal coercion
- [ ] Array to slice coercion
- [ ] Function item to function pointer

#### Diagnostics
- [ ] Type mismatch errors
- [ ] Trait not implemented errors
- [ ] Method not found errors
- [ ] Field not found errors
- [ ] Ambiguous method call errors
- [ ] Infinite type errors
- [ ] Unresolved type errors
- [ ] Arg count mismatch errors
- [ ] Generic arg count mismatch errors

### 7.5 Coherence & Specialization

- [ ] Overlap check for all trait impl pairs
- [ ] Orphan rule enforcement
- [ ] Negative impl support
- [ ] Specialization graph construction
- [ ] Default impl method dispatch
- [ ] Forward compat for overlapping impls

---

## 8. Key Design Decisions Explained

### 8.1 Why Next-Gen (Recursive Goal-Driven) Solver?

The old rustc solver uses `select` (pick one candidate) + `fulfill` (queue obligations). This has known soundness holes with cycles and coinduction.

The next-gen solver:
- **Evaluates all candidates simultaneously** in isolated probes
- **Merges responses** to detect ambiguity
- **Handles cycles via search graph** with provisional results
- **Supports coinductive traits** (auto traits like `Send`)
- **Is more cacheable** due to canonicalization

### 8.2 Why No Subtyping?

Yelang doesn't have lifetimes, so the primary use of subtyping (lifetime variance) doesn't exist. Width subtyping for anonymous structs is handled as a coercion, not a general subtyping relation. This simplifies unification to pure equality.

### 8.3 Canonicalization Strategy

Canonicalization is critical for caching. Two goals `Vec<?x>: Clone` and `Vec<?y>: Clone` should share a cache entry. We canonicalize to `exists<T> Vec<T>: Clone`.

**Key rule**: All inference variables become existentially bound. All placeholders become universally bound. Regions are all mapped to existentially bound vars (since Yelang has no lifetimes, this is simpler).

### 8.4 Error Recovery

When type checking fails, we:
1. Report the error
2. Replace the failed type with `TyKind::Error`
3. Continue checking the rest of the program

This ensures we report as many errors as possible in one pass.

---

## 9. Implementation Order

### Phase 1: Core Type System (`yelang-ty`)
1. Define `Ty`, `TyKind`, interning infrastructure
2. Define `GenericArg`, `Substitution`
3. Define `Predicate`, `TraitPredicate`, `ProjectionPredicate`
4. Implement `TypeFolder` and `TypeFoldable`
5. Implement canonicalization
6. **Tests**: Fold/visit round-trips, canonicalization invariants

### Phase 2: Inference Engine (`yelang-infer`)
1. Unification table with `ena`
2. `InferCtxt` with variable creation
3. `eq` and `can_eq`
4. Snapshots and rollback
5. Type resolution (full and opportunistic)
6. Int/float variable fallback
7. **Tests**: Unification, occurs check, rollback, resolution

### Phase 3: Trait Solver (`yelang-trait-solver`)
1. `Goal`, `ParamEnv`, `EvalCtxt`
2. `evaluate_goal` with canonicalization
3. `compute_trait_goal`
4. `assemble_param_env_candidate`
5. `assemble_impl_candidate`
6. `assemble_builtin_candidate` (Sized, Copy)
7. Search graph with provisional results
8. Cycle handling
9. `compute_projection_goal` (normalization)
10. Coherence checking
11. Specialization
12. **Tests**: Trait solving, normalization, coherence, cycles

### Phase 4: Type Checker (`yelang-typeck`)
1. Type collection from HIR
2. Expression checking (literals, paths, binary, unary)
3. Call and method call checking
4. Block, if, match checking
5. Closure checking
6. Pattern checking
7. Method lookup
8. Coercion
9. Writeback
10. Diagnostics
11. **Tests**: All expression kinds, patterns, method lookup, coercion

### Phase 5: Integration
1. Wire type checker into compiler pipeline
2. Run full test suite
3. Fix integration issues

---

## 10. Verification Plan

For each phase, the following must be true before proceeding:

1. **All code compiles** with `cargo check`
2. **All unit tests pass** (`cargo test -p <crate>`)
3. **All integration tests pass** (`cargo test`)
4. **No `todo!()` or `unimplemented!()`** in the code path
5. **Design doc checklist items** for that phase are all checked

---

## References

- [rustc dev guide: Next-gen trait solver](https://rustc-dev-guide.rust-lang.org/solve/trait-solving.html)
- [rustc dev guide: The solver](https://rustc-dev-guide.rust-lang.org/solve/the-solver.html)
- [rustc dev guide: Canonicalization](https://rustc-dev-guide.rust-lang.org/solve/canonicalization.html)
- [rustc dev guide: Type inference](https://rustc-dev-guide.rust-lang.org/type-inference.html)
- [rustc dev guide: Type checking](https://rustc-dev-guide.rust-lang.org/type-checking.html)
- [Rust Project Goals: Next-gen trait solver](https://rust-lang.github.io/rust-project-goals/2025h2/next-solver.html)
- [LWN: Rust's next-generation trait solver](https://lwn.net/Articles/1063124/)
- [ra-ap-rustc_next_trait_solver docs](https://docs.rs/ra-ap-rustc_next_trait_solver)
- [rustc next trait solver source](https://github.com/rust-lang/rust/tree/master/compiler/rustc_next_trait_solver)
- [Chalk solver (historical reference)](https://github.com/rust-lang/chalk)
