# Phase 7.2b — Parse Helpers & Introspection Checklist

Status legend:
- `[ ]` not started
- `[/]` in progress / skeleton / partial
- `[x]` done

---

## 1. Design

- [x] Document parse helper API (`Cursor`, `Parse`, `Parser`, `BufferedCursor`, `ParseError`).
- [x] Document token introspection API (`TokenWalker`, `walk_stream`, `walk_tree`, helpers).
- [x] Exhaustive file tree for `yelang-proc-macro/src/parse/`, `introspect/`, and `tests/`.
- [x] Examples for custom `Parse` impl and token walking.

---

## 2. `Cursor`

- [x] `Cursor<'a>` holds a token-stream snapshot and an offset.
- [x] `new(stream: &TokenStream)` constructor.
- [x] `peek()` and `peek_n(n)`.
- [x] `next()` consume.
- [x] `advance(n)`.
- [x] `is_empty()`, `position()`, `remaining()`.
- [x] `span()` at current position.
- [x] `fork()` cheap clone.
- [x] `remaining_stream()`.
- [x] `parse<T: Parse>()` driver.
- [x] Tests for all cursor operations.

---

## 3. `ParseError`

- [x] Struct with `span` and `message`.
- [x] `new(span, message)` constructor.
- [x] `Display` and `std::error::Error` implementations.
- [x] `to_diagnostic()` conversion.
- [x] Tests.

---

## 4. `Parse` trait and built-in impls

- [x] `Parse` trait definition.
- [x] `Parse` for `TokenStream`.
- [x] `Parse` for `TokenTree`.
- [x] `Parse` for `Group`.
- [x] `Parse` for `Ident`.
- [x] `Parse` for `Literal`.
- [x] `Parse` for `Punct`.
- [x] Tests for each built-in impl.

---

## 5. `Parser` combinators

- [x] `Parser<'a>` wraps a `Cursor`.
- [x] `new(stream)`, `from_cursor(cursor)` constructors.
- [x] `parse<T: Parse>()`.
- [x] `peek()`, `peek_n(n)`, `is_empty()`, `next()`.
- [x] `expect(msg)`.
- [x] `expect_ident()`, `expect_punct(ch)`, `expect_literal()`.
- [x] `expect_group(delimiter)`.
- [x] `expect_keyword(name)`.
- [x] `matches_punct(ch)`, `matches_ident(name)` predicates.
- [x] `consume_punct(ch)`, `consume_ident(name)`.
- [x] `parse_optional<T: Parse>()` via fork.
- [x] `parse_group()`.
- [x] `parse_terminated<T>(is_end, separator)`.
- [x] `parse_many0<T: Parse>()`, `parse_many1<T: Parse>()`.
- [x] `parse_separated0<T: Parse>(separator)`, `parse_separated1<T: Parse>(separator)`.
- [x] `parse_delimited(delimiter)`.
- [x] Tests for every combinator.

---

## 6. `BufferedCursor`

- [x] Rename `Buffered` to `BufferedCursor`.
- [x] Wraps a `Cursor` and supports fork/reset/commit.
- [x] `new(cursor)` constructor.
- [x] `fork()` and `reset(snapshot)` / `commit(cursor)`.
- [x] `cursor()` / `cursor_mut()` accessors.
- [x] `into_cursor()`.
- [x] Tests.

---

## 7. `TokenWalker`

- [x] Trait with `visit_*` callbacks returning `ControlFlow<()>`.
- [x] Default recursive implementation.
- [x] `walk_stream` and `walk_tree` helpers.
- [x] `count_tokens`, `find_idents` convenience functions.
- [x] `visit_enter_group` / `visit_leave_group` hooks.
- [x] Tests for visitor, short-circuiting, and helpers.

---

## 8. Integration and verification

- [x] `parse/mod.rs` and `introspect/mod.rs` are re-export routers only.
- [x] `cargo fmt`.
- [x] `cargo check -p yelang-proc-macro` clean (proc-macro-local warnings only).
- [x] `cargo test -p yelang-proc-macro` passes.
- [x] Update main macro-system checklist.
