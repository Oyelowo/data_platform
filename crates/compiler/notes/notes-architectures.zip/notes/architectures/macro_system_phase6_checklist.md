# Macro System Phase 6 Checklist

## Goal

Implement fragment fields (RFC 3714), unsafe attribute/derive rules (RFC 3715), and field-position macro expansion so that declarative macros are complete for all in-language positions.

## Research and design

- [x] Review RFC 3714 — Macro fragment fields.
- [x] Review RFC 3715 — Unsafe derives and attributes.
- [x] Review Kangrejos 2025 paper examples for real-world derive/attribute use cases.
- [x] Decide exact set of fragment-field accessors per fragment kind.
- [x] Decide field-position invocation syntax and parsing strategy.
- [x] Write Phase 6 design section in `macro_system_completeness_design.md`.
- [x] Write this checklist.

## Fragment fields

- [x] Extend matcher capture binding to record sub-spans/components while parsing fragments.
- [x] Add `FragmentField` representation in transcriber (`$name.field`).
- [x] Parse dotted metavariable syntax in transcriber.
- [x] Resolve fragment fields during transcription.
- [x] Implement `.name` accessor for `:ident` fragments.
- [x] Implement `.type` accessor for `:expr` fragments (type annotation, if present).
- [x] Implement `.name` and `.args` accessors for `:ty` fragments.
- [x] Implement `.vis`, `.name`, `.attrs` accessors for `:item` fragments.
- [x] Error when accessor is used on incompatible fragment kind.
- [x] Error when accessor targets a component that is absent (e.g., type on an expression without annotation).

## Unsafe attribute/derive rules

- [x] Extend macro parser to accept `unsafe attr(<matcher>)(<item-matcher>)` rule prefix.
- [x] Extend macro parser to accept `unsafe derive(<matcher>)(<item-matcher>)` rule prefix.
- [x] Store `is_unsafe` flag on `MacroRule`.
- [x] During attribute macro dispatch, require `unsafe(...)` wrapper if rule is unsafe.
- [x] During derive macro dispatch, require `unsafe(...)` wrapper if rule is unsafe.
- [x] Error when `unsafe(...)` is used but no matching unsafe rule exists.
- [x] Error/warning when `unsafe(...)` wraps a safe rule.
- [x] Support both `@derive(unsafe(Name))` and `#[derive(unsafe(Name))]` syntax.
- [x] Support both `@unsafe(name) item` and `#[unsafe(name)] item` syntax.

## Field-position macro expansion

- [x] Struct literal field values may be macro invocations (`Foo { x: mac!() }`).
- [x] Struct pattern field values may be macro invocations (`Foo { x: mac!() }`).
- [x] Struct/enum field-definition types may be macro invocations (`struct Foo { x: mac!() }`).
- [x] Enum tuple-variant field types may be macro invocations (`enum Foo { Bar(mac!()) }`).
- [x] Array type size expressions may be macro invocations (`[T; mac!()]`).
- [x] Generic arguments may be macro invocations (`Foo<mac!()>`).
- [ ] Allow macro invocation as field name when it expands to an `ident` (deferred: requires AST change to `FieldAssign.name`, `FieldPattern.name`, and `MemberAccess.member`).
- [x] Update `yelang-ast` parser to recognize macro invocation in field positions.
- [x] Update `MacroExpander` to expand field-position macros.
- [x] Ensure hygiene works for field-position expansions.
- [x] Ensure loop detection covers field-position invocations.

## Integration and error handling

- [x] Fragment-field errors carry the dotted metavariable span.
- [x] Unsafe-rule errors name the macro and the required `unsafe(...)` syntax.
- [x] Field-position errors are reported at the field span.
- [x] Macro backtraces include fragment-field/unsafe/field-position frames.

## Tests

Create `yelang-macro/tests/declarative_macros_phase6.rs` covering:

- [x] `$ident.name` expands to the identifier text.
- [x] `$expr.type` expands to the type annotation of a typed expression.
- [x] `$ty.name` expands to the base type name.
- [x] `$ty.args` expands to generic arguments (and reconstructs a full type with `$ty.name$ty.args`).
- [x] `$item.vis` and `$item.name` expand correctly.
- [x] Fragment-field error on incompatible accessor.
- [x] Fragment-field error on missing component.
- [x] `unsafe derive()` rule invoked with `@derive(unsafe(Name))`.
- [x] `unsafe attr()` rule invoked with `@unsafe(name) item`.
- [x] Missing `unsafe(...)` for unsafe rule emits error.
- [x] Unnecessary `unsafe(...)` wrapper on safe rule warns but expands.
- [x] Struct literal field value is a macro invocation.
- [x] Struct pattern field value is a macro invocation.
- [x] Field definition type is a macro invocation.
- [x] Enum tuple-variant field type is a macro invocation.
- [x] Enum struct-variant field type is a macro invocation.
- [x] Array type size expression is a macro invocation.
- [x] Generic argument is a macro invocation.

## Verification

- [x] `cargo test -p yelang-macro` passes
- [x] `cargo test` (workspace) passes
- [x] `cargo check` workspace clean

## Completion notes

- Phase 6 completed on 2026-07-15.
- Fragment fields implemented in `yelang-macro/src/matcher/fragment_fields.rs`, `yelang-macro/src/matcher/bindings.rs`, and `yelang-macro/src/transcribe.rs`.
- Unsafe attribute/derive rules implemented in `yelang-macro/src/matcher/parser.rs` and `yelang-macro/src/expander.rs`.
- Field-position expansion leverages existing `ExprKind::MacroInvocation`, `PatternKind::MacroInvocation`, and `TypeKind::MacroInvocation` support in `yelang-ast`; `MacroExpander` recurses into struct literals, struct patterns, field definitions, enum variants, array sizes, and generic arguments.
- 18 integration tests in `yelang-macro/tests/declarative_macros_phase6.rs` plus unit tests in `yelang-macro/src/matcher/fragment_fields.rs`.
- The only deferred field-position item is macro invocation as a field *name* (e.g., `self.mac!()` or `Foo { mac!(): 1 }`), which requires AST changes and is not supported by Rust either.
