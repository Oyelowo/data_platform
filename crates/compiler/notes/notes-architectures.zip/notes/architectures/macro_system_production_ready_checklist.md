# Phase 7 — Production-Ready Macro System Checklist

Status legend:
- `[ ]` not started
- `[/]` in progress / skeleton / partial
- `[x]` done

This checklist follows the design in
`notes/architectures/macro_system_production_ready_design.md`.

---

## 1. Design and documentation

- [x] Verify current macro implementation state.
- [x] Research production-ready proc-macro best practices (RFCs, rustc dev guide,
      rust-analyzer issues, JetBrains article, Kangrejos 2025).
- [x] Write `notes/architectures/macro_system_production_ready_design.md`.
- [x] Write `notes/architectures/macro_system_production_ready_checklist.md`.
- [ ] Get explicit user approval on architecture, file tree, and phased roadmap.
- [ ] Update `DESIGN.md` crate graph to include proc-macro crates.
- [ ] Add proc-macro examples to `notes/syntax_grammar/`.

---

## 2. Phase 7.1 — Foundational proc-macro bridge

### 2.1 AST/HIR support needed by the bridge

- [x] Raw pointer types parse and codegen (`*const T`, `*mut T`).
- [x] Raw pointer types lower to HIR `TyKind::RawPtr`.
- [x] `extern "ABI" fn` parses and codegens on function items and function pointer types.
- [x] `extern "ABI"` lowers through AST → HIR with `abi` field preserved.

### 2.2 `#[yelang_proc_macro::macro_export]` codegen

- [x] `@yelang_proc_macro::macro_export` recognized.
- [x] `@yelang_proc_macro::macro_export_attribute` recognized.
- [x] `@yelang_proc_macro::macro_export_derive` recognized.
- [x] Validates function signature based on return type and argument count.
- [x] Generates stable `extern "C-unwind"` wrapper function.
- [x] Generates per-macro name static.
- [x] Generates per-macro `YelangMacroDescriptor` static.
- [x] Fix unused `YelangMacroInvoke` field initialization (replace `0 as fn`
      casts with null stub functions).
- [x] Generates `yelang_alloc`, `yelang_free`, and `yelang_proc_macro_entry`.
- [x] Encapsulates raw-pointer unsafety inside `yelang_proc_macro::bridge` helpers.

### 2.3 Bridge ABI

- [x] `YelangProcMacroExports` C struct.
- [x] `CURRENT_ABI_VERSION` constant checked at entry time.
- [x] `yelang_proc_macro_entry` symbol name.
- [x] `ProcMacroKind` enum.
- [x] `YelangFnLikeMacro`, `YelangAttrMacro`, `YelangDeriveMacro` C signatures.
- [x] `C-unwind` ABI for macro functions.
- [x] `YelangAllocFn` / `YelangFreeFn` exported by dylib.
- [x] `WireExpansionResult` carries output tokens and diagnostics.
- [x] `YelangMacroInvoke` is a `#[repr(C)]` struct with three function-pointer
      fields (not a C union).
- [ ] Stable C ABI layout tests.

### 2.4 Server

- [x] `main.rs` CLI parses `--version`, `--listen-fd` (future), `--log`.
- [x] Request loop over stdin/stdout.
- [x] `Session` with slotmap-based `LibraryHandle`.
- [x] `LoadedLibrary` with real dylib handle and macro descriptors.
- [x] Load / unload library requests using `libloading`.
- [x] Dispatch by macro kind.
- [x] Serialize input token streams before calling dylib.
- [x] Deserialize `WireExpansionResult` after dylib returns.
- [x] Panic conversion to `Response::Panic` via `catch_unwind` around `C-unwind` calls.

### 2.5 In-process integration

- [x] `ProcMacroId` newtype.
- [x] `ProcMacroRegistry` for in-process macros.
- [x] `ProcMacroResolver`.
- [x] `ProcMacroClient` spawns server process.
- [x] `InProcessExecutor` and `InProcessProcMacro` trait.
- [x] Integrate in-process proc macros into `expand_macro_invocation`.
- [x] Integrate in-process proc macros into `expand_user_attribute_macro`.
- [x] Integrate in-process proc macros into `expand_user_derive_macro`.

### 2.6 Tests

- [x] `yelang-proc-macro-server` loads a real dylib fixture.
- [x] Function-like proc macro expands through server.
- [x] Attribute proc macro expands through server.
- [x] Derive proc macro expands through server.
- [x] Panic recovery.
- [x] Wrong macro kind returns `MacroNotFound`.
- [x] Macro index out of bounds returns `MacroNotFound`.
- [x] `@yelang_proc_macro::macro_export` generates wrapper/descriptor/entry point.

---

## 3. Phase 7.2 — Complete public API

### 3.1 Core types

- [x] `TokenStream` with `new`, `is_empty`, `len`, `iter`, `into_iter`, `push`, `extend`.
- [x] `TokenTree` enum (`Group`, `Ident`, `Punct`, `Literal`).
- [x] `Group` with delimiter, inner stream, span.
- [x] `Delimiter` enum (`Parenthesis`, `Brace`, `Bracket`, `None`).
- [x] `Ident` with constructor, span, equality by value, raw support.
- [x] `Punct` with char, spacing, span.
- [x] `Spacing` enum (`Alone`, `Joint`).
- [x] `Span` API: `call_site`, `mixed_site`, `def_site`, `source_file`, `start`, `end`, `resolved_at`.
- [x] `SourceFile` and `LineColumn`.
- [x] `Literal` constructors: `byte_string`, `byte`.

### 3.2 Display / rendering

- [x] `Display` for `TokenStream` and `TokenTree`.
- [x] `render_source` method on `TokenStream`.
- [x] `from_core_stream` method on `TokenStream`.
- [x] `into_core_stream` method on `TokenStream`.

### 3.3 Quote macro

- [x] `quote!` procedural macro crate (`yelang-quote`) re-exported by `yelang-proc-macro`.
- [x] Supports interpolating `Ident`, `TokenStream`, `TokenTree`, `Literal`, `Group`, `Punct`.
- [x] Supports any type implementing `ToTokens` (including references, `Option`, `Vec`, slices).
- [x] Supports repetition `#(...)*`, `#(...),*`, `#(...);*` (single-token separator).
- [ ] Supports `#(...)+` one-or-more repetition.
- [ ] Supports nested repetitions.
- [ ] Supports `##` escape (blocked in Rust 2024 call sites; reserved for compiler-hosted quote).
- [x] Produces a `TokenStream` expression.
- [x] Tests for interpolation shapes.
- [x] Tests for repetition shapes.

### 3.4 Lightweight parsing helper

- [x] `Cursor` for token peek/consume/fork.
- [x] `Parse` trait with built-in impls for `TokenStream`, `TokenTree`, `Group`, `Ident`, `Literal`, `Punct`.
- [x] `Parser` struct with combinators (`parse`, `peek`, `next`, `expect`, `expect_*`, `matches_*`, `consume_*`, `parse_optional`, `parse_group`, `parse_terminated`, `parse_many0/1`, `parse_separated0/1`, `parse_delimited`).
- [x] `ParseError` with span and message, `Display`, `std::error::Error`, `to_diagnostic`.
- [x] Lookahead / fork support through `BufferedCursor`.
- [x] Tests for cursor, parser combinators, `BufferedCursor`, and built-in `Parse` impls.

### 3.5 Diagnostics

- [x] `Diagnostic` struct.
- [x] `Level` enum (`Error`, `Warning`, `Note`, `Help`).
- [x] `DiagnosticSpan`.
- [x] `emit` function that stashes diagnostics in thread-local context.

### 3.6 Introspection helper

- [x] `TokenWalker` visitor trait with `visit_token`, `visit_ident`, `visit_punct`, `visit_literal`, `visit_group`, `visit_enter_group`, `visit_leave_group`.
- [x] `walk_stream` and `walk_tree` helpers returning `ControlFlow<()>` for short-circuiting.
- [x] `count_tokens` and `find_idents` convenience helpers.
- [x] Tests for visitor, group enter/leave hooks, short-circuiting, and helpers.

---

## 4. Phase 7.3 — Server-based expansion integration

- [x] Convert AST tokens to `WireTokenStream` for server-based macros via the
      public `yelang_proc_macro::TokenStream` API (replaces broken
      `<symbol:N>` placeholder path).
- [x] Convert `WireTokenStream` back to AST tokens for server-based macros.
- [x] Send expansion request and await response for server-based macros from
      `MacroExpander`.
- [x] Surface diagnostics returned by server to the user as expansion errors.
- [x] End-to-end tests: function-like, attribute, and derive macros through the
      server.
- [x] End-to-end tests: server panic, missing library, invalid output, and
      diagnostic propagation.

---

## 5. Phase 7.4 — Resource limits

- [x] `Limits` struct (memory, time, output tokens).
- [x] `SandboxError` enum.
- [ ] Per-expansion heap limit enforcement.
- [ ] Per-expansion CPU time enforcement.
- [ ] Per-expansion output token count enforcement.
- [ ] Server-level max loaded libraries.
- [ ] Tests for timeout and OOM.

---

## 6. Phase 7.5 — Cross-crate discovery

- [x] Detect `proc-macro` crate type in workspace metadata.
      (`*.ypm.json` manifest format defined in
      `yelang-macro/src/proc_macro/manifest.rs` — the workspace has no other
      crate-metadata layer; the manifest is the crate-type record, carrying
      name, version, host triple, protocol version, dylib fingerprint, and
      the exported macro list. Design doc:
      `notes/architectures/phase_7_5_cross_crate_discovery_design.md`.)
- [x] Load macro descriptors from server.
      (`ProcMacroClient::load_library` returns `LoadedLibrary { handle,
      descriptors }`; introspection fallback registers them directly and
      pre-seeds the validated cache.)
- [x] Store `(crate, name, kind, library_path, macro_index)`.
      (`ProcMacroDef` gained `crate_name`; `library_path` is canonicalized on
      registration; indices come from dylib export order, cross-checked at
      first load.)
- [x] Replace `ProcMacroDiscovery::discover_static` with real metadata-based
      discovery. (`ProcMacroRuntime::discover`/`discover_all` with
      `ProcMacroSource::{Manifest, Dylib}`; `discover_static`/`StaticEntry`
      deleted; kind-aware registry with duplicate detection;
      `DuplicateLibrary` enforces one-dylib-per-registration.)
- [x] Harden manifest I/O.
      (Bounded reads up to `MAX_MANIFEST_BYTES + 1`; atomic temp-file + rename
      writes; streaming blake3 fingerprinting; op-annotated `Io` errors;
      intra-manifest duplicate `(name, kind)` rejection.)
- [x] Harden resolver cache.
      (`CacheEntry { result, validated }`; introspection marked pre-validated;
      `resolver_mut()` for registry mutation after construction.)
- [x] Harden server lookup.
      (`spawn_default` ignores empty/whitespace `YELANG_PROC_MACRO_SERVER`.)
- [x] Integrate discovered attribute macros into expansion.
      (`is_user_attribute_macro` now consults the out-of-process runtime
      resolver in addition to declarative and in-process proc macros.)
- [x] Harden panic isolation.
      (Fixture crate type is `dylib` to share the panic runtime with the
      server; macro ABI functions are `extern "C-unwind"`;
      `yelang_proc_macro::bridge::run` captures panics via a chained hook and
      converts them to error diagnostics inside the dylib; server
      `catch_unwind` is the last-resort belt.)
- [x] Test cross-crate proc-macro use.
      (Integration tests moved to `yelang-proc-macro-server/tests/` so the
      server binary and fixture dylib are available without a circular
      dev-dependency; 17 macro_discovery + 10 macro_server_integration +
      12 server_integration tests covering manifest/introspection discovery,
      sidecar probe, hash/size/protocol/triple rejection, stale-manifest
      load-time validation, `DuplicateMacro`, `DuplicateLibrary`, cross-kind
      namespaces, batch discovery, `spawn_default`, driver API, wire-protocol
      expansion, diagnostic propagation, panic conversion, and isolated
      temp-dir manifests.)

---

## 7. Phase 7.6 — Declarative attribute and derive macros

**Status:** implemented and tested. The checklist was stale; the parser and
expander already support these forms. RFC 3714 fragment fields are partially
implemented (`$x.field`-style accessors work for some fragment kinds).

- [x] Parse `attr(...)` macro rule prefix.
      (`yelang-macro/src/matcher/parser.rs` recognizes `attr($args)($item)`.
- [x] Parse `derive(...)` macro rule prefix.
      (`yelang-macro/src/matcher/parser.rs` recognizes `derive($args)($item)`.
- [x] Parse `unsafe attr(...)` and `unsafe derive(...)` prefixes.
      (`yelang-macro/src/matcher/parser.rs` handles `unsafe attr` / `unsafe derive`.)
- [x] Expand attribute macros defined by `macro_rules!`.
      (`expander.rs` dispatches attribute rules with proper outer-to-inner
      ordering and unsafe-flag handling.)
- [x] Expand derive macros defined by `macro_rules!`.
      (`expander.rs` dispatches derive rules, user rules take precedence over
      built-in derives.)
- [/] Fragment fields (RFC 3714) extension point.
      (Basic `$x.field` accessors exist; full structural field access on all
      fragment kinds is a future enhancement.)
- [x] Tests for declarative attr/derive macros.
      (`declarative_macros_exhaustive.rs` and `declarative_macros_phase6.rs`
      cover attr/derive rules, args, unsafe wrappers, and precedence over
      built-in derives.)

---

## 8. Phase 7.7 — Full hygiene

- [/] `Span` serialization with syntax context (wire types carry the field).
- [/] `Span::def_site()` and `Span::mixed_site()` currently resolve to `call_site()`.
- [ ] Deserialize spans preserving syntax context.
- [ ] New identifiers from server get correct contexts.
- [ ] Cross-crate hygiene table serialization in rlib metadata.
- [ ] Test: generated names do not collide.

---

## 9. Phase 8 — Comptime / compile-time evaluation

Design doc: `notes/architectures/comptime_design.md`.  
Checklist: `notes/architectures/comptime_checklist.md`.

- [ ] Reserve `comptime` keyword.
- [ ] Parse `comptime { ... }` blocks and `comptime fn` items.
- [ ] Add AST/HIR nodes for comptime blocks and functions.
- [ ] Implement `yelang-comptime` interpreter crate.
- [ ] Integrate comptime evaluator with `yelang-tycheck`.
- [ ] Evaluate comptime expressions in const contexts.
- [ ] Implement reflection builtins (`@typeInfo`, `@typeName`).
- [ ] Implement `@compileLog` and `@setEvalBranchQuota`.
- [ ] Enforce comptime sandbox (no I/O, env, network).
- [ ] Splice comptime values and generated types back into compilation.
- [ ] Tests: unit, integration, and adversarial.

---

## 10. Negative tests

- [x] Wrong function signature rejected for `@yelang_proc_macro::macro_export`.
- [ ] Missing `macro_export` means macro is not discoverable.
- [x] Protocol version mismatch produces error.
- [ ] Server timeout / OOM produces error.
- [x] Recursive proc macro hits depth limit.
- [x] Dylib with wrong ABI version rejected at load time.
- [ ] Malformed dylib produces clear error.
- [ ] Returned invalid tokens produce parser error with span.

---

## 10. Final verification

- [x] `cargo fmt`
- [x] `cargo check --workspace` clean (existing warnings allowed)
- [x] `cargo test --workspace`
- [x] Phase 7.2 tests pass after implementation.
- [x] Design doc and checklist updated for the new `yelang-quote` crate and `quote!` implementation..
