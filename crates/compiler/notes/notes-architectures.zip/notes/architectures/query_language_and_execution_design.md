# Yelang Query Language & Execution — Unified Design

**Status:** Proposed. Supersedes `YELANG_QUERY_EXECUTION_DESIGN.md`, the
`query-aggregation*.md` series, `query-iterarion.md`, and the QIR placeholder
semantics where they conflict. Complements (does not replace)
`notes/syntax_grammar/semantics.md` (surface syntax) and
`notes/docs/PHASEH_QUERY_EXPRESSION_DESIGN.md` (HIR lowering).

**Scope:** Everything between "the parser produced a query AST" and "bytes move
on a wire or disk": semantic model, typing rules, extensibility (decorators),
value semantics, the iterator/stream/aggregate trait surface, logical and
physical IRs, rewrites, the optimizer, the execution engine, backends
(in-memory / embedded / remote / distributed), streaming, and the roadmap.

This document is opinionated. Where it diverges from earlier notes, the
decision register (§16) says so and why.

---

## 1. Current-state audit (what we actually have)

| Area | State | Where |
|---|---|---|
| Query syntax (select/create/update/upsert/delete/link/unlink, links traversal, group by, order, range) | **Implemented, parsed** | `yelang-ast/src/query/` |
| Selectors `[*]`, `[where]`, `[**]` → uniform `Expr::Comprehension` | **Implemented** | `yelang-hir/src/lowering/expr.rs` |
| Type checking of queries (links, group-by, multi-root, comprehensions, mutation queries) | **Implemented** (69 integration tests) | `yelang-tycheck/src/check.rs` |
| Trait solver (Chalk-style search graph, caching, auto traits, negative impls) | **Implemented** | `yelang-trait-solver/` |
| HM inference, interned `TyId`, unions, existentials, assoc types | **Implemented** | `yelang-ty/` |
| Lang-item registry (`@lang("...")`) | **Implemented** | `yelang-resolve/src/lang_items.rs` |
| `let mut`, `Ty::Ref(TyId, Mutability)` | **Implemented** | `yelang-ast`, `yelang-ty` |
| Built-in derives as compiler intrinsics | **Implemented** | `yelang-hir/src/derive/` |
| QIR (logical/physical/exec/backend) | **Placeholder** (~870 lines, empty plans) | `yelang-qir/` |
| Stdlib | **Placeholder** (Rust crate, empty dirs; no `.yed` files exist) | `stdlib/` |
| User-defined macros | **Removed by ADR** (2026-07-17); `comptime` is the sole planned extensibility mechanism and is design-only | `notes/architectures/adr_no_user_defined_macros.md` |
| Effect system, Send/Sync, async runtime | **Absent** (async/gen parse only) | — |

Consequences that shape this design:

1. **The macro removal is load-bearing.** Old notes assumed attribute macros
   (`@attribute pub struct Transaction { ... }` + an `AttributeProcessor`).
   That mechanism no longer exists. Decorator semantics must come from (a)
   built-in derives/compiler intrinsics and (b) `comptime` when it lands. §6
   redesigns decorators accordingly.
2. **Tycheck already type-checks queries.** The "should we wait for tycheck"
   question is moot for typing — the missing phase is everything *after*
   tycheck: real QIR lowering, rewrites, physical planning, execution.
3. **The trait solver is ready** for the recognition strategy this design
   depends on (recognizing `Queryable`/`Aggregate` impls by resolution, not by
   name).

---

## 2. Design principles

**P1 — Queries are ordinary expressions.** A query is not a DSL island. It is
typed by ordinary expression typing, its clauses are ordinary expressions over
ordinary bindings, and its result is an ordinary value. The pipeline
(`from/links/where/group/order/range`) only introduces names and collections;
the projection is the query. (Already our #1 surface rule; here it becomes the
*type rule*.)

**P2 — One calculus, many backends.** All queryable sources — in-memory
arrays, the embedded storage engine, remote clusters, event streams — lower to
one comprehension-based core calculus. Backends differ only in *capabilities*,
exposed to the compiler as trait implementations and to the planner as a
capability profile. There is no per-backend syntax and no per-backend semantic
fork.

**P3 — The compiler knows mechanisms, never domain vocabulary.** No
`DecoratorKind`, no `ProjKind`, no `AggregateKind`, no hardcoded `Table`. The
compiler hardcodes exactly: the comprehension core, a small lang-item set
(`Iterator`, `Queryable`, `Aggregate`, `Copy`, …), physical properties
(ordering, partitioning, location, boundedness), and aggregate *classes*
(distributive/algebraic/holistic). Everything else — tables, edges, indexes,
`sum`, transactions — is stdlib or user code recognized by resolved identity.

**P4 — Value semantics everywhere; sharing is an optimization.** Assignment
and argument passing are logically copies. Copy-on-write makes this fast; it
never changes observable behavior. No aliasing surprises, no `&`-style shared
mutable references, `let mut` required to mutate.

**P5 — Fail at compile time, or be explicit at runtime.** Untranslatable query
fragments are compile errors naming the subterm, with an explicit `.local()`
escape hatch — never silent client-side evaluation (EF Core's pre-3.0 disaster)
and never runtime `InvalidOperationException: could not be translated`
(LINQ's #1 documented regret).

**P6 — Stream and batch are one engine.** A batch is a bounded stream. The
bounded/unbounded distinction is a *property* in the IR from day one, so
streaming is never a second engine bolted on later (the Lambda-architecture
trap).

**P7 — Ship plans, not code.** Remote shards execute versioned plan fragments
against a pre-deployed, closed operator set. Never serialized closures
(Spark's Python-UDF lesson: sandboxing, versioning, performance hell).

**P8 — Simple physical design, serious cardinality estimation.** Hash joins
and scans tolerate estimation error; index-nested-loop-rich designs punish it
catastrophically (Leis et al., Join Order Benchmark). We invest in
samples/statistics before cost-model cleverness.

---

## 3. Semantic model

### 3.1 Collections: `Seq[T]` vs `Coll[T]` — order is a type-level fact

SQL's bag semantics leaked into host languages is a permanent documented pain
(LINQ-to-SQL null/ordering mismatch sections). PartiQL's lesson is the right
one: **ordered and unordered collections are different types**.

- **`Seq[T]`** — ordered. In-memory arrays, the result of `order by`, event
  streams (ordered by event time within a partition). Today's `Array<T>` lang
  item becomes `Seq[T]`.
- **`Coll[T]`** — unordered bag. Storage-backed sources, the result of any
  unordered-preserving operation over a `Coll`. Bags enable the optimizer to
  chunk, parallelize, reorder, and partition freely.

Rules:

- `order by` converts `Coll[T] → Seq[T]`. Materializing a `Coll` into an array
  without ordering is allowed but the order is *unspecified* and may vary
  between runs, backends, and plans.
- `range`/`take` requires `Seq` (an unordered `skip` is meaningless — this
  kills the "pagination without order by" footgun at the type level).
- Every unordered-preserving operator (`filter`, `map`, joins without order
  requirements) propagates unorderedness. `distinct` on `Coll` is cheap; on
  `Seq` it must document whether it preserves first-occurrence order.
- `Seq[T]` is usable wherever `Coll[T]` is expected (order is *extra*
  information, discardable), never the reverse.

This single decision buys: honest distributed semantics, optimizer freedom,
and an end to users relying on incidental scan order.

### 3.2 Projection determines the result — as a typing theorem

The result type of a query is **exactly the type of the projection
expression**. Formally, in the typing judgment for a query:

```
Γ; Π ⊢ pipeline ⇒ Γ'          (pipeline introduces bindings/collections into Γ')
Γ' ⊢ projection : τ
─────────────────────────────
Γ; Π ⊢ query : τ
```

The pipeline has **zero** influence on the result type. Consequences, all
intended:

- `select 1 from users@u:User` : `Int`. It returns `1`.
- `select users@u[*].{ id, age } from users@u:User order by u.age desc range 20..30`
  : `Seq[{ id: …, age: … }]`. `order`/`range` determine *which* elements and
  in what order; the projection determines the shape.
- `group by … into groups` rebinds the root names (the groups collection
  replaces the source collection in scope); the projection still decides
  everything.

**Demand-driven elision (optimizer corollary).** Bindings the projection does
not consume (transitively, including through `where`/`order` keys the
projection iterates over) are dead: the physical planner may elide the scans
behind them. `select 1 from users` reads zero rows. Type checking still
validates the whole pipeline — elision is execution-only. This is
lazy-evaluation discipline inside an eager language, and it composes with
snapshot semantics: an elided source takes no snapshot, holds no locks.

**Avalanche safety.** Nested projections produce nested results in one
evaluation; the number of plan fragments/round-trips depends only on the
*nesting degree of the result type*, never on data size (Ferry/DSH's
"avalanche-safe" property). Because we own the engine, nested results are
native — no SQL shredding needed for our own backends; shredding is only an
interop concern for foreign SQL backends later.

### 3.3 Absence: `Option[T]`, no NULL

**Decision: there is no `NULL` in yelang queries.** The placeholder `QLit::Null`
is removed. Absence is `Option[T]`, uniformly with the rest of the language.

- Outer joins produce `Option` fields. Missing fields on schema-flexible
  sources produce `Option`. Three-valued logic does not exist;
  `Option == Option` is ordinary `Eq`.
- Rationale: SQL's 3VL is the single most regretted semantic in database
  history, and every LINQ provider docs page has a permanent "null semantics
  mismatch" section. PartiQL needed *two* absence values (NULL + MISSING) to
  stay SQL-compatible; we have no such legacy. EdgeDB proved a no-NULL design
  is viable (they use empty-set; `Option` is the better fit for us because our
  values aren't uniformly sets).
- Aggregate over empty input: `count` → `0`; `sum` → `0` for numeric with an
  additive identity, else `None`; `min/max/avg` → `None`. These are spelled
  out per aggregate in its stdlib definition, not in the compiler.

### 3.4 Determinism and purity: a three-level volatility contract

The optimizer's legality conditions (folding, pushdown, reordering, remote
shipping) need to know what a function may do. We adopt Postgres's proven
three levels as a **declaration on every function** (default: `stable`):

- **`pure`** — deterministic, no effects, no environment reads. Foldable,
  reorderable, duplicate-call eliminable, shippable to shards, usable in
  index predicates and comptime.
- **`stable`** — deterministic within one query execution (may read snapshot
  state). Pushable, not foldable across the query boundary.
- **`volatile`** — anything else (clock, RNG, I/O, mutation). Never folded,
  never pushed into a backend, forces a `.local()`-style boundary in a query.

This is *not* an effect system. It is one declared bit-per-level on function
items, checked conservatively (a `pure` fn may only call `pure` fns; the
compiler enforces this through ordinary resolution). Stdlib marks its surface;
user functions default to `stable`. Wrong user labels on `pure` are UB-grade
lies, so `pure` on user fns is opt-in and linted.

**Froid corollary.** Because we own the compiler, yelang function bodies used
inside queries are **inlined into the query IR** (assignments → projections,
`if` → `cond`, per Froid, VLDB'17) and optimized with everything else. UDFs
are never opaque zero-cost black boxes — the mistake that gave UDFs their
reputation.

### 3.5 Mutability and aliasing (surface semantics)

- `let x = v` binds an immutable value; `let mut x = v` permits mutation.
  (Already implemented.)
- `let b = a` is **logically a copy**. Mutating `b` never changes `a`. This is
  the least-confusing default for a no-borrow-checker language and the only
  one compatible with distribution (values cross shards by value anyway).
- There are **no shared mutable references** in the surface language.
  `Ty::Ref(_, Mut)` exists in the type IR for internal use (method receivers,
  cursor-style borrows within a function), but a mutable reference cannot be
  *stored* in a container, *captured* by a closure, or *returned* — the Hylo
  "mutable value semantics" restriction, which gives race-freedom without a
  borrow checker. This is the PHP lesson in reverse: PHP's `&` references
  permanently poison CoW (`is_ref`) and create action-at-a-distance; we simply
  don't have them.

§7 covers how CoW makes this fast.

---

## 4. The core calculus: everything lowers to comprehensions

### 4.1 Why a comprehension core

The load-bearing theorem of language-integrated query (Wong 1996; Libkin &
Wong 1997; Cheney/Lindley/Wadler): **any expression in the nested
comprehension calculus whose result type is a flat relation has an equivalent
normal form translatable to a backend query** — and the normalization rules
are a strongly-normalizing rewrite system, i.e. an algorithm, not a heuristic.
Quill turned this into a production design (compile-time quotation +
normalization + static translatability); Links proved whole-program static
guarantees are possible.

We adopt exactly this architecture, with our own twist: the "backend query"
is not SQL but our own plan algebra (§9–§11), and the "quotation" is not a
macro — it is the ordinary HIR → QIR lowering of well-typed expressions.

### 4.2 The core (QIR logical expression/operator substrate)

Two kinds of terms, mirroring Calcite's RelNode/RexNode split:

- **Collection terms** (`Operator`): `Scan`, `Filter`, `Map`, `FlatMap`,
  `OrderBy`, `Range`, joins, `GroupBy`, `Aggregate`, `Window`, `SetOp`,
  `Distinct`, `Exchange` (physical-only, §10), `Values`.
- **Scalar terms** (`QExpr`): literals, bound refs (by **unique id**, never by
  name — DataFusion's string-name-alias bug class), field access, arithmetic,
  `Call { fn_id: DefId, args }`, `Record`, `If`, and — critically —
  `Comprehension` for nested cases before decorrelation.

All surface forms desugar to this core *before or during type checking*:

| Surface | Core |
|---|---|
| `users@u[*].f(u)` | `Map(Scan(users), λu. f(u))` |
| `users@u[where p(u)]` | `Filter(Scan(users), λu. p(u))` |
| `users@u[**]` / `[***]` | `FlatMap` with flatten depth |
| `from a@x, b@y` | `CrossJoin`/dependent product → later rewritten |
| `where` clause | `Filter` over the product |
| `group by {k…} into g` | `GroupBy(keys, members_label=g)` producing group records |
| `order by` / `range` | `OrderBy` (Coll→Seq) / `Range` (Seq only) |
| `links` paths | traversal joins against the edge index (§13.3) |
| method calls on `Queryable` | the same operators, resolved via lang item |

The clause form and the method form are **two surfaces over one core**
(PRQL/KQL evidence: linear pipelines are more readable for composition; clause
form is better for multi-source binding). Neither is privileged; both produce
identical QIR for equivalent programs. This is already how PHASEH lowers
selectors; we extend it to everything.

### 4.3 Normalization (the rewrite that makes translatability an algorithm)

Before any cost-based planning, a canonicalization pass runs the published
comprehension normalization rules to a fixpoint:

- **Monad-comprehension laws**: map fusion (`map f ∘ map g = map (f∘g)`),
  flat-map associativity, unit/identity elimination, nested-comprehension
  collapse (`concat ∘ map` fusion).
- **Filter migration**: predicates move across maps/joins toward scans when
  their referenced ids allow it (this is predicate pushdown, derived from the
  laws rather than special-cased).
- **Record/field normalization**: projection collapsing, dead-field
  elimination (columns pruned = fields never read by the projection —
  §3.2's demand analysis made mechanical).
- **Decorrelation** (§4.4).
- **Constant folding** over `pure` calls only (§3.4).

Implementation: Catalyst-style — immutable trees, rules as pattern-match
partials, batches run to fixpoint, per-rule before/after dump available via a
compiler flag from day one, per-pass disable flags (DuckDB's hard-earned
debuggability lesson). Ids are interned integers; no name-based identity
anywhere below HIR.

### 4.4 Decorrelation: dependent join first

Correlated subqueries (including `links` traversals and nested projections
referencing outer binders) lower initially to a **`DependentJoin`** operator
(the placeholder already has the variant). Then Neumann & Kemper's
"Unnesting Arbitrary Queries" algorithm applies:

1. If the inner side has no correlation → plain join.
2. Push `DependentJoin` down through the inner expression with the standard
   rewrite identities (through Filter/Map/joins/aggregates).
3. When all dependent references vanish from a subtree, the dependent join
   over it degenerates into a regular join variant.
4. Aggregation case: evaluate the inner aggregate once per **distinct**
   correlation-value tuple (D = π distinct outer values), join back; scalar-agg
   empty-input semantics via outer join + the per-aggregate defaults of §3.3.

This subsumes magic sets for a new engine and guarantees no accidental O(N²)
evaluation. Do **not** build ad-hoc per-shape unnesting heuristics — that is
the pre-2015 state of the art and it never generalizes.

### 4.5 `group by … into` as a first-class operator (not sugar to flat SQL)

`group by { k₁: e₁, … } into g` produces, per distinct key tuple, a **group
record**: `{ k₁: …, …, <members_label>: Coll[element] }` where the members
label is the *root source's* label (`g.users` in the user's example — the
root label `users` flows through as the member collection). `having` does not
exist as a clause: filtering groups is just filtering the groups collection in
the projection (`groups@g[where …]`). Canonical accessor methods `g.key()` /
`g.items()` exist for the method form.

Key types must be `Eq + Hash` (hash-grouping) or `Ord` (sort-grouping); the
planner picks. Keys are ordinary expressions of any hashable type — the
current "orderable primitives only" restriction is a placeholder limitation,
not a design decision.

---

## 5. Typing rules for queries (delta to tycheck)

Tycheck already handles the bulk (comprehensions, links, group-by, multi-root).
The delta this design requires:

1. **`Seq`/`Coll` split** (§3.1): `Array<T>` lang item renamed/split; `order by`
   is the introduction form of `Seq` over storage; `range` requires `Seq`.
2. **Projection-typed results** (§3.2): the query's type is the projection's
   type — already the rule; formalize `group by … into` rebinding so the
   post-group scope exposes group records (mostly done in `check_group_by`).
3. **`Option` propagation** (§3.3): outer-join links paths wrap target fields
   in `Option`; `min/max/avg` return `Option`.
4. **Volatility-aware query checking** (§3.4): a query that would run on a
   backend rejecting `volatile` calls is a **compile error pointing at the
   exact call**, with the `.local()` boundary as the explicit alternative.
5. **Queryable recognition via trait resolution**: tycheck records, for each
   method call inside a query/comprehension, whether resolution went through
   the `Queryable`/`Iterator` lang-item traits (the solver already gives us
   this); QIR lowering consumes that fact rather than re-matching names.
6. **Cardinality-lite** (not now, reserved): EdgeDB-style `One/Many`
   cardinality *inference* for projections over `[*]`-free paths is a possible
   later refinement of `Option` ergonomics (`AtMostOne → Option`, `One → T`).
   Not in the first implementation; the syntax must not foreclose it.

---

## 6. Decorators and extensibility (post-macro-ADR redesign)

### 6.1 The rule

The compiler **never** enumerates decorator vocabulary. There is no
`DecoratorKind { Table, View, … }` anywhere in the pipeline. Decorators are
syntactically generic (`@path(args)`, already parsed) and semantically
three-tiered:

### 6.2 Tier 1 — lang items (compiler semantics)

A closed, slowly-evolving set the compiler *must* know: `@lang("queryable")`,
`@lang("aggregate")`, `@lang("iterator")`, `@lang("copy")`, `@lang("seq")`,
`@lang("coll")`… (the existing `LangItem` registry mechanism, extended).
Adding one is a compiler change and a design event. Test for admission: "does
a compiler pass need to reason about this to produce correct/optimized code?"
`Queryable` passes; `table` does not.

### 6.3 Tier 2 — built-in derives (compiler intrinsics, library meaning)

Storage registration needs generated code (schema metadata, `Queryable` impl,
index descriptors). With macros gone, this is done by **built-in derives**
(the intrinsic infrastructure already exists in `yelang-hir/src/derive/`):

```yed
@derive(Table)          // built-in intrinsic, like @derive(Clone)
struct User { @primary id: Uuid, @unique email: String, age: Int }
```

`@derive(Table)` generates: the schema descriptor (from field types + the
field-level markers `@primary/@unique/@index/@default`), a `Queryable`
impl over the storage connection, and `Send`/`Share` instances as
appropriate. The field markers are **inert Tier-3 metadata** consumed by the
`Table` derive — the compiler core knows nothing about `@primary`.

`@table` as a bare attribute is deliberately *not* special: what makes a type
"storage-backed" is that it implements the `Queryable` lang-item trait,
however that impl got written (derive, hand-written impl, or later comptime).
A hand-rolled impl over a REST API is exactly as valid as the derived one.

### 6.4 Tier 3 — inert metadata + future comptime processors

`@transaction`, `@retry`, `@permission`, `@cron`, `@deprecated`… are
**metadata**: name-resolved, argument-checked as comptime constants, carried
on the item's DefId, readable by (a) the storage/runtime when it registers
the item, (b) tooling, (c) later, `comptime` attribute processors (the
comptime design doc's typed-interpreter model is the replacement for the
removed attribute-macro system — when comptime lands, Tier 3 items can opt
into code generation without any compiler change).

Transactions specifically: `@transaction` is a **runtime/library concern**
(wrapping a function body in begin/commit/rollback against a connection),
not a planner concern. The planner cares only about volatility (§3.4) and
snapshot consistency (§13.4). Do not entangle the two.

---

## 7. Value semantics and memory model

Goal recap: no GC, no borrow checker, deterministic destruction (cursors,
handles), value semantics with CoW performance. The research consensus for
exactly this target is compiler-managed precise reference counting with
uniqueness-optimized in-place mutation (Perceus for Lean/Koka; Lobster's
ownership analysis; Nim's ARC; Roc's opportunistic mutation; Swift's CoW).
Concretely for yelang:

### 7.1 Representation (invisible to users)

- **Small values inline**: primitives and heap-free structs ≤ 16 bytes are
  `Copy` (bitwise). Everything else is one heap object with a **pointer-width
  refcount word immediately before the payload** (Roc layout: one allocation,
  count never overflows).
- **Immortal literals**: string/array literals live in read-only memory with a
  sentinel refcount; no RC traffic ever (PHP interned strings / CPython
  immortalization).
- **No `Share<T>` in surface syntax.** Sharing is a representation detail.
  (This corrects the old execution doc, which exposed `Share` too eagerly.)

### 7.2 Compiler-inserted RC, and the whole game is deleting RC ops

- The MIR/codegen inserts `dup`/`drop` precisely; drops happen at **last
  use**, not scope exit (Perceus). Cost of RC ∝ number of RC ops, so:
- **Move/sink analysis** (Nim `lastReadOf`): last use of a binding moves
  instead of dup+drop. Function parameters are `sink` by default.
- **Cursor inference** (Nim): `let v = a[i]` does not copy when neither `v`
  nor `a[i]` is later mutated.
- **Ownership analysis with RC fallback** (Lobster): where the compiler proves
  a single owner, RC ops vanish entirely; where it can't, it inserts an
  increment **instead of an error** — borrow-checker performance without
  borrow-checker UX. Lobster eliminates ~95% of RC ops this way.
- **Reuse analysis** (later optimization, Perceus): pair `free` of size n with
  `alloc` of size n for in-place structure updates.

### 7.3 CoW rule (the one rule users can feel)

Every mutating operation checks **refcount == 1** (one fused "begin mutation →
uniqueness" builtin, Swift's `isKnownUniquelyReferenced` shape). Unique →
mutate in place. Shared → deep-clone the spine, then mutate. Because §3.5
forbids storable mutable references, this check can never be bypassed — there
is no PHP `is_ref` poisoning, no action at a distance. The refcount saturates
at 2 (never R's sticky 0/1/many NAMED bug, where one past share causes
spurious copies forever).

### 7.4 Threads without a borrow checker

Universal atomic refcounts cost up to 50% (Ungar, cited by Perceus). Our rule
(Pony-lite, one line): **a value may cross a thread boundary only if the
compiler proves it unique (move) or deeply immutable.** Both keep all
refcounts non-atomic. Everything else is a compile error at the `spawn`/send
site with a suggestion (`.freeze()` to make deeply immutable, or restructure
to move). No `Send`/`Sync` marker traits needed for the common path; the
auto-trait machinery exists if we later want them for FFI-ish escape hatches.

### 7.5 Cycles and destruction

- **Deterministic**: precise (non-deferred) RC — a cursor's last drop closes
  it *now*, which is exactly what query cursors, file handles, and
  transactions need. No deferred/biased reclamation on the local count.
- **Cycles**: value-semantics trees don't cycle; graphs do. Decision: cycles
  are **unconstructable through plain values** (no way to make one without an
  explicit indirection), and explicit graph structures use library-provided
  `NodeId`/arena handles (index-based, no RC) or an explicit `Weak` type.
  This is "acyclic by construction + opt-in weak", chosen *now* (Nim's ARC +
  async leaks show what retrofitting looks like).

---

## 8. The stdlib trait surface (the part users see)

This is the *entire* query-facing compiler contract. Small on purpose.

```yed
// Tier: lang items. The optimizer understands these by resolution.

@lang("iterator")
trait Iterator[T] {              // local, eager-pull, single-node
    fn next(self) -> Option[(Self, T)];   // state-passing; no storable refs (§3.5)
    // default combinators: map, filter, fold, take…  (ordinary default methods)
}
@lang("into_iter")
trait IntoIterator[T] { fn into_iter(self) -> impl Iterator[T]; }

@lang("queryable")
trait Queryable[T] {             // lazy, optimizable, backend-agnostic
    // The methods below are *default methods* over a tiny kernel.
    // The compiler recognizes calls resolved through this trait as plan nodes.
    fn filter(self, pred: fn(T) -> Bool) -> Self;
    fn map[U](self, f: fn(T) -> U) -> Queryable[U];
    fn order_by[K: Ord](self, key: fn(T) -> K) -> Seq[T];
    fn group_by[K](self, key: fn(T) -> K) -> Queryable[Group[K, T]];
    fn aggregate[A: Aggregate[T]](self, agg: A) -> A::Out;
    // no fold: arbitrary folds are local-only by design (§ iterators doc)
}

@lang("aggregate")
trait Aggregate[In] {            // UDA protocol — the ONLY aggregate hook
    type Acc;                    // serializable accumulator state
    type Out;
    fn init() -> Self::Acc;
    fn step(acc: Self::Acc, item: In) -> Self::Acc;
    fn merge(a: Self::Acc, b: Self::Acc) -> Self::Acc;   // required
    fn finish(acc: Self::Acc) -> Self::Out;
    fn class() -> AggregateClass; // the one thing the planner reads
}

enum AggregateClass { Distributive, Algebraic, Holistic }  // hardcoded: planner mechanics, not vocabulary
```

- `sum()`, `count()`, `avg()`, `min()`, `max()` are **ordinary stdlib
  structs** implementing `Aggregate` (`Sum`, `Avg{sum,count}` (algebraic:
  state ≠ output), `Count`, …) plus default-method sugar
  `q.sum() = q.aggregate(Sum)`. A user's `P95` implements the same trait and
  gets distributed execution for free. **No `AggregateKind` enum anywhere** —
  the QIR carries `AggregateOp { agg: DefId, class, input }` and calls the
  resolved impl's compiled functions. (This kills the placeholder's
  hardcoded `AggregateKind`/`WindowKind`; windows get the same treatment:
  `WindowFn` trait, planner reads only frame/partition requirements.)
- Class semantics for the planner: **Distributive** — merge partials from any
  partitioning (`count`, `sum`, `min`, `max`); **Algebraic** — like
  distributive but Acc ≠ Out and merge still works (`avg = (sum,count)`);
  **Holistic** — needs all values co-located per group (`median`, `p95` →
  planner inserts a repartition-by-key exchange before final).
- **Streams**: `Stream[T]: Queryable[T]` with `Bounded = false` (a type-level
  property, §12). Order-dependent and blocking operators are unavailable on
  unbounded sources unless windowed — enforced by trait bounds, i.e. ordinary
  type errors.
- `.iter()` does not exist (nothing to disambiguate without ownership);
  `.collect()`/`.to_seq()` are explicit terminals for forcing materialization
  or choosing a concrete collection. Query results are already typed values;
  terminals are for laziness boundaries only.

---

## 9. QIR: logical layer (rebuilding the placeholder)

Keep the placeholder's bones (operator arena, `QExpr`, `NestedShape`,
`BackendCapability` trait) and rebuild the semantics:

1. **Lowering** (`logical/lower.rs`): typed HIR → core calculus (§4.2),
   emitting `DependentJoin` for correlation and group records for `group by`.
   Consumes tycheck's trait-resolution facts (§5.5) instead of name-matching.
2. **Expression identity**: interned `QExprId`s everywhere; columns/bindings
   carry unique ids with names only as debug metadata (DataFusion lesson).
3. **Properties as first-class**: every logical operator carries/propagates
   *logical properties* — cardinality class, **boundedness** (bounded /
   unbounded), keys/unique-ness, and the demand set (fields actually consumed
   downstream, computed from the projection per §3.2).
4. **Rewrite** (`rewrite/`): the §4.3 normalization batches + decorrelation
   (§4.4) + volatility-aware folding. Rules are pure functions
   `Operator → Option<Operator>`; batches to fixpoint; instrumented.

---

## 10. Physical planning: Cascades bones, Calcite's location trait

### 10.1 Framework

Cascades (Graefe & McKenna) — the framework every serious modern optimizer
descends from (SQL Server, Orca, CockroachDB, Calcite's VolcanoPlanner):

- **Memo** of expression groups (logically equivalent expressions share a
  group; physical plans hang off groups).
- **One rule class**: transformation rules (logical→logical) and
  implementation rules (logical→physical) interleave in a single top-down,
  goal-driven search with branch-and-bound cost pruning. No exhaustive
  pre-expansion (Volcano's documented flaw).
- **Physical properties + enforcers**: required properties (`Ordering`,
  `Partitioning`, `Location`, `Boundedness`) are satisfied by inserting
  enforcer operators (`Sort`, `Exchange`, `Gather`) via ordinary rules. This
  is how distribution enters the plan: **network transfer is just an
  enforcer** satisfying a `Location` property — Calcite's `Convention` trait,
  generalized. One algebra for in-memory/embedded/remote/distributed; *where*
  an operator runs is a physical property decided by cost + capabilities.
- **Task scheduler**: optimize-group / explore-expression / apply-rule tasks
  with cost limits; per-(expression, rule) applied-bitmap.

### 10.2 Capabilities (replacing the placeholder trait)

`BackendCapability` becomes the *planner's question set about a location*:

```rust
trait BackendCapability {
    fn supports(&self, op: &PhysOp) -> Support;         // No | Partial(plan fragment) | Full
    fn aggregate_support(&self, agg: DefId) -> AggSupport; // No | FinalOnly | Partial
    fn stats(&self, source: SourceId) -> SourceStats;   // cardinality class, zone maps, sizes
    fn exchange_kinds(&self) -> ExchangeKinds;          // shuffle? broadcast? broadcast-limit?
}
```

The memory backend answers "everything, trivially"; the embedded engine
answers per its indexes (zone maps, index lookup); a remote cluster answers
per its deployment. `aggregate_support` keys off the aggregate's *class* and
whether its accumulator functions are registered in the deployment's function
registry (§13.2) — not off an enum.

### 10.3 Cost and join ordering

- **Cardinality estimation first** (P8): table samples + zone-map statistics +
  per-column distinct estimates; independence-assumption damping as predicate
  count grows (JOB finding: errors compound exponentially; engines
  systematically underestimate).
- **Join order: DPccp** (connected-subgraph/complement enumeration, optimal
  bushy trees without cross products) up to ~12 joins, then greedy (GOO)
  fallback. Hash-join-centric physical design; nested-loop only with proven
  unique-key inner lookups. Runtime insurance: min/max filters observed on
  hash-join build sides pushed to probe-side scans (DuckDB's dynamic-filter
  trick — 10× on real workloads, cheap to build).
- **Cost model: deliberately simple** (tuple-count-driven with per-operator
  weights). JOB: cost-model sophistication on top of bad cardinalities buys
  nothing.

---

## 11. Execution engine

### 11.1 One operator model: push-based, batch-granular

- **Push, not pull.** Sources `produce` batches; operators `consume(batch)`;
  pipeline-breakers materialize. Modern consensus (DuckDB, Snowflake,
  ClickHouse, Velox): push over batches simplifies parallelism, backpressure,
  and pipeline scheduling; Volcano-style tuple-at-a-time pull pays a virtual
  call per tuple and fights batching/SIMD.
- **The batch is the universal data unit**: columnar, ~1–4K values, **Arrow
  layout**. Same representation in-memory, on disk pages, and on the wire
  (Arrow IPC zero-copy; Flight for transport later). No custom wire format —
  that forfeits ecosystem interop for nothing.
- **Interpreted vectorized everywhere; codegen later.** Vectorized
  interpretation is the universal path (Kersten et al.: vectorized pull even
  *wins* on hash probing; compiled push wins on compute-heavy expression
  trees). A later JIT fuses hot *expression kernels* only (Umbra's flying
  start/adaptive execution: interpret first, compile morsel-granular hot
  paths mid-query). Do not build an LLVM query compiler as the only path —
  compile latency kills interactive queries.

### 11.2 Parallelism: morsels, not plan-baked DoP

Morsel-driven scheduling (Leis et al. 2014): the work unit is
(pipeline × small data fragment ~100K values); a dispatcher hands morsels to
pinned workers, NUMA-local first, work-stealing. Degree of parallelism is
**elastic at runtime** — resilient to skew and stragglers, identical binary
for 1 core or 64. The morsel maps cleanly to a shard-range remotely and a
row-group locally: one abstraction, every scale.

### 11.3 Exchanges and flow control

`Exchange` is a first-class physical operator in three flavors: **local**
(repipeline within a node), **shuffle** (hash/range repartition across
nodes), **broadcast** (with a hard size cap from stats). Every exchange edge
runs **credit-based flow control** (Flink's model: receiver grants buffer
credits, sender transmits only against credits) — backpressure then falls out
of the same mechanism for streaming, remote I/O, and cross-shard execution.
Pipelined (non-materializing) exchanges by default; materializing exchanges
only where recovery or sorting requires them (Spark's everything-blocks
shuffle is the latency anti-pattern).

### 11.4 Memory: governed from day one

- Hierarchical memory pools (query → pipeline → operator), quantized
  reservations, a cross-query **arbitrator** that pauses tasks and forces
  spillable operators to spill (Velox's design).
- Every blocking operator implements `spill()` with **radix-partitioned**
  state: only partitions that don't fit spill — graceful degradation, no
  all-or-nothing cliffs (DuckDB's out-of-core hash join/agg/sort).
- Query results are **arena/region-allocated** and freed as one region when
  the result is consumed — composes with §7's RC world because result regions
  are single-owner by construction.

### 11.5 Operators inventory (v1)

Scan (memory/embedded/remote), Filter, Project (fused expression kernels),
HashJoin (partitioned, spillable, build-side bloom+min/max), MergeJoin,
NestedLoopJoin (unique-inner only), HashAggregate (partial/final pairs,
spillable), Sort (spillable, bounded TopK variant), Window (later), Union/
Concat, Distinct, Exchange (local/shuffle/broadcast), Values, Limit/Slice
(Seq only), TraversalExpand (edge-index driven, §13.3), and the streaming
operators of §12 when streams land.

---

## 12. Streaming: one engine, boundedness as a property

Batch is a bounded stream. Concretely:

- `Boundedness` is a **logical property** (§9.3) and a **physical property**
  (§10.1) from day one. Sources declare it (`Seq`/`Coll` bounded; `Stream`
  unbounded). Operators declare what they do with it: `Filter`/`Map` are
  transparent; `Aggregate`/`Sort`/`Distinct` are *blocking* on unbounded
  input — a compile error unless the stream is **windowed**.
- **Windowing is a query-language concept**, Beam-style: event time with
  watermarks, triggers, and accumulation modes (discarding/accumulating/
  retracting). Syntax TBD but reserved; semantics designed before
  implementation (retrofitting event time creates a second engine — the
  Lambda trap).
- **Execution**: the push-based batch graph *is* the streaming dataflow;
  batches on unbounded edges are deltas. Window operators are ordinary
  stateful operators with watermark-driven firing. State goes through the
  same spilling/pools machinery.
- **Event bus** is a `Stream` source backend (§13), capability-flagged
  (no random access, no stats → planner keeps stateful ops local, pushes
  only stateless filters/projects toward it).
- **Incremental view maintenance / differential computation** (Materialize,
  DBSP): adopt the *(data, time, ±diff)* batch representation as a later,
  compatible upgrade — our batches already carry counts; what we do *not*
  adopt lightly is Naiad's full cyclic progress-tracking protocol. v1
  streams are non-incremental windowed computation; continuous
  self-maintaining queries are v2.

---

## 13. Backends and distribution

### 13.1 The backend matrix (one algebra, four+ locations)

| Backend | Source type | Capabilities | Planner behavior |
|---|---|---|---|
| In-memory (`Seq`/`Coll` values) | local collections | everything | full operator set, morsel-parallel |
| Embedded storage engine (ours) | `Coll` + indexes | filter/project/order/limit pushdown, zone maps, index lookup | push to storage; local exchange only |
| Remote cluster (ours) | `Coll` sharded | partial aggregates, exchanges, plan-fragment execution | fragment splits at exchanges; partial/final aggregate pairs |
| Event bus | `Stream` | stateless pushdown only | windowed ops local; filters/projects toward source |
| Object storage (later) | `Coll` over files | scan + filter/project, zone maps per file | file pruning, late materialization |

New backends implement `BackendCapability` + a plan-fragment executor. The
compiler core never changes.

### 13.2 Ship fragments, not code

- Remote execution ships a **versioned binary plan-fragment format**: our own
  schema (not Substrait — it covers logical plans only and physical ops don't
  standardize; see the UPlan critique), Substrait-*inspired* in one respect:
  a **function registry** where every function/aggregate callable in a
  fragment is URI-anchored and semantics-versioned.
- Shards pre-deploy the closed operator set + registered functions. A query
  referencing an unregistered function/aggregate **cannot run remotely** —
  discovered at plan time, reported as a compile/planning error naming the
  function (P5), with automatic fallback to executing that fragment locally
  over an exchange (explicit, costed — never silent).
- Aggregates: `Distributive`/`Algebraic` → `PartialAggregate` per shard +
  `Exchange(repartition by key)` + `FinalAggregate`; accumulators serialize
  as Arrow batches. `Holistic` → repartition first, then full aggregation.

### 13.3 Graph traversals (`links`)

`links` paths lower to joins against the **edge index** (adjacency
structures maintained by the storage engine, a graph-index capability on the
backend). Bounded traversals (`hops 1..=3`) = repeated joins with a
depth counter; variable-length = a fixpoint operator (v2, with cycle
detection semantics pinned then). Nothing about this is a separate "graph
language" — it's the same algebra with one more index type, which is exactly
how EdgeDB/Gel compiles its paths to relational plans.

### 13.4 Snapshots, transactions, consistency

- Every query executes against a **snapshot** (MVCC in the storage engine);
  the query's `stable` functions (§3.4) pin to that snapshot. Long analytics
  never block writers.
- Writes (`create/update/upsert/delete/link/unlink`) are statement-level
  transactions; `@transaction` (Tier-3, §6.4) composes them at the library
  level. Distributed writes: two-phase commit lives in the storage engine,
  not the query layer. The query layer's only consistency contract: a query
  sees one snapshot, and elided sources (§3.2) take none.

---

## 14. Correctness and testing strategy

The optimizer is only allowed to be clever because it's checkable:

1. **Reference executor**: a deliberately dumb, obviously-correct in-memory
   interpreter over the logical plan (no rewrites). ~1–2k lines, written
   first.
2. **Differential/property testing**: random query generator over random
   schemas+data; reference vs optimized vs (later) distributed results must
   agree *as bags* (or as sequences where `Seq` semantics require order).
   This is SQLancer's "NoREC/TLP" idea adapted to a comprehension core.
3. **Invariant suites as executable contracts**: projection-determines-shape
   (`select 1 …` ≡ `1`), elision (dead sources unread), Option propagation,
   unorderedness honesty (no test may depend on unrequested order — enforced
   by a test-mode flag that shuffles all `Coll` batches between operators).
4. **Rule-level tests**: every rewrite rule gets before/after golden plans
   (the per-rule dump from §4.3 doubles as the test harness).
5. **Benchmarks**: TPC-H-derived suite once the algebra is complete; JOB once
   joins/stats mature; streaming: Nexmark when windows land.
6. **Logic tests**: sqllogictest-style files per surface feature, run against
   every backend that reaches parity.

---

## 15. Roadmap (mapped to crates)

**Phase 0 — semantic groundwork** (tycheck, ty): `Seq`/`Coll` split, `Option`
in queries, volatility declarations + enforcement, query-typed-by-projection
formalization, group-record scoping. *Deliverable: the type system tells the
truth about queries.* No QIR yet.

**Phase 1 — in-memory end-to-end** (qir): logical lowering of the full
comprehension core, normalization batches, reference executor + vectorized
push executor over `Seq`/`Coll`, group-by/aggregates via the `Aggregate`
trait (classes live, exchanges trivial), differential testing harness.
*Deliverable: queries over in-memory collections run through the real
pipeline; hardcoded `AggregateKind`/`WindowKind` deleted.*

**Phase 2 — embedded storage** (new crate `yelang-store` + qir): storage
engine v1 (columnar pages, zone maps, MVCC snapshots, edge index),
pushdown rules, morsel scheduler, memory pools + spilling hash agg/join/sort.
*Deliverable: real tables, real indexes, graceful OOM.*

**Phase 3 — remote** (qir + transport): fragment format + function registry,
exchanges with credit-based flow control, partial/final aggregates, Arrow IPC.
*Deliverable: one query, many nodes, backpressure-correct.*

**Phase 4 — distributed planning maturity**: Cascades memo (replacing the
Phase 1–3 heuristic pipeline), DPccp, statistics collection, dynamic filters.
*Deliverable: the optimizer earns its name.*

**Phase 5 — streaming** (qir + event-bus backend): boundedness end-to-end
(already threaded through since Phase 0), windows/watermarks/triggers,
stateful operators. *Deliverable: batch and stream share the engine.*

**Phase 6 — adaptive execution**: morsel-granular JIT of expression kernels,
adaptive re-optimization mid-query (Umbra), differential/incremental views
evaluation. *Deliverable: fast stays fast.*

Ordering rationale: semantics before execution (Phase 0) because every later
phase reads type-level facts; reference executor before optimization because
correctness needs an anchor; Cascades *after* remote works because you cannot
cost what you cannot run.

---

## 16. Decision register

| # | Decision | Alternatives rejected | Diverges from old notes? |
|---|---|---|---|
| D1 | `Seq[T]` (ordered) vs `Coll[T]` (bag) as distinct types | "everything ordered" (kills parallelism), SQL-style untyped unorderedness (footguns) | New — pins what notes left vague |
| D2 | Projection alone types the query; demand-driven elision | pipeline-shaped results (SQL) | No — confirms semantics.md §0.1, adds elision corollary |
| D3 | No NULL; `Option` everywhere; per-aggregate empty-input defaults | SQL 3VL; PartiQL NULL+MISSING; EdgeDB empty-set | **Yes** — removes `QLit::Null` |
| D4 | Volatility tri-state (`pure`/`stable`/`volatile`) on fns, enforced | full effect system (too big), no contract (no fold/pushdown legality) | **Yes** — notes assumed "deterministic" vibes, no mechanism |
| D5 | No `DecoratorKind`/`ProjKind`/`AggregateKind` enums; lang items + built-in derives + resolution | hardcoded kind enums (placeholder did this) | **Yes** — placeholder QIR superseded |
| D6 | Storage-backed = implements `Queryable`; `@derive(Table)` intrinsic; field markers are inert metadata | attribute macros (removed by ADR), `@table` magic | **Yes** — redesigned for post-macro reality; comptime processors later |
| D7 | Comprehension calculus core + normalization (Wong/Quill architecture) | ad-hoc clause-by-clause lowering | Mostly no — PHASEH already went this way; now it's policy |
| D8 | Dependent-join decorrelation (Neumann–Kemper) | magic sets, per-shape heuristics | No — placeholder had the variant; now it's the algorithm |
| D9 | Value semantics + compiler-managed precise RC + CoW uniqueness check; no storable mutable refs | GC; borrow checker; `Share<T>` in surface syntax; PHP-style `&` | Refines old `Share<T>` doc — sharing invisible |
| D10 | Threads: values cross only if provably unique or deeply immutable; non-atomic RC | atomic-everything (30–50% cost), Send/Sync markers everywhere | New |
| D11 | Cycles unconstructable via plain values; `Weak`/arena handles opt-in | trial-deletion GC (ORC), leak-them | New — decided now to avoid Nim's retrofit |
| D12 | Push-based batch execution, Arrow layout, interpreted-vectorized first, JIT kernels later | Volcano pull; compile-everything (HyPer) | Sharpens old exec doc |
| D13 | Morsel-driven parallelism, elastic DoP | plan-baked parallelism | New |
| D14 | Exchanges first-class (local/shuffle/broadcast) + credit-based flow control | Spark-style blocking shuffle; TCP-only backpressure | New |
| D15 | Ship versioned plan fragments + function registry; never closures | Substrait wholesale (logical-only); Spark closures | Refines old exec doc |
| D16 | Streams = unbounded `Queryable`; Beam windowing semantics; blocking ops need windows | separate streaming engine; bolt-on event time | Sharpens vague notes |
| D17 | Cascades optimizer (Phase 4); DPccp; stats-first, simple cost model | Volcano; rule-soup pipelines; fancy cost models | New |
| D18 | Group-by produces group records; `having` = filter on groups | SQL HAVING clause | No — confirms pipelining.md §7 |
| D19 | `links` = joins over edge index; no separate graph language | dedicated graph IR | Sharpens notes |
| D20 | Transactions/snapshots in storage engine; query layer sees exactly one snapshot | planner-level transaction semantics | Clarifies decorators-transactions.md |
| D21 | No AST-level query desugaring; recognition at tycheck/QIR by resolved identity | AST rewrites pre-resolution (`desugar.rs`) | **Yes** — deletes the aggregate desugar pass |
| D22 | `Queryable` on query-source handles (`Table`, `Stream`, `Querying<[T]>` adapter), never on raw `[T]`; `[T]` uses `Iterator` | `impl Queryable for [T]` (LINQ's blurry seam) | **Yes** — current stdlib corrected |
| D23 | Kernel trait methods carry their own lang items (`@lang("query_filter")`); sugar methods are ordinary default methods inlined at lowering | name-matched method tables; `QueryableMethod::{Sum,Avg,…}` variants | **Yes** — `stdlib.rs`/`queryable.rs` reworked |
| D24 | Projection scope = root labels only; element binders are element-context-only; `select u` is a compile error suggesting `users[*]` | SQL-style row-variable projection scope | **Yes** — fixes a live tycheck scoping bug |
| D25 | Synthetic items allocated in the definitions arena (one uniform DefId space); derive helpers take generics/attrs | fabricated out-of-arena DefIds | **Yes** — fixes derive fragility |
| D26 | Aggregate closures extracted from type-checked stdlib impl bodies; class const-evaluated from `class()`; no compiler-built aggregates | hand-built QExpr closures per aggregate (`aggregate_impl.rs`), name fallbacks | **Yes** — `aggregate_impl.rs` deleted |
| D27 | Decorrelation = BTW'25 single-pass top-down (union-find substitution, per-group TopN, window/FOJ/recursive coverage) | NK'15 repeated bottom-up; ad-hoc per-shape unnesting | Sharpens D8 with the current state of the art |

Phase J concrete structures, algorithms, and file tree:
`notes/docs/PHASEJ_QIR_STRUCTURE_DESIGN.md` + `PHASEJ_QIR_CHECKLIST.md`.

---

## 17. Key references

Foundations: Wong, *Querying Nested Collections* (Kleisli thesis); Libkin &
Wong, *Query Languages for Bags and Aggregate Functions* (JCSS'97); Cheney,
Lindley, Wadler, *The Essence of Language-Integrated Query*; *Query
Shredding* (SIGMOD'14, arXiv:1404.7078); Cooper, *The Script-Writer's Dream*
(DBPL'09); Fegaras & Maier, *Optimizing Object Queries Using an Effective
Calculus*.

Optimizers: Graefe, *The Cascades Framework for Query Optimization*; Begani
et al., *Apache Calcite* (SIGMOD'18, arXiv:1802.10233); Armbrust et al.,
*Spark SQL/Catalyst*; Neumann & Kemper, *Unnesting Arbitrary Queries*
(BTW'15); Galindo-Legaria & Joshi, *Orthogonal Optimization of Subqueries*
(SIGMOD'01); Moerkotte & Neumann, *Dynamic Programming Strikes Back*
(DPccp); Leis et al., *How Good Are Query Optimizers, Really?* (JOB,
VLDB'15); Ramachandra et al., *Froid* (VLDB'17).

Execution: Neumann, *Efficiently Compiling Efficient Query Plans* (VLDB'11);
Kersten et al., *Compiled and Vectorized Queries* (VLDB'18); Leis et al.,
*Morsel-Driven Parallelism* (SIGMOD'14); Boncz et al., *MonetDB/X100*;
Akidau et al., *The Dataflow Model* (VLDB'15); Flink credit-based flow
control docs; Velox memory-management docs; DuckDB out-of-core release notes;
Apache Arrow columnar/IPC spec; Budiu et al., *DBSP* (VLDB'22).

Memory models: Reinking et al., *Perceus: Garbage Free Reference Counting
with Reuse*; Swift CoW/`isKnownUniquelyReferenced` internals; Nim ARC/ORC
docs; Lobster memory-management docs; Roc builtins docs; Hylo language;
Choi et al., *Biased Reference Counting* (PACT'18, via CPython PEP 703);
*Advanced R*, names-and-values chapter (the NAMED cautionary tale);
PHP internals book, zval separation.

Semantics of others: Ong et al., *SQL++* (arXiv:1405.3631); *PartiQL
Specification*; EdgeDB/Gel docs + *EdgeQL formal semantics*
(arXiv:2507.16089); EF Core client-evaluation docs (the cautionary tale);
Meijer, *The World According to LINQ*.
