# Yelang Compile-Time Evaluation (`comptime`) — Design Document

**Status:** design approved for implementation.  
**Scope:** compile-time execution of Yelang code, complementing (not replacing) the
existing macro system.  
**Depends on:** HIR lowering (complete), name resolution (complete), and the
in-progress type checker (`yelang-tycheck`).

This document is based on Zig’s `comptime` semantics, Rust’s Miri const evaluator,
D’s compile-time function execution (CTFE), Nim’s compile-time evaluation, and
staged-metaprogramming research. Because Yelang is greenfield, we adopt the best
known design immediately rather than accumulating legacy workarounds.

---

## 1. Executive summary

`comptime` lets the programmer run ordinary Yelang code at compile time. It is
**not** a macro system: it does not transform token streams. Instead, it evaluates
typed code and splices the result back into the compilation unit.

We keep the existing declarative and procedural macro systems because they excel
at syntax extension. `comptime` excels at typed metaprogramming: generics,
reflection, compile-time lookup tables, and zero-cost abstractions.

Key decisions:

- `comptime { ... }` blocks evaluate expressions at compile time.
- `comptime fn` marks functions executable at compile time.
- The comptime evaluator is a **typed interpreter over HIR** (later optionally a
dedicated `CIR`).
- Comptime code is subject to the **same type system** as runtime code.
- Comptime code has **no host leakage**: it cannot observe the machine the
compiler runs on, only the compilation target.
- Comptime code is **sandboxed**: no I/O, no networking, no environment variables,
no unsafe operations that would require runtime resources.
- Branch quotas and memory limits prevent runaway compile-time evaluation.

---

## 2. Why both macros and comptime?

| Capability | Macros (`macro`, proc macro) | `comptime` |
|---|---|---|
| Add new surface syntax | yes | no |
| Transform token streams | yes | no |
| Operate on typed AST/HIR | no | yes |
| Return types and generic parameters | limited | yes |
| Reflection over fields/variants | awkward | natural |
| Compile-time lookup tables | possible | natural |
| Hygienic name generation | yes | N/A (uses normal names) |
| Debug with `print` at compile time | panic/diagnostic only | `@compileLog` |
| Separate compilation unit for proc macros | required | not required |

A language with only macros forces authors to parse and type-check by hand (the
`syn` problem in Rust). A language with only comptime cannot extend syntax. The
two systems are complementary, with a clear phase separation:

1. **Macros expand first.** They turn tokens into tokens, then the parser produces
   AST.
2. **AST lowers to HIR.**
3. **Type collection** gathers item signatures.
4. **Comptime evaluation** runs during body type checking. Comptime-known values
   are evaluated; the rest become runtime code.
5. **Runtime code generation** proceeds normally.

[Zig’s comptime](https://marcelgarus.dev/comptime) is “just Zig code that runs at
compile time.” [Rust’s macros](https://lobste.rs/s/r1hu2x/crabtime_zig_s_comptime_rust),
by contrast, are “a second language inside a language.” Yelang gives users both
first-class tools.

---

## 3. Design principles

1. **Same language, same types.** Comptime code is parsed, lowered, and type-checked
   by the same pipeline as runtime code. There is no separate “comptime language.”
2. **No host leakage.** Comptime execution must be deterministic and target-independent.
   `usize` in comptime means the target’s `usize`, not the host compiler’s. This
   follows [Zig’s principle](https://matklad.github.io/2025/04/19/things-zig-comptime-wont-do.html).
3. **Sand-boxed by default.** Comptime code cannot perform I/O, spawn processes,
   access the network, or read environment variables.
4. **Explicit opt-in.** A block or function is only evaluated at compile time if
   marked `comptime` or required by a const context (array length, const generic).
5. **Composable with macros.** A macro can emit a `comptime { ... }` block; a
   comptime block can call macros because macro expansion happens first.
6. **Inspectable results.** `@compileLog(expr)` prints the value and type of `expr`
   during compilation without failing, mirroring Zig’s debugging aid.
7. **Resource limits.** Branch quota, recursion depth, memory, and wall-clock time
   limits prevent compile-time runaway.
8. **SlotMap-style IDs.** Interpreter frames, allocations, and memoization keys use
   slotmap newtypes, consistent with the rest of the compiler.
9. **No `util` modules; `lib.rs`/`mod.rs` are routers.** Implementation lives in
   named submodules.

---

## 4. Syntax

### 4.1 `comptime { ... }` block

Evaluates a block at compile time. The result replaces the block expression.

```yed
const TABLE: [u8; 256] = comptime {
    let mut t = [0u8; 256];
    for i in 0..256 {
        t[i] = i as u8;
    }
    t
};
```

A `comptime` block can appear anywhere a constant expression is expected:

- initializer of `const` / `static`
- array length: `[T; comptime { ... }]`
- const generic argument: `Vector<T, comptime { ... }>`
- enum discriminant
- default value of a struct field or const parameter

### 4.2 `comptime fn`

Marks a function as callable at compile time. The body is type-checked with the
same rules as a normal function, plus comptime restrictions.

```yed
comptime fn fib(n: u32) -> u32 {
    if n < 2 { n } else { fib(n - 1) + fib(n - 2) }
}

const FIB_10: u32 = fib(10);
```

A `comptime fn` can also be called at runtime if its signature and body satisfy
runtime restrictions. This is the default in Zig and avoids unnecessary
specialization.

### 4.3 `@comptime` item attribute

Existing attribute syntax for items whose initializer should be evaluated at
compile time:

```yed
@comptime
const LOOKUP: [u8; 256] = build_lookup();
```

Semantically equivalent to wrapping the initializer in `comptime { ... }`. It is
provided for consistency with Yelang’s attribute-heavy style.

### 4.4 `comptime` parameter modifier (future)

```yed
fn make_array(comptime n: usize, value: i32) -> [i32; n] {
    [value; n]
}
```

`comptime n` means the parameter must be a compile-time-known value. The return
type can depend on it. This subsumes much of Rust’s const generics and Zig’s
`comptime T: type` parameter pattern.

### 4.5 `@compileLog`

A built-in compile-time-only function for debugging:

```yed
comptime {
    @compileLog(fib(10));
}
```

Prints the value and type during compilation and continues. Does not affect the
compiled output. Must only appear inside comptime contexts.

### 4.6 `comptime type` / `comptime val` (future extension)

For type-level computation:

```yed
comptime type VecN(n: usize) = Array<f32, n>;
let v: VecN(3) = [0.0, 0.0, 0.0];
```

Deferred until the core expression-level comptime is solid.

---

## 5. Semantics

### 5.1 Comptime-known vs runtime

A value is **comptime-known** if it can be reduced to a `ConstValue` by the
interpreter. Examples:

- literals
- results of `comptime { ... }` blocks
- calls to `comptime fn` with comptime-known arguments
- const parameters
- fields/indices of comptime-known aggregates

A value is **runtime** if it depends on:

- function parameters (unless marked `comptime`)
- mutable state that survives to runtime
- I/O or environment
- randomness

The type checker tracks comptime-knownness as a lattice:

```text
Unknown
  |
MaybeComptime
  |
ComptimeKnown(ConstValue)
```

When a `comptime` context requires a value, the type checker invokes the
interpreter. If the value cannot be made comptime-known, it reports an error.

### 5.2 Const contexts

The following contexts implicitly require comptime-known values:

- `const` / `static` initializers
- array lengths
- const generic arguments
- enum discriminants
- bit widths of integer types (if we add dependent integers)
- `comptime { ... }` blocks themselves

### 5.3 Type checking comptime code

Comptime code is type-checked before evaluation. This means:

- Type errors in comptime blocks are reported like any other type errors.
- The interpreter never sees ill-typed code.
- Generic functions called at comptime are monomorphized by the type checker
  before interpretation begins.

### 5.4 Reflection

Comptime code can inspect types via a built-in reflection API:

```yed
comptime fn has_field<T>(name: &str) -> bool {
    for field in @typeInfo(T).struct_fields {
        if field.name == name { return true; }
    }
    false
}
```

The `@typeInfo(T)` builtin returns a comptime-known struct describing `T`. The
exact shape is defined in `yelang-comptime/src/reflect.rs`.

### 5.5 Code generation from comptime

A `comptime fn` can return a type; that type can be used in declarations:

```yed
comptime fn Pair(T: type) -> type {
    struct { first: T, second: T }
}

let p: Pair(i32) = { first: 1, second: 2 };
```

When a comptime function returns a type, the compiler materializes the type
into the type system and lowers any generated items into the crate.

---

## 6. Compiler pipeline integration

```text
Source
  │
  ▼
Tokenize ──► Parse ──► AST
  │
  ▼
Macro expansion (declarative + procedural)
  │
  ▼
Name resolution (early + late)
  │
  ▼
Lower to HIR
  │
  ▼
Type collection (item signatures)
  │
  ▼
Comptime evaluation  <── yelang-comptime
  │    - interprets HIR bodies
  │    - resolves comptime-known values
  │    - splices ConstValue / generated types back
  ▼
Body type checking
  │
  ▼
Trait solving + monomorphization
  │
  ▼
Code generation
```

### 6.1 Where comptime runs

Comptime evaluation is a **query** invoked by the type checker:

```rust
// Pseudo-signature
typeck.comptime_evaluate(hir_id: HirId, expected_ty: Ty<'_>) -> ConstValue;
```

The evaluator receives:

- the HIR expression to evaluate,
- the expected type (already known from type checking),
- the current generic substitution,
- the lexical environment (visible names, const params).

It returns a `ConstValue` or an evaluation error.

### 6.2 Interaction with generics

When a generic function is instantiated with concrete arguments, the type
checker evaluates any comptime expressions that depend on those arguments. The
result is memoized by `(DefId, GenericArgs)` to avoid duplicate work.

### 6.3 Splicing results back

- For **value results**, the HIR expression is replaced with a `Const` node
  carrying the `ConstValue`.
- For **type results**, the type is interned and substituted in the type system.
- For **generated items** (structs, functions emitted by comptime), the items are
  added to the crate with synthetic names and DefIds.

---

## 7. Interpreter architecture

The comptime interpreter lives in `yelang-comptime`. It is a tree-walking
interpreter over HIR (or a future dedicated `CIR`).

### 7.1 Core components

| Module | Responsibility |
|---|---|
| `interpreter.rs` | Main evaluation loop over HIR expressions. |
| `value.rs` | Runtime values during interpretation (`ConstValue` + heap allocations). |
| `memory.rs` | Heap, stack frames, allocation IDs, pointer arithmetic. |
| `environment.rs` | Lexical scopes, variable bindings, const parameters. |
| `resolve.rs` | Resolving paths to comptime-known definitions. |
| `reflect.rs` | `@typeInfo`, `@typeName`, and other reflection builtins. |
| `emit.rs` | Splicing comptime results back into HIR/types. |
| `limit.rs` | Branch quota, recursion depth, memory, and time budgets. |
| `error.rs` | Evaluation errors with spans. |

### 7.2 Values

```rust
pub enum CtValue<'tcx> {
    Const(ConstValue),
    /// Heap-allocated value (array, struct, string, etc.)
    Alloc(AllocId),
    /// A type value used by comptime-type functions.
    Type(Ty<'tcx>),
    /// A function item that can be called at comptime.
    Fn(DefId, GenericArgsRef<'tcx>),
    /// Error sentinel.
    Error,
}
```

### 7.3 Memory model

Comptime memory is isolated from runtime memory. It uses a simple bump allocator
with `AllocId` handles. Pointers carry an alloc ID and offset. The interpreter
validates bounds and prevents use-after-free.

### 7.4 Supported operations

Initial support:

- all literals
- arithmetic and bitwise ops on primitives
- comparisons
- field access on structs/tuples
- array/slice indexing
- control flow (`if`, `match`, `loop`, `break`, `continue`, `return`)
- local variables and assignment
- function calls to `comptime fn`
- const parameters
- `@typeInfo`, `@typeName`, `@compileLog`, `@setEvalBranchQuota`

Explicitly disallowed:

- I/O of any kind
- environment access
- networking
- spawning threads/processes
- raw pointer casts that leak host addresses
- reading from files unless via a future build-system-provided API
- unsafe operations that require runtime resources

### 7.5 Limits

```rust
pub struct EvalLimits {
    /// Maximum number of backward branches (loops, recursion).
    pub branch_quota: u64,
    /// Maximum call-stack depth.
    pub recursion_depth: u64,
    /// Maximum comptime heap bytes.
    pub heap_bytes: u64,
    /// Maximum wall-clock seconds for a single evaluation.
    pub time_seconds: u64,
}
```

Default: `branch_quota = 1_000_000`, `recursion_depth = 1_000`,
`heap_bytes = 64 * 1024 * 1024`, `time_seconds = 10`.

Users can raise the branch quota with `@setEvalBranchQuota(n)`.

### 7.6 Memoization

Comptime function calls are memoized by `(DefId, GenericArgs, argument
ConstValues)`. This is essential for generic monomorphization performance and for
avoiding exponential blow-up in recursive comptime functions.

---

## 8. Exhaustive file tree

```text
crates/compiler/
├── yelang-comptime/                       # NEW crate
│   ├── Cargo.toml
│   └── src/
│       ├── lib.rs                         # re-exports only
│       ├── interpreter.rs                 # main HIR evaluation loop
│       ├── value.rs                       # CtValue, ConstValue conversions
│       ├── memory.rs                      # heap, stack, AllocId
│       ├── environment.rs                 # lexical scopes and bindings
│       ├── resolve.rs                     # path -> comptime definition
│       ├── reflect.rs                     # @typeInfo, @typeName builtins
│       ├── emit.rs                        # splice results back into HIR/types
│       ├── limit.rs                       # EvalLimits, quota tracking
│       ├── error.rs                       # EvalError with span
│       └── query.rs                       # compiler query glue
│
├── yelang-hir/                            # EXTENDED
│   └── src/
│       ├── hir_expr.rs                    # + ExprKind::Comptime { .. }
│       └── hir_item.rs                    # + ItemKind::ComptimeFn
│
├── yelang-ast/                            # EXTENDED
│   └── src/
│       ├── expr/...                       # + ExprKind::ComptimeBlock
│       └── item/...                       # + ItemKind::ComptimeFn
│
├── yelang-tycheck/                        # EXTENDED
│   └── src/
│       ├── check.rs                       # invoke comptime evaluator
│       └── comptime.rs                    # type checking comptime contexts
│
├── yelang-ty/                             # EXTENDED
│   └── src/
│       └── ty.rs                          # ConstValue already exists; add
│                                          #   comptime-known tracking if needed
│
└── yelang-macro/                          # UNCHANGED for this phase
    └── ...
```

No new crates beyond `yelang-comptime` are required for the core feature.

---

## 9. Public API for macro authors

Comptime does not change the proc-macro API. However, proc macros can generate
`comptime { ... }` blocks, and comptime code can invoke built-in macros such as
`@compileLog`.

Future extension: a proc macro could request comptime evaluation of a token
stream via a backcall to the compiler. This is **not** in scope for the initial
implementation; the protocol leaves room for it.

---

## 10. Examples

### 10.1 Compile-time lookup table

```yed
comptime fn build_crc_table() -> [u32; 256] {
    let mut table = [0u32; 256];
    for i in 0..256 {
        let mut c = i as u32;
        for _ in 0..8 {
            if c & 1 != 0 {
                c = 0xEDB88320 ^ (c >> 1);
            } else {
                c >>= 1;
            }
        }
        table[i] = c;
    }
    table
}

const CRC_TABLE: [u32; 256] = build_crc_table();
```

### 10.2 Reflection-based derived behavior

```yed
comptime fn derive_clone(T: type) -> type {
    // @typeInfo(T) is comptime-known.
    let info = @typeInfo(T);
    if info.kind != .Struct { @compileError("expected struct"); }

    // Generate an impl block at compile time.
    // The exact syntax for emitting items from comptime is TBD; this shows intent.
}
```

### 10.3 Type-safe state machine

```yed
comptime fn state_machine(states: &[&str]) -> type {
    // Validates state names and emits an enum + transition table.
}

type Door = state_machine(&["Open", "Closed", "Locked"]);
```

### 10.4 Array length from comptime computation

```yed
const N: usize = comptime {
    let mut x = 1;
    for i in 1..=10 { x *= i; }
    x
};

let arr: [i32; N] = [0; N];
```

---

## 11. Adversarial considerations

| Attack / failure | Behaviour |
|---|---|
| Infinite loop at compile time | Branch quota / time budget exceeded → compile error. |
| Exponential comptime blow-up | Memoization of `(DefId, args)` calls. |
| Host information leak (e.g., `std::env::var`) | Operation is not in the comptime capability set → compile error. |
| Reading arbitrary files | Not allowed unless via an explicit build-system API. |
| Pointer escape to runtime | Comptime allocations are not runtime-accessible; splicing validates this. |
| `usize` confusion on cross-compile | Comptime `usize` is the target’s `usize`, not the host’s. |
| Use-after-free in comptime heap | Bounds-checked interpreter memory; deterministic error. |
| Macro emitting malformed comptime block | Caught by parser/type checker, not the interpreter. |

---

## 12. Relationship to Rust const eval and Zig comptime

- **Rust const eval** operates on MIR via Miri. It is powerful but separate from
  the macro system and cannot return types or generate code. Yelang’s comptime
  is designed to subsume that role and go further (type generation, reflection).
- **Zig comptime** is implemented as a ZIR interpreter inside `Sema`. Yelang
  currently lacks ZIR; we interpret HIR directly to reduce implementation cost.
  If performance becomes a bottleneck, we can lower HIR to a dedicated
  `ComptimeIR` (CIR) later without changing the surface syntax.
- **D CTFE** and **Nim compile-time evaluation** prove that compile-time
  execution of the full language is practical. We follow their capability model:
  most pure language features work; side-effecting operations are gated.

---

## 13. Phased implementation roadmap

### Phase A — Foundation (after type checker is usable)

- Add `comptime { ... }` AST/HIR nodes.
- Implement the interpreter loop for literals, arithmetic, and control flow.
- Evaluate simple `comptime` blocks in const contexts.
- Add branch quota and recursion limits.

### Phase B — Functions and memory

- Add `comptime fn`.
- Implement comptime heap and aggregate construction.
- Support field/index access on comptime values.
- Memoize comptime function calls.

### Phase C — Reflection and type generation

- Implement `@typeInfo`, `@typeName`.
- Allow `comptime fn` to return types.
- Splice generated types into the type system.

### Phase D — Integration and ergonomics

- `@comptime` item attribute.
- `@compileLog`.
- Better error messages with comptime stack traces.
- Interaction with generics and const generics.

---

## 14. References

- [Zig comptime overview](https://marcelgarus.dev/comptime)
- [Zig comptime implementation notes (ZIR interpreter)](https://ziggit.dev/t/implementation-of-comptime/5041)
- [Things Zig comptime won’t do](https://matklad.github.io/2025/04/19/things-zig-comptime-wont-do.html)
- [Rust Miri const evaluator](https://longfangsong.github.io/rustc-dev-guide-cn/miri.html)
- [Rust const evaluation singularity (FOSDEM)](https://archive.fosdem.org/2018/schedule/event/rust_miri_const_evaluation/)
- [Staged Metaprogramming for Shader System Development](https://escholarship.org/content/qt2f8448n2/qt2f8448n2.pdf)
- [Scala 3 scalable metaprogramming (TASTy quoting)](https://infoscience.epfl.ch/record/299370/files/EPFL_TH8257.pdf)
- [Kangrejos 2025 — Rust Declarative Macro Improvements](https://kangrejos.com/2025/Rust%20Declarative%20Macro%20Improvements:%20A%20Step%20Forward%20for%20Rust%20Macros%20Usability.pdf)
