# Macro System Phase 5 Checklist

## Goal

Implement eager expansion for built-in macros: `concat!`, `concat_bytes!`, `stringify!`, `include!`, `include_str!`, `include_bytes!`, `env!`, `option_env!`, `compile_error!`, `cfg!`.

## Research and design

- [x] Review rust-analyzer eager builtin implementation
- [x] Review Rust Reference eager expansion rules
- [x] Review `concat!`, `stringify!`, `include!` argument semantics
- [x] Write Phase 5 design doc
- [x] Write Phase 5 checklist

## Dependency-injection traits

- [x] Add `FileLoader` trait with `resolve_path`, `read_to_string`, `read_to_bytes`.
- [x] Add `EnvProvider` trait with `var`.
- [x] Provide default `StdFileLoader` and `StdEnvProvider` implementations.
- [x] Provide `MemoryFileLoader` and `MemoryEnvProvider` for tests.

## Eager builtin enum and dispatch

- [x] Add `EagerBuiltin` enum.
- [x] Implement `EagerBuiltin::from_path`.
- [x] Add `EagerContext` struct holding interner, file loader, env provider, current file, cfg options.

## Eager expansion engine

- [x] Implement `expand_eager_macros_in_stream`.
- [x] Implement recursive eager expansion inside macro argument token trees.
- [x] Implement invocation detection (`path!` followed by delimiters).
- [x] Implement cycle guard for recursive eager macros.

## Individual builtin implementations

- [x] `concat!` with string, char, int, float, bool, negative number literals.
- [x] `concat!` rejects byte-string / byte-char literals and non-literals.
- [x] `concat_bytes!` with byte, byte-string, integer, and array literals.
- [x] `stringify!` renders token tree to string literal.
- [x] `include!` reads file and returns token stream.
- [x] `include_str!` reads file as UTF-8 string literal.
- [x] `include_bytes!` reads file as byte-array literal.
- [x] `env!` returns string literal or error if unset.
- [x] `option_env!` returns `Some("value")` or `None` token stream.
- [x] `compile_error!` emits `ExpandError`.
- [x] `cfg!` evaluates cfg predicate to `true` / `false`.

## Integration with main expander

- [x] Add `EagerContext` to `MacroExpander`.
- [x] Call eager expansion before parsing captured `expr` fragments.
- [x] Call eager expansion before parsing captured `ty` fragments.
- [x] Call eager expansion before parsing captured `pat` fragments.
- [x] Call eager expansion before parsing captured `stmt` fragments.
- [x] Call eager expansion before expanding eager builtins in `expand_builtin_macro`.
- [x] Ensure recursive expansion picks up newly generated eager macros.

## Error handling

- [x] Eager builtin malformed arguments produce `ExpandError` with backtrace.
- [x] Missing file produces clear error.
- [x] Missing env var produces clear error.
- [x] Recursive include detected.

## Tests

- [x] Create `yelang-macro/tests/declarative_macros_phase5.rs`.
- [x] `concat!` basic concatenation.
- [x] `concat!` mixed literal kinds.
- [x] `concat!` empty.
- [x] `concat!` error on non-literal.
- [x] `concat!` error on byte string.
- [x] `stringify!` token tree.
- [x] `include!` file splicing.
- [x] `include!` with nested eager path.
- [x] `include_str!` file content.
- [x] `include_bytes!` file content.
- [x] `env!` deterministic test.
- [x] `option_env!` deterministic test.
- [x] `compile_error!` emits error.
- [x] `cfg!` evaluates predicates.
- [x] Nested eager expansion `include!(concat!(env!(...), ...))`.
- [x] Eager macro inside declarative macro capture.
- [x] File not found errors.
- [x] Recursive include error.
- [x] `concat_bytes!` basic and array forms.

## Verification

- [x] `cargo fmt`
- [x] `cargo test -p yelang-macro` passes
- [x] `cargo test` (workspace) passes
- [x] `cargo check` workspace clean
