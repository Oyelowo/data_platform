
# COMPLETE SYNTAX EXAMPLES
# Every construct, annotated with internal representation

---

## EXAMPLE 1: Simple Generic Function (NO HRTB)

### User Code
```rust
fn identity<T>(x: T) -> T {
    x
}
```

### Internal Representation
```
Item: FnDef {
    def_id: DefId(0, 1),          // "identity"
    generics: Generics {
        params: [
            GenericParam {
                index: 0,
                name: "T",
                kind: Ty,
            }
        ]
    },
    sig: FnSig {
        inputs: [Param(ParamTy { index: 0, name: "T" })],
        output: Param(ParamTy { index: 0, name: "T" }),
    }
}
```

### Key Points
- `T` is a **Param** (early-bound generic)
- NO `Binder` is used — early-bound params are NOT inside a binder
- The Param is substituted at call sites: `identity::<i32>(5)` replaces all `T` with `i32`

---

## EXAMPLE 2: Function Pointer with HRTB (Single Param)

### User Code
```rust
type IdentityFn = for<T> fn(T) -> T;
```

### Internal Representation
```
Type: FnPtr(
    Binder {
        bound_vars: [Ty],                    // One late-bound parameter: T
        value: FnSig {
            inputs: [
                Bound(DebruijnIndex(0), BoundVar(0))   // T = ^0_0
            ],
            output: Bound(DebruijnIndex(0), BoundVar(0)) // T = ^0_0
        }
    }
)
```

### Key Points
- `for<T>` creates a `Binder<Ty>` wrapper
- Inside the binder, `T` is represented as `Bound(DebruijnIndex(0), BoundVar(0))`
  - `DebruijnIndex(0)` = nearest binder (0 binders outward)
  - `BoundVar(0)` = 0th parameter in that binder
- This is a **type**, not a function definition. It describes the shape of a function pointer.

---

## EXAMPLE 3: Function Pointer with HRTB (Multiple Params)

### User Code
```rust
type SwapFn = for<T, U> fn(T, U) -> (U, T);
```

### Internal Representation
```
Type: FnPtr(
    Binder {
        bound_vars: [Ty, Ty],                // Two late-bound params: T, U
        value: FnSig {
            inputs: [
                Bound(DebruijnIndex(0), BoundVar(0)),   // T = ^0_0
                Bound(DebruijnIndex(0), BoundVar(1))    // U = ^0_1
            ],
            output: Tuple([
                Bound(DebruijnIndex(0), BoundVar(1)),   // U = ^0_1
                Bound(DebruijnIndex(0), BoundVar(0))   // T = ^0_0
            ])
        }
    }
)
```

### Key Points
- `BoundVar(0)` = T (first parameter in binder)
- `BoundVar(1)` = U (second parameter in binder)
- Both have `DebruijnIndex(0)` because they are in the nearest binder

---

## EXAMPLE 4: Nested HRTB

### User Code
```rust
type Nested = for<T> fn(for<U> fn(T, U) -> U) -> T;
```

### Internal Representation
```
Type: FnPtr(
    Binder {                               // Outer binder: for<T>
        bound_vars: [Ty],                   // T
        value: FnSig {
            inputs: [
                FnPtr(
                    Binder {               // Inner binder: for<U>
                        bound_vars: [Ty],  // U
                        value: FnSig {
                            inputs: [
                                // T is 1 binder outward from here
                                Bound(DebruijnIndex(1), BoundVar(0)),  // T = ^1_0
                                // U is in the nearest binder
                                Bound(DebruijnIndex(0), BoundVar(0))  // U = ^0_0
                            ],
                            output: Bound(DebruijnIndex(0), BoundVar(0)) // U = ^0_0
                        }
                    }
                )
            ],
            output: Bound(DebruijnIndex(0), BoundVar(0))  // T = ^0_0
        }
    }
)
```

### Key Points
- **Outer T**: `Bound(DebruijnIndex(0), BoundVar(0))` in outer position
  - 0 binders outward = the outer binder
- **Inner T**: `Bound(DebruijnIndex(1), BoundVar(0))` in inner position
  - 1 binder outward = skip inner binder, reach outer binder
- **Inner U**: `Bound(DebruijnIndex(0), BoundVar(0))` in inner position
  - 0 binders outward = the inner binder

### Why This Matters
Without De Bruijn indices, both T references would look the same (just "T"), and you couldn't tell which binder they belong to in the nested case.

---

## EXAMPLE 5: HRTB in Where Clause (Trait Bound)

### User Code
```rust
fn apply<F>(f: F)
where
    F: for<T> Fn(T) -> T,
{
    f(10);       // T = i32
    f("hello");  // T = String
}
```

### Internal Representation of Where Clause
```
ParamEnv {
    caller_bounds: [
        Trait(
            Binder {                               // for<T>
                bound_vars: [Ty],                 // T
                value: TraitRef {
                    def_id: FnTrait,              // std::ops::Fn
                    args: GenericArgs {
                        types: [
                            Param(ParamTy { index: 0, name: "F" }),  // F (early-bound)
                            Bound(DebruijnIndex(0), BoundVar(0)),    // T = ^0_0 (input)
                            Bound(DebruijnIndex(0), BoundVar(0))     // T = ^0_0 (output)
                        ],
                        consts: []
                    }
                }
            }
        )
    ]
}
```

### What Happens During Type Checking

**When checking `f(10)`:**
1. `f` has type `Param(F)`
2. We need `F: Fn(i32) -> ?Ret`
3. Find where clause: `F: for<T> Fn(T) -> T`
4. **Instantiate the binder**: create a fresh inference variable `?T`
   - Replace `Bound(^0_0)` with `?T` (both occurrences)
   - Where clause becomes: `F: Fn(?T) -> ?T`
5. Unify: `?T = i32`, `?Ret = ?T = i32`
6. Check succeeds

**When checking `f("hello")`:**
1. Same process
2. Create a **fresh** inference variable `?U`
3. Where clause becomes: `F: Fn(?U) -> ?U`
4. Unify: `?U = String`, `?Ret = ?U = String`
5. Check succeeds

### Key Point
Each call to `f` **independently instantiates** the `for<T>` binder with a different type. This is the power of HRTB.

---

## EXAMPLE 6: Skolemization in the Solver

### Scenario
We need to prove: `for<T> fn(T) -> T : SomeTrait`

### Step 1: The Goal (Local Inference Context)
```
Goal: FnPtr(Binder { bound_vars: [Ty], value: FnSig { ... } }) : SomeTrait
ParamEnv: []
```

### Step 2: Enter the Binder (Skolemization)
```rust
// In the solver:
infcx.enter_forall(&binder, |instantiated_sig| {
    // Inside this closure:
    // - Universe advanced from U0 to U1
    // - Bound(^0_0) replaced with Placeholder(!1_0)
    // 
    // instantiated_sig = FnSig {
    //     inputs: [Placeholder(PlaceholderTy { universe: U1, bound: BoundVar(0) })],
    //     output: [Placeholder(PlaceholderTy { universe: U1, bound: BoundVar(0) })],
    // }
    // 
    // Now prove: fn(!1_0) -> !1_0 : SomeTrait
})
```

### Step 3: Prove with Placeholder
```
// Try impl: impl<T> SomeTrait for fn(T) -> T
// Unify: T = !1_0
// !1_0 is rigid (placeholder), but that's fine — the impl works for any T
// Check succeeds
```

### Step 4: Conclude
Since the goal holds for **arbitrary** `!1_0`, it holds for **all** `T`.

---

## EXAMPLE 7: Universe Soundness Check

### User Code (Hypothetical, Would Be Rejected)
```rust
// BAD: This would be unsound if allowed
fn bad<T>(x: T)
where
    T: for<U> Trait<U>,
{
    // Can we conclude T: Trait<i32> from T: for<U> Trait<U>?
    // Yes! We instantiate U = i32.

    // Can we conclude U = i32 everywhere?
    // NO! U is scoped to the where clause.
}
```

### Why Universes Prevent the Bug
```
// Where clause: T: for<U> Trait<U>
// During solving:
//   U is skolemized to !1_0 (universe U1)
//   T is a Param (universe U0)
// 
// Goal: T: Trait<i32>
//   i32 is in U0
// 
// We CANNOT unify !1_0 (U1) with i32 (U0) directly.
// Instead, we instantiate the binder:
//   Create fresh infer var ?U in U0
//   Replace !1_0 with ?U
//   Now: T: Trait<?U>
//   Unify ?U = i32
//   Check: T: Trait<i32> follows from T: Trait<?U> where ?U = i32
//   Yes!
```

---

## EXAMPLE 8: Trait Object with HRTB

### User Code
```rust
trait Mapper<T> {
    fn map(&self, x: T) -> T;
}

fn use_mapper(m: &dyn for<T> Mapper<T>) {
    m.map(10);       // T = i32
    m.map("hello");  // T = String
}
```

### Internal Representation
```
Type: Ref(
    Dyn(
        Binder {                               // for<T>
            bound_vars: [Ty],                  // T
            value: TraitRef {
                def_id: Mapper,
                args: GenericArgs {
                    types: [Bound(DebruijnIndex(0), BoundVar(0))],  // T = ^0_0
                    consts: []
                }
            }
        }
    )
)
```

### Key Points
- Trait objects (`dyn Trait`) wrap the trait ref in a `Binder`
- The binder allows the trait object to work with any type
- Each method call independently instantiates the binder

---

## EXAMPLE 9: Associated Type with HRTB

### User Code
```rust
trait Container<T> {
    type Item;
}

// For any T, Vec<T> is a Container<T> with Item = T
impl<T> Container<T> for Vec<T> {
    type Item = T;
}

fn get_item<C, T>(c: C) -> <C as Container<T>>::Item
where
    C: Container<T>,
{
    // ...
}
```

### Internal Representation
```
// The return type is an AliasTy:
AliasTy {
    trait_def_id: Container,
    assoc_item_def_id: Item,
    args: GenericArgs {
        types: [
            Param(ParamTy { index: 0, name: "C" }),  // C
            Param(ParamTy { index: 1, name: "T" })  // T
        ]
    }
}

// When normalizing <Vec<i32> as Container<i32>>::Item:
// 1. Find impl: impl<T> Container<T> for Vec<T>
// 2. Match: Vec<i32> = Vec<T>  =>  T = i32
// 3. Assoc type: Item = T = i32
// 4. Normalized result: i32
```

---

## EXAMPLE 10: Complete Type Checking Walkthrough

### User Code
```rust
fn main() {
    let v = vec![1, 2, 3];
    let cloned = v.clone();
    println!("{:?}", cloned);
}
```

### Step-by-Step Type Checking

**Step 1: `vec![1, 2, 3]`**
```
Expression: vec![1, 2, 3]
- Macro expands to: Vec::new() then pushes
- Type checker creates: Infer(?0) for the result
- Later: ?0 = Vec<?1> where ?1 is the element type
```

**Step 2: Integer literals `1, 2, 3`**
```
Each literal: Infer(?int) (integer variable)
Default: ?int = i32 (if no other constraints)
So: ?1 = i32
```

**Step 3: `v.clone()`**
```
Expression: MethodCall(v, "clone", [])
- v has type: Vec<i32>
- Method "clone" requires: Vec<i32> : Clone
- Find impl: impl<T: Clone> Clone for Vec<T>
- Nested goal: i32 : Clone
- i32 implements Clone (built-in)
- Check succeeds
- Return type: Vec<i32>
```

**Step 4: `let cloned = ...`**
```
Pattern: Binding("cloned", Mutability::Not)
Type: Vec<i32> (inferred from RHS)
```

**Step 5: `println!("{:?}", cloned)`**
```
Expression: MacroCall("println", ["{:?}", cloned])
- cloned has type: Vec<i32>
- Requires: Vec<i32> : Debug
- Find impl: impl<T: Debug> Debug for Vec<T>
- Nested goal: i32 : Debug
- i32 implements Debug (built-in)
- Check succeeds
```

---

## EXAMPLE 11: Coherence Check

### User Code
```rust
trait Display {
    fn display(&self);
}

impl Display for i32 {
    fn display(&self) { println!("{}", self); }
}

impl<T> Display for Vec<T> {
    fn display(&self) { println!("[...]"); }
}
```

### Coherence Check
```
Impl 1: Display for i32
  Self type: i32

Impl 2: Display for Vec<T>
  Self type: Vec<T> where T is a Param

Overlap check:
  Try unify: i32 = Vec<T>
  Result: FAIL (different type constructors)

Conclusion: No overlap. OK.
```

### Bad Example (Would Be Rejected)
```rust
impl Display for i32 { ... }
impl<T> Display for T where T: Numeric { ... }

Overlap check:
  Try unify: i32 = T
  Result: SUCCESS (T = i32)
  Where clauses: Numeric is a supertrait of i32? Maybe.
  Conclusion: POTENTIAL OVERLAP → ERROR
```

---

## EXAMPLE 12: Variance Inference

### User Code
```rust
struct Container<T> {
    item: T,
}

struct Getter<T> {
    get: fn() -> T,
}

struct Setter<T> {
    set: fn(T),
}
```

### Variance Results
```
Container<T>: 
  Field "item" has type T
  T appears in "output" position (stored data)
  Variance: Covariant

Getter<T>:
  Field "get" has type fn() -> T
  T appears in return position (output of function)
  Variance: Covariant

Setter<T>:
  Field "set" has type fn(T)
  T appears in input position (argument to function)
  Variance: Contravariant
```

### Why Variance Matters
```rust
fn foo(c: Container<&'static str>) { ... }

// If Container is covariant in T:
let s: &str = "hello";  // shorter lifetime
let c: Container<&str> = Container { item: s };
// Can we pass `c` where `Container<&'static str>` is expected?
// Yes, if Container is covariant!
```

---

## SUMMARY: When Each Variable Type Is Used

| Scenario | Variable Type | Example |
|----------|--------------|---------|
| Generic function param | Param | `fn foo<T>(x: T)` |
| Unknown expression type | Infer | `let x = 42` |
| Inside `for<T>` type | Bound | `for<T> fn(T)` |
| During solver, from `for<T>` | Placeholder | `!1_0` from skolemization |
| In canonical query | Canonical bound | `∃0` or `∀0` |

---

## SUMMARY: When Each Concept Is Used

| Concept | Used For | Your Language Needs It? |
|---------|----------|------------------------|
| Param | Early-bound generics | YES |
| Infer | Type inference | YES |
| Bound | Inside Binder<T> | YES (for HRTB) |
| Placeholder | Skolemization in solver | YES (for HRTB) |
| Binder<T> | HRTB scopes | YES (for HRTB) |
| DebruijnIndex | Nested binder lookup | YES (for HRTB) |
| UniverseIndex | Placeholder soundness | YES (for HRTB) |
| Canonical<Goal> | Solver caching | YES |
