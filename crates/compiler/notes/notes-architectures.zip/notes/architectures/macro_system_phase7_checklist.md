# Phase 7 Checklist — Procedural Macro Framework

Status legend:
- `[ ]` not started
- `[/]` in progress / skeleton / partial
- `[x]` done

---

## 1. Infrastructure

- [x] Create `yelang-proc-macro` crate in workspace `Cargo.toml`.
- [x] Create `yelang-proc-macro-bridge` crate in workspace `Cargo.toml`.
- [x] Create `yelang-proc-macro-server` crate in workspace `Cargo.toml`.
- [x] Add shared dependencies: `yelang-macro-core`, `postcard`, `slotmap`, `serde`.
- [x] Add `thiserror` for structured errors.
- [x] Verify `cargo check` passes after crate skeletons are added.

## 2. `yelang-proc-macro` Public API

### 2.1 Core types

- [x] `TokenStream` with `new`, `is_empty`, `len`, `iter`, `into_iter`, `push`, `extend`.
- [x] `TokenTree` enum (`Group`, `Ident`, `Punct`, `Literal`).
- [x] `Group` with delimiter, inner stream, span.
- [x] `Delimiter` enum (`Parenthesis`, `Brace`, `Bracket`, `None`).
- [x] `Ident` with constructor, span, equality by value (not span).
- [x] `Punct` with char, spacing, span.
- [x] `Literal` constructors: `string`, `char`, `int`, `float`, `bool`, `raw_string`.
- [ ] `Literal` constructors: `byte_string`, `byte`.
- [x] `Spacing` enum (`Alone`, `Joint`).
- [x] `Span` API: `call_site`, `mixed_site`, `def_site`, `source_file`, `start`, `end`, `resolved_at`.
- [x] `SourceFile` and `LineColumn`.

### 2.2 Display / rendering

- [x] `Display` for `TokenStream` and `TokenTree`.
- [x] `render_source` method on `TokenStream` that preserves spacing and uses an interner fallback.
- [x] `from_core_stream` method on `TokenStream` to convert compiler-internal tokens using a supplied interner.

### 2.3 Macro export attribute

- [ ] `#[yelang_proc_macro::macro_export]` attribute macro.
- [ ] Registers macro in a static table accessible via the C ABI.
- [ ] Validates function signature based on return type and argument count.

### 2.4 Quote macro

- [/] `quote!` procedural macro (bootstrap declarative macro; supports basic interpolation).
- [ ] Supports interpolating `Ident`, `TokenStream`, `TokenTree`, `Literal` comprehensively.
- [ ] Supports repetition `#(...)*` and `#(...),*`.
- [ ] Produces a `TokenStream` expression.
- [ ] Tests for all interpolation shapes.

### 2.5 Lightweight parsing helper

- [ ] `Cursor` for token peek/consume.
- [ ] `Parse` trait.
- [ ] `Parser` struct with combinators (`parse`, `peek`, `step`).
- [ ] `ParseError` with span and message.
- [ ] Lookahead / fork support.

### 2.6 Diagnostics

- [x] `Diagnostic` struct.
- [x] `Level` enum (`Error`, `Warning`, `Note`, `Help`).
- [x] `DiagnosticSpan`.
- [x] `emit` function that stashes diagnostics in thread-local context.

## 3. `yelang-proc-macro-bridge`

### 3.1 Protocol

- [x] `Request` enum with all variants.
- [x] `Response` enum with all variants.
- [x] `WireTokenStream` and `WireTokenTree`.
- [x] `WireSpan` carrying file/lo/hi/syntax_context.
- [x] `WireDiagnostic` and `WireDiagnosticSpan`.
- [x] `ErrorCode` enum.
- [x] Postcard encode/decode for every message variant.
- [x] Framed I/O helper: 8-byte length prefix + payload.
- [x] Protocol version negotiation logic.

### 3.2 ABI

- [x] `YelangProcMacroExports` C struct.
- [x] `yelang_proc_macro_entry` symbol name.
- [x] `ProcMacroKind` enum.
- [x] Function signature descriptors.
- [x] Registration table layout.

### 3.3 Sandbox

- [x] `Limits` struct (memory, time, output tokens).
- [x] `SandboxError` enum.

## 4. `yelang-proc-macro-server`

### 4.1 CLI

- [x] `main.rs` parses `--version`, `--listen-fd` (future), `--log`.
- [x] Exits cleanly on `Request::Shutdown`.

### 4.2 Server core

- [x] `Server` struct with request loop.
- [x] `Session` with slotmap-based `LibraryHandle`.
- [/] `LoadedLibrary` with dylib handle and macro descriptors (skeleton; no real dylib loading).
- [/] Load / unload library requests (`LoadLibrary` currently returns `LibraryNotFound`).
- [/] Dispatch by macro kind.

### 4.3 Executor

- [/] `invoke_fn_like`, `invoke_attr`, `invoke_derive` (skeleton).
- [x] Panic hook converting to `Response::Panic`.
- [/] Thread-local `MacroContext` for callbacks.
- [/] Resource limit enforcement.

### 4.4 Protocol I/O

- [x] Read framed messages from stdin.
- [x] Write framed messages to stdout.
- [x] Handle broken pipe gracefully.

## 5. `yelang-macro` Integration

### 5.1 Discovery

- [/] `ProcMacroDiscovery` module exists.
- [ ] Detect `proc-macro` crate type in workspace metadata.
- [ ] Load macro descriptors from server.
- [ ] Store `(crate, name, kind, library_path, macro_index)`.

### 5.2 Resolution

- [x] `ProcMacroId` newtype.
- [x] `ProcMacroRegistry` for in-process macros.
- [x] `ProcMacroResolver`.
- [ ] Resolve names in `MacroNS` to either declarative or proc macro (currently in-process proc macros are checked separately).

### 5.3 Expansion

- [x] `ProcMacroClient` that spawns and owns the server process.
- [x] `InProcessExecutor` and `InProcessProcMacro` trait for testing and bootstrapping.
- [x] Integrate in-process proc macros into `expand_macro_invocation` (function-like).
- [x] Integrate in-process proc macros into `expand_user_attribute_macro`.
- [x] Integrate in-process proc macros into `expand_user_derive_macro`.
- [x] Convert AST tokens to `yelang_proc_macro::TokenStream` using the expander's interner.
- [x] Convert `yelang_proc_macro::TokenStream` back to AST tokens via source text and re-tokenization.
- [x] Parse returned tokens.
- [x] Integrate diagnostics into `ExpandError`.
- [ ] Convert AST tokens to `WireTokenStream` for server-based macros.
- [ ] Convert `WireTokenStream` back to AST tokens for server-based macros.
- [ ] Send expansion request and await response for server-based macros.

### 5.4 Hygiene bridge

- [/] `Span` serialization with syntax context (wire types carry the field).
- [/] `Span::def_site()` and `Span::mixed_site()` currently resolve to `call_site()`.
- [ ] Deserialize spans preserving syntax context.
- [ ] New identifiers from server get correct contexts.

## 6. Testing

### 6.1 Unit tests

- [x] `TokenStream` round-trip via `from_core_stream` / `render_source`.
- [x] `Literal::raw_string` rendering.
- [/] `quote!` produces expected token trees (basic tests).
- [x] Postcard serialization round-trip for all messages.
- [ ] Slotmap session reuse after unload.
- [ ] Panic conversion.

### 6.2 Integration tests

- [x] Function-like proc macro expands correctly (in-process).
- [x] Attribute proc macro expands correctly (in-process).
- [x] Derive proc macro expands correctly (in-process).
- [ ] Proc macro hygiene: generated names do not collide.
- [/] Proc macro diagnostic: emitted error reaches user with span (in-process).
- [ ] Proc macro panic: compiler reports clean error.
- [ ] Invalid returned tokens: parser error with span.
- [ ] Out-of-process server expansion end-to-end.

### 6.3 Negative tests

- [ ] Wrong function signature rejected.
- [ ] Missing `macro_export` means macro is not discoverable.
- [x] Protocol version mismatch produces error.
- [ ] Server timeout / OOM produces error.
- [x] Recursive proc macro hits depth limit (via shared expansion stack).

## 7. Documentation

- [x] `notes/architectures/macro_system_phase7_design.md` created.
- [ ] Update `DESIGN.md` crate graph.
- [ ] Add proc-macro examples to `notes/syntax_grammar/` if appropriate.
- [x] Keep `lib.rs` and `mod.rs` free of implementation per project convention.

## 8. Final Verification

- [x] `cargo fmt`
- [x] `cargo check` clean (existing warnings allowed)
- [x] `cargo test -p yelang-proc-macro`
- [x] `cargo test -p yelang-proc-macro-bridge`
- [x] `cargo test -p yelang-proc-macro-server`
- [x] `cargo test -p yelang-macro`
- [x] `cargo test` (workspace)
