 
 
Here is the complete design for how users declare and attach implementations to collections/iterators, how the compiler recognizes them without hardcoding, and how aggregation generalizes across embedded, distributed, and storage backends.

---

## 1. The Core Principle: Traits + Registration, Not Hardcoding

The compiler core knows **algebraic shapes**. The stdlib and user code register **which trait methods map to which shapes**. This is exactly how Rust's `Iterator` trait works — `map`, `filter`, `fold` are trait methods with default implementations, and the compiler doesn't special-case them. 

Your language extends this: the query optimizer recognizes certain trait method patterns via a registry, but the type system treats them as normal methods.

---

## 2. How Users Declare Collection/Iterator Implementations

### 2.1 The Base Trait (Defined in Stdlib)

```rust
// stdlib/core/iter.fl
// This is a REGULAR trait. No compiler magic.

trait Iterator<T> {
    // Required: pull next element
    fn next(self: &mut Self) -> Option<T>;
    
    // Transformations (lazy, return new iterator types)
    fn map<U>(self, f: impl Fn(T) -> U) -> Map<Self, T, U>;
    fn filter(self, pred: impl Fn(&T) -> bool) -> Filter<Self, T>;
    fn flat_map<U>(self, f: impl Fn(T) -> impl Iterator<U>) -> FlatMap<Self, T, U>;
    fn take(self, n: usize) -> Take<Self, T>;
    fn skip(self, n: usize) -> Skip<Self, T>;
    
    // Aggregations (eager, consume iterator)
    fn fold<U>(self, init: U, f: impl Fn(U, T) -> U) -> U;
    fn reduce(self, f: impl Fn(T, T) -> T) -> Option<T>;
    fn sum(self) -> T where T: Add;
    fn count(self) -> usize;
    fn collect<C>(self) -> C where C: FromIterator<T>;
    
    // Grouping (returns iterator of groups)
    fn group_by<K>(self, key: impl Fn(&T) -> K) -> GroupBy<Self, T, K>;
    
    // Ordering
    fn order_by(self, key: impl Fn(&T) -> impl Ord, dir: Direction) -> OrderBy<Self, T>;
}

// For types that can produce an iterator
trait IntoIterator<T> {
    fn into_iter(self) -> impl Iterator<T>;
}
```

### 2.2 User Implements Iterator for Their Type

```rust
// User's custom collection
struct MyVec<T> {
    data: Box<[T]>,
    len: usize,
}

// User implements Iterator for their collection's iterator
struct MyVecIter<T> {
    vec: Rc<MyVec<T>>,
    pos: usize,
}

impl Iterator<T> for MyVecIter<T> {
    fn next(self: &mut Self) -> Option<T> {
        if self.pos < self.vec.len {
            let item = self.vec.data[self.pos].clone(); // Rc clone or Copy
            self.pos += 1;
            Some(item)
        } else {
            None
        }
    }
}

// IntoIterator bridges collection -> iterator
impl IntoIterator<T> for MyVec<T> {
    fn into_iter(self) -> MyVecIter<T> {
        MyVecIter { vec: self, pos: 0 }
    }
}
```

### 2.3 Storage Engine Implements Iterator

```rust
// stdlib/infra/storage/lsm.fl
// LSM-backed collection iterator
struct LsmScan<K, V> {
    cursor: LsmCursor,  // Your storage engine cursor
    snapshot: Snapshot,
}

impl Iterator<(K, V)> for LsmScan<K, V> {
    fn next(self: &mut Self) -> Option<(K, V)> {
        self.cursor.next().map(|entry| {
            let key = deserialize(entry.key);
            let value = deserialize(entry.value);
            (key, value)
        })
    }
}

// The collection itself
@table
struct UserTable {
    // This decorator tells the query planner:
    // "This type is a storage-backed collection"
    // But it's just a decorator. The type system sees a regular struct.
}

impl IntoIterator<User> for UserTable {
    fn into_iter(self) -> LsmScan<UserId, User> {
        self.storage.scan()
    }
}
```

---

## 3. How the Compiler Recognizes Methods Without Hardcoding

### 3.1 The Registry (Populated by Stdlib + User Code)

```rust
// middle/query_registry.rs
// This is NOT in the compiler core. It's a middle-layer plugin.

pub struct QueryRegistry {
    // Map: (trait_def_id, method_def_id) -> OperatorShape
    patterns: FxHashMap<(DefId, DefId), OperatorShape>,
    
    // Map: aggregate_def_id -> AggregateClassification
    aggregates: FxHashMap<DefId, AggregateClass>,
}

pub enum OperatorShape {
    Source,                    // into_iter, scan
    Transform(TransformKind),  // map, filter, flat_map
    Aggregate(AggregateKind),  // fold, sum, count, group_by
    Combine(CombineKind),      // join, union
    Order,                     // order_by
    Limit,                     // take, skip, range
}

pub enum TransformKind {
    Map,      // 1-to-1
    Filter,   // 1-to-0-or-1
    FlatMap,  // 1-to-many
}

pub enum AggregateKind {
    Fold,      // General: (acc, T) -> acc
    Reduce,    // (T, T) -> T
    Scalar,    // sum, count, avg -> single value
    Grouping,  // group_by -> groups
}

pub enum AggregateClass {
    Distributive,  // sum, count, min, max — partial results merge
    Algebraic,     // avg, stddev — fixed-size intermediate
    Holistic,      // median, percentile — must see all data
}
```

### 3.2 Stdlib Registers Its Methods

```rust
// stdlib/core/iter.fl
// These registrations happen at compiler init or via metadata

@register_query_operator(trait = "core::iter::Iterator", method = "map", shape = Transform(Map))
@register_query_operator(trait = "core::iter::Iterator", method = "filter", shape = Transform(Filter))
@register_query_operator(trait = "core::iter::Iterator", method = "flat_map", shape = Transform(FlatMap))
@register_query_operator(trait = "core::iter::Iterator", method = "fold", shape = Aggregate(Fold))
@register_query_operator(trait = "core::iter::Iterator", method = "sum", shape = Aggregate(Scalar), class = Distributive)
@register_query_operator(trait = "core::iter::Iterator", method = "count", shape = Aggregate(Scalar), class = Distributive)
@register_query_operator(trait = "core::iter::Iterator", method = "group_by", shape = Aggregate(Grouping), class = Algebraic)
@register_query_operator(trait = "core::iter::Iterator", method = "order_by", shape = Order)
@register_query_operator(trait = "core::iter::Iterator", method = "take", shape = Limit)
@register_query_operator(trait = "core::iter::Iterator", method = "skip", shape = Limit)
```

### 3.3 User Registers Custom Aggregates

```rust
// User-defined aggregate
@register_aggregate(class = Holistic)
fn percentile(self: Iterator<f64>, p: f64) -> f64 {
    let mut values = self.collect::<Vec<f64>>();
    values.sort();
    values[(values.len() as f64 * p) as usize]
}

// This registers:
// - (Iterator<f64>, "percentile") -> Aggregate(Scalar)
// - AggregateClass::Holistic
```

---

## 4. The Query Extractor: How It Works

After type checking, a middle-layer pass walks the HIR/MIR and builds an operator tree:

```rust
// middle/query_extractor.rs

pub fn extract_query_plan(expr: &Expr) -> Option<QueryPlan> {
    match expr {
        // Chain of method calls: a.map(...).filter(...).sum()
        Expr::MethodCall(receiver, method, args) => {
            let (trait_id, method_id) = resolve_method(expr)?;
            
            // Look up in registry
            if let Some(shape) = registry.lookup(trait_id, method_id) {
                let input = extract_query_plan(receiver)?;
                build_operator(shape, input, args)
            } else {
                // Opaque method: can't optimize, leave as function call
                None
            }
        }
        
        // Collection literal or variable: starting point
        Expr::Path(_) | Expr::StructLit(_) => {
            Some(QueryPlan::Source(expr.clone()))
        }
        
        _ => None,
    }
}

fn build_operator(shape: OperatorShape, input: QueryPlan, args: &[Expr]) -> Option<QueryPlan> {
    match shape {
        OperatorShape::Transform(TransformKind::Map) => {
            let closure = extract_closure(&args[0])?;
            Some(QueryPlan::Map {
                input: Box::new(input),
                projection: closure,
            })
        }
        
        OperatorShape::Transform(TransformKind::Filter) => {
            let closure = extract_closure(&args[0])?;
            Some(QueryPlan::Filter {
                input: Box::new(input),
                predicate: closure,
            })
        }
        
        OperatorShape::Aggregate(AggregateKind::Scalar) => {
            let class = registry.aggregate_class(method_id)?;
            Some(QueryPlan::Aggregate {
                input: Box::new(input),
                group_by: None,
                aggregation: Aggregation::Scalar {
                    method: method_id,
                    class,
                },
            })
        }
        
        OperatorShape::Aggregate(AggregateKind::Grouping) => {
            let closure = extract_closure(&args[0])?;
            Some(QueryPlan::Aggregate {
                input: Box::new(input),
                group_by: Some(closure),
                aggregation: Aggregation::Group,
            })
        }
        
        // ... etc
    }
}
```

---

## 5. Aggregation Generalization: The Same Interface, Different Backends

### 5.1 The Unified Operator Tree

```rust
// middle/query_plan.rs

pub enum QueryPlan {
    Source(SourcePlan),
    
    Transform {
        input: Box<QueryPlan>,
        kind: TransformKind,
        closure: ClosureId,
    },
    
    Aggregate {
        input: Box<QueryPlan>,
        group_by: Option<ClosureId>,  // None = global reduce
        aggregation: Aggregation,
    },
    
    Join {
        kind: JoinKind,
        left: Box<QueryPlan>,
        right: Box<QueryPlan>,
        on: ClosureId,
    },
    
    Order {
        input: Box<QueryPlan>,
        keys: Vec<(ClosureId, Direction)>,
    },
    
    Limit {
        input: Box<QueryPlan>,
        skip: usize,
        take: usize,
    },
}

pub enum Aggregation {
    Fold { init: Value, combine: ClosureId },
    Scalar { method: DefId, class: AggregateClass },
    Group,
}
```

### 5.2 Backend-Specific Code Generation

The same `QueryPlan::Aggregate` generates different code based on the backend:

```rust
// backend/embedded.rs
fn generate_embedded(plan: QueryPlan) -> MIR {
    match plan {
        QueryPlan::Aggregate { input, group_by: None, aggregation: Aggregation::Scalar { method, class } } => {
            // Single-threaded fold
            mir! {
                let mut iter = generate_embedded(*input);
                let mut acc = init_for(method);
                while let Some(item) = iter.next() {
                    acc = combine(acc, item);
                }
                acc
            }
        }
        
        QueryPlan::Aggregate { input, group_by: Some(key), .. } => {
            // HashMap grouping
            mir! {
                let mut map = HashMap::new();
                let mut iter = generate_embedded(*input);
                while let Some(item) = iter.next() {
                    let k = key(item);
                    map.entry(k).or_insert_with(Vec::new).push(item);
                }
                map.into_iter()  // returns Iterator<(K, Vec<T>)>
            }
        }
    }
}

// backend/distributed.rs
fn generate_distributed(plan: QueryPlan, shard_key: Expr) -> PhysicalPlan {
    match plan {
        QueryPlan::Aggregate { input, group_by: None, aggregation: Aggregation::Scalar { class: Distributive, method } } => {
            // Two-phase: partial agg per shard, then merge
            PhysicalPlan::Exchange {
                input: Box::new(PhysicalPlan::Aggregate {
                    input: Box::new(generate_distributed(*input, shard_key)),
                    agg: Partial(method),
                }),
                merge: Box::new(PhysicalPlan::Aggregate {
                    input: Box::new(PhysicalPlan::Gather),
                    agg: Final(method),
                }),
            }
        }
        
        QueryPlan::Aggregate { input, group_by: Some(key), .. } => {
            // Shuffle by key, then local aggregate
            PhysicalPlan::Exchange {
                input: Box::new(generate_distributed(*input, shard_key)),
                hash: Some(key),
                merge: Box::new(PhysicalPlan::Aggregate {
                    input: Box::new(PhysicalPlan::Gather),
                    agg: Group,
                }),
            }
        }
        
        QueryPlan::Aggregate { aggregation: Aggregation::Scalar { class: Holistic, .. }, .. } => {
            // Must gather all data to single node
            PhysicalPlan::Aggregate {
                input: Box::new(PhysicalPlan::Gather {
                    input: Box::new(generate_distributed(*input, shard_key)),
                }),
                agg: Full,
            }
        }
    }
}

// backend/sql.rs
fn generate_sql(plan: QueryPlan) -> String {
    match plan {
        QueryPlan::Aggregate { input, group_by: None, aggregation: Aggregation::Scalar { method, .. } } => {
            let subquery = generate_sql(*input);
            format!("SELECT {}(t.*) FROM ({}) t", method_name(method), subquery)
        }
        
        QueryPlan::Aggregate { input, group_by: Some(key), aggregation } => {
            let subquery = generate_sql(*input);
            let key_sql = generate_expr(key);
            let agg_sql = generate_aggregation(aggregation);
            format!("SELECT {}, {} FROM ({}) t GROUP BY {}", key_sql, agg_sql, subquery, key_sql)
        }
    }
}
```

---

## 6. Your Examples, Fully Lowered

### Example 1: Group By

```rust
select groups@g[*].{
  city_lower: g.city_lower,
  decade: g.decade,
  users: g.users@u[*].{ id, age },
}
from users@u:User
group by {
  city_lower: string::lower(u.city),
  decade: (u.age / 10) * 10,
} into groups
```

**Parsed AST:**
```rust
Expr::Select {
    projection: StructLit([
        Field("city_lower", FieldAccess(Path("g"), "city_lower")),
        Field("decade", FieldAccess(Path("g"), "decade")),
        Field("users", Expr::Select {
            projection: StructLit([Field("id", ...), Field("age", ...)]),
            from: Source("g.users", alias="u"),
            // ...
        }),
    ]),
    from: Source("users", alias="u", ty=User),
    group_by: Some(Closure([u], StructLit([
        Field("city_lower", Call("string::lower", [FieldAccess(u, "city")])),
        Field("decade", Binary(Div, Mul(FieldAccess(u, "age"), 10), 10)),
    ]))),
}
```

**Lowered to HIR (method calls):**
```rust
users
    .group_by(|u| {
        city_lower: string::lower(u.city),
        decade: (u.age / 10) * 10,
    })
    .map(|g| {
        city_lower: g.key.city_lower,
        decade: g.key.decade,
        users: g.values.map(|u| { id: u.id, age: u.age })
    })
```

**Query Plan:**
```rust
QueryPlan::Map {
    input: Box::new(QueryPlan::Aggregate {
        input: Box::new(QueryPlan::Source(SourcePlan::Table("users"))),
        group_by: Some(closure_0),  // |u| { city_lower: ..., decade: ... }
        aggregation: Aggregation::Group,
    }),
    projection: closure_1,  // |g| { city_lower: ..., decade: ..., users: ... }
}
```

**Type:** `Iterator<{ city_lower: String, decade: i32, users: Iterator<{ id: i32, age: i32 }> }>`

---

### Example 2: Order + Range

```rust
select users@u[*].{ id, age }
from users@u:User
order by u.age desc
range 20..30
```

**Lowered to HIR:**
```rust
users
    .order_by(|u| u.age, desc)
    .skip(20)
    .take(10)
    .map(|u| { id: u.id, age: u.age })
```

**Query Plan:**
```rust
QueryPlan::Map {
    input: Box::new(QueryPlan::Limit {
        input: Box::new(QueryPlan::Order {
            input: Box::new(QueryPlan::Source(SourcePlan::Table("users"))),
            keys: [(closure_age, Desc)],
        }),
        skip: 20,
        take: 10,
    }),
    projection: closure_proj,
}
```

---

## 7. File Tree: Where Everything Lives

```
compiler/
├── src/
│   ├── core/                    # LAYER 1: Pure compiler, no query knowledge
│   │   ├── parse/
│   │   ├── resolve/
│   │   ├── typeck/              # Type-checks trait methods normally
│   │   ├── hir/
│   │   ├── mir/
│   │   └── lib.rs
│   │
│   ├── query/                   # LAYER 2: Query extraction & optimization
│   │   ├── mod.rs
│   │   ├── registry.rs          # OperatorShape, AggregateClass registry
│   │   ├── extractor.rs         # Walk HIR/MIR, build QueryPlan
│   │   ├── plan.rs              # QueryPlan, Operator enums
│   │   ├── decorrelate.rs       # Subquery unnesting
│   │   ├── optimize.rs          # Pushdown, reordering
│   │   └── validate.rs          # Cardinality, type checks
│   │
│   └── backend/                 # LAYER 3: Code generation
│       ├── mod.rs
│       ├── embedded.rs          # Iterator chains
│       ├── distributed.rs         # Exchange operators, shuffling
│       └── sql.rs               # SQL string generation
│
└── stdlib/
    ├── core/
    │   ├── iter.fl              # Iterator trait (regular methods)
    │   ├── collect.fl           # Vec, HashMap, etc.
    │   └── register.fl          # @register_query_operator declarations
    │
    └── infra/
        ├── storage/
        │   ├── lsm.fl           # LSM-backed collections
        │   ├── distributed.fl   # Shard-aware collections
        │   └── remote.fl        # Remote SQL collections
        └── stream.fl            # Event bus, streaming
```

---

## 8. Summary

| Question | Answer |
|----------|--------|
| **How do users declare implementations?** | `impl Iterator<T> for MyType { fn next(...) }` — regular trait impl |
| **How do aggregates attach?** | `sum`, `count`, `group_by` are trait methods with `@register_query_operator` |
| **How does compiler recognize them?** | Registry maps `(trait_id, method_id)` → `OperatorShape` + `AggregateClass` |
| **How to generalize across backends?** | Same `QueryPlan::Aggregate` generates embedded/distributed/SQL code |
| **What about custom aggregates?** | `@register_aggregate(class = Distributive/Algebraic/Holistic)` |
| **No `.iter()` needed?** | Correct. `IntoIterator` is implicit. `users.filter(...)` just works. |

---

Want me to write out the **full MIR generator** for the embedded backend that turns `QueryPlan::Aggregate { group_by: Some(...), ... }` into actual MIR instructions, or the **distributed physical plan** for a sharded `group_by` with exchange operators?