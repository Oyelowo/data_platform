I see the confusion. Let me clarify with the actual trait relationships, how `avg()` is sugar that desugars to `Aggregate::aggregate`, and what the concrete types look like.

---

## 1. The Trait Hierarchy

There are **two separate traits** that work together:

```rust
// ============================================
// TRAIT 1: Aggregate — defines HOW to aggregate
// Users implement this for custom aggregates
// ============================================

trait Aggregate<T, Acc, Out> {
    fn init() -> Acc;
    fn iterate(acc: Acc, value: T) -> Acc;
    fn merge(left: Acc, right: Acc) -> Acc;
    fn finalize(acc: Acc) -> Out;
    fn classify() -> AggregateClass;
}

// ============================================
// TRAIT 2: Queryable — defines pipeline operations
// The stdlib provides default implementations
// ============================================

trait Queryable<T> {
    fn map<U>(self, f: impl Fn(T) -> U) -> impl Queryable<U>;
    fn filter(self, pred: impl Fn(&T) -> bool) -> impl Queryable<T>;
    
    // This is the ONE aggregation hook. Everything else is sugar.
    fn aggregate<A, Acc, Out>(self, agg: A) -> Out 
    where 
        A: Aggregate<T, Acc, Out>;
    
    // SUGAR: these have default implementations calling aggregate()
    fn sum(self) -> T where T: Add, Self: Sized {
        self.aggregate(Sum)  // Sum is a type that implements Aggregate
    }
    
    fn avg(self) -> f64 where T: Numeric, Self: Sized {
        self.aggregate(Avg)  // Avg is a type that implements Aggregate
    }
    
    fn count(self) -> usize where Self: Sized {
        self.aggregate(Count)
    }
}
```

---

## 2. What `Sum`, `Avg`, `Count` Actually Are

They are **marker types** (zero-sized) that implement `Aggregate`:

```rust
// ============================================
// Sum — Distributive aggregate
// ============================================

struct Sum;  // Zero-sized type, just a marker

impl<T: Add + Zero> Aggregate<T, SumAcc<T>, T> for Sum {
    fn init() -> SumAcc<T> { 
        SumAcc { value: T::zero() } 
    }
    
    fn iterate(acc: SumAcc<T>, value: T) -> SumAcc<T> {
        SumAcc { value: acc.value + value }
    }
    
    fn merge(a: SumAcc<T>, b: SumAcc<T>) -> SumAcc<T> {
        SumAcc { value: a.value + b.value }
    }
    
    fn finalize(acc: SumAcc<T>) -> T {
        acc.value
    }
    
    fn classify() -> AggregateClass { 
        AggregateClass::Distributive 
    }
}

struct SumAcc<T> { value: T }


// ============================================
// Avg — Algebraic aggregate
// ============================================

struct Avg;  // Zero-sized marker

impl<T: Add + Zero + ToF64> Aggregate<T, AvgAcc<T>, f64> for Avg {
    fn init() -> AvgAcc<T> {
        AvgAcc { sum: T::zero(), count: 0 }
    }
    
    fn iterate(acc: AvgAcc<T>, value: T) -> AvgAcc<T> {
        AvgAcc { 
            sum: acc.sum + value, 
            count: acc.count + 1 
        }
    }
    
    fn merge(a: AvgAcc<T>, b: AvgAcc<T>) -> AvgAcc<T> {
        AvgAcc {
            sum: a.sum + b.sum,
            count: a.count + b.count,
        }
    }
    
    fn finalize(acc: AvgAcc<T>) -> f64 {
        acc.sum.to_f64() / acc.count as f64
    }
    
    fn classify() -> AggregateClass { 
        AggregateClass::Algebraic 
    }
}

struct AvgAcc<T> { sum: T, count: usize }


// ============================================
// Percentile — Holistic aggregate (user-defined)
// ============================================

struct Percentile { p: f64 }  // Has state! Not zero-sized

impl<T: Ord + Clone> Aggregate<T, PercentileAcc<T>, T> for Percentile {
    fn init() -> PercentileAcc<T> {
        PercentileAcc { values: vec![], p: self.p }
    }
    
    fn iterate(mut acc: PercentileAcc<T>, value: T) -> PercentileAcc<T> {
        acc.values.push(value);
        acc
    }
    
    fn merge(mut a: PercentileAcc<T>, b: PercentileAcc<T>) -> PercentileAcc<T> {
        a.values.extend(b.values);
        a
    }
    
    fn finalize(mut acc: PercentileAcc<T>) -> T {
        acc.values.sort();
        let idx = (acc.values.len() as f64 * acc.p) as usize;
        acc.values[idx].clone()
    }
    
    fn classify() -> AggregateClass { 
        AggregateClass::Holistic 
    }
}

struct PercentileAcc<T> { values: Vec<T>, p: f64 }
```

---

## 3. How `users.avg()` Actually Works

**Step 1: Surface syntax**
```rust
let avg_age = users.map(|u| u.age).avg();
```

**Step 2: Type checking**
- `users` is `Queryable<User>`
- `.map(|u| u.age)` returns `Queryable<i32>`
- `.avg()` is a trait method with default impl calling `self.aggregate(Avg)`
- `Avg` implements `Aggregate<i32, AvgAcc<i32>, f64>`
- Return type: `f64`

**Step 3: Lowered HIR**
```rust
// The default method body expands:
let avg_age = users.map(|u| u.age).aggregate(Avg);
```

**Step 4: The `aggregate` method on `Queryable`**

```rust
// For in-memory Vec:
impl<T> Queryable<T> for VecQueryable<T> {
    fn aggregate<A, Acc, Out>(self, agg: A) -> Out 
    where 
        A: Aggregate<T, Acc, Out>
    {
        let mut acc = A::init();
        for item in self {
            acc = A::iterate(acc, item);
        }
        A::finalize(acc)
    }
}

// For distributed:
impl<T> Queryable<T> for DistributedQueryable<T> {
    fn aggregate<A, Acc, Out>(self, agg: A) -> Out 
    where 
        A: Aggregate<T, Acc, Out>
    {
        match A::classify() {
            AggregateClass::Distributive | AggregateClass::Algebraic => {
                // Partial aggregate per shard
                let partials: Vec<Acc> = self.nodes.map(|node| {
                    node.execute_partial(self.plan_fragment.clone(), &agg)
                });
                
                // Merge partials
                let final_acc = partials.into_iter()
                    .fold(A::init(), |a, b| A::merge(a, b));
                
                A::finalize(final_acc)
            }
            
            AggregateClass::Holistic => {
                // Must gather ALL data first
                let all_data: Vec<T> = self.execute(); // gather from all nodes
                let mut acc = A::init();
                for item in all_data {
                    acc = A::iterate(acc, item);
                }
                A::finalize(acc)
            }
        }
    }
}
```

---

## 4. The Registry: How Compiler Knows Without Hardcoding

The compiler doesn't know `Avg` or `Sum`. It knows the `aggregate` method and the `Aggregate` trait.

```rust
// middle/query_registry.rs

// The registry maps: (trait_id, method_id) -> OperatorShape
// But ONLY for methods that have registered shapes.

pub struct OperatorRegistry {
    // Key insight: we register the SUGAR methods, not aggregate()
    // aggregate() itself is opaque — we don't know what A is at compile time
    
    // But: we CAN register that sum(), avg(), count() are aggregation sugar
    patterns: FxHashMap<(DefId, DefId), OperatorShape>,
}

// Registration (done by stdlib):
registry.register(
    trait_id("core::queryable::Queryable"),
    method_id("sum"),
    OperatorShape::Aggregate {
        agg_trait: trait_id("core::aggregate::Aggregate"),
        agg_type: type_id("core::aggregate::Sum"),  // The marker type
        class: AggregateClass::Distributive,
    }
);

registry.register(
    trait_id("core::queryable::Queryable"),
    method_id("avg"),
    OperatorShape::Aggregate {
        agg_trait: trait_id("core::aggregate::Aggregate"),
        agg_type: type_id("core::aggregate::Avg"),
        class: AggregateClass::Algebraic,
    }
);
```

**But wait** — this still hardcodes `Sum` and `Avg` in the registry. The cleaner way:

```rust
// The registry doesn't hardcode types. It uses a CONVENTION.
// Any method named `sum` on `Queryable<T>` where `T: Add` 
// is ASSUMED to be a Distributive aggregate.

// OR: the trait method itself carries the classification:

trait Queryable<T> {
    // The aggregate method is generic — we can't classify at registry time
    fn aggregate<A, Acc, Out>(self, agg: A) -> Out 
    where A: Aggregate<T, Acc, Out>;
    
    // But the sugar methods are concrete — we CAN classify them:
    #[operator(aggregate = Sum, class = Distributive)]
    fn sum(self) -> T where T: Add;
    
    #[operator(aggregate = Avg, class = Algebraic)]
    fn avg(self) -> f64 where T: Numeric;
}
```

The `#[operator(...)]` attribute is what the registry reads. It's metadata on the trait method, not hardcoded in the compiler.

---

## 5. User-Defined Aggregates: The Full Picture

```rust
// User writes:
@aggregate(class = Holistic)
fn percentile(values: Iterator<f64>, p: f64) -> f64 {
    let mut sorted = values.collect::<Vec<f64>>();
    sorted.sort();
    sorted[(sorted.len() as f64 * p) as usize]
}

// The @aggregate decorator expands to:
struct Percentile { p: f64 }

impl Aggregate<f64, PercentileAcc<f64>, f64> for Percentile {
    // ... as shown above ...
}

// And ALSO generates a trait extension:
trait QueryablePercentileExt<T> {
    fn percentile(self, p: f64) -> f64;
}

impl<T> QueryablePercentileExt<T> for Queryable<T> 
where T: Into<f64>  // or whatever constraint
{
    fn percentile(self, p: f64) -> f64 {
        self.aggregate(Percentile { p })
    }
}

// And registers:
#[operator(aggregate = Percentile, class = Holistic)]
fn percentile(self, p: f64) -> f64;
```

**Now the user can write:**
```rust
let median_age = users.map(|u| u.age as f64).percentile(0.5);
```

The compiler:
1. Type-checks `.percentile(0.5)` as a trait method call
2. Looks up in registry: finds `#[operator(class = Holistic)]`
3. Query extractor builds: `Operator::Aggregate { aggregation: UserDefined(Percentile), class: Holistic }`
4. Distributed backend sees `Holistic` → must gather all data first

---

## 6. The Complete Flow

```
User writes:
    let avg_age = users.map(|u| u.age).avg();

Compiler:
    1. Parse → AST: MethodCall(MethodCall(users, "map", [...]), "avg", [])
    
    2. Resolve → HIR: 
       - users: DistributedQueryable<User>
       - .map(|u| u.age): DistributedQueryable<i32>
       - .avg(): trait method on Queryable<i32>
         - default impl: self.aggregate(Avg)
         - Avg: type that impl Aggregate<i32, AvgAcc<i32>, f64>
    
    3. Type check:
       - Avg::classify() → Algebraic
       - Return type: f64 ✓
    
    4. Query extraction (middle layer):
       - Walk HIR, see MethodCall(..., "avg", [])
       - Registry lookup: "avg" → OperatorShape::Aggregate { class: Algebraic }
       - Build: Operator::Aggregate {
           input: Operator::Map { ... },
           aggregation: UserDefined(Avg),
           class: Algebraic,
         }
    
    5. Optimization:
       - Algebraic → can partial + merge
       - Insert Exchange nodes for distributed execution
    
    6. Code generation (distributed backend):
       - Generate: partial avg per shard → merge → finalize
```

---

## 7. Summary Table

| Concept | What It Is | Example |
|--------|-----------|---------|
| `Aggregate<T, Acc, Out>` | Trait defining aggregation mechanics | `impl Aggregate<i32, SumAcc<i32>, i32> for Sum` |
| `Sum`, `Avg`, `Count` | Zero-sized marker types | `struct Sum;` |
| `SumAcc<T>`, `AvgAcc<T>` | Accumulator types | `struct SumAcc<T> { value: T }` |
| `Queryable<T>` | Pipeline trait with `aggregate()` method | `fn aggregate<A>(self, agg: A) -> Out` |
| `.sum()`, `.avg()` | Default trait methods (sugar) | `fn sum(self) { self.aggregate(Sum) }` |
| `#[operator(...)]` | Registry metadata on trait method | Tells query extractor this is optimizable |
| `@aggregate` decorator | User-defined aggregate sugar | Generates marker type + trait impl + registry entry |

---

Does this clarify? The key is: **`Queryable` is the pipeline interface, `Aggregate` is the aggregation algebra, and marker types like `Sum`/`Avg` connect them. The registry only knows about the sugar methods (`.sum()`, `.avg()`) via metadata, not the core `aggregate()` method.**