Here is the complete architecture: **zero-copy serialization via Arrow/FlatBuffers**, **lexer as a hand-rolled state machine**, **AST with arena allocation**, and the corrected trait design.

---

## 1. Serialization: Zero-Copy with Arrow

From the research , the solution is **Apache Arrow** or **FlatBuffers** for cross-process/cross-node data, and **arena allocation** for intra-process.

### The Problem with Traditional Serialization

```
Traditional:  Row data → Serialize to bytes → Send → Deserialize → Row data
              (copies data 3+ times, CPU overhead, memory pressure)

Arrow:        Columnar data → Arrow IPC (metadata + shared buffers) → Send → Arrow IPC
              (zero-copy: same memory buffers, just metadata exchange)
```

### Arrow IPC for Distributed Execution

```rust
// Arrow IPC format: metadata describes the layout, data stays in shared memory
// Nodes share the same physical buffers via RDMA, mmap, or shared memory

// On coordinator:
let plan = DistributedPlan {
    stages: [
        Stage {
            nodes: [1, 2, 3],
            plan: PhysicalPlan::Aggregate { ... },
            // The accumulator TYPE is serialized, not the data
            accumulator_type: TypeId::of::<SumAcc<i32>>(),
        }
    ],
};

// On each node:
fn execute_stage(stage: Stage, input: ArrowRecordBatch) -> ArrowRecordBatch {
    // Input is Arrow IPC: zero-copy deserialization
    let acc = stage.init_accumulator();  // SumAcc { value: 0 }
    
    // Iterate over Arrow columns directly (no copy)
    for value in input.column(0).as_primitive::<Int32Type>() {
        acc = Sum::iterate(acc, value);
    }
    
    // Output is Arrow IPC: zero-copy serialization
    ArrowRecordBatch::from(&[acc.value])  // Single value as Arrow array
}
```

### When to Use What

| Scenario | Format | Why |
|----------|--------|-----|
| **Within process** | Arena-allocated structs | No serialization, just pointer bumps |
| **Cross-process, same machine** | Arrow IPC over shared memory | Zero-copy via mmap |
| **Cross-machine, RDMA** | Arrow IPC + RDMA | NIC reads/writes user memory directly |
| **Cross-machine, TCP** | FlatBuffers or packed Arrow | Small wire format, still zero-copy decode |
| **Storage engine** | Arrow/Parquet on disk | Columnar, mmap-friendly |

From the research on zero-copy , the key is **columnar layout** + **memory mapping** + **buffer reuse**.

---

## 2. Lexer: Hand-Rolled State Machine

From the research on lexer design , the fastest lexers use **table-driven DFA** or **hand-rolled state machines with jump tables**.

### Lexer Structure

```rust
// lexer/mod.rs

pub struct Lexer<'a> {
    source: &'a [u8],       // Raw bytes for fast indexing
    pos: usize,             // Current byte position
    line: u32,              // Line number for error messages
    col: u32,               // Column number
    // State for contextual lexing (e.g., raw strings)
    state: LexerState,
}

pub enum LexerState {
    Normal,
    String { delimiter: u8, raw: bool },
    Comment { depth: u32 },  // For nested block comments
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum TokenKind {
    // Literals
    Integer(i64),           // 42, 0x2A, 0b1010
    Float(f64),             // 3.14, 1e10
    String(Symbol),         // Interned string content
    Char(char),             // 'a'
    Bool(bool),             // true, false
    
    // Identifiers
    Ident(Symbol),          // variable_name
    TypeIdent(Symbol),      // TypeName (capitalized)
    Underscore,             // _
    
    // Keywords
    Fn, Let, Mut, If, Else, Match, Loop, Break, Continue, Return,
    Struct, Enum, Union, Trait, Impl, For, In, Where,
    Select, From, Links, GroupBy, OrderBy, WhereKw, // Query keywords
    Into, As, Is, TypeOf,
    
    // Operators
    Plus, Minus, Star, Slash, Percent,
    Eq, NotEq, Lt, Gt, Le, Ge,
    And, Or, Not,
    Assign, PlusAssign, MinusAssign, // +=, -=
    Arrow, FatArrow,                 // ->, =>
    At, Dot, DotDot, DotDotDot,      // @, ., .., ...
    Colon, ColonColon, Semi, Comma,
    LParen, RParen, LBracket, RBracket, LBrace, RBrace,
    
    // Special
    Eof,
    Error(LexError),
}

pub struct Token {
    pub kind: TokenKind,
    pub span: Span,         // Byte offsets into source
}
```

### The State Machine (Fast Path)

```rust
// lexer/state_machine.rs
// Hand-rolled for performance, not generated

impl<'a> Lexer<'a> {
    pub fn next_token(&mut self) -> Token {
        self.skip_whitespace_and_comments();
        
        let start = self.pos;
        let byte = self.peek_byte();
        
        // Fast path: ASCII single-byte tokens
        match byte {
            b'+' => {
                self.advance();
                if self.peek_byte() == b'=' {
                    self.advance();
                    return self.token_at(start, PlusAssign);
                }
                return self.token_at(start, Plus);
            }
            b'-' => {
                self.advance();
                match self.peek_byte() {
                    b'>' => { self.advance(); return self.token_at(start, Arrow); }
                    b'=' => { self.advance(); return self.token_at(start, MinusAssign); }
                    _ => return self.token_at(start, Minus),
                }
            }
            b'@' => { self.advance(); return self.token_at(start, At); }
            b'.' => {
                self.advance();
                match (self.peek_byte(), self.peek_byte_at(1)) {
                    (b'.', b'.') => { self.advance_by(2); return self.token_at(start, DotDotDot); }
                    (b'.', _) => { self.advance(); return self.token_at(start, DotDot); }
                    _ => return self.token_at(start, Dot),
                }
            }
            b'(' => { self.advance(); return self.token_at(start, LParen); }
            b')' => { self.advance(); return self.token_at(start, RParen); }
            // ... etc
            b'a'..=b'z' | b'_' => return self.ident_or_keyword(start),
            b'A'..=b'Z' => return self.type_ident(start),
            b'0'..=b'9' => return self.number(start),
            b'"' | b'\'' => return self.string_or_char(start),
            b'/' => {
                self.advance();
                match self.peek_byte() {
                    b'/' => self.line_comment(),
                    b'*' => self.block_comment(),
                    _ => return self.token_at(start, Slash),
                }
            }
            0 => return self.token_at(start, Eof),
            _ => {
                // Unicode slow path
                self.advance_utf8();
                return self.token_at(start, Error(InvalidChar));
            }
        }
    }
    
    // Identifier/keyword: check perfect hash table
    fn ident_or_keyword(&mut self, start: usize) -> Token {
        self.advance_while(|c| c.is_ascii_alphanumeric() || c == b'_');
        let text = self.slice(start, self.pos);
        let symbol = Symbol::intern(text);  // Intern string
        
        // Perfect hash table for keywords
        if let Some(kind) = KEYWORD_TABLE.get(text) {
            return self.token_at(start, kind);
        }
        
        self.token_at(start, TokenKind::Ident(symbol))
    }
    
    // Number: integer or float, multiple bases
    fn number(&mut self, start: usize) -> Token {
        // 0x hex, 0b binary, 0o octal, or decimal
        // Handle underscores as digit separators: 1_000_000
        // Handle decimal point and exponent for floats
        todo!()
    }
}
```

### Keyword Table: Perfect Hash

```rust
// lexer/keywords.rs
// Generated at compile time, O(1) lookup

static KEYWORD_TABLE: phf::Map<&'static [u8], TokenKind> = phf_map! {
    b"fn" => TokenKind::Fn,
    b"let" => TokenKind::Let,
    b"mut" => TokenKind::Mut,
    b"if" => TokenKind::If,
    b"else" => TokenKind::Else,
    b"match" => TokenKind::Match,
    b"loop" => TokenKind::Loop,
    b"break" => TokenKind::Break,
    b"continue" => TokenKind::Continue,
    b"return" => TokenKind::Return,
    b"struct" => TokenKind::Struct,
    b"enum" => TokenKind::Enum,
    b"union" => TokenKind::Union,
    b"trait" => TokenKind::Trait,
    b"impl" => TokenKind::Impl,
    b"for" => TokenKind::For,
    b"in" => TokenKind::In,
    b"where" => TokenKind::Where,
    b"select" => TokenKind::Select,
    b"from" => TokenKind::From,
    b"links" => TokenKind::Links,
    b"group" => TokenKind::GroupBy,  // group by
    b"order" => TokenKind::OrderBy,   // order by
    b"into" => TokenKind::Into,
    b"as" => TokenKind::As,
    b"is" => TokenKind::Is,
    b"typeof" => TokenKind::TypeOf,
    b"true" => TokenKind::Bool(true),
    b"false" => TokenKind::Bool(false),
};
```

---

## 3. AST: Arena-Allocated with Generated Visitors

From the research on AST design , the modern approach is:

- **Arena allocation** for all nodes (fast bump allocation, drop entire arena at once)
- **Lifetime `'a`** on all nodes (references arena)
- **Generated visitors** via macros
- **Compact enum sizes** (16 bytes on x86_64)

### AST Structure

```rust
// ast/mod.rs

pub struct Ast<'a> {
    pub allocator: &'a Allocator,  // Bump allocator
    pub source: &'a str,
    pub items: Vec<'a, Item<'a>>,
}

// Every node has a span and is arena-allocated
#[derive(Debug)]
pub struct Item<'a> {
    pub span: Span,
    pub kind: ItemKind<'a>,
    pub attrs: Vec<'a, Attribute<'a>>,
}

pub enum ItemKind<'a> {
    Fn(FnItem<'a>),
    Struct(StructItem<'a>),
    Enum(EnumItem<'a>),
    Union(UnionItem<'a>),
    Trait(TraitItem<'a>),
    Impl(ImplItem<'a>),
    TypeAlias(TypeAliasItem<'a>),
    Const(ConstItem<'a>),
    Static(StaticItem<'a>),
    Mod(ModItem<'a>),
    Use(UseItem<'a>),
    // Query-specific items (parsed as regular items, lowered later)
    Query(QueryItem<'a>),
}

// Function
pub struct FnItem<'a> {
    pub name: Ident,
    pub generics: Option<&'a Generics<'a>>,
    pub params: Vec<'a, Param<'a>>,
    pub ret: Option<&'a Ty<'a>>,
    pub body: &'a Expr<'a>,
    pub is_async: bool,
    pub is_const: bool,
}

// Parameter: can be regular, self, or query binding
pub struct Param<'a> {
    pub span: Span,
    pub pat: &'a Pat<'a>,
    pub ty: Option<&'a Ty<'a>>,
    pub kind: ParamKind,  // Regular, Self, SelfRef, QueryBinding
}

pub enum ParamKind {
    Regular,
    SelfValue,
    SelfRef(Mutability),
    QueryBinding { cardinality: Cardinality }, // users@u[*]
}

// Types
pub enum Ty<'a> {
    Path(Path<'a>),
    Tuple(Vec<'a, &'a Ty<'a>>),
    Array(&'a Ty<'a>, &'a Expr<'a>),           // [T; n]
    Slice(&'a Ty<'a>),                        // [T]
    Ref(Mutability, &'a Ty<'a>),               // &T, &mut T
    Fn(Vec<'a, &'a Ty<'a>>, &'a Ty<'a>),      // fn(T) -> U
    AnonStruct(Vec<'a, FieldDef<'a>>),        // { x: i32, y: i32 }
    Union(Vec<'a, &'a Ty<'a>>),               // A | B | C
    TypeOf(&'a Expr<'a>),                      // typeof(expr)
    TypeIs(&'a Expr<'a>, &'a Ty<'a>),         // expr is Type
    Query(&'a QueryExpr<'a>),                   // select ... from ...
    Lit(LitTy),                                // 42, "hello" as types
    Omit(&'a Ty<'a>, Vec<'a, Symbol>),
    Pick(&'a Ty<'a>, Vec<'a, Symbol>),
    ReturnType(&'a Ty<'a>),                    // ReturnType<fn() -> T>
    Params(&'a Ty<'a>),                       // Params<(T, U) -> R>
    Infer,                                     // _
    Err,
}

// Expressions
pub enum Expr<'a> {
    Lit(&'a Lit<'a>),
    Path(Path<'a>),
    Binary(BinOp, &'a Expr<'a>, &'a Expr<'a>),
    Unary(UnOp, &'a Expr<'a>),
    Call(&'a Expr<'a>, Vec<'a, &'a Expr<'a>>),
    MethodCall(&'a Expr<'a>, Ident, Vec<'a, &'a Expr<'a>>),
    Field(&'a Expr<'a>, Ident),
    Index(&'a Expr<'a>, &'a Expr<'a>),
    StructLit(&'a StructLit<'a>),
    ArrayLit(Vec<'a, &'a Expr<'a>>),
    Block(&'a Block<'a>),
    If(&'a Expr<'a>, &'a Expr<'a>, Option<&'a Expr<'a>>),
    Match(&'a Expr<'a>, Vec<'a, Arm<'a>>),
    Loop(&'a Block<'a>, Option<Label>),
    While(&'a Expr<'a>, &'a Block<'a>),
    For(&'a Pat<'a>, &'a Expr<'a>, &'a Block<'a>),
    Closure(Vec<'a, Param<'a>>, &'a Expr<'a>),
    Async(&'a Block<'a>),
    Await(&'a Expr<'a>),
    Try(&'a Expr<'a>),                         // expr?
    Assign(&'a Expr<'a>, &'a Expr<'a>),
    CompoundAssign(BinOp, &'a Expr<'a>, &'a Expr<'a>),
    Range(Option<&'a Expr<'a>>, Option<&'a Expr<'a>>, RangeKind),
    Cast(&'a Expr<'a>, &'a Ty<'a>),
    Query(&'a QueryExpr<'a>),                   // select ... from ...
    Err,
}

// Query expression (parsed as sugar, lowered to method calls)
pub struct QueryExpr<'a> {
    pub span: Span,
    pub projection: &'a Expr<'a>,              // The .{ ... } part
    pub sources: Vec<'a, QuerySource<'a>>,
    pub links: Vec<'a, LinkDef<'a>>,
    pub filter: Option<&'a Expr<'a>>,
    pub group_by: Option<&'a GroupBy<'a>>,
    pub order_by: Option<&'a OrderBy<'a>>,
    pub range: Option<&'a Range<'a>>,
}

pub struct QuerySource<'a> {
    pub collection: Path<'a>,
    pub alias: Ident,
    pub ty: &'a Ty<'a>,
    pub cardinality: Cardinality,
}

pub enum Cardinality {
    One,       // implicit
    Many,      // [*]
    Flatten,   // [**]
    Optional,  // [?]
}

pub struct LinkDef<'a> {
    pub from: Path<'a>,
    pub from_alias: Ident,
    pub edge: Path<'a>,
    pub edge_alias: Ident,
    pub edge_ty: &'a Ty<'a>,
    pub to: Path<'a>,
    pub to_alias: Ident,
}

pub struct GroupBy<'a> {
    pub key: &'a Expr<'a>,
    pub into: Ident,
}

pub struct OrderBy<'a> {
    pub key: &'a Expr<'a>,
    pub direction: Direction,
}

// Patterns
pub enum Pat<'a> {
    Wild,
    Ident(Ident, Mutability),
    Lit(&'a Lit<'a>),
    Struct(&'a PatStruct<'a>),
    Tuple(Vec<'a, &'a Pat<'a>>),
    Or(Vec<'a, &'a Pat<'a>>),
    Range(&'a Pat<'a>, &'a Pat<'a>),
    Ref(Mutability, &'a Pat<'a>),
    Box(&'a Pat<'a>),
    QueryBinding { ident: Ident, cardinality: Cardinality }, // @u[*]
}

// Literals
pub enum Lit<'a> {
    Integer(i64, Base),
    Float(f64),
    String(Symbol),
    Char(char),
    Bool(bool),
}

// Decorators/Attributes
pub struct Attribute<'a> {
    pub span: Span,
    pub kind: AttrKind<'a>,
}

pub enum AttrKind<'a> {
    Decorator(&'a Decorator<'a>),
    DocComment(Symbol),
}

pub struct Decorator<'a> {
    pub path: Path<'a>,
    pub args: Vec<'a, DecoratorArg<'a>>,
}

pub enum DecoratorArg<'a> {
    Expr(&'a Expr<'a>),
    Ty(&'a Ty<'a>),
    Path(Path<'a>),
    Lit(&'a Lit<'a>),
}
```

### Arena Allocation

```rust
// ast/arena.rs
// Uses bumpalo or similar

use bumpalo::Bump;

pub struct Allocator {
    bump: Bump,
}

impl Allocator {
    pub fn new() -> Self {
        Self { bump: Bump::new() }
    }
    
    pub fn alloc<T>(&self, value: T) -> &mut T {
        self.bump.alloc(value)
    }
    
    pub fn alloc_slice<T>(&self, values: &[T]) -> &mut [T] 
    where T: Copy {
        self.bump.alloc_slice_copy(values)
    }
    
    pub fn alloc_str(&self, string: &str) -> &str {
        self.bump.alloc_str(string)
    }
}
```

### Generated Visitors (Macro)

```rust
// ast/visit.rs
// Generated by macro from ast/mod.rs definitions

pub trait Visitor<'a> {
    fn visit_item(&mut self, item: &Item<'a>) { walk_item(self, item) }
    fn visit_expr(&mut self, expr: &Expr<'a>) { walk_expr(self, expr) }
    fn visit_ty(&mut self, ty: &Ty<'a>) { walk_ty(self, ty) }
    // ... etc
}

pub fn walk_item<'a, V: Visitor<'a>>(visitor: &mut V, item: &Item<'a>) {
    match &item.kind {
        ItemKind::Fn(f) => visitor.visit_fn_item(f),
        ItemKind::Struct(s) => visitor.visit_struct_item(s),
        // ...
    }
}

pub fn walk_expr<'a, V: Visitor<'a>>(visitor: &mut V, expr: &Expr<'a>) {
    match expr {
        Expr::Binary(_, left, right) => {
            visitor.visit_expr(left);
            visitor.visit_expr(right);
        }
        Expr::Call(func, args) => {
            visitor.visit_expr(func);
            for arg in args {
                visitor.visit_expr(arg);
            }
        }
        // ...
    }
}
```

---

## 4. Corrected Aggregate Design: Config + Acc + Trait

From your questions, here's the unified design:

```rust
// ============================================
// AGGREGATE CONFIG: What the user creates
// Has fields when configurable, zero-sized when not
// ============================================

// No config needed → zero-sized
pub struct Sum;
pub struct Count;
pub struct Min;
pub struct Max;

// Config needed → has fields
pub struct Percentile { pub p: f64 }
pub struct TopN { pub n: usize }
pub struct WindowedAvg { pub window: usize }

// ============================================
// ACCUMULATOR: Serializable state for distributed execution
// Separate from config because it changes during execution
// ============================================

pub struct SumAcc<T> { pub value: T }
pub struct CountAcc { pub count: usize }
pub struct AvgAcc<T> { pub sum: T, pub count: usize }
pub struct PercentileAcc<T> { pub values: Vec<T>, pub p: f64 }

// ============================================
// TRAIT: Connects config → accumulator → output
// ============================================

pub trait Aggregate<T, Acc, Out> {
    fn init(&self) -> Acc;
    fn iterate(&self, acc: Acc, value: T) -> Acc;
    fn merge(&self, left: Acc, right: Acc) -> Acc;
    fn finalize(&self, acc: Acc) -> Out;
    fn classify(&self) -> AggregateClass;
}

// Implementations
impl<T: Add + Zero> Aggregate<T, SumAcc<T>, T> for Sum {
    fn init(&self) -> SumAcc<T> { SumAcc { value: T::zero() } }
    fn iterate(&self, acc: SumAcc<T>, value: T) -> SumAcc<T> {
        SumAcc { value: acc.value + value }
    }
    fn merge(&self, a: SumAcc<T>, b: SumAcc<T>) -> SumAcc<T> {
        SumAcc { value: a.value + b.value }
    }
    fn finalize(&self, acc: SumAcc<T>) -> T { acc.value }
    fn classify(&self) -> AggregateClass { AggregateClass::Distributive }
}

impl<T: Ord + Clone> Aggregate<T, PercentileAcc<T>, T> for Percentile {
    fn init(&self) -> PercentileAcc<T> {
        PercentileAcc { values: Vec::new(), p: self.p }
    }
    fn iterate(&self, mut acc: PercentileAcc<T>, value: T) -> PercentileAcc<T> {
        acc.values.push(value);
        acc
    }
    fn merge(&self, mut a: PercentileAcc<T>, b: PercentileAcc<T>) -> PercentileAcc<T> {
        a.values.extend(b.values);
        a
    }
    fn finalize(&self, mut acc: PercentileAcc<T>) -> T {
        acc.values.sort();
        let idx = (acc.values.len() as f64 * acc.p) as usize;
        acc.values[idx].clone()
    }
    fn classify(&self) -> AggregateClass { AggregateClass::Holistic }
}

// ============================================
// QUERYABLE: Pipeline trait
// aggregate() is the ONLY aggregation hook
// ============================================

pub trait Queryable<T> {
    fn map<U>(self, f: impl Fn(T) -> U) -> impl Queryable<U>;
    fn filter(self, pred: impl Fn(&T) -> bool) -> impl Queryable<T>;
    
    // The core aggregation method
    fn aggregate<A, Acc, Out>(self, agg: A) -> Out 
    where A: Aggregate<T, Acc, Out>;
    
    // Sugar: default implementations
    fn sum(self) -> T where T: Add + Zero, Self: Sized {
        self.aggregate(Sum)
    }
    
    fn avg(self) -> f64 where T: Numeric, Self: Sized {
        self.aggregate(Avg)
    }
    
    fn percentile(self, p: f64) -> T where T: Ord + Clone, Self: Sized {
        self.aggregate(Percentile { p })
    }
}
```

---

## 5. No Registry: Lang Items + Trait Resolution

The compiler uses **lang items** (like Rust) or just **trait bounds** to recognize optimizable patterns:

```rust
// In stdlib:
#[lang = "queryable"]
trait Queryable<T> { ... }

#[lang = "aggregate"]
trait Aggregate<T, Acc, Out> { ... }

// Compiler query extractor:
fn extract_operator(expr: &Expr) -> Option<Operator> {
    // Pattern: expr.aggregate(agg) where expr: Queryable<T>, agg: Aggregate<T, Acc, Out>
    if let Expr::MethodCall(receiver, "aggregate", [agg_expr]) = expr {
        let receiver_ty = typeck(receiver)?;  // Queryable<T>
        let agg_ty = typeck(agg_expr)?;       // Some type implementing Aggregate<T, _, _>
        
        // Resolve the Aggregate impl to get classify()
        let classify = resolve_associated_const(agg_ty, "classify")?;
        
        Some(Operator::Aggregate {
            input: extract_operator(receiver)?,
            aggregation: agg_ty,
            class: classify,
        })
    } else {
        None
    }
}
```

**No registry needed.** The compiler uses normal trait resolution.

---

## 6. Complete File Tree

```
compiler/
├── src/
│   ├── lexer/
│   │   ├── mod.rs              # Lexer struct, main loop
│   │   ├── state_machine.rs    # Hand-rolled DFA
│   │   ├── keywords.rs         # Perfect hash table
│   │   ├── tokens.rs           # TokenKind, Token
│   │   └── errors.rs           # LexError
│   │
│   ├── ast/
│   │   ├── mod.rs              # All AST nodes (Item, Expr, Ty, Pat, etc.)
│   │   ├── arena.rs            # Bump allocator wrapper
│   │   ├── visit.rs            # Visitor trait (generated by macro)
│   │   ├── query.rs            # QueryExpr, QuerySource, LinkDef
│   │   └── macros.rs           # #[ast(visit)] proc macro
│   │
│   ├── parse/
│   │   ├── mod.rs              # Parser struct
│   │   ├── expr.rs             # Expression parsing (incl. query syntax)
│   │   ├── item.rs             # Item parsing
│   │   ├── ty.rs               # Type parsing
│   │   ├── pat.rs              # Pattern parsing
│   │   └── errors.rs           # ParseError
│   │
│   ├── resolve/
│   │   ├── mod.rs
│   │   ├── early.rs            # Module tree, imports
│   │   ├── late.rs             # Path resolution in exprs/types
│   │   └── decorator.rs        # Decorator resolution
│   │
│   ├── typeck/
│   │   ├── mod.rs
│   │   ├── expr.rs             # Expression type checking
│   │   ├── item.rs             # Item type checking
│   │   ├── query.rs            # Query-specific type rules
│   │   └── infer.rs            # Type inference engine
│   │
│   ├── hir/
│   │   ├── mod.rs
│   │   ├── lowering.rs         # AST → HIR
│   │   └── query_lower.rs      # Query syntax → method calls
│   │
│   ├── mir/
│   │   ├── mod.rs
│   │   ├── mir.rs              # MIR instructions
│   │   ├── lowering.rs         # HIR → MIR
│   │   └── cow.rs              # CoW insertion pass
│   │
│   ├── query/                   # MIDDLE LAYER (not in core)
│   │   ├── mod.rs
│   │   ├── extractor.rs        # Walk MIR, build operator tree
│   │   ├── plan.rs             # Operator enum
│   │   ├── optimize.rs         # Pushdown, reordering
│   │   └── decorrelate.rs      # Subquery unnesting
│   │
│   ├── backend/
│   │   ├── mod.rs
│   │   ├── embedded.rs         # Iterator code gen
│   │   ├── distributed.rs      # Exchange operators, Arrow IPC
│   │   └── sql.rs              # SQL string generation
│   │
│   └── lib.rs
│
└── stdlib/
    ├── core/
    │   ├── iter.fl              # Iterator trait
    │   ├── queryable.fl         # #[lang = "queryable"] Queryable trait
    │   ├── aggregate.fl         # #[lang = "aggregate"] Aggregate trait + impls
    │   ├── share.fl             # Share<T> unified reference
    │   └── arena.fl             # Region allocator
    │
    └── infra/
        ├── storage/
        │   ├── lsm.fl           # LsmQueryable
        │   └── distributed.fl   # DistributedQueryable
        └── stream.fl            # Event bus
```

---

## Summary

| Question | Answer |
|----------|--------|
| **Serialization expensive?** | Use **Arrow IPC** for zero-copy cross-node; **arena allocation** for intra-process. |
| **Lexer design?** | Hand-rolled **state machine with jump table**, perfect hash for keywords. |
| **AST design?** | **Arena-allocated** with `'a` lifetimes, **generated visitors**, compact enums. |
| **Aggregate config vs acc?** | **Config** = user-facing struct (may have fields). **Acc** = serializable state. Both implement `Aggregate` trait. |
| **No registry?** | Use **lang items** or **trait bounds** in query extractor. |
| **Memory model?** | `Share<T>` with CoW, no `Box`/`Rc`/`GC` in surface syntax. |

Want me to write out the **full MIR lowering** for a query expression (showing `select ... from ...` → method calls → MIR), or the **Arrow IPC serialization** of accumulator state for distributed execution?