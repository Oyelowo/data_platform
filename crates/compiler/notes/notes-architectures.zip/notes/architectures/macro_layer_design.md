# yelang-macro layer — design document (Option A)

## Goal

Finish the declarative macro subsystem so that `yelang-macro` is a complete,
production-ready expansion phase before any further compiler work is added.

This document describes the architecture, concrete syntax, data structures,
expansion pipeline, and an exhaustive checklist for the implementation.  It also
answers the cross-cutting questions raised for the project (token systems,
ID allocation, proc-macro scope, and naming conventions).

## Cross-cutting architectural decisions

### 1. Token / TokenStream systems

The compiler currently has **two** token representations, and that is
intentional and matches the separation of concerns in mature compilers
(including rustc):

| Layer | Crate | Purpose | Carries |
|-------|-------|---------|---------|
| Lexer tokens | `yelang-lexer` | Tokenization, lossless retokenization, source spans | `TokenKind`, `Span` (byte offsets) |
| Macro token trees | `yelang-macro-core` | Macro expansion, hygiene, provenance | `TokenTree`, `TokenId`, `SyntaxContextId`, `ExpnId` |

`yelang-ast::expr::convert` translates lexer tokens into macro-core token trees
when a macro body or invocation is parsed.  After expansion, macro-core token
streams are rendered back to source and re-tokenized with `yelang-lexer` so the
rest of the pipeline (parser, HIR lowering, type checking) sees only one token
system.

**Decision:** keep the two-token-system split.  Do **not** try to unify them
into a single token type; the hygiene/provenance requirements of macro expansion
are fundamentally different from the byte-span requirements of the lexer.

### 2. ID allocation and slotmap

`yelang-macro-core` already uses dense integer IDs (`TokenId`, `ExpnId`,
`SyntaxContextId`, `MacroDefId`) backed by simple counters.  For the macro layer
this is sufficient because the IDs are never reused and lookup is either
monotonic (hygiene tables) or indirected through maps held by the expander.

For the HIR layer and beyond the user has suggested `slotmap` (or an arena).
That decision belongs to the HIR/type-checking redesign and is **out of scope
for Option A**.  When that work starts, the recommendation is:

- Use `slotmap::SlotMap` or `yelang-arena` for graph-like, referentially stable
  IDs (HIR nodes, type variables, inference variables).
- Keep simple counter IDs for tokens, spans, and expansion IDs where the ID is
  never used as a lookup key into a dense array of heterogeneous objects.

### 3. Proc-macro support (declarative vs. derive/attribute/function-like)

**In scope for Option A:**
- Modern `macro name { ... }` declarative macros (the current work).

**Explicitly out of scope for Option A:**
- External proc-macro crates / dynamic loading.
- A public `proc-macro2`-style API.
- Rust-style `macro_rules!` syntax.

**Planned for a future phase (Option B):**
- Built-in derive macros (`#[derive(Clone)]`, `#[derive(Debug)]`, etc.) —
  already partially present in `builtin_decorators.rs` but not yet exposed
  through a stable, user-extensible mechanism.
- Built-in attribute macros (`#[test]`, `#[repr(C)]`, etc.).
- A compiler-internal "quote / paste / syn" toolkit so that built-in proc-like
  macros can be written in yelang itself.  This will reuse `yelang-macro-core`
  token trees and the AST parser rather than reimplementing `syn`.

**Decision for Option A:** make the declarative layer rock-solid first.  The
infrastructure we build here (token trees, hygiene, expansion loop detection,
matcher/transcriber) is the foundation for all later macro kinds.

### 4. Introspection and `comptime`

Compile-time execution of user code is a powerful feature but it is also a
multi-year design effort (see Zig `comptime`, D `CTFE`, Rust const generics).

**Decision:** defer `comptime` / user-written compile-time code until after the
type checker and trait solver are complete.  The macro layer in Option A is
purely syntactic — it manipulates token trees, not evaluated values.  This keeps
the expansion phase decoupled from type checking and avoids circular dependencies
in the compiler pipeline.

### 5. Crate / module naming conventions

- `lib.rs` and `mod.rs` are used only for re-exports and module registration,
  not for implementation logic.  This is already the pattern in
  `yelang-macro/src/lib.rs` and `yelang-macro/src/matcher/mod.rs`.
- Avoid generic names like `util`, `common`, `helpers`.  Prefer domain-specific
  names (`cursor.rs`, `bindings.rs`, `fragment.rs`).
- The existing `yelang-util` crate should be revisited in the HIR phase; Option A
  does not add new `util` modules.

## Concrete syntax

```yelang
// Definition
macro unless {
    ($cond:expr, $body:expr) => {
        if !$cond { $body }
    };
}

// Invocation in expression position
let x = unless!(false, 42);
```

### Macro body grammar

```text
MacroBody     ::= Rule (";" Rule)* ";"?
Rule          ::= MatcherGroup "=>" TranscriberGroup
MatcherGroup  ::= "(" MatcherSeq ")"
                | "[" MatcherSeq "]"
                | "{" MatcherSeq "}"
TranscriberGroup ::= "(" TranscriberSeq ")"
                | "[" TranscriberSeq "]"
                | "{" TranscriberSeq "}"
MatcherSeq    ::= MatcherAtom*
MatcherAtom   ::= "$" Ident ":" Fragment      // metavariable
                | "$" Group RepOp             // repetition
                | TokenTree                    // terminal
Fragment      ::= ident | expr | stmt | block | tt | literal
                | ty | path | item | pat
RepOp         ::= "*" | "+" | "?"
TranscriberSeq ::= TranscriberAtom*
TranscriberAtom ::= "$" Ident                  // substitution
                | "$" Group Sep? RepOp        // repetition expansion
                | TokenTree
Sep           ::= any single token (usually "," or ";")
```

* `$(...)*` may be written with an optional separator before the operator:
  `$(...),*`.
* Inside a transcriber, `$name` substitutes a single capture; `$($name),*`
  expands a repeated capture.

## Crate layout after Option A

```text
yelang-macro-core/src
  lib.rs                 # pure re-exports
  id.rs                  # ExpnId, SyntaxContextId, MacroDefId, TokenId
  hygiene.rs             # HygieneData, context/mark management
  token_tree/
    mod.rs               # re-exports only
    tree.rs              # TokenTree, Group, Delimiter
    stream.rs            # TokenStream
    ident.rs             # Ident
    literal.rs           # Literal, LitKind
    punct.rs             # Punct, Spacing
    span.rs              # Span (with ctx)
    render.rs            # source rendering
    codegen.rs           # codegen helpers
    token_id.rs          # TokenId details

yelang-arena/src
  lib.rs                 # pure re-exports
  arena.rs
  map.rs
  set.rs
  id.rs

yelang-ast/src
  ...
  tokenizer/tokens/types.rs   # TokenKind::Macro
  tokenizer/tokens/display.rs # Display/Debug for Macro
  tokenizer/tokens/tokenize.rs# map "macro" -> TokenKind::Macro
  item/item.rs                # ItemKind::MacroDef(Box<MacroDef>)
  item/macro_def.rs           # MacroDef parser
  expr/macro_invocation.rs    # MacroInvocation parser
  expr/convert.rs             # lexer tokens -> macro-core token trees

yelang-macro/src
  lib.rs                 # pure re-exports only
  expander.rs            # MacroExpander, expand_program, expand_item
  builtin_macros.rs      # existing built-in expression macros
  builtin_decorators.rs  # existing derive/attribute-like decorators
  quote.rs               # programmatic token-tree construction helpers
  paste.rs               # identifier/string pasting helpers
  matcher/
    mod.rs               # re-exports only
    types.rs             # MatcherOp, TranscriberOp, FragmentKind, RepetitionKind
    parser.rs            # parse matchers/transcribers from TokenStream
    bindings.rs          # Bindings / Binding storage
    cursor.rs            # TokenCursor
    fragment.rs          # validate and consume fragment specifiers
    engine.rs            # recursive matcher + rule selection
  transcribe.rs          # substitute bindings + expand repetitions + hygiene
  resolver.rs            # collect ItemKind::MacroDef and resolve invocations
  error.rs               # ExpandError + matcher/transcriber errors
```

## Core data structures

```rust
// yelang-ast/src/item/macro_def.rs
pub struct MacroDef {
    pub name: Ident,
    pub body: TokenStream, // macro-core token stream of the brace group contents
    pub span: Span,
}

// yelang-macro/src/matcher/types.rs
pub enum MatcherOp {
    Terminal(TokenTree),
    Metavar { name: Symbol, fragment: FragmentKind },
    Group { delimiter: Delimiter, ops: Vec<MatcherOp> },
    Repeat { kind: RepetitionKind, sep: Option<TokenTree>, ops: Vec<MatcherOp> },
}

pub enum TranscriberOp {
    Terminal(TokenTree),
    Group { delimiter: Delimiter, ops: Vec<TranscriberOp> },
    Subst(Symbol),
    Repeat { kind: RepetitionKind, sep: Option<TokenTree>, ops: Vec<TranscriberOp> },
}

pub enum FragmentKind {
    Ident, Expr, Stmt, Block, Tt, Literal, Ty, Path, Item, Pat,
}

pub enum RepetitionKind { ZeroOrMore, OneOrMore, ZeroOrOne }

// yelang-macro/src/matcher/bindings.rs
pub struct Bindings {
    map: HashMap<Symbol, Binding>,
}

pub enum Binding {
    Single(TokenStream),
    Repeat(Vec<Binding>),
}

// yelang-macro/src/matcher/types.rs
pub struct MacroRule {
    pub matcher: Vec<MatcherOp>,
    pub transcriber: Vec<TranscriberOp>,
}

pub struct DeclarativeMacro {
    pub name: String,
    pub rules: Vec<MacroRule>,
}
```

## Expansion pipeline

1. **Parse** the source program. `macro name { ... }` parses as
   `ItemKind::MacroDef` with the raw body token stream.
2. **Collect** definitions (`resolver.rs`). All `MacroDef` items are removed
   from the AST and stored in a name-indexed map. Rules are parsed eagerly;
   malformed definitions produce errors but do not stop the pipeline.
3. **Expand** iteratively (`expander.rs`):
   * Walk the AST.
   * For each `ExprKind::MacroInvocation`:
     - Built-in macro? use existing expansion.
     - User macro? look up in resolver; try rules in order.
     - First matching rule wins; if more than one rule matches, report
       ambiguity.
   * Transcribe the matched rule, applying hygiene marks to generated tokens.
   * Parse the resulting token stream back into the AST at the invocation site
     (expression/statement/item position).
   * Repeat until a fixed point or until a loop/depth limit is hit.

## Matcher engine

Recursive descent over `MatcherOp` against a token-tree cursor.

* **Terminal**: structural equality of `TokenTree` ignoring span/id/hygiene.
  Literals compare by `LitKind` only (so two integer literals with different
  `TokenId`s still match).
* **Metavariable**: consume tokens according to `FragmentKind`.
  * `tt` / `ident` / `literal`: one token tree.
  * `block`: one brace group.
  * `expr` / `stmt` / `ty` / `path` / `item` / `pat`: consume until a top-level
    separator (`,`) or the end of the current group; render, parse with the
    AST parser, and on success capture the consumed token stream.
* **Group**: expect a matching delimited group and recurse into it.
* **Repeat**:
  * `*` zero or more; `+` one or more; `?` zero or one.
  * Separator (if any) is consumed **between** iterations for `*` and `+`.
  * For `?` the separator token must live inside the repetition body (Rust
    semantics); the `sep` field is therefore only meaningful for `*`/`+`.
  * Stop when the sub-matcher fails.
  * Build a `Binding::Repeat(Vec<Binding>)` where each element contains the
    captures of one iteration.

## Transcriber

Recursive walk over the transcriber token stream using the current binding
environment.

* `$name` where `name` maps to `Single(stream)` emits `stream`.
* `$name` where `name` maps to `Repeat(...)` is an error unless inside a
  repetition.
* `$($body)sep*` expands once per iteration of the repeated captures referenced
  inside `$body`. All referenced repeated captures must have the same length.
  The separator token is emitted between iterations.
* `?` repetitions emit once if the referenced metavariable is present, zero
  times otherwise.
* All other token trees are emitted as-is.

## Hygiene

* Each user-macro expansion allocates a fresh `ExpnId` and a fresh
  `SyntaxContextId` via `HygieneData::apply_mark(..., Opaque)`.
* Captured argument tokens keep their original `SyntaxContextId`.
* Every token generated from the macro definition body (terminals and implicit
  punctuation inserted by the transcriber) gets its span rewritten to the new
  opaque context.
* Identifiers introduced by a macro therefore cannot accidentally resolve to
  names at the call site.

## Loop detection

* Maintain an expansion stack of `(macro_name, call_span)` in `MacroExpander`.
* Before expanding a user macro, check whether the same `(name, span)` is
  already on the stack; if so, emit `ExpandError::ExpansionLoop`.
* As a safety net, also enforce a global maximum expansion depth (128) across
  the whole program.

## Error variants

```rust
pub enum ExpandError {
    UnknownMacro { path: String, span: Span },
    MalformedMacroArgs { reason: String, span: Span },
    DecoratorError { reason: String, span: Span },
    ExpansionLoop { path: String, span: Span },
    // present / planned for Option A
    MacroDefError { name: String, reason: String, span: Span },
    MacroMatchError { name: String, reason: String, span: Span },
    MacroTranscribeError { name: String, reason: String, span: Span },
    AmbiguousMacro { name: String, span: Span },
}
```

## Implementation status & exhaustive checklist

Legend: `[x]` implemented and tested, `[-]` partially implemented,
`[ ]` not yet implemented.

### Matcher parser
- [x] parse simple terminal rule
- [x] parse metavariable for each fragment kind
- [x] parse `*` / `+` / `?` repetitions
- [x] parse repetitions with `,` and `;` separators
- [x] parse nested repetitions
- [x] reject `$x` without a fragment specifier in matcher
- [x] reject repetition without an operator
- [x] reject unknown fragment specifier
- [ ] reject metavariables in transcriber that are not bound by matcher
- [ ] reject transcriber repetition referencing non-repeated matcher variable
- [ ] detect unreachable macro rules

### Fragment consumption
- [x] `ident` consumes one identifier
- [x] `literal` consumes one literal
- [x] `tt` consumes one token tree
- [x] `block` consumes one brace group
- [x] `expr` consumes a simple expression
- [x] `expr` consumes an expression in parentheses
- [x] `expr` rejects invalid expression
- [x] `stmt` consumes `let` statement
- [x] `stmt` consumes expression statement
- [x] `ty` consumes a type
- [x] `path` consumes a path
- [x] `item` consumes an item
- [x] `pat` consumes a pattern
- [ ] `expr` handles comma-separated multiple expressions correctly
- [ ] `block` validates contents are a valid block expression
- [ ] `pat` handles or-patterns and struct patterns

### Matcher engine
- [x] terminal token match
- [x] terminal sequence match
- [x] metavariable capture and retrieve
- [x] group match `( ... )`
- [x] group match `[ ... ]`
- [x] group match `{ ... }`
- [x] `*` matches zero iterations
- [x] `*` matches many iterations
- [x] `+` matches one or more
- [x] `+` fails on zero
- [x] `?` matches zero or one
- [x] separator consumed between repetitions
- [x] first rule wins
- [x] ambiguity detected when two rules match
- [x] no rule matches → error
- [ ] trailing-separator handling for `*`/`+` repetitions
- [ ] proper follow-set validation for fragment specifiers

### Transcriber
- [x] substitute single capture
- [x] substitute multiple captures
- [x] emit terminal tokens unchanged
- [x] expand `$($x),*` with captures
- [x] expand `$($x);+` with captures
- [x] expand `$( $x )?` zero/one
- [x] nested repetition expansion
- [x] error on unbound metavariable
- [x] error on repeated capture used outside repetition
- [x] error on mismatched repetition counts
- [ ] transcriber loop / nested-environment hygiene stress test

### Hygiene
- [x] macro-introduced `let` binding does not shadow call-site name
- [x] macro-introduced identifier cannot be referenced from call site
- [x] argument identifiers keep call-site context
- [ ] macro-introduced macro invocation uses correct expansion context
- [ ] hygiene preserved across multiple expansion rounds

### Loop detection
- [x] direct recursive macro is caught
- [ ] indirect recursive macro is caught
- [x] non-recursive repeated expansion is allowed

### Integration
- [x] parse and expand a simple `macro` definition
- [x] expand macro in expression position
- [x] expand macro in statement position
- [x] expand macro inside a function body
- [x] expand macro inside a module body
- [x] macros can be defined before or after use in the same file
- [x] unknown macro still reports error
- [x] built-in macros continue to work
- [x] decorators continue to work on items next to macro defs
- [ ] macro expansion at item position (not just expression/statement)
- [ ] macro expansion inside patterns

### Code quality
- [x] `yelang-macro` compiles with `#![deny(unused_imports, unused_variables,
  dead_code, ambiguous_glob_imports)]` in `src/lib.rs`
- [x] `yelang-macro` has no `ambiguous_glob_imports` warnings
- [x] `yelang-macro` has no `dead_code` warnings

### Full suite
- [x] `cargo test -p yelang-macro` passes
- [x] `cargo test -p yelang-macro-core` passes
- [x] `cargo test -p yelang-ast --lib` passes
- [x] `cargo test --workspace` passes (excluding in-progress crates)

## Option A completion status

Option A is complete. `yelang-macro` now:
- implements function-like declarative macros,
- detects ambiguity and expansion loops,
- passes 98 tests with zero warnings,
- enforces `#![deny(unused_imports, unused_variables, dead_code, ambiguous_glob_imports)]`.

## Next phase after Option A

The next phase is **not** HIR/type-checking yet. The macro story is only
partially complete: user-defined attribute and derive macros, expansion in all
syntactic positions, follow-set validation, metavariable expressions, fragment
fields, and a future procedural-macro framework are still missing.

See **`notes/architectures/macro_system_completeness_design.md`** for the
exhaustive gap analysis, research-backed design, and implementation phases for
finishing the macro/metaprogramming layer before returning to HIR/type-checking.

Only after the macro layer is fully complete should we move to:
1. HIR / type-checking robustness.
2. Stable ID strategy using `slotmap` / arena.
3. User-visible quote / paste / introspection API.
4. `comptime`.

## References

- `rustc` macro expansion chapter:
  `notes/architectures/references/rustc_dev_guide_macro_expansion.md`
- `rustc` proc-macro hygiene/spans:
  `notes/architectures/references/rustc_proc_macro_hygiene_spans.md`
- Rust reference: macro-by-example
- Rust RFC 1584 (macros 2.0), RFC 550 (follow sets)
