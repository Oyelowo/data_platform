# Complete Guide to Subquery Unnesting / Decorrelation
## Corrected against Thomas Neumann's related papers from 2015, 2024, and 2025

This guide summarizes the Neumann/Kemper framework for decorrelating SQL subqueries by eliminating dependent joins. It is intentionally written as an implementation-oriented guide, not as a full formal proof.

Relevant papers checked:

- Thomas Neumann and Alfons Kemper, **Unnesting Arbitrary Queries**, BTW 2015.
- Thomas Neumann, **A Formalization of Top-Down Unnesting**, 2024.
- Thomas Neumann, **Improving Unnesting of Complex Queries**, BTW 2025.

---

## 1. The Core Idea: the Domain Table `D`

A correlated subquery is represented algebraically as a **dependent join**. The right side can reference attributes from the left side, so a naive execution evaluates the right side once per left tuple.

The first transformation computes the distinct set of outer bindings needed by the right side, then evaluates the right side once per distinct binding:

```text
L ⧑_p R  ≡  L ⋈_{p ∧ natural_D} (D ⧑ R)

where D := Π^set_{F(R) ∩ A(L)}(L)
```

Meaning:

- `L` is the outer side of the dependent join.
- `R` is the correlated inner expression.
- `p` is the dependent-join predicate, if one is present.
- `F(R)` is the set of free variables used by `R`.
- `A(L)` is the attribute set produced by `L`.
- `D` is the **duplicate-eliminating projection** of `L` to the outer columns referenced by `R`.
- `natural_D` means that the final regular join connects `L` back to the corresponding `D` attributes. In SQL, write this explicitly rather than using `NATURAL JOIN`.

`D` is always a set. This is essential: the push-down rules rely on `D` being duplicate-free, while the overall query still preserves SQL bag/multiset semantics for the real query inputs and results.

---

## 2. Bottom-Up and Top-Down Algorithms

### 2.1 2015 bottom-up strategy

The 2015 algorithm repeatedly removes one dependent join by:

1. Computing `D` from the left side.
2. Replacing the original dependent join by a regular join between `L` and `(D ⧑ R)`.
3. Pushing `D ⧑` down through the inner algebra tree using operator-specific equivalences.
4. Stopping when the right side no longer depends on the left side, at which point the dependent join can be replaced by a regular join.
5. Optionally substituting `D` attributes with equivalent attributes already present inside the subtree.

### 2.2 2025 top-down strategy

The 2025 work keeps the same core idea but changes the algorithmic strategy for deeply nested correlations. Instead of repeatedly unnested dependent joins bottom-up, it performs a top-down traversal that carries information about outer references, representative columns, equivalence classes, and nested dependent accesses. This avoids repeatedly expanding shared or nested subtrees.

In implementation terms, the 2025 strategy:

1. Starts at a dependent join to be removed.
2. Builds the needed domain/binding information.
3. Recurses downward through the right-hand algebra tree.
4. Rewrites column references to their representatives.
5. Merges nested dependent-join removals when another dependent join is encountered.
6. Handles complex constructs such as recursive CTEs and `ORDER BY ... LIMIT`.

---

## 3. Operator-Specific Rewrite Rules

The rules below are algebraic rewrite rules for pushing a dependent join with a duplicate-free `D` downward. SQL examples use explicit `JOIN ... ON ...` clauses, because SQL `NATURAL JOIN` is usually the wrong implementation choice.

### 3.1 Selection / Filter

```text
D ⧑ σ_p(R)  ≡  σ_p(D ⧑ R)
```

The filter can be applied after the dependent join has been pushed through it, with correlated columns rewritten to `D` attributes.

**Valid scalar example**

```sql
-- Original correlated scalar subquery.
SELECT u.name,
       (SELECT MAX(o.amount)
        FROM orders o
        WHERE o.user_id = u.id AND o.amount > 100) AS max_amt
FROM users u;

-- Decorrelated form.
SELECT u.name, d.max_amt
FROM users u
LEFT JOIN (
  SELECT D.id, MAX(o.amount) AS max_amt
  FROM (SELECT DISTINCT id FROM users) AS D
  LEFT JOIN orders o
    ON o.user_id = D.id
   AND o.amount > 100
  GROUP BY D.id
) AS d
  ON d.id = u.id;
```

Do not use a scalar subquery such as `SELECT o.amount ...` unless it is guaranteed to return at most one row, for example by aggregation or `ORDER BY ... LIMIT 1`.

---

### 3.2 Projection / Map

```text
D ⧑ Π_A(R)    ≡  Π_{A ∪ A(D)}(D ⧑ R)
D ⧑ Π^+_A(R) ≡  Π^+_{A ∪ A(D)}(D ⧑ R)
```

Projection must retain the `D` attributes so that later joins/grouping can still connect inner results back to outer rows.

---

### 3.3 Inner Join / Cross Product: One Side Correlated

For an inner join or cross product, if only one side uses `D`, push `D ⧑` only into that side:

```text
D ⧑ (R1 ⋈_p R2)  ≡  (D ⧑ R1) ⋈_p R2       if F(R2) ∩ A(D) = ∅
D ⧑ (R1 ⋈_p R2)  ≡  R1 ⋈_p (D ⧑ R2)       if F(R1) ∩ A(D) = ∅
```

**Example**

```sql
-- Original lateral query: only products depends on u.region.
SELECT u.name, l.order_id, l.price
FROM users u
JOIN LATERAL (
  SELECT o.id AS order_id, p.price
  FROM orders o
  JOIN products p
    ON p.id = o.product_id
   AND p.category = u.region
) AS l ON TRUE;

-- Decorrelated form.
SELECT u.name, d.order_id, d.price
FROM users u
JOIN (
  SELECT D.region, o.id AS order_id, p.price
  FROM (SELECT DISTINCT region FROM users) AS D
  JOIN orders o ON TRUE
  JOIN products p
    ON p.id = o.product_id
   AND p.category = D.region
) AS d
  ON d.region = u.region;
```

---

### 3.4 Inner Join / Cross Product: Both Sides Correlated

If both sides of an inner join depend on `D`, replicate the `D` binding into both sides and reconnect them on the common `D` attributes:

```text
D ⧑ (R1 ⋈_p R2)
  ≡  (D ⧑ R1) ⋈_{p ∧ natural_D} (D ⧑ R2)
```

Replication is not inherently worse asymptotically than the original dependent evaluation, because both sides would have been evaluated per binding anyway. However, an optimizer should still cost the alternatives.

---

### 3.5 Group By / Aggregation

```text
D ⧑ Γ_{A; agg}(R)  ≡  Γ_{A ∪ A(D); agg}(D ⧑ R)
```

All `D` attributes needed by outer references must be added to the grouping attributes. Otherwise, results for different outer bindings can be mixed.

**Scalar aggregate example**

```sql
-- Original correlated aggregate.
SELECT u.name,
       (SELECT SUM(o.amount)
        FROM orders o
        WHERE o.user_id = u.id) AS total
FROM users u;

-- Decorrelated form.
SELECT u.name, d.total
FROM users u
LEFT JOIN (
  SELECT D.id, SUM(o.amount) AS total
  FROM (SELECT DISTINCT id FROM users) AS D
  LEFT JOIN orders o
    ON o.user_id = D.id
  GROUP BY D.id
) AS d
  ON d.id = u.id;
```

For scalar aggregate subqueries without an explicit `GROUP BY`, every outer binding must still produce one aggregate result. A left join from `D` is the usual SQL representation for preserving empty groups.

---

### 3.6 Static Group By: Aggregate without Explicit `GROUP BY`

A SQL aggregate without an explicit `GROUP BY`, such as `SELECT COUNT(*) FROM ...`, has a single aggregate group even when the input is empty. During decorrelation this becomes one group per `D` binding.

```sql
-- Original.
SELECT u.name,
       (SELECT COUNT(*)
        FROM orders o
        WHERE o.user_id = u.id) AS c
FROM users u;

-- Decorrelated form.
SELECT u.name, d.c
FROM users u
LEFT JOIN (
  SELECT D.id, COUNT(o.id) AS c
  FROM (SELECT DISTINCT id FROM users) AS D
  LEFT JOIN orders o
    ON o.user_id = D.id
  GROUP BY D.id
) AS d
  ON d.id = u.id;
```

Use `COUNT(o.id)` or another non-null inner column after a left join. `COUNT(*)` would count the preserved `D` row and incorrectly return `1` for users with no matching orders.

For `SUM`, `AVG`, `MIN`, and `MAX`, the preserved row with `NULL` inner values naturally yields SQL's empty-input behavior for the scalar aggregate: `NULL` except for `COUNT`, which yields `0` when written as `COUNT(inner_column)`.

---

### 3.7 Window Functions and `ORDER BY ... LIMIT`

The 2025 paper explains that correlated `ORDER BY ... LIMIT/OFFSET` has to be enforced per outer binding, not globally. A portable SQL rewrite uses a window function and adds the outer bindings to the `PARTITION BY` clause:

```text
D ⧑ Window_{partition, order}(R)
  ≡  Window_{partition ∪ A(D), order}(D ⧑ R)
```

**Scalar `LIMIT 1` example**

```sql
-- Original.
SELECT u.name,
       (SELECT o.amount
        FROM orders o
        WHERE o.user_id = u.id
        ORDER BY o.amount DESC
        LIMIT 1) AS top_amount
FROM users u;

-- Decorrelated form.
SELECT u.name, d.amount AS top_amount
FROM users u
LEFT JOIN (
  SELECT id, amount
  FROM (
    SELECT D.id,
           o.amount,
           ROW_NUMBER() OVER (
             PARTITION BY D.id
             ORDER BY o.amount DESC
           ) AS rn
    FROM (SELECT DISTINCT id FROM users) AS D
    LEFT JOIN orders o
      ON o.user_id = D.id
  ) AS ranked
  WHERE rn = 1
) AS d
  ON d.id = u.id;
```

A scalar subquery with `LIMIT 2` is invalid if used directly as one scalar value. Use a lateral/table-valued result or aggregate the top rows into an array/list.

**Top-2 as an array/list**

```sql
SELECT u.name, d.amounts AS top_two_amounts
FROM users u
LEFT JOIN (
  SELECT ranked.id,
         ARRAY_AGG(ranked.amount ORDER BY ranked.amount DESC) AS amounts
  FROM (
    SELECT D.id,
           o.amount,
           ROW_NUMBER() OVER (
             PARTITION BY D.id
             ORDER BY o.amount DESC
           ) AS rn
    FROM (SELECT DISTINCT id FROM users) AS D
    JOIN orders o
      ON o.user_id = D.id
  ) AS ranked
  WHERE ranked.rn <= 2
  GROUP BY ranked.id
) AS d
  ON d.id = u.id;
```

This version uses an inner join inside the ranking subquery so users with no orders do not get an artificial `[NULL]` array. If the desired result is an empty array instead of `NULL`, wrap the final value in `COALESCE` using the target SQL dialect's empty-array syntax.

---

### 3.8 Semi Join: `EXISTS` and Some `IN` Cases

```text
D ⧑ (R1 ⋉_p R2)
  ≡  (D ⧑ R1) ⋉_{p ∧ natural_D} (D ⧑ R2)
```

**`EXISTS` example**

```sql
-- Original.
SELECT u.name
FROM users u
WHERE EXISTS (
  SELECT 1
  FROM orders o
  WHERE o.user_id = u.id
);

-- Decorrelated form.
SELECT u.name
FROM users u
JOIN (
  SELECT DISTINCT D.id
  FROM (SELECT DISTINCT id FROM users) AS D
  JOIN orders o
    ON o.user_id = D.id
) AS d
  ON d.id = u.id;
```

`IN` can often be represented as a semi join, but SQL `IN` has three-valued NULL semantics. Nullable expressions may require null-aware handling that is not the same as a plain semi join.

---

### 3.9 Anti Join: `NOT EXISTS`, not Plain `NOT IN`

```text
D ⧑ (R1 ▷_p R2)
  ≡  (D ⧑ R1) ▷_{p ∧ natural_D} (D ⧑ R2)
```

**`NOT EXISTS` example**

```sql
-- Original.
SELECT u.name
FROM users u
WHERE NOT EXISTS (
  SELECT 1
  FROM orders o
  WHERE o.user_id = u.id
);

-- Decorrelated form.
SELECT u.name
FROM users u
LEFT JOIN (
  SELECT DISTINCT D.id
  FROM (SELECT DISTINCT id FROM users) AS D
  JOIN orders o
    ON o.user_id = D.id
) AS d
  ON d.id = u.id
WHERE d.id IS NULL;
```

Do not rewrite `NOT IN` as the above anti join unless NULL semantics have been handled. SQL `NOT IN` can evaluate to UNKNOWN if the subquery contains NULL.

---

### 3.10 Left, Right, and Full Outer Joins

Outer joins require more care than inner joins because they preserve unmatched rows from one or both sides.

For a left outer join:

```text
D ⧑ (R1 ⟕_p R2)
  ≡  (D ⧑ R1) ⟕_p R2
      if R2 does not depend on D

D ⧑ (R1 ⟕_p R2)
  ≡  (D ⧑ R1) ⟕_{p ∧ natural_D} (D ⧑ R2)
      otherwise
```

The key distinction is whether the preserved/unmatched side needs `D` information and whether unmatched rows must be tracked. Do not blindly push `D` only to one side of an outer join.

**Example**

```sql
-- Original correlated aggregate with a left join inside the subquery.
SELECT u.name,
       (SELECT COUNT(p.id)
        FROM orders o
        LEFT JOIN products p
          ON p.id = o.product_id
         AND p.category = u.region
        WHERE o.user_id = u.id) AS matching_products
FROM users u;

-- Decorrelated form.
SELECT u.name, d.matching_products
FROM users u
LEFT JOIN (
  SELECT D.id,
         D.region,
         COUNT(p.id) AS matching_products
  FROM (SELECT DISTINCT id, region FROM users) AS D
  LEFT JOIN orders o
    ON o.user_id = D.id
  LEFT JOIN products p
    ON p.id = o.product_id
   AND p.category = D.region
  GROUP BY D.id, D.region
) AS d
  ON d.id = u.id
 AND d.region = u.region;
```

Note that `COUNT(p.id)` counts matched products. Use `COUNT(o.id)` if the desired value is order count regardless of whether a product matched.

---

### 3.11 Nested Dependent Joins

A simplistic rule such as “push `D` only into the left side of a nested dependent join” is not generally sufficient. The 2025 algorithm handles nested dependent joins top-down and merges removals when another dependent join is encountered. Conceptually, the algorithm keeps track of which nested operators access which outer bindings and rewrites shared representatives consistently.

Practical rule: when a dependent join is encountered inside a subtree currently being unnested, do not treat it as an ordinary binary join. Merge or coordinate the unnesting of the nested dependent join with the current unnesting state.

---

### 3.12 Set Operations

Set operations must also preserve the `D` attributes. For example, union-like operations can push `D` to both sides and then reconnect on the `D` columns. Exact rewrites depend on bag/set semantics and the operator (`UNION ALL`, duplicate-eliminating `UNION`, `INTERSECT`, `EXCEPT`). The 2024 formalization is useful here because it reasons explicitly using multiset characteristic functions.

---

## 4. Consistent Example Data

The examples below use this schema.

**users**

| id | name  | region | min_spend |
|----|-------|--------|-----------|
| 1  | Alice | US     | 100       |
| 2  | Bob   | EU     | 50        |
| 3  | Carol | US     | 200       |
| 4  | Dan   | US     | 300       |

**orders**

| id  | user_id | product_id | region | amount |
|-----|---------|------------|--------|--------|
| 101 | 1       | 10         | US     | 150    |
| 102 | 1       | 20         | US     | 80     |
| 103 | 2       | 30         | EU     | 60     |
| 104 | 1       | 40         | US     | 250    |

**products**

| id | category | price |
|----|----------|-------|
| 10 | US       | 120   |
| 20 | US       | 40    |
| 30 | EU       | 70    |
| 40 | US       | 300   |

---

## 5. Worked Examples

### Example 1: Scalar Aggregate, Equality Correlation

```sql
SELECT u.name,
       (SELECT SUM(o.amount)
        FROM orders o
        WHERE o.user_id = u.id) AS total
FROM users u;
```

Result:

| name  | total |
|-------|-------|
| Alice | 480   |
| Bob   | 60    |
| Carol | NULL  |
| Dan   | NULL  |

General decorrelated form:

```sql
SELECT u.name, d.total
FROM users u
LEFT JOIN (
  SELECT D.id, SUM(o.amount) AS total
  FROM (SELECT DISTINCT id FROM users) AS D
  LEFT JOIN orders o
    ON o.user_id = D.id
  GROUP BY D.id
) AS d
  ON d.id = u.id;
```

Substitution-optimized form:

```sql
SELECT u.name, d.total
FROM users u
LEFT JOIN (
  SELECT o.user_id AS id, SUM(o.amount) AS total
  FROM orders o
  GROUP BY o.user_id
) AS d
  ON d.id = u.id;
```

The substitution-optimized form is often cheaper because `D.id` is equivalent to `o.user_id`. It is not universally better: if joining with `D` is selective, keeping `D` can prune inner rows earlier.

---

### Example 2: Non-Equality Correlation

```sql
SELECT u.name, u.min_spend,
       (SELECT SUM(o.amount)
        FROM orders o
        WHERE o.amount > u.min_spend) AS big_spend
FROM users u;
```

Result:

| name  | min_spend | big_spend |
|-------|-----------|-----------|
| Alice | 100       | 400       |
| Bob   | 50        | 540       |
| Carol | 200       | 250       |
| Dan   | 300       | NULL      |

Correct decorrelated form:

```sql
SELECT u.name, u.min_spend, d.big_spend
FROM users u
LEFT JOIN (
  SELECT D.min_spend, SUM(o.amount) AS big_spend
  FROM (SELECT DISTINCT min_spend FROM users) AS D
  LEFT JOIN orders o
    ON o.amount > D.min_spend
  GROUP BY D.min_spend
) AS d
  ON d.min_spend = u.min_spend;
```

The original guide's value `540` for Alice was incorrect because Alice's `min_spend` is `100`, and the order amounts greater than `100` are `150` and `250`, totaling `400`.

---

### Example 3: Multi-Column Correlation

```sql
SELECT u.name,
       (SELECT SUM(o.amount)
        FROM orders o
        WHERE o.region = u.region
          AND o.amount > u.min_spend) AS total
FROM users u;
```

```sql
SELECT u.name, d.total
FROM users u
LEFT JOIN (
  SELECT D.region, D.min_spend, SUM(o.amount) AS total
  FROM (SELECT DISTINCT region, min_spend FROM users) AS D
  LEFT JOIN orders o
    ON o.region = D.region
   AND o.amount > D.min_spend
  GROUP BY D.region, D.min_spend
) AS d
  ON d.region = u.region
 AND d.min_spend = u.min_spend;
```

---

### Example 4: Grouped Result from a Correlated Subquery

A SELECT-list scalar subquery cannot return two columns and multiple rows. Use a lateral/table-valued result instead.

```sql
-- Original as a lateral query.
SELECT u.name, b.bucket, b.total
FROM users u
LEFT JOIN LATERAL (
  SELECT CASE WHEN o.amount > u.min_spend THEN 'big' ELSE 'small' END AS bucket,
         SUM(o.amount) AS total
  FROM orders o
  WHERE o.user_id = u.id
  GROUP BY CASE WHEN o.amount > u.min_spend THEN 'big' ELSE 'small' END
) AS b ON TRUE;
```

```sql
-- Decorrelated form.
SELECT u.name, d.bucket, d.total
FROM users u
LEFT JOIN (
  SELECT D.id,
         D.min_spend,
         CASE WHEN o.amount > D.min_spend THEN 'big' ELSE 'small' END AS bucket,
         SUM(o.amount) AS total
  FROM (SELECT DISTINCT id, min_spend FROM users) AS D
  JOIN orders o
    ON o.user_id = D.id
  GROUP BY D.id,
           D.min_spend,
           CASE WHEN o.amount > D.min_spend THEN 'big' ELSE 'small' END
) AS d
  ON d.id = u.id
 AND d.min_spend = u.min_spend;
```

Here the inner join to `orders` is appropriate because the original grouped subquery returns no row for users with no orders. The final `LEFT JOIN` preserves the outer user rows from the `LEFT JOIN LATERAL` formulation.

---

### Example 5: `HAVING` with an Outer Reference

```sql
SELECT u.name,
       (SELECT SUM(o.amount)
        FROM orders o
        WHERE o.user_id = u.id
        HAVING SUM(o.amount) > u.min_spend) AS total
FROM users u;
```

```sql
SELECT u.name, d.total
FROM users u
LEFT JOIN (
  SELECT D.id, D.min_spend, SUM(o.amount) AS total
  FROM (SELECT DISTINCT id, min_spend FROM users) AS D
  LEFT JOIN orders o
    ON o.user_id = D.id
  GROUP BY D.id, D.min_spend
  HAVING SUM(o.amount) > D.min_spend
) AS d
  ON d.id = u.id
 AND d.min_spend = u.min_spend;
```

`HAVING` is applied after the per-binding group has been formed.

---

### Example 6: `ORDER BY ... LIMIT 1`

```sql
SELECT u.name,
       (SELECT o.amount
        FROM orders o
        WHERE o.user_id = u.id
        ORDER BY o.amount DESC
        LIMIT 1) AS top_amount
FROM users u;
```

```sql
SELECT u.name, d.amount AS top_amount
FROM users u
LEFT JOIN (
  SELECT id, amount
  FROM (
    SELECT D.id,
           o.amount,
           ROW_NUMBER() OVER (
             PARTITION BY D.id
             ORDER BY o.amount DESC
           ) AS rn
    FROM (SELECT DISTINCT id FROM users) AS D
    LEFT JOIN orders o
      ON o.user_id = D.id
  ) AS ranked
  WHERE rn = 1
) AS d
  ON d.id = u.id;
```

---

### Example 7: Correlated Top-N as Rows

If the intended result is more than one row per user, represent the query as lateral/table-valued rather than scalar.

```sql
-- Original.
SELECT u.name, t.amount
FROM users u
LEFT JOIN LATERAL (
  SELECT o.amount
  FROM orders o
  WHERE o.user_id = u.id
  ORDER BY o.amount DESC
  LIMIT 2
) AS t ON TRUE;

-- Decorrelated form.
SELECT u.name, d.amount
FROM users u
LEFT JOIN (
  SELECT id, amount
  FROM (
    SELECT D.id,
           o.amount,
           ROW_NUMBER() OVER (
             PARTITION BY D.id
             ORDER BY o.amount DESC
           ) AS rn
    FROM (SELECT DISTINCT id FROM users) AS D
    JOIN orders o
      ON o.user_id = D.id
  ) AS ranked
  WHERE rn <= 2
) AS d
  ON d.id = u.id;
```

---

### Example 8: Correlation in a Join Condition

```sql
SELECT u.name,
       (SELECT SUM(o.amount + p.price)
        FROM orders o
        JOIN products p
          ON p.id = o.product_id
         AND p.category = u.region
        WHERE o.user_id = u.id) AS total
FROM users u;
```

```sql
SELECT u.name, d.total
FROM users u
LEFT JOIN (
  SELECT D.id,
         D.region,
         SUM(o.amount + p.price) AS total
  FROM (SELECT DISTINCT id, region FROM users) AS D
  LEFT JOIN orders o
    ON o.user_id = D.id
  LEFT JOIN products p
    ON p.id = o.product_id
   AND p.category = D.region
  GROUP BY D.id, D.region
) AS d
  ON d.id = u.id
 AND d.region = u.region;
```

This example assumes `orders.product_id` exists, as defined in the corrected example schema.

---

### Example 9: Nested Correlated Subqueries

```sql
SELECT u.name,
       (SELECT SUM(o.amount)
        FROM orders o
        WHERE o.user_id = u.id
          AND o.amount > (
            SELECT AVG(p.price)
            FROM products p
            WHERE p.category = u.region
          )) AS total
FROM users u;
```

```sql
SELECT u.name, d.total
FROM users u
LEFT JOIN (
  SELECT D2.id, D2.region, SUM(o.amount) AS total
  FROM (SELECT DISTINCT id, region FROM users) AS D2
  JOIN (
    SELECT D1.region, AVG(p.price) AS avg_price
    FROM (SELECT DISTINCT region FROM users) AS D1
    LEFT JOIN products p
      ON p.category = D1.region
    GROUP BY D1.region
  ) AS avg_by_region
    ON avg_by_region.region = D2.region
  LEFT JOIN orders o
    ON o.user_id = D2.id
   AND o.amount > avg_by_region.avg_price
  GROUP BY D2.id, D2.region
) AS d
  ON d.id = u.id
 AND d.region = u.region;
```

The join to `avg_by_region` is safe as an inner join here because the derived table produces one row per `D1.region`, including a row with `NULL` `avg_price` if a region has no products. The left join to `orders` preserves scalar aggregate behavior.

---

### Example 10: `LATERAL` Joins

```sql
-- Original CROSS JOIN LATERAL.
SELECT u.name, l.amount
FROM users u
JOIN LATERAL (
  SELECT o.amount
  FROM orders o
  WHERE o.user_id = u.id
) AS l ON TRUE;

-- Decorrelated form.
SELECT u.name, d.amount
FROM users u
JOIN (
  SELECT D.id, o.amount
  FROM (SELECT DISTINCT id FROM users) AS D
  JOIN orders o
    ON o.user_id = D.id
) AS d
  ON d.id = u.id;
```

```sql
-- Original LEFT JOIN LATERAL.
SELECT u.name, l.amount
FROM users u
LEFT JOIN LATERAL (
  SELECT o.amount
  FROM orders o
  WHERE o.user_id = u.id
) AS l ON TRUE;

-- Decorrelated form.
SELECT u.name, d.amount
FROM users u
LEFT JOIN (
  SELECT D.id, o.amount
  FROM (SELECT DISTINCT id FROM users) AS D
  JOIN orders o
    ON o.user_id = D.id
) AS d
  ON d.id = u.id;
```

For the left-lateral case, using an inner join inside the derived table avoids manufacturing a single NULL-valued inner row. The outer `LEFT JOIN` already preserves users with no matching orders.

---

## 6. Join-Type Guidelines

These are practical SQL templates, not universal algebraic laws. Always check scalar/table-valued behavior and SQL NULL semantics.

| Situation | Typical inner derived-table join | Typical final join to outer |
|---|---|---|
| Scalar aggregate in `SELECT`, no explicit `GROUP BY` | `LEFT JOIN` from `D` to preserve one group per binding | `LEFT JOIN` |
| Scalar `COUNT` after `LEFT JOIN` | `COUNT(inner_non_null_column)` | `LEFT JOIN` |
| Table-valued grouped subquery / `LEFT JOIN LATERAL` | Often `JOIN` to matching rows, because no group means no inner row | `LEFT JOIN` |
| `EXISTS` | `JOIN` plus `DISTINCT`/semi-join | `JOIN`/semi-join |
| `NOT EXISTS` | `JOIN` plus `DISTINCT` | `LEFT JOIN ... IS NULL`/anti-join |
| `IN` / `NOT IN` with nullable expressions | Requires null-aware handling | Do not use a plain semi/anti join blindly |
| `ORDER BY ... LIMIT` | Use `ROW_NUMBER()` partitioned by `D` attributes | Depends on scalar vs table-valued context |
| `JOIN LATERAL` | `JOIN` | `JOIN` |
| `LEFT JOIN LATERAL` | Usually `JOIN`, unless null-extended inner rows are semantically needed | `LEFT JOIN` |

---

## 7. Key Insights from the Papers

### 7.1 `D` is duplicate-free

The 2015 paper emphasizes that the domain relation `D` is a set. This is what permits pushing the dependent join through operators while preserving the surrounding SQL multiset semantics.

### 7.2 Substitution is an optimization, not a mandatory rewrite

If `D` attributes are equivalent to attributes already present in the inner subtree, `D` can sometimes be eliminated by substitution. This is common for simple equi-correlations such as `o.user_id = u.id`. However, substitution can increase intermediate cardinality by losing `D`'s pruning effect, so it should be costed.

### 7.3 Top-down unnesting avoids repeated expansion for deep nesting

The 2025 paper addresses a limitation of the 2015 bottom-up strategy: nested dependent joins can cause repeated expansion and poor plans. The top-down strategy considers nested dependent accesses in one traversal.

### 7.4 `ORDER BY ... LIMIT/OFFSET` is per binding

When a correlated subquery uses `ORDER BY ... LIMIT`, the limit must be enforced separately for each outer binding. A portable rewrite uses `ROW_NUMBER()` and adds `D` attributes to `PARTITION BY`.

### 7.5 The 2024 paper proves correctness formally

The 2024 paper formalizes operator semantics using multisets and characteristic functions, then proves the individual rewrite steps and the full top-down unnesting approach correct. It also treats `NULL` in its algebraic natural-join shorthand as an ordinary domain value, so SQL implementations must account for that explicitly.

---

## 8. Common Pitfalls

### 8.1 `COUNT(*)` after a left join

After preserving a `D` row with a left join, `COUNT(*)` counts the preserved row. Use `COUNT(inner_non_null_column)` when modeling `COUNT(*)` over the original inner input.

### 8.2 Forgetting `D` attributes in grouping or window partitioning

Add all required outer bindings to `GROUP BY` and `PARTITION BY`. Otherwise the query can mix independent outer bindings.

### 8.3 Treating scalar and table-valued subqueries the same

A scalar subquery must return at most one column and at most one row. Examples that return multiple rows must be written as `LATERAL`/table-valued queries or aggregated into an array/list.

### 8.4 Ignoring SQL NULL semantics

The formal natural-join shorthand treats two `NULL` values as equal. SQL `=` and SQL `NATURAL JOIN` do not. Use explicit predicates such as `IS NOT DISTINCT FROM` when NULL-safe equality is required.

### 8.5 Rewriting `NOT IN` as `NOT EXISTS`

`NOT IN` and `NOT EXISTS` differ when NULLs are present. A correct optimizer needs null-aware anti-join logic for `NOT IN`.

### 8.6 Using left joins inside every derived table

Left joins are needed for static scalar aggregates and some null-preserving contexts, but not for every decorrelation. For table-valued lateral results, a left join inside the derived table can manufacture unwanted NULL rows; the final outer join is often enough.

---

## 9. Summary

The Neumann framework for subquery unnesting is:

1. Build a duplicate-free domain table `D` from the outer bindings referenced by the inner expression.
2. Replace the original dependent join by a regular join between the outer side and `(D ⧑ inner)`.
3. Push `D ⧑` down through the inner algebra tree using operator-specific rules.
4. When the right side no longer depends on outer variables, replace the dependent join by a regular join.
5. Add `D` attributes to grouping and window partitions as needed.
6. Handle scalar, table-valued, outer-join, and NULL semantics explicitly in SQL.
7. Optionally eliminate `D` by substitution when equivalent inner attributes are available and the cost model favors it.

The approach applies to arbitrary correlated SQL expressions at the algebraic level. The 2025 top-down variant improves handling of deep nesting and extends coverage to constructs such as recursive CTEs and `ORDER BY ... LIMIT/OFFSET`.
