# Phase 8: Macro hygiene — span-preserving output parsing & resolver-aware lookup

## 1. Goal

Make the hygiene context that is already carried on macro token trees survive all the way into name resolution, so that:

1. Identifiers introduced by a macro cannot accidentally capture or be captured by user bindings (Rust-style "mixed" hygiene).
2. Captured identifiers (metavariable substitutions) keep the call-site context and resolve normally.
3. Procedural-macro authors can choose `call_site`, `def_site`, or `mixed_site` spans and have those choices honored by the resolver.

This phase depends on the hygiene plumbing finished in Phase 7.

## 2. Scope

### In scope
- A span-preserving converter from `yelang_macro_core::token_tree::TokenStream` to `yelang_lexer::TokenStream<yelang_ast::tokenizer::TokenKind>`.
- Replacing the current render-and-re-tokenize path for macro outputs in `yelang-macro/src/expander.rs`.
- Updating declarative macro transcription to use **mixed** transparency (the Rust `macro_rules!` default) instead of fully opaque transparency.
- Threading `HygieneData` into `yelang-resolve`.
- Storing syntax contexts in resolver `Rib` bindings and `ModuleTree` items.
- A hygiene-aware lookup that compares context ancestry and transparency.
- Comprehensive tests and adversarial cases.

### Out of scope for this phase
- Cross-crate hygiene serialization in metadata (requires rmeta design).
- `Span::def_site()` for procedural macros using the real macro-definition span (the span is not yet threaded through `ResolvedProcMacro`; tracked as a follow-up).
- Full `comptime` evaluation.

## 3. Background & precedents

Rust uses the *Macros That Work Together* (MTWT) hygiene algorithm. The key ideas we adopt:

- Every identifier carries an invisible **syntax context** (a chain of macro-expansion marks).
- A mark records the macro expansion that produced it, its parent context, and a **transparency**:
  - `Opaque` — blocks resolution against bindings from outside the expansion (proc-macro `def_site`).
  - `Transparent` — behaves as if the expansion did not happen (proc-macro `call_site`).
  - `Mixed` — blocks local-variable bindings but allows items/types (Rust `macro_rules!` default).
- A use of an identifier with context `C` can resolve to a binding with context `B` only if `B` is an ancestor of `C` and every mark on the path from `B` to `C` is transparent for that kind of binding in that namespace.

References:

- [The Little Book of Rust Macros — Hygiene](https://lukaswirth.dev/tlborm/decl-macros/minutiae/hygiene.html)
- [Rust Compiler Development Guide — Name resolution](https://rustc-dev-guide.rust-lang.org/name-resolution.html)
- [Rust issue tracking macro hygiene improvements](https://github.com/rust-lang/rust/issues/39412)

## 4. Design principles

- **No silent context loss.** Any code path that turns a macro token tree into AST tokens must preserve `syntax_context`.
- **Fail closed.** If a context comparison cannot be performed, the binding is not visible.
- **Keep the resolver data-parallel.** Each namespace keeps its own rib stack; each binding stores its syntax context independently.
- **Prefer exact project idioms.** Use `yelang_lexer::TokenStream<TokenKind>`, `yelang_macro_core::Span`/`HygieneData`, and the existing `Rib`/`ModuleTree` abstractions.

## 5. Exhaustive file tree

```
crates/compiler/
├── yelang-arena/src/arena.rs              # already exposes ArenaKey::as_u64/from_u64
├── yelang-macro-core/src/
│   ├── hygiene.rs                         # already has HygieneData, insert_expn, update_expn
│   └── id.rs                              # already has ExpnId::raw/from_raw
├── yelang-macro/src/
│   ├── expander.rs                        # replace render+tokenize calls; use span-preserving parser
│   ├── hygiene.rs                         # existing payload serialization (minor additions)
│   ├── parse_macro_output.rs              # NEW: TokenTree -> TokenStream<TokenKind> converter
│   └── transcribe.rs                      # change declarative mark transparency to Mixed
├── yelang-resolve/src/
│   ├── lib.rs                             # accept optional HygieneData in resolve_crate
│   ├── scope.rs                           # add resolve_name_with_context, thread hygiene data
│   ├── rib.rs                             # store (Resolution, syntax_context) per binding
│   ├── module_tree.rs                     # store syntax_context on module items
│   ├── hygiene.rs                         # NEW: context ancestry + transparency filter
│   ├── early.rs, late.rs, path.rs         # pass identifier span.context into lookups
│   └── def_collector.rs                   # record syntax_context when collecting items
└── notes/architectures/
    └── macro_hygiene_phase8_checklist.md  # NEW: implementation + test checklist
```

## 6. Detailed design

### 6.1 Span-preserving macro-output parser

Current macro outputs are rendered to a string and re-tokenized, which drops `syntax_context`. We will replace that with a direct converter.

#### New module: `yelang-macro/src/parse_macro_output.rs`

```rust
pub fn parse_macro_output(
    stream: &yelang_macro_core::token_tree::TokenStream,
    interner: &yelang_interner::Interner,
) -> Result<yelang_lexer::TokenStream<yelang_ast::tokenizer::TokenKind>, ParseMacroOutputError>;
```

Responsibilities:
1. Walk `TokenTree`s recursively.
2. Map identifiers to `TokenKind::Ident` or keyword variants, preserving the `yelang_macro_core::Span` converted to `yelang_lexer::Span`.
3. Map literals to `TokenKind::Lit`.
4. Map groups to the matching open/close delimiter tokens and recurse into the inner stream.
5. Combine adjacent punctuation into compound operators using the same precedence list as the real tokenizer.
6. Combine `SingleQuote` + `Ident` into `TokenKind::Lifetime`.

#### Compound-operator table

The converter greedily matches the longest possible operator at each position. The table is the same one the real tokenizer uses:

- 3-character: `..=`, `<<=`, `>>=`, `<->`
- 2-character: `==`, `&&`, `->`, `..`, `<-`, `<=`, `>=`, `=>`, `::`, `+=`, `-=`, `*=`, `/=`, `%=`, `^=`, `&=`, `|=`, `!=`
- 1-character: everything else.

Note: `||` is intentionally kept as two `Pipe` tokens, matching the existing tokenizer.

#### Identifier keyword mapping

The helper `ident_token_kind(ident: &yelang_lexer::Ident) -> TokenKind` checks `interner.resolve(&ident.symbol)` against the full keyword list and returns the corresponding keyword variant, or `TokenKind::Ident(ident)` for non-keywords. `$crate` / `$package` origins are already resolved by `transcribe.rs`, so the resulting `Ident` simply carries `IdentOrigin::Crate`/`Package`.

#### Literal mapping

| `yelang_macro_core::LitKind` | `yelang_lexer::Literal` |
|---|---|
| `Int { value, suffix }` | `Literal::Int(IntegerLit { value, suffix })` |
| `Float { value, suffix }` | `Literal::Float(FloatLit { value, suffix })` |
| `Str { value, kind }` | `Literal::Str(StringLit { value, kind })` |
| `Char(c)` | `Literal::Char(c)` |
| `Bool(b)` | `Literal::Bool(b)` |
| `ByteStr { value, kind }` | `Literal::Bytes(...)` or `Literal::Str` depending on how byte strings are represented in the AST tokenizer (to be aligned) |
| `Byte(b)` | `Literal::Byte(b)` |

#### Error handling

The converter fails on genuinely invalid macro output (e.g., an unknown punctuation character) with a structured `ParseMacroOutputError` that the expander turns into an `ExpandError`.

### 6.2 Declarative macro transparency

In `yelang-macro/src/expander.rs`, `transcribe_rule` currently creates the generated context with `Transparency::Opaque`. Change it to `Transparency::Mixed`, which matches Rust `macro_rules!` semantics:

- Generated **local bindings** (`let x`) are not visible outside the macro.
- Generated **items/types** are visible outside the macro.
- Captured identifiers keep their original context and resolve normally.

### 6.3 Hygiene-aware name resolution

#### Threading `HygieneData`

`resolve_crate` will gain an optional `hygiene: Option<&HygieneData>` parameter. The macro expander already owns a `HygieneData`; it will pass a reference after expansion. When `None`, the resolver falls back to exact context matching (backward-compatible behavior for callers that do not run macro expansion).

#### Rib changes

`Rib` bindings change from:

```rust
bindings: FxHashMap<Namespace, FxHashMap<Symbol, Resolution>>
```

to:

```rust
bindings: FxHashMap<Namespace, FxHashMap<Symbol, Vec<(u32, Resolution)>>>
```

Each `(syntax_context, Resolution)` pair records the context in which the binding was introduced. `Rib::insert` takes the binding identifier's `syntax_context`.

#### ModuleTree changes

`ModuleTree::Module::items` currently map `(Namespace, Symbol) -> DefId`. Extend it to map to `(DefId, u32)` so module items also carry their syntax context. `def_collector.rs` records `item.name.span.syntax_context()`.

#### Context visibility predicate

New module: `yelang-resolve/src/hygiene.rs`

```rust
pub fn is_visible(
    hygiene: &HygieneData,
    use_context: u32,
    binding_context: u32,
    resolution: &Resolution,
) -> bool;
```

Algorithm:
1. If `use_context == binding_context`, return `true`.
2. Walk from `use_context` toward the root using `HygieneData::syntax_context_data`.
3. For each context on the path, check its `transparency`:
   - `Transparent` → continue.
   - `Opaque` → return `false`.
   - `Mixed` → return `true` for `Resolution::Def` and `Resolution::Import`; return `false` for `Resolution::Local`.
4. If the walk reaches `binding_context`, return `true`.
5. If the walk reaches the root without finding `binding_context`, return `false`.

#### Resolver lookup

Add `Resolver::resolve_name_with_context(ns, name, use_context) -> Option<Resolution>`:

1. Scan ribs from innermost to outermost.
2. For each rib, get all `(ctx, res)` pairs for `(ns, name)`.
3. Return the first `res` for which `is_visible` is true.
4. If no rib matches, scan the module tree and prelude, treating those bindings as context `ROOT_SYNTAX_CONTEXT`.

All call sites that resolve identifiers (path segments, local names, patterns, etc.) are updated to pass `ident.span.syntax_context()`.

## 7. Checklist

### 7.1 Span-preserving parser

- [ ] Create `yelang-macro/src/parse_macro_output.rs`.
- [ ] Implement `parse_macro_output`.
- [ ] Implement identifier → keyword mapping.
- [ ] Implement literal mapping for all `LitKind` variants.
- [ ] Implement group/delimiter recursion.
- [ ] Implement compound-operator combination (greedy, longest-match).
- [ ] Implement `SingleQuote` + `Ident` → `Lifetime`.
- [ ] Replace `parse_items_from_token_stream` render path.
- [ ] Replace `parse_stmts_from_token_stream` render path.
- [ ] Replace `parse_expr_from_token_stream` render path.
- [ ] Replace `parse_type_from_token_stream` render path.
- [ ] Replace `parse_pattern_from_token_stream` render path.
- [ ] Add tests for each token category.
- [ ] Add adversarial tests: unknown punctuation, partial compound operators, empty streams.

### 7.2 Declarative macro transparency

- [ ] Change `transcribe_rule` to `Transparency::Mixed`.
- [ ] Update transcribe unit tests to expect mixed semantics.
- [ ] Add expander test: generated `let` binding does not shadow call-site `let`.
- [ ] Add expander test: generated `fn` item is visible outside the macro.

### 7.3 Resolver hygiene

- [ ] Add `HygieneData` parameter to `resolve_crate`.
- [ ] Update `Rib` to store `(syntax_context, Resolution)`.
- [ ] Update `ModuleTree` item storage to `(DefId, syntax_context)`.
- [ ] Create `yelang-resolve/src/hygiene.rs` with `is_visible`.
- [ ] Implement `resolve_name_with_context`.
- [ ] Update all identifier-resolution call sites to pass `syntax_context`.
- [ ] Update `def_collector.rs` to record item syntax contexts.
- [ ] Add resolver tests for opaque/transparent/mixed marks.
- [ ] Add adversarial tests: malformed context chains, missing hygiene data, deeply nested contexts.

### 7.4 Final verification

- [ ] `cargo fmt --all`
- [ ] `cargo test --workspace`
- [ ] `cargo clippy -p yelang-macro -p yelang-resolve -p yelang-macro-core -p yelang-lexer -p yelang-ast`
- [ ] Update design doc if any assumptions changed during implementation.

## 8. Test matrix

| Scenario | Expected behavior |
|---|---|
| Macro expands to `let x = 1; x` and call site has `let x = 2;` | The two `x`s have different contexts; no collision; call-site `x` still resolves to its own binding. |
| Macro captures `x` from call site and returns `x` | Captured `x` keeps call-site context and resolves to call-site binding. |
| Macro defines `fn helper() {}` and call site calls `helper()` | Generated `helper` has mixed context; visible outside; resolves. |
| Proc-macro emits token with `Span::call_site()` | Token has call-site context; resolves like user-written code. |
| Proc-macro emits token with `Span::def_site()` | Token has def-site opaque context; does not resolve to call-site bindings. |
| Nested macro `outer! { inner! { x } }` | Final `x` context is a descendant of both outer and inner marks. |
| Compound operator `+=` produced by macro | Converted to single `PlusEqual` token, not `+` `=`. |
| Lifetime `'a` produced by macro | Converted to `Lifetime('a)`. |
| Unknown character emitted by buggy proc macro | `ParseMacroOutputError` reported cleanly. |

## 9. Risks & mitigations

| Risk | Mitigation |
|---|---|
| Compound-operator combination differs from the real tokenizer. | Reuse the exact operator table and order from `yelang-ast/src/tokenizer/tokens/tokenize.rs`; add round-trip tests against the real tokenizer. |
| Keyword mapping misses a contextual keyword. | Centralize keyword lookup and compare against the existing `KEYWORDS` array; add snapshot/insta tests. |
| Resolver changes break existing resolution tests. | Keep exact-match fallback when `HygieneData` is absent; add new tests before changing behavior. |
| Performance of context-chain walks in hot resolver paths. | Cache context-parent lookups inside `Resolver` if profiling shows it matters; do not optimize prematurely. |

## 10. Open questions

1. How should byte-string literals be represented in `yelang_lexer::Literal`? The current AST tokenizer may not have a perfect mirror for `LitKind::ByteStr`; this needs alignment before mapping.
2. Should we store `HygieneData` in `ResolvedCrate` so later passes (HIR lowering, type check) can query context chains? Probably yes, but this phase focuses on resolution.
3. Do we want to support the real proc-macro `def_site` span before cross-crate hygiene? Recommendation: keep `def_site` = call-site fallback for now and land the parser/resolver changes first.
