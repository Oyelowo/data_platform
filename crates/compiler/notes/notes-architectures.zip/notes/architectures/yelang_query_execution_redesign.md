# Yelang Query Execution Redesign

> Status: design proposal awaiting sign-off  
> Scope: everything from typed HIR down to distributed physical execution, with the stdlib written in `.ye`.

## 1. Why this redesign is necessary

The current implementation has accumulated bridging code that duplicates semantics in Rust:

- `yelang-qir/src/logical/aggregate_impl.rs` hand-builds `init`/`iterate`/`merge`/`finalize` closures for `Sum`, `Avg`, `Count`, etc., by string-matching marker names and allocating magic field-symbol IDs.
- `yelang-qir/src/logical/queryable.rs` contains a hardcoded enum of `QueryableMethod`s and a giant `match` that builds logical operators by hand.
- Query syntax (`select sum(x) from xs@x`) was being lowered by desugaring it to a method call (`xs.sum()`), which is backwards: query syntax is the declarative source of truth.
- `yelang-hir/src/derive/helpers.rs` synthesizes `DefId`s for derived impl items instead of allocating them through the same arena/slotmap mechanism used for source items.
- `Queryable` is conflated with `Iterator` and concrete collections (`Array<T>`). It should be a compiler-known abstraction over *query plans*, not over ordinary arrays.

The goal is to return to first principles:

1. The stdlib (`Queryable`, `Iterator`, `Aggregate`) is written in `.ye`.
2. The compiler parses, resolves, and type-checks the stdlib through the real pipeline.
3. A **THIR** (Typed High-level IR) sits between HIR and QIR and is the canonical place to lower query syntax and extract operator shapes from typed stdlib bodies.
4. QIR/LIR/PIR/Exec are clean layers: logical plan, physical plan, and runtime plan.

---

## 2. THIR: the missing layer between HIR and QIR

Rust uses THIR as a lowered, fully-typed version of HIR that exists only while a body is being lowered to MIR or checked for exhaustiveness/unsafety . THIR is simpler than HIR: method calls and overloaded operators are already converted into ordinary `Call` instances, and it only represents executable bodies.

We should adopt the same idea.

### 2.1 What lives in each layer

| Layer | Purpose | Lifetime |
|-------|---------|----------|
| **AST** | Surface syntax, sugar, spans | Whole crate |
| **HIR** | Name-resolved item tree; types may still be inference variables | Whole crate |
| **THIR** | Fully typed, desugared bodies; method calls -> function calls; query syntax -> `Query(QueryId)` referencing the side table | Per body, on demand |
| **QIR/LIR** | Logical query plan: scan, filter, map, aggregate, group, exchange | Whole query |
| **PIR** | Physical plan: memory, storage, distributed, stream backends | Whole query |
| **Exec** | Runtime operator tree / bytecode | Per execution |

### 2.2 Why THIR specifically helps us

1. **Query syntax lowering**: `select users@u[*].id from users@u:User` is surface syntax. In THIR it becomes `ThirExpr::Query(QueryId)`. The `Query` data (projection, from, links, where, group, order, range) lives in a side table, exactly as it does in HIR. THIR does not contain pipeline operators.
2. **Method-call desugaring**: `xs.sum()` becomes `Queryable::aggregate(xs, Sum)` in THIR, indistinguishable from a user-written call. QIR no longer needs a `QueryableMethod` enum.
3. **Impl body extraction**: `impl Aggregate<i32, SumAcc<i32>, i32> for Sum` is type-checked as ordinary Rust-like code. THIR exposes its `init`/`iterate`/`merge`/`finalize` bodies as typed THIR expressions that QIR can lower like any other closure.
4. **Single source of truth**: the `.ye` stdlib is the only place where `sum`, `avg`, `filter`, `map`, etc. are defined. Rust code only knows the *lang items* and the *operator shapes* that the compiler derives from them.
5. **Clean boundary**: THIR is still an expression IR. The QIR layer is the first place that thinks in operators (`Scan`, `Filter`, `Map`, etc.).

### 2.3 THIR data model (sketch)

```rust
// yelang-thir/src/expr.rs
pub enum ThirExpr {
    Literal(ThirLit),
    Var(DefId),
    Field { base: ThirExprId, field: Symbol },
    Call { func: ThirExprId, args: Vec<ThirExprId> },
    Closure { params: Vec<ThirPatId>, body: ThirExprId },
    Block { stmts: Vec<ThirStmt>, tail: Option<ThirExprId> },
    Query(QueryId),           // select ... from ...; data lives in side table
    // ... all other expression forms, no method calls, no query syntax
}
```

Query operators (`Scan`, `Filter`, `Map`, etc.) do **not** appear in THIR. They appear only in QIR/LIR. In THIR, a queryable pipeline is represented as a combination of:

- `ThirExpr::Query(QueryId)` for the `select ... from ...` form.
- `@intrinsic(query_filter(...))`, `@intrinsic(query_map(...))`, etc. calls inside the `.ye` stdlib bodies. From THIR's perspective these are ordinary function calls to compiler-recognized intrinsics.

The QIR extractor walks THIR and recognizes:

1. `ThirExpr::Query(QueryId)` — lower the query side table entry to a LIR subplan.
2. `@intrinsic(query_*)` calls — emit the corresponding LIR operator.
3. Ordinary function calls to `Aggregate` trait methods — emit `Aggregate` operator using the THIR bodies of the marker's impl.

> Note: THIR is not a query-only IR. It is the general body IR. Query operators are first constructed in QIR.

### 2.4 Expressions in query plans are ordinary THIR functions

You are right: expressions inside queries should not be a special, restricted subset of the language. A predicate like `u.age > 18`, a projection like `{ id: u.id, age: u.age }`, and an aggregate per-row function are all ordinary expressions.

Therefore, QIR operators do **not** hold a special `QExpr` type. They hold references to typed **THIR bodies** (closures/functions):

```rust
// yelang-qir/src/logical/operator.rs
pub struct Filter {
    pub input: LirId,
    pub pred: ThirBodyId,   // a typed THIR closure: |row| bool
}

pub struct Map {
    pub input: LirId,
    pub projection: ThirBodyId,  // a typed THIR closure: |row| U
}
```

`ThirBodyId` points to a THIR body stored in the query plan's THIR arena. That body can contain any valid THIR expression: literals, field access, arithmetic, method calls, even local control flow.

The query optimizer then **analyzes** these THIR bodies to decide what it can optimize:

- A predicate analysis pass recognizes simple patterns (literals, field access, comparisons, boolean combinations) and marks the predicate as *pushable*.
- A projection analysis pass extracts which fields/columns are accessed.
- An effect analysis pass determines whether a closure is pure/deterministic.
- Complex closures that the optimizer does not fully understand are left in place and compiled normally through MIR.

This mirrors how production compilers optimize: the IR is general, and specialized passes recognize optimizable patterns rather than restricting the input language.

Example: the predicate `|u| u.age > 18` is just a THIR closure body:

```rust
ThirExpr::Binary(
    Gt,
    ThirExpr::Field(ThirExpr::Var(u), age),
    ThirExpr::Literal(Int(18)),
)
```

The optimizer sees this and decides it can be pushed down. A more complex predicate like `|u| expensive_hash(u.name) in allowed_set` is still a valid THIR closure; the optimizer may decide it is not pushable and leave it where it is.

This removes `QExpr` entirely from the design. Query operators hold THIR bodies; MIR remains the single codegen target for all expressions.

---

## 3. Surface semantics (grounded in the existing notes)

The existing notes establish these non-negotiable rules:

- **Projection determines the result shape** (`select <expr>`). `select 1 from users@u:User` returns `1`.
- **No implicit row-by-row mapping** from `from` into the projection. Per-element results require explicit selectors: `[*]`, `[where ...]`, `[n]`, slices, `[**]`.
- **`from` introduces root collections** with a collection label (`users`) and an item binder (`@u`).
- **`links` is correlated traversal**, not a general join. It materializes nested arrays at the syntactic level where labels are written (`strict locality`).
- **Stage-affecting modifiers** (`from ... where ... order by ... range ...`, pipeline `where`, `group by`) change what later pipeline stages see.
- **Value-level selectors** (`users@u[where ...][0..10]`) transform an already-existing collection value and do not retroactively constrain earlier stages.
- **Range does not change types**. Whether the result is an array or scalar is still determined solely by the projection.
- **Grouping produces a new collection of group objects** (keys + members). "Having" is just filtering the `groups` collection in projection.

These rules are the contract that every IR layer must preserve.

---

## 4. Stdlib in `.ye`

The standard library for iteration, queryability, and aggregation must be ordinary `.ye` source that goes through the same parser, resolver, type checker, and THIR lowerer as user code.

### 4.1 `Iterator<T>`

A regular trait for concrete, immediate, single-node iteration. Not a lang item.

```ye
// stdlib/core/iter.ye

trait Iterator<T> {
    fn next(self: &mut Self) -> Option<T>;

    fn map<U>(self, f: impl Fn(T) -> U) -> Map<Self, T, U>
    where Self: Sized {
        Map { iter: self, f }
    }

    fn filter(self, pred: impl Fn(&T) -> bool) -> Filter<Self, T>
    where Self: Sized {
        Filter { iter: self, pred }
    }

    fn fold<U>(self, init: U, f: impl Fn(U, T) -> U) -> U
    where Self: Sized {
        let mut acc = init;
        while let Some(x) = self.next() {
            acc = f(acc, x);
        }
        acc
    }

    fn collect<C>(self) -> C
    where C: FromIterator<T>, Self: Sized {
        C::from_iter(self)
    }
}
```

### 4.2 `IntoIterator<T>` and `[T]`

Slices (`[T]`) and arrays (`Array<T>`) implement `IntoIterator<T>`, not `Iterator<T>` directly. `for` loops and explicit `.iter()` use this.

```ye
// stdlib/core/iter.ye

trait IntoIterator<T> {
    fn into_iter(self) -> impl Iterator<T>;
}

impl<T> IntoIterator<T> for [T] {
    fn into_iter(self) -> SliceIter<T> { ... }
}

impl<T, const N: usize> IntoIterator<T> for Array<T, N> {
    fn into_iter(self) -> ArrayIter<T, N> { ... }
}
```

### 4.3 `Queryable<T>`

A **lang-item trait** that represents a lazy, optimizable, backend-aware pipeline. It is implemented by query-plan wrapper types, not by raw arrays.

```ye
// stdlib/core/queryable.ye

@lang("queryable")
trait Queryable<T> {
    fn map<U>(self, f: impl Fn(T) -> U) -> impl Queryable<U>;
    fn filter(self, pred: impl Fn(&T) -> bool) -> impl Queryable<T>;
    fn flat_map<U>(self, f: impl Fn(T) -> impl Queryable<U>) -> impl Queryable<U>;

    fn aggregate<A, Acc, Out>(self, agg: A) -> Out
    where A: Aggregate<T, Acc, Out>;

    fn sum(self) -> T
    where T: Add + Zero, Self: Sized {
        self.aggregate(Sum)
    }

    fn avg(self) -> f64
    where T: Numeric, Self: Sized {
        self.aggregate(Avg)
    }

    fn count(self) -> usize
    where Self: Sized {
        self.aggregate(Count)
    }

    fn take(self, n: usize) -> impl Queryable<T>;
    fn skip(self, n: usize) -> impl Queryable<T>;
    fn order_by(self, key: impl Fn(&T) -> impl Ord) -> impl Queryable<T>;
    fn distinct(self) -> impl Queryable<T>;
    fn group_by<K>(self, key: impl Fn(&T) -> K) -> impl Queryable<Group<K, T>>;

    fn execute(self) -> Vec<T>;
}
```

Concrete implementations:

```ye
// stdlib/infra/query/query_array.ye
struct QueryArray<T> {
    plan: PlanId,  // opaque compiler/runtime handle
}

impl<T> Queryable<T> for QueryArray<T> {
    fn map<U>(self, f: impl Fn(T) -> U) -> impl Queryable<U> {
        QueryArray { plan: @intrinsic(query_map(self.plan, f)) }
    }

    fn filter(self, pred: impl Fn(&T) -> bool) -> impl Queryable<T> {
        QueryArray { plan: @intrinsic(query_filter(self.plan, pred)) }
    }

    fn aggregate<A, Acc, Out>(self, agg: A) -> Out
    where A: Aggregate<T, Acc, Out> {
        @intrinsic(query_aggregate(self.plan, agg))
    }

    // ...
}
```

The `@intrinsic(...)` calls are the hook: the compiler recognizes these intrinsics and emits QIR operators instead of ordinary function calls. The `.ye` bodies remain the authoritative definition of each method's operator shape.

### 4.4 `Aggregate<T, Acc, Out>`

A **lang-item trait** that defines aggregation algebra.

```ye
// stdlib/core/aggregate.ye

@lang("aggregate")
trait Aggregate<T, Acc, Out> {
    fn init(self: &Self) -> Acc;
    fn iterate(self: &Self, acc: Acc, value: T) -> Acc;
    fn merge(self: &Self, left: Acc, right: Acc) -> Acc;
    fn finalize(self: &Self, acc: Acc) -> Out;
    fn classify(self: &Self) -> AggregateClass;
}

enum AggregateClass {
    Distributive,
    Algebraic,
    Holistic,
}
```

Built-in aggregates:

```ye
// stdlib/core/aggregate_impls.ye

struct Sum;
struct SumAcc<T> { value: T }

impl<T: Add + Zero> Aggregate<T, SumAcc<T>, T> for Sum {
    fn init(self: &Self) -> SumAcc<T> { SumAcc { value: T::zero() } }
    fn iterate(self: &Self, acc: SumAcc<T>, value: T) -> SumAcc<T> {
        SumAcc { value: acc.value + value }
    }
    fn merge(self: &Self, a: SumAcc<T>, b: SumAcc<T>) -> SumAcc<T> {
        SumAcc { value: a.value + b.value }
    }
    fn finalize(self: &Self, acc: SumAcc<T>) -> T { acc.value }
    fn classify(self: &Self) -> AggregateClass { AggregateClass::Distributive }
}

struct Avg;
struct AvgAcc<T> { sum: T, count: usize }

impl<T: Add + Zero + ToF64> Aggregate<T, AvgAcc<T>, f64> for Avg {
    fn init(self: &Self) -> AvgAcc<T> { AvgAcc { sum: T::zero(), count: 0 } }
    fn iterate(self: &Self, acc: AvgAcc<T>, value: T) -> AvgAcc<T> {
        AvgAcc { sum: acc.sum + value, count: acc.count + 1 }
    }
    fn merge(self: &Self, a: AvgAcc<T>, b: AvgAcc<T>) -> AvgAcc<T> {
        AvgAcc { sum: a.sum + b.sum, count: a.count + b.count }
    }
    fn finalize(self: &Self, acc: AvgAcc<T>) -> f64 {
        acc.sum.to_f64() / acc.count as f64
    }
    fn classify(self: &Self) -> AggregateClass { AggregateClass::Algebraic }
}
```

The compiler never string-matches `Sum` or `Avg`. It type-checks these impls, lowers their bodies to THIR, and the QIR extractor uses the THIR bodies directly. The only special knowledge the compiler has is the `#[lang("aggregate")]` trait and the `@intrinsic` query hooks.

### 4.5 User-defined collection methods

Users can extend the query system in three ways, without any hardcoded operator list:

#### 4.5.1 Custom aggregates

Implement the `Aggregate` trait and use it through `aggregate`:

```ye
struct GeoMean;
struct GeoMeanAcc<T> { product: T, count: usize }

impl<T: Mul + Pow> Aggregate<T, GeoMeanAcc<T>, f64> for GeoMean {
    fn init(self: &Self) -> GeoMeanAcc<T> { GeoMeanAcc { product: T::one(), count: 0 } }
    fn iterate(self: &Self, acc, value) -> GeoMeanAcc<T> {
        GeoMeanAcc { product: acc.product * value, count: acc.count + 1 }
    }
    fn merge(self: &Self, a, b) -> GeoMeanAcc<T> {
        GeoMeanAcc { product: a.product * b.product, count: a.count + b.count }
    }
    fn finalize(self: &Self, acc) -> f64 {
        acc.product.powf(1.0 / acc.count as f64)
    }
    fn classify(self: &Self) -> AggregateClass { AggregateClass::Algebraic }
}

let gm = users.map(|u| u.salary).aggregate(GeoMean);
```

Because `GeoMean` implements `Aggregate`, the planner knows from `classify()` that it is Algebraic and can generate a partial+merge distributed plan automatically. PostgreSQL and MariaDB support similar user-defined aggregate registration via `CREATE AGGREGATE FUNCTION` ; here the same capability is provided by ordinary trait implementation.

#### 4.5.2 Compositional queryable methods

Users can write ordinary functions that compose existing `Queryable` methods:

```ye
fn active_adults<U>(users: impl Queryable<U>) -> impl Queryable<U>
where U: HasAge + HasActive {
    users.filter(|u| u.active).filter(|u| u.age >= 18)
}

let ids = active_adults(users).map(|u| u.id);
```

These lower to the same QIR operators as hand-written chains because the function bodies are inlined or lowered at the call site.

#### 4.5.3 New primitive pipeline operators

If a user wants a pipeline operator that the stdlib does not provide (e.g., a custom window or sample operator), they write an extension trait whose method body calls a new `@intrinsic`:

```ye
@lang("queryable_ext")
trait QueryableSampleExt<T> {
    fn reservoir_sample(self, k: usize, seed: u64) -> impl Queryable<T>;
}

impl<T> QueryableSampleExt<T> for QueryArray<T> {
    fn reservoir_sample(self, k: usize, seed: u64) -> impl Queryable<T> {
        QueryArray { plan: @intrinsic(query_reservoir_sample(self.plan, k, seed)) }
    }
}
```

The compiler recognizes `@intrinsic(query_reservoir_sample)` and the QIR extractor emits a corresponding LIR operator. The user provides the PIR/Exec lowering for that operator through a backend plugin or by contributing it to the stdlib. This mirrors how extensible optimizers like Calcite and Orca add new `RelNode` types and transformation rules .

---

## 5. Query syntax is canonical; method calls desugar to it

### 5.1 Query syntax lowers directly to operators

```ye
select users@u[*].age
from users@u:User
where u.age > 18
```

THIR:

```rust
// The `select ... from ...` surface form becomes a ThirExpr::Query.
// The Query data (projection, from, where, etc.) lives in a side table
// and is lowered to LIR operators by the QIR extractor.
ThirExpr::Query(query_id)
```

QIR/LIR:

```rust
let users = Scan(Table("users"));
let filtered = Filter(users, |u| u.age > 18);
let projected = Map(filtered, |u| u.age);
```

### 5.2 Method calls desugar to query syntax / queryable intrinsics

```ye
users.filter(|u| u.age > 18).map(|u| u.age)
```

THIR:

```rust
let q = Queryable::filter(QueryArray(users), |u| u.age > 18);
Queryable::map(q, |u| u.age)
```

Because `Queryable::filter` and `Queryable::map` bodies contain `@intrinsic(query_filter(...))` and `@intrinsic(query_map(...))`, the QIR extractor sees the intrinsics and emits the same operators as the query-syntax form.

This is the opposite of the current code, which lowered `select sum(x) from xs@x` to `xs.sum()`. Query syntax is primary; method calls are sugar.

---

## 6. LIR / QIR / PIR / Exec architecture

```text
compiler/
├── yelang-hir/              # Name-resolved item tree
├── yelang-thir/             # NEW: typed, desugared bodies
│   ├── src/
│   │   ├── lib.rs
│   │   ├── expr.rs          # ThirExpr, ThirStmt, ThirPat
│   │   ├── lower.rs         # HIR -> THIR
│   │   ├── query.rs         # query syntax -> operator expr
│   │   └── operator.rs      # PipelineOp enum
│   └── tests/
├── yelang-qir/              # Logical + physical query plans
│   ├── src/
│   │   ├── lib.rs
│   │   ├── expr.rs          # operator properties and THIR body refs
│   │   ├── ids.rs           # LirId, PirId, BinderId, etc.
│   │   ├── logical/         # LIR
│   │   │   ├── mod.rs
│   │   │   ├── plan.rs      # LogicalPlan, LogicalOp
│   │   │   ├── lower.rs     # THIR -> LIR
│   │   │   ├── operator.rs  # LogicalOp enum
│   │   │   ├── properties.rs
│   │   │   ├── rewrite/     # logical rewrites
│   │   │   │   ├── mod.rs
│   │   │   │   ├── pushdown.rs
│   │   │   │   ├── decorrelate.rs
│   │   │   │   ├── unnest.rs
│   │   │   │   ├── simplify.rs
│   │   │   │   └── merge.rs
│   │   │   └── extract.rs   # extract query operators from THIR intrinsics
│   │   ├── physical/        # PIR
│   │   │   ├── mod.rs
│   │   │   ├── plan.rs
│   │   │   ├── operator.rs
│   │   │   ├── enforcer.rs  # distribution / ordering / singleton enforcers
│   │   │   ├── backend/
│   │   │   │   ├── memory.rs
│   │   │   │   ├── storage.rs
│   │   │   │   ├── distributed.rs
│   │   │   │   └── stream.rs
│   │   │   └── lower.rs     # LIR -> PIR
│   │   ├── exec/            # Runtime operators
│   │   │   ├── mod.rs
│   │   │   ├── plan.rs
│   │   │   ├── operator.rs
│   │   │   ├── vm.rs
│   │   │   ├── codegen.rs
│   │   │   └── lower.rs     # PIR -> Exec
│   │   ├── types.rs
│   │   └── errors.rs
│   └── tests/
└── stdlib/
    ├── core/
    │   ├── queryable.ye
    │   ├── aggregate.ye
    │   ├── aggregate_impls.ye
    │   ├── iter.ye
    │   ├── slice.ye
    │   └── array.ye
    └── infra/
        ├── query/
        │   ├── query_array.ye
        │   ├── query_slice.ye
        │   └── query_storage.ye
        ├── storage/
        │   └── lsm.ye
        └── stream.ye
```

### 6.1 LIR (Logical IR)

```rust
// yelang-qir/src/logical/operator.rs

pub enum LogicalOp {
    Scan { source: ScanSource },
    Filter { input: LirId, pred: ThirBodyId },
    Map { input: LirId, projection: ThirBodyId },
    FlatMap { input: LirId, projection: ThirBodyId },
    Project { input: LirId, projection: ThirBodyId },   // record/struct construction
    Construct { fields: Vec<(Symbol, LirId)> },      // multi-root facet
    Aggregate { input: LirId, agg: AggregateOp },
    GroupBy { input: LirId, key: ThirBodyId, into: Symbol },
    OrderBy { input: LirId, keys: Vec<OrderKey> },
    Slice { input: LirId, start: Option<usize>, end: Option<usize>, inclusive: bool },
    Distinct { input: LirId, key: Option<ThirBodyId> },
    Join { kind: JoinKind, left: LirId, right: LirId, on: Option<ThirBodyId> },
    Apply { kind: ApplyKind, left: LirId, right: LirId },  // correlated subquery
    Exchange { input: LirId, kind: ExchangeKind },
    Gather { input: LirId },
    Materialize { input: LirId },
}

pub enum ScanSource {
    Table { name: Symbol },
    Link { base: LirId, edge: Symbol, direction: LinkDirection },
    Expr(ThirBodyId),
}

pub struct AggregateOp {
    pub agg_def: DefId,           // the Aggregate marker type
    pub per_row: ThirBodyId,         // optional per-row projection
    pub class: AggregateClass,
    pub elem_ty: TyId,
    pub acc_ty: TyId,
    pub out_ty: TyId,
}
```

### 6.2 PIR (Physical IR)

```rust
// yelang-qir/src/physical/operator.rs

pub enum PhysicalOp {
    // Sources
    TableScan { table: Symbol, columns: Vec<Symbol> },
    StorageScan { handle: StorageHandle, projection: Vec<Symbol> },
    Values { rows: Vec<ThirBodyId> },

    // Local operators
    Filter { input: PirId, pred: ThirBodyId },
    Map { input: PirId, projection: ThirBodyId },
    FlatMap { input: PirId, projection: ThirBodyId },
    Project { input: PirId, projection: ThirBodyId },
    HashAggregate { input: PirId, groups: Vec<ThirBodyId>, aggs: Vec<PhysicalAggregate> },
    SortAggregate { input: PirId, groups: Vec<ThirBodyId>, aggs: Vec<PhysicalAggregate> },
    Sort { input: PirId, keys: Vec<OrderKey> },
    Slice { input: PirId, start: usize, end: usize },
    Distinct { input: PirId, key: Vec<ThirBodyId> },

    // Joins
    NestedLoopJoin { kind: JoinKind, left: PirId, right: PirId, on: ThirBodyId },
    HashJoin { kind: JoinKind, left: PirId, right: PirId, left_key: ThirBodyId, right_key: ThirBodyId },
    MergeJoin { kind: JoinKind, left: PirId, right: PirId, keys: Vec<MergeKey> },
    SemiJoin { left: PirId, right: PirId, keys: Vec<ThirBodyId> },
    AntiJoin { left: PirId, right: PirId, keys: Vec<ThirBodyId> },
    MarkJoin { left: PirId, right: PirId, keys: Vec<ThirBodyId>, marker: Symbol },

    // Distribution
    Exchange { input: PirId, partitioning: Partitioning },
    Broadcast { input: PirId },
    Shuffle { input: PirId, keys: Vec<ThirBodyId> },
    Gather { input: PirId },
    Repartition { input: PirId, partitioning: Partitioning },

    // Execution properties
    Enforce { input: PirId, property: PhysicalProperty },
}

pub enum PhysicalAggregate {
    Partial { agg_def: DefId },
    Final { agg_def: DefId },
    Full { agg_def: DefId },
}
```

### 6.3 Exec (Runtime)

```rust
// yelang-qir/src/exec/operator.rs

pub enum ExecOp {
    Scan(ScanSpec),
    Filter(ClosureHandle),
    Map(ClosureHandle),
    FlatMap(ClosureHandle),
    Aggregate(AggregateSpec),
    GroupBy(GroupBySpec),
    OrderBy(OrderBySpec),
    Slice(Range<usize>),
    HashJoin(JoinSpec),
    Exchange(ExchangeSpec),
    Gather,
    // ...
}

pub struct AggregateSpec {
    pub init: ClosureHandle,
    pub iterate: ClosureHandle,
    pub merge: ClosureHandle,
    pub finalize: ClosureHandle,
    pub class: AggregateClass,
}
```

### 6.4 Query algebra

The LIR operators are not arbitrary; they are instantiations of a small algebra inspired by MRQL's `cmap` and `groupBy` . MRQL achieves MapReduce completeness with just these higher-order operators plus a generalized join that can nest results instead of flattening them. Our algebra is:

```text
map(f)(X)        = { f(x) | x ∈ X }
filter(p)(X)     = { x | x ∈ X ∧ p(x) }
flat_map(f)(X)   = ⋃ { f(x) | x ∈ X }        (cmap)
group_by(k)(X)   = { (k, { x | x ∈ X ∧ k(x)=k }) | k ∈ image(k, X) }
aggregate(a)(X)  = a.finalize(fold(a.init, a.iterate, X))
order_by(k)(X)   = X sorted by k
slice(r)(X)      = X[r]
```

All other surface forms (`[*]`, `[where ...]`, `[**]`, `links`, nested `select`) lower to combinations of these. For example:

- `users@u[*].age` -> `map(|u| u.age)(users)`
- `users@u[where u.age > 18]` -> `filter(|u| u.age > 18)(users)`
- `u.writes@w[*].books@b[**]` -> `flat_map(|w| flat_map(|b| b)(w.books))(u.writes)`
- `group by { city: u.city } into groups` -> `group_by(|u| { city: u.city })(users)`

This algebraic foundation makes optimization and correctness reasoning straightforward: every rewrite is an algebraic equivalence.

### 6.5 End-to-end trace

Take this query:

```ye
select users@u[*].{
    id: u.id,
    age: u.age,
}
from users@u:User
where u.age > 18
order by u.age desc
range ..10
```

**AST:** A `Select` query node with projection, from, where, order_by, and range clauses. The projection is a comprehension `users@u[*].{ id: u.id, age: u.age }`.

**HIR:**
- `Expr::Query(QueryId)` where `QueryId` points to a side-table `Query`.
- The `Query` stores: `projection`, `from: [FromItem { label: "users", binder: u, ty: User }]`, `where_clause: Some(u.age > 18)`, `order_by: [u.age desc]`, `range: Some(..10)`.
- Names are resolved: `u` -> `PatId`, `users` -> `users` collection label.

**THIR:**
- `ThirExpr::Query(query_id)` with the same side table.
- The predicate `u.age > 18`, projection `{ id: u.id, age: u.age }`, and order key `u.age` are typed THIR expressions (closures over binder `u`).

**QIR extraction (HIR/THIR -> LIR):**

The QIR extractor allocates THIR bodies for each closure and stores them in the plan's THIR arena. It then builds LIR operators that reference those bodies by `ThirBodyId`.

```rust
// THIR body for the filter predicate: |u| u.age > 18
let pred_body = plan.alloc_thir_body(ThirExpr::Closure {
    params: [u],
    body: ThirExpr::Binary(
        Gt,
        ThirExpr::Field(ThirExpr::Var(u), age),
        ThirExpr::Literal(Int(18)),
    ),
});

// THIR body for the order key: |u| u.age
let order_key_body = plan.alloc_thir_body(ThirExpr::Closure {
    params: [u],
    body: ThirExpr::Field(ThirExpr::Var(u), age),
});

// THIR body for the projection: |u| { id: u.id, age: u.age }
let proj_body = plan.alloc_thir_body(ThirExpr::Closure {
    params: [u],
    body: ThirExpr::Record(vec![
        ("id", ThirExpr::Field(ThirExpr::Var(u), id)),
        ("age", ThirExpr::Field(ThirExpr::Var(u), age)),
    ]),
});

let users = plan.scan(ScanSource::Table("users"), user_ty);
let filtered = plan.filter(users, pred_body, user_ty);
let ordered = plan.order_by(
    filtered,
    vec![OrderKey { body: order_key_body, dir: Desc, nulls: Last }],
    user_ty,
);
let sliced = plan.slice(ordered, None, Some(10), false, user_ty);
let projected = plan.map(sliced, proj_body, output_ty);
```

**Logical rewrites:**
- Predicate pushdown: the filter is already directly above the scan.
- Projection pushdown: the projection happens after slice, so no columns can be pruned from the scan (id and age are both used).
- Constant folding: none applicable.

**LIR -> PIR (memory backend, single node):**

```rust
let users = PhysicalOp::TableScan { table: "users", columns: [id, age] };
let filtered = PhysicalOp::Filter { input: users, pred: ... };
let ordered = PhysicalOp::Sort { input: filtered, keys: [...] };
let sliced = PhysicalOp::Slice { input: ordered, start: 0, end: 10 };
let projected = PhysicalOp::Project { input: sliced, projection: ... };
```

**PIR -> Exec:**

```rust
let users = ExecOp::Scan(TableScanSpec { table: "users", columns: [id, age] });
let filtered = ExecOp::Filter(ClosureHandle(filter_age));
let ordered = ExecOp::OrderBy(OrderBySpec { key: closure_age_desc });
let sliced = ExecOp::Slice(0..10);
let projected = ExecOp::Project(ClosureHandle(project_record));
```

**Execution (concrete data):**

Input `users` table:

| id | age |
|---|---|
| 1 | 12 |
| 2 | 25 |
| 3 | 30 |
| 4 | 17 |
| 5 | 45 |

1. **Scan** reads all rows: `[(1,12), (2,25), (3,30), (4,17), (5,45)]`.
2. **Filter** applies `|u| u.age > 18`: `[(2,25), (3,30), (5,45)]`.
3. **Sort** by `age` descending: `[(5,45), (3,30), (2,25)]`.
4. **Slice** first 10: `[(5,45), (3,30), (2,25)]` (all remain).
5. **Project** to `{ id, age }`: `[{ id: 5, age: 45 }, { id: 3, age: 30 }, { id: 2, age: 25 }]`.
6. Return that array.

At every step, the operator invokes the relevant `ThirBodyId` closure via the runtime's closure-call mechanism, using the current row as the argument. The closures are ordinary THIR functions that compile through MIR like any other function.

---

## 7. Links and joins

The surface language does not have an explicit `JOIN` keyword. `links` expresses correlated graph traversal, and `nested select` expresses explicit correlation. Both lower to **join operators** in LIR/PIR. Correlated subqueries are handled by the decorrelation pass described in §9.

### 7.1 Surface `links` -> LIR

```ye
from users@u:User
links (users)->[writes@w:UserWritesBook]->(books@b:Book)
select users@u[*].{
    id,
    books: u.writes@w[*].books@b[**].{ title }
}
```

LIR (conceptual):

```rust
let users = Scan(Table("users"));
let linked = NestJoin {
    left: users,
    left_key: |u| u.id,
    right: Scan(Table("UserWritesBook")),
    right_key: |w| w._from,
    nest_label: "writes",
    // For each user, collect matching writes as a nested array
};
let with_books = NestJoin {
    left: linked,
    left_key: |w| w._to,  // edge target
    right: Scan(Table("books")),
    right_key: |b| b.id,
    nest_label: "books",
    nest_under: "writes",  // strict locality: books attach under edges
};
Map(with_books, |u| {
    id: u.id,
    books: flat_map(u.writes, |w| w.books).map(|b| { title: b.title })
})
```

The `NestJoin` operator is a hash/merge join that builds a nested structure instead of a flat tuple. It is the LIR equivalent of nested relational algebra's `nest` operator combined with join .

### 7.2 Join operators in LIR/PIR

```rust
pub enum LogicalOp {
    // ... existing operators ...
    NestedLoopJoin { kind: JoinKind, left: LirId, right: LirId, on: ThirBodyId },
    HashJoin { kind: JoinKind, left: LirId, right: LirId, left_key: ThirBodyId, right_key: ThirBodyId },
    MergeJoin { kind: JoinKind, left: LirId, right: LirId, keys: Vec<MergeKey> },
    SemiJoin { left: LirId, right: LirId, keys: Vec<ThirBodyId> },
    AntiJoin { left: LirId, right: LirId, keys: Vec<ThirBodyId> },
    MarkJoin { left: LirId, right: LirId, keys: Vec<ThirBodyId>, marker: Symbol },
    NestJoin { left: LirId, right: LirId, left_key: ThirBodyId, right_key: ThirBodyId, nest_label: Symbol, nest_under: Option<Symbol> },
}
```

| Join kind | Use case |
|-----------|----------|
| **NestedLoopJoin** | Small right side, arbitrary predicate |
| **HashJoin** | Equality join, general purpose |
| **MergeJoin** | Sorted inputs, equality join |
| **SemiJoin** | `EXISTS`-style: keep left rows with at least one right match |
| **AntiJoin** | `NOT EXISTS`-style: keep left rows with no right match |
| **MarkJoin** | Generalized existence with a boolean marker column |
| **NestJoin** | `links` traversal that materializes nested arrays |

### 7.3 When links becomes a flat join

If the projection does not preserve nesting, the optimizer may replace `NestJoin` with a flat `HashJoin`:

```ye
select u.id, b.title
from users@u:User
links (users)->[writes@w:UserWritesBook]->(books@b:Book)
```

Here the result is flat pairs, so the planner can choose:

```rust
let users = Scan(Table("users"));
let edges = Scan(Table("UserWritesBook"));
let books = Scan(Table("books"));
let u_w = HashJoin(Inner, users, edges, |u| u.id, |w| w._from);
let u_w_b = HashJoin(Inner, u_w, books, |w| w._to, |b| b.id);
Map(u_w_b, |row| { id: row.u.id, title: row.b.title })
```

This is a key optimizer decision: the surface semantics are "nested materialization", but the physical plan can be a flat join when the observed result is the same.

### 7.4 Multi-root `from` and cross products

Multi-root `from users@u:User, books@b:Book` with no `links` is independent. If the user wants a cross product, they write it explicitly:

```ye
select users@u[*].{ user_id: u.id, book_id: b.id }
from users@u:User, books@b:Book
```

LIR:

```rust
let users = Scan(Table("users"));
let books = Scan(Table("books"));
let pairs = CrossJoin(users, books);
Map(pairs, |row| { user_id: row.u.id, book_id: row.b.id })
```

There is no implicit cross product. The user must ask for it.

---

## 8. Aggregation

Aggregation follows the accumulator pattern from DryadLINQ and the aggregate classification from Gray et al. .

### 8.1 Aggregate classes

| Class | Property | Examples | Distributed strategy |
|-------|----------|----------|----------------------|
| **Distributive** | `merge == iterate` with `init` | `sum`, `count`, `min`, `max` | Partial aggregate per shard, then merge |
| **Algebraic** | Fixed-size accumulator | `avg`, `stddev`, `variance` | Partial aggregate per shard, then merge |
| **Holistic** | Must see all data | `median`, `percentile`, `mode` | Gather all data to one node first |

### 8.2 Distributed aggregation plan

For Distributive/Algebraic:

```text
LIR:  Aggregate(Sum, Scan(users))
PIR:  Exchange(
        HashAggregate(partial: Sum, Scan(shard(users))),
        partition: hash(groups)
      )
      -> HashAggregate(final: Sum, Gather)
```

For Holistic:

```text
LIR:  Aggregate(Percentile, Scan(users))
PIR:  Gather(
        Exchange(Scan(shard(users)), partition: single)
      )
      -> SortAggregate(full: Percentile)
```

The `classify()` method on the `Aggregate` trait is what tells the planner which strategy to use (§11.4). No hardcoded list of aggregates in the planner.

---

## 9. Decorrelation and unnesting

Correlated subqueries are the biggest correctness/performance risk in a query language with nested collections. We adopt the **top-down unnesting** approach from Neumann (2025) rather than the older bottom-up approach.

### 9.1 Core idea

A correlated subquery is represented as a **dependent join** `L ⋉D R`, where the right-hand side `R` can reference attributes from the left-hand side `L`. Naive execution is `O(|L| · |R|)`.

Neumann's algorithm annotates every non-trivial dependent join with the set of correlation attributes it provides, then pushes a **domain relation `D`** (the distinct values of those attributes from `L`) down through the algebra tree. Once the dependent join reaches a point where the right-hand side no longer depends on it, it becomes an ordinary join. The key improvement in the 2025 paper is a **holistic/top-down pass** that handles stacked dependent joins together, avoiding the pathological cross-products produced by repeated bottom-up unnesting .

### 9.2 Our operators for correlation

```rust
pub enum LogicalOp {
    // ...
    Apply {
        kind: ApplyKind,   // Cross, Semi, Anti, Single (scalar)
        left: LirId,
        right: LirId,
    },
}

pub enum ApplyKind {
    Cross,      // dependent cross product
    Semi,       // EXISTS-style
    Anti,       // NOT EXISTS-style
    Single,     // scalar subquery
    Mark(Symbol), // true/false marker (for disjunctions)
}
```

A nested `select` that references outer bindings lowers to `Apply(Single, ...)` or `Apply(Semi, ...)` depending on context (see also the join operators in §7).

### 9.3 Decorrelation rewrite rules (from Neumann)

For a dependent join `D ⋉ R` where `D` is the domain of correlation values:

```text
D ⋉ σ_p(R)  ->  σ_p(D ⋉ R)
D ⋉ (R1 × R2)  ->  (D ⋉ R1) × R2   if R2 does not depend on D
D ⋉ Γ_{A;agg}(R)  ->  Γ_{A ∪ A(D); agg}(D ⋉ R)
D ⋉ δ(R)  ->  δ(D ⋉ R)   // distinct
```

The rewrite rules are applied top-down until the dependent join becomes trivial (right-hand side no longer references left-hand side), at which point it becomes an ordinary join.

### 9.4 When correlation remains

If a subquery uses a Holistic aggregate, or if the planner decides that keeping the dependent join is cheaper (e.g., highly selective outer relation), the `Apply` operator may remain in PIR and be executed as a nested-loop join with batching.

---

## 10. Grouping, ordering, and range

### 10.1 Grouping

`group by { city: u.city } into groups` is a pipeline transform that produces a new collection `groups: Array<Group<{city: string}, User>>`.

```rust
// LIR
GroupBy {
    input: Scan(users),
    key: |u| { city: u.city },
    into: "groups",
}

// PIR (hash grouping)
HashAggregate {
    input: Scan(users),
    groups: [|u| u.city],
    aggs: [],  // members are implicit
}
```

Group objects expose:
- Key fields directly (`g.city`).
- Member collection via the original root label (`g.users`).

### 10.2 Ordering

`order by u.age desc` at pipeline level is a stage-affecting operator. `users@u[order by u.age desc]` is a value-level operator. Both lower to `OrderBy` in LIR, but the pipeline-level version is positioned before `group by`/`range` while the value-level version is positioned where the expression occurs.

### 10.3 Range

`range 20..30` is a pipeline slice. In LIR it becomes `Slice { start: 20, end: 30, inclusive: false }`. The planner may push it into `TableScan` with limit/offset if the storage backend supports it.

---

## 11. Backend architecture and capabilities

The same logical query can be executed by many different runtimes. Rather than having a separate code path for each backend, the planner emits PIR operators and the runtime chooses implementations based on **capabilities**. This is the approach taken by extensible optimizers such as Orca and Apache Calcite , and by data-parallel language embeddings such as DryadLINQ and FlumeJava . The aggregation strategies described in §8 and the decorrelation rules in §9 are backend-agnostic: the physical planner in §11.4 selects the distributed or local implementation.

### 11.1 Capability model

A backend advertises what it can do:

```rust
pub struct BackendCapabilities {
    pub kind: BackendKind,
    pub max_parallelism: usize,
    pub supports_pushdown: PushdownCapabilities,
    pub supports_exchange: bool,
    pub supports_ordering: bool,
    pub supports_streaming: bool,
    pub default_cost: CostModel,
}

pub enum BackendKind {
    Memory,      // in-process Vec, HashMap, BTree
    Storage,     // embedded LSM, columnar, page cache
    Distributed, // partitioned across nodes
    Remote,      // SQL/REST translator
    Stream,      // unbounded event source
}

pub struct PushdownCapabilities {
    pub filter: bool,
    pub projection: bool,
    pub limit: bool,
    pub ordering: bool,
    pub aggregation: bool,
}
```

The planner consults these capabilities when converting LIR to PIR. For example, a `Storage` backend that can evaluate predicates receives a `TableScan` with an embedded filter expression; a `Memory` backend receives a separate `Filter` operator.

### 11.2 In-memory backend

The simplest backend. LIR operators map one-to-one to iterator/pull-based physical operators:

```rust
let users = PhysicalOp::TableScan { table: "users", columns: [id, age] };
let filtered = PhysicalOp::Filter { input: users, pred: ... };
let ordered = PhysicalOp::Sort { input: filtered, keys: [...] };
```

Exec generation produces closures that drive a `Vec`-backed iterator. This backend is used for unit tests, small datasets, and fallback execution.

### 11.3 Embedded storage backend (LSM / columnar)

Storage backends implement the same `Queryable` trait but their intrinsics produce scan cursors instead of arrays:

```ye
// stdlib/infra/storage/lsm.ye
struct LsmQueryable<T> {
    plan: PlanId,
}

impl<T> Queryable<T> for LsmQueryable<T> {
    fn filter(self, pred: impl Fn(&T) -> bool) -> impl Queryable<T> {
        LsmQueryable { plan: @intrinsic(query_filter(self.plan, pred)) }
    }
}
```

At PIR generation, `query_filter` on a storage source becomes a `StorageScan` with a pushdown predicate if the storage engine supports it, otherwise a `Filter` above a plain `StorageScan`.

### 11.4 Distributed backend

Distributed data is partitioned by some key. The planner inserts **exchange** operators to move data between stages:

| Logical operator | Distributed strategy |
|------------------|----------------------|
| `Filter` / `Map` | Push to each shard, no shuffle |
| `Aggregate(Distributive/Algebraic)` | Partial aggregate per shard → shuffle by group key → final aggregate |
| `Aggregate(Holistic)` | Gather all data to one node → full aggregate |
| `GroupBy` | Shuffle by key, aggregate per group |
| `OrderBy` | Local sort per shard → merge-sort on coordinator, or range partition |
| `Slice` | Push limit to shards if possible, else apply after gather |
| `Join` | Broadcast small side, or shuffle both sides by join key |

```text
LIR:  Aggregate(Sum, GroupBy(users, |u| u.city))
PIR:  Exchange(
        HashAggregate(partial: Sum, groups: city, Scan(shard(users))),
        partition: hash(city)
      )
      -> HashAggregate(final: Sum, groups: city, Gather)
```

### 11.5 Stream backend

Streaming sources are unbounded. The same logical operators apply, but `Slice` becomes a window, `OrderBy` becomes an ordered buffer, and `Aggregate` becomes a windowed aggregate. We treat stream windows as a special case of `Slice` over event time.

### 11.6 Pushdown and enforcers

When a backend supports a capability, the planner **pushes** the operation into the scan. When it does not, the planner inserts an **enforcer** operator:

```rust
pub enum PhysicalProperty {
    Ordered(Vec<OrderKey>),       // required ordering
    Distributed(Partitioning),    // required distribution
    Singleton,                    // all data on one node
}

pub enum EnforcerOp {
    Sort,
    Shuffle,
    Broadcast,
    Gather,
}
```

Enforcers are first-class PIR operators. The cost model includes their cost so the optimizer can choose between pushing work to storage versus performing it centrally.

### 11.7 Why one trait, many backends

The user writes one expression:

```ye
let total = users.filter(|u| u.age > 18).sum();
```

The type of `users` determines which `Queryable` impl is used (`QueryArray`, `LsmQueryable`, `DistributedQueryable`, etc.). The compiler does not have a list of backends; it only knows the `Queryable` lang item and the intrinsics. The backend-specific behavior lives in the `.ye` stdlib and the runtime.

---

## 12. API design philosophy: a real language, not a DSL

Your language is a general-purpose programming language that happens to understand your infrastructure. The query API should feel like ordinary code, not like SQL embedded in strings or a restricted DSL. The stdlib definitions are in §4 and the backend mappings are in §11.

### 12.1 Deferred execution via lazy plans

`Queryable` values are **descriptions** of work, not the result. They are lazy by default:

```ye
let young = users.filter(|u| u.age < 25);   // Queryable<User>, no work done
let ids   = young.map(|u| u.id);             // Queryable<i32>, still no work
let arr   = ids.execute();                    // Vec<i32>, work happens here
```

This is the same model as DryadLINQ and Spark : build a logical plan, then submit it. The difference is that in Yelang this is expressed through ordinary trait methods, not through a separate query API.

### 12.2 Composability without sacrificing optimization

Because `Queryable` methods are ordinary trait methods, users can write helper functions:

```ye
fn active_adults<U>(users: impl Queryable<U>) -> impl Queryable<U>
where U: HasAge + HasActive {
    users.filter(|u| u.active).filter(|u| u.age >= 18)
}

let ids = active_adults(users).map(|u| u.id).execute();
```

The compiler inlines or lowers the helper at the call site, so the optimizer sees a single `Filter(Filter(Scan))` chain and can fuse/push it.

### 12.3 User-defined aggregates are ordinary trait impls

A user-defined aggregate is just an `Aggregate` impl:

```ye
struct GeoMean;
struct GeoMeanAcc<T> { product: T, count: usize }

impl<T: Mul + Pow> Aggregate<T, GeoMeanAcc<T>, f64> for GeoMean {
    fn init(self: &Self) -> GeoMeanAcc<T> { ... }
    fn iterate(self: &Self, acc, value) -> GeoMeanAcc<T> { ... }
    fn merge(self: &Self, a, b) -> GeoMeanAcc<T> { ... }
    fn finalize(self: &Self, acc) -> f64 { ... }
    fn classify(self: &Self) -> AggregateClass { AggregateClass::Algebraic }
}

let gm = users.map(|u| u.salary).aggregate(GeoMean);
```

The planner knows from `classify()` that `GeoMean` is Algebraic and can generate a partial+merge distributed plan without any hardcoded knowledge of `GeoMean`.

### 12.4 New primitive operators via `@intrinsic`

If a user needs an operator the stdlib does not provide (e.g., reservoir sampling, custom windowing), they write an extension trait whose body calls a new intrinsic:

```ye
@lang("queryable_ext")
trait QueryableSampleExt<T> {
    fn reservoir_sample(self, k: usize, seed: u64) -> impl Queryable<T>;
}

impl<T> QueryableSampleExt<T> for QueryArray<T> {
    fn reservoir_sample(self, k: usize, seed: u64) -> impl Queryable<T> {
        QueryArray { plan: @intrinsic(query_reservoir_sample(self.plan, k, seed)) }
    }
}
```

The compiler recognizes `@intrinsic(query_reservoir_sample)` and the QIR extractor emits a corresponding LIR operator. The user provides the PIR/Exec lowering through a backend plugin or by contributing it to the stdlib. This mirrors how extensible optimizers like Calcite and Orca add new `RelNode` types and transformation rules .

### 12.5 Surface syntax is canonical, methods are sugar

The `select ... from ...` form is the canonical representation. Method chains are sugar that lower to the same intrinsics:

```ye
// These two produce the same LIR:
select users@u[*].age from users@u:User where u.age > 18

users.filter(|u| u.age > 18).map(|u| u.age)
```

The QIR extractor does not care which form was used. It sees `ThirExpr::Query(QueryId)` in the first case and `@intrinsic(query_filter)`/`@intrinsic(query_map)` calls in the second.

### 12.6 No ad-hoc operator list

There is no fixed enum of `QueryableMethod`s in the compiler. The only fixed things are:

- The `Queryable` lang-item trait.
- The `Aggregate` lang-item trait.
- The set of `@intrinsic(query_*)` hooks recognized by the QIR extractor.

Everything else (sum, avg, filter, map, group_by, custom window, custom sample) is defined in `.ye`. This is what makes the system general-purpose and extensible rather than a fixed DSL.

---

## 13. Memory model: reference vs value

For an infrastructure language without a borrow checker, the pragmatic choice is:

| Construct | Semantics | Implementation |
|-----------|-----------|---------------|
| Primitives (`i32`, `f64`, `bool`) | `Copy` (implicit) | Stack/register |
| Small structs (< 64 bytes, no heap) | `Copy` by default | `memcpy` |
| Large structs / collections | `Share` (reference counted, CoW on mutation) | Non-atomic RC for single-threaded; atomic for cross-thread |
| Closures | `Share` | Capture environment by RC |
| Query results | `Arena` | Bump allocator, freed when query completes |
| Cross-request caches | `Share` + explicit invalidation | Atomic RC |

No `Box`, no `Rc`, no GC in surface syntax. The compiler uses escape analysis to optimize `Share<T>` to stack/unique-heap when safe.

---

## 14. Implementation methodology: no bootstrap code, no half-measures

To avoid the accumulation of contrived, incomplete, or "temporary" code that never gets removed, the following rules apply to every phase:

### 14.1 Phase gates

- A phase is not complete until all its checklist items are done **and** all tests pass.
- We do not start phase `N+1` while phase `N` has failing tests, skipped tests, or placeholder implementations.
- If a feature cannot be implemented fully, it is **not implemented at all** in that phase. We do not leave `TODO` stubs in production paths.

### 14.2 No magic constants or string matching

- No magic symbol IDs (e.g., `Symbol::from(1000)`).
- No string-matching on aggregate names (`"Sum"`, `"Avg"`) to build closures.
- No hardcoded enum of `QueryableMethod`s.
- The compiler recognizes `@lang(...)` traits and `@intrinsic(...)` calls by their structured identity, not by name.

### 14.3 Single source of truth

- The `.ye` stdlib is the only place where `Queryable`, `Iterator`, and `Aggregate` semantics are written.
- Rust code extracts operator shapes from typed THIR bodies; it does not reimplement them.
- If the stdlib source is not available (e.g., hand-written HIR tests), the test must provide a real `Aggregate` impl in HIR/THIR, not a Rust-side fallback.

### 14.4 Deletion, not deprecation

- `aggregate_impl.rs` and the hardcoded `QueryableMethod` enum are deleted in Phase 3, not kept as fallbacks.
- Any code that says "until impl-body typechecking works" is removed once impl-body typechecking works.

### 14.5 Testing standards

- Every THIR expression form has a unit test.
- Every LIR operator has a construction + round-trip test.
- Every logical rewrite has a correctness test and, where applicable, a counterexample test showing it does not apply when invalid.
- Every aggregate class (Distributive, Algebraic, Holistic) has a distributed-plan test.
- Decorrelation rewrites are tested against the examples in Neumann's paper.
- End-to-end tests cover every surface form in `notes/syntax_grammar/`.
- Logical rewrites are fuzz-tested with a random plan generator + an executable semantics oracle.

### 14.6 Review checkpoint

After each phase, we stop and verify:

1. Does the public API match the design doc?
2. Are there any TODOs or unimplemented!() in production code?
3. Do all new tests pass without ignoring any?
4. Can the next phase be built on top without hacks?

Only after all four are true do we proceed.

---

## 15. Implementation phases and checklist

### Phase 0: Foundation

- [ ] Allocate `DefId`s through a proper arena/slotmap for all HIR items, including derived impl items.
- [ ] Remove `ctx.next_synthetic_def_id()` from derive helpers; use the same allocator as source items.
- [ ] Ensure `Generics` and `attrs` are preserved in derived `ImplItem`s.
- [x] Verify `@lang(...)` attribute support in the parser and resolver.
- [x] Add `@intrinsic(...)` expression support in AST/HIR/type checker.

### Phase 1: THIR

- [ ] Create `yelang-thir` crate.
- [ ] Define `ThirExpr`, `ThirStmt`, `ThirPat`, `ThirBody`.
- [ ] Implement HIR -> THIR lowering:
  - [ ] Method calls -> function calls with explicit `self` argument.
  - [ ] Query syntax -> `ThirExpr::Query(QueryId)` referencing the side table.
  - [ ] `for` loops -> `Iterator` method calls.
  - [ ] Closures preserved as closures.
- [ ] Add THIR tests for each expression form.

### Phase 2: Stdlib in `.ye`

- [ ] Write `stdlib/core/iter.ye`.
- [ ] Write `stdlib/core/queryable.ye` with `@lang("queryable")`.
- [ ] Write `stdlib/core/aggregate.ye` with `@lang("aggregate")`.
- [ ] Write `stdlib/core/aggregate_impls.ye`.
- [ ] Write `stdlib/infra/query/query_array.ye` / `query_slice.ye`.
- [ ] Make the driver load the stdlib as a prelude for every compilation.
- [ ] Add driver tests that compile the stdlib through the full pipeline.

### Phase 3: QIR extraction from THIR

- [ ] Rewrite `yelang-qir/src/logical/extract.rs` to read THIR instead of HIR.
- [ ] Recognize `@intrinsic(query_*)` calls and emit LIR operators.
- [ ] Extract aggregate closures from typed THIR bodies of `Aggregate` impls.
- [ ] Delete `aggregate_impl.rs` and the hardcoded `QueryableMethod` enum.
- [ ] Make all existing QIR tests pass against the new extraction path.

### Phase 4: Logical operators and rewrites

- [ ] Implement all LIR operators from §6.1.
- [ ] Implement rewrite passes:
  - [ ] Predicate pushdown.
  - [ ] Projection pushdown.
  - [ ] Map/filter fusion.
  - [ ] Decorrelation (§9).
  - [ ] Unnesting (§9).
  - [ ] Constant folding and simplification.
- [ ] Add logical-plan tests for each rewrite.

### Phase 5: Physical planning

- [ ] Implement PIR operators from §6.2.
- [ ] Implement backend traits:
  - [ ] Memory backend.
  - [ ] Storage backend (LSM pushdown).
  - [ ] Distributed backend.
  - [ ] Stream backend.
- [ ] Implement enforcers (distribution, ordering, singleton).
- [ ] Add cost model and plan enumeration.

### Phase 6: Execution

- [ ] Implement Exec operators from §6.3.
- [ ] Codegen closures to bytecode/native code.
- [ ] Implement distributed exchange/gather.
- [ ] Add end-to-end tests for all query forms in the notes.

### Phase 7: Polish

- [ ] Remove all dead bootstrap code.
- [ ] Document the public QIR API.
- [ ] Performance benchmarks against hand-written queries.
- [ ] Fuzz logical rewrites for correctness.

---

## 16. References

- Rust Compiler Development Guide, [The THIR](https://rustc-dev-guide.rang-lang.org/thir.html).
- Thomas Neumann, [Improving Unnesting of Complex Queries](https://15799.courses.cs.cmu.edu/spring2025/papers/11-unnesting/neumann-btw2025.pdf), BTW 2025.
- L. Fegaras et al., [An Optimization Framework for Map-Reduce Queries](https://lambda.uta.edu/mrql.pdf), EDBT 2012.
- M. Isard et al., [DryadLINQ: A System for General-Purpose Distributed Data-Parallel Computing Using a High-Level Language](https://www.microsoft.com/en-us/research/publication/dryadlinq-a-system-for-general-purpose-distributed-data-parallel-computing-using-a-high-level-language/), OSDI 2009.
- C. Chambers et al., [FlumeJava: Easy, Efficient Data-Parallel Pipelines](https://research.google/pubs/flumejava-easy-efficient-data-parallel-pipelines/), PLDI 2010.
- J. Gray et al., [Data Cube: A Relational Aggregation Operator](https://arxiv.org/pdf/cs/0701155), 2007.
- G. Graefe, [The Volcano Optimizer Generator: Extensibility and Efficient Search](https://www.cs.ubc.ca/~rap/teaching/504/2006/slides/volcano.pdf).
- Apache Calcite, [Relational Operators](https://www.querifylabs.com/blog/relational-operators-in-apache-calcite) and [VolcanoPlanner Javadoc](https://calcite.apache.org/javadocAggregate/org/apache/calcite/plan/volcano/package-summary.html).
- S. Chaudhuri, [Extensible Query Optimizers in Practice](https://www.microsoft.com/en-us/research/wp-content/uploads/2024/12/Extensible-Query-Optimizers-in-Practice.pdf), Microsoft Research 2024.
- MariaDB, [Create Aggregate Function](https://mariadb.org/mariadb-hidden-gem-create-aggregate-function/) (user-defined aggregates in SQL).
- Yelang internal notes:
  - `notes/syntax_grammar/select.md`
  - `notes/syntax_grammar/semantics.md`
  - `notes/syntax_grammar/pipelining.md`
  - `notes/syntax_grammar/complex_query.sql`
