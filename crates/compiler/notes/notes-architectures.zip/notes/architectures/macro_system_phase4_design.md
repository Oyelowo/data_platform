# Macro System Phase 4 Design: Statement-Position Macros

## Overview

Phase 4 introduces first-class statement-position macro invocations. Today, a
macro invocation at statement position is forced into `StmtKind::Expr` or
`StmtKind::TermExpr`, which only works if the macro expands to an expression.
This phase adds `StmtKind::MacroInvocation` so that macros invoked with curly
braces (`foo! { ... }`) can expand to arbitrary statements, including `let`
bindings, nested items, and multiple statements.

## Motivation

- **Statement generators**: `declare_vars! { a: i32, b: string }` expands to
  multiple `let` bindings.
- **Block-local items**: `generate_helper! { }` expands to a `fn` inside a
  block.
- **Alignment with Rust**: modern Rust distinguishes expression invocations
  (`foo!()`, `foo![]`) from statement/item invocations (`foo!{}`).

## Syntactic design

We adopt the delimiter-based rule from [RFC 378](https://rust-lang.github.io/rfcs/0378-expr-macros.html)
and the [Rust Reference](https://doc.rust-lang.org/reference/macros-by-example.html),
which avoids the pre-RFC ambiguity where `foo!().bar` failed to parse at the
start of a statement.

| Delimiter | Syntactic context | Expected expansion |
|-----------|-------------------|--------------------|
| `foo!()`  | expression        | `Expr`             |
| `foo![]`  | expression        | `Expr`             |
| `foo!{}`  | statement / item  | `Stmt` or `Item`   |

In statement position:

- `foo!()` and `foo![]` are parsed as expression statements exactly like
  `foo();` and `foo[];`.
- `foo!{}` is parsed as `StmtKind::MacroInvocation`.

## AST representation

Add a new variant to `StmtKind` in `yelang-ast/src/stmt/stmt.rs`:

```rust
pub enum StmtKind {
    // ... existing variants ...

    /// Macro invocation in statement position: `foo! { ... }`.
    ///
    /// This is distinct from `Expr(MacroInvocation(...))` because the macro
    /// may expand to statements, items, or a sequence of statements rather
    /// than a single expression.
    MacroInvocation(MacroInvocation),
}
```

`MacroInvocation` is reused from `yelang_ast::expr::MacroInvocation` to keep
the AST uniform across all macro positions.

## Parser design

`Stmt::parse` currently falls through to `Expr` parsing for anything that is
not `let`, an item keyword, or empty. We insert a check before expression
parsing:

1. Try to parse a `Path`.
2. If the path is immediately followed by `!`:
   - If the next token after `!` is `{`, consume `!`, parse macro arguments,
     and produce `StmtKind::MacroInvocation`.
   - If the next token after `!` is `(` or `[`, restore the checkpoint and
     fall through to normal expression parsing (which already handles
     expression-position macro invocations).
3. Otherwise restore the checkpoint and parse as a normal statement.

This keeps the existing expression-macro path untouched while giving
`{}`-delimited invocations their own AST node.

## Expansion design

### Fragment re-parsers

We need a way to turn a macro-produced token stream back into one or more
statements:

```rust
fn parse_stmts_from_token_stream(
    stream: &TokenStream,
    interner: &Interner,
) -> Result<Vec<Stmt>, String>
```

The function tokenizes the rendered stream and repeatedly calls `Stmt::parse`
until EOF, consuming trailing semicolons naturally. It must accept:

- `let` statements
- expression statements (`expr;` or terminating `expr`)
- item statements
- nested `StmtKind::MacroInvocation`

### Expansion helpers

- `expand_macro_invocation` (already exists) produces the raw expanded token
  stream.
- `expand_stmt` changes its return type from `(Stmt, bool)` to `(Vec<Stmt>,
  bool)` to accommodate macros that expand to multiple statements.
- For `StmtKind::MacroInvocation`:
  1. Expand the macro invocation to a token stream.
  2. Parse the stream into `Vec<Stmt>`.
  3. Recursively expand each resulting statement.
  4. Return the flattened vector.
- For all other statement kinds, return a single-element vector as before.

### Wiring

- `expand_block_expr` collects the vectors from `expand_stmt` and flattens
  them into the block's statement list.
- Function bodies, `if`/`match`/`loop` arms, closures, and async blocks all
  use `expand_block_expr`, so statement macros work everywhere blocks do.

## Follow sets

The `stmt` fragment specifier already exists in `FragmentKind`. Its follow set
is shared with `expr` (`=>`, `,`, `;`) per the Rust Reference. No follow-set
changes are required.

## Downstream handling

Residual unexpanded `StmtKind::MacroInvocation` nodes are handled gracefully:

- `yelang-resolve::late::resolve_stmt` ignores them.
- `yelang-hir` lowering skips them (they produce no HIR statements).

This mirrors the treatment of residual type/item/pattern macros from Phase 3.

## Testing strategy

Tests live in `yelang-macro/tests/declarative_macros_phase4.rs` and verify:

1. Statement macro expanding to a `let` binding.
2. Statement macro expanding to an expression statement.
3. Statement macro expanding to a block-local item.
4. Statement macro expanding to multiple statements.
5. Statement macro inside `if`, `match`, `loop`, and closure bodies.
6. Nested statement macros.
7. Delimiter rule: `foo!{}` is a statement macro, `foo!()`/`foo![]` are
   expression macros even at statement position.
8. Error cases:
   - unknown statement macro
   - macro producing invalid statement(s)
   - expression macro at statement position that does not produce an
     expression

## Future work

- A `stmt` fragment capture currently parses a single statement; supporting
  multiple captured statements (`$($s:stmt);*`) already works through
  repetitions.
- Proc-macro support remains out of scope.
