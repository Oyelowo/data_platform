# Query Expression Rethink — Implementation Checklist

**Last updated:** after closure-based aggregate bootstrap landed.
**Status:** `cargo test -p yelang-qir` passes (all suites, including the new `aggregate_closure_tests`).
**Current frontier:** moving from hand-constructed bootstrap closures to real `.ye` stdlib trait introspection (Phases 0–2 + full Phase 3).

## Phase 0 — Typechecker bootstrap
- [ ] Parse and typecheck trait default method bodies with method-level generics (`fn map<U>`, `fn sum` where `T: Add`).
- [ ] Parse and typecheck `Self: Sized` where clauses on trait methods.
- [ ] Parse and typecheck aggregate methods taking `self: &Self`.
- [ ] Verify `self.aggregate(Sum)` in a default trait body resolves correctly.

## Phase 1 — `.ye` standard library
- [ ] Update `stdlib/core/src/aggregate.ye`:
  - [ ] Change `Aggregate` trait methods to take `self: &Self`.
  - [ ] Make `Sum`, `Count` generic over `T`.
  - [ ] Make `Avg` generic over `T: Add + Zero + ToF64`.
  - [ ] Add `Product<T>`, `Min<T>`, `Max<T>` aggregates.
  - [ ] Add helper traits `Zero`, `One`, `ToF64` (or reuse existing numeric traits).
- [ ] Update `stdlib/core/src/query.ye`:
  - [ ] Add default sugar methods: `sum`, `product`, `count`, `avg`, `min`, `max`.
  - [ ] Add `fold`, `reduce` declarations (or default bodies lowering to aggregates).
- [ ] Update `stdlib/core/src/lib.ye` re-exports.
- [ ] Add example user-defined `Percentile` aggregate (in tests or docs).

## Phase 2 — Method resolution enrichment
- [ ] Extend `MethodResolution` with `trait_ref: Option<TraitRef>` and `impl_subst: Option<Substitution>`.
- [ ] Update `yelang-tycheck/src/method.rs` `confirm_and_record` to populate them.
- [ ] For inherent candidates, record `impl_def_id` + `impl_subst`.
- [ ] For trait candidates, record `trait_def_id`, `method_def_id`, `trait_ref`, and `impl_subst` after trait solving.
- [ ] Add `TyCtxt` helper to resolve a trait goal to a selected impl + substitution.

## Phase 3 — Generic aggregate lowering
- [x] Create `yelang-qir/src/logical/aggregate_impl.rs`.
- [x] Implement `resolve_aggregate_impl(tcx, marker_ty, in_ty) -> (impl_def_id, impl_subst, acc_ty, out_ty)`.
  - *Current:* bootstrap resolver for built-in markers (`Sum`, `Product`, `Count`, `Avg`).
  - *Pending:* full trait-solver based resolution for user-defined aggregates.
- [x] Implement extraction of `init`/`step`/`merge`/`finish`/`class` method bodies from an `Aggregate` impl.
  - *Current:* hand-constructed closure sequences for built-in markers.
  - *Pending:* extraction from real `.ye` trait impl ASTs.
- [x] Implement lowering of an impl method body into a `QExpr` closure with:
  - [x] Fresh binder for each parameter.
  - [x] `self` bound to the aggregate config value.
  - [ ] Generic substitution applied.
- [x] Extend `AggregateOp` with `init`, `step`, `merge`, `finish`, `config` closures.
- [x] Update `yelang-qir/src/logical/queryable.rs` `lower_aggregate_call` to use closure extraction.
  - *Current:* uses bootstrap aggregate impls; falls back to placeholder if stdlib not loaded.

## Phase 4 — Sugar inlining
- [ ] Detect default trait method bodies (`sum`, `avg`, etc.) during lowering.
- [ ] Inline the body so `q.sum()` becomes `q.aggregate(Sum)` before operator construction.
- [ ] Support user overrides: if a downstream impl provides its own `sum`, use that body.
- [ ] Remove `QueryableMethod::Sum`, `Avg`, `Count` and the special-case lowering.

## Phase 5 — Trait-introspection operator shapes
- [ ] Replace `QueryableMethod` enum with `OperatorShape` inferred from `Queryable` trait signatures.
- [ ] In `yelang-qir/src/logical/stdlib.rs`, build shape table from trait AST:
  - [ ] `filter` → `FilterShape`
  - [ ] `map` → `MapShape`
  - [ ] `flat_map` → `FlatMapShape`
  - [ ] `order_by` → `OrderByShape`
  - [ ] `group_by` → `GroupByShape`
  - [ ] `distinct` → `DistinctShape`
  - [ ] `take`/`skip` → `SliceShape`
  - [ ] `aggregate` → `AggregateShape`
  - [ ] `fold`/`reduce` → lower to aggregate shapes
  - [ ] `execute` → no-op / materialization boundary
- [ ] Update `queryable.rs` `lower` to dispatch by shape, not by enum.
- [ ] Keep introspection fallback for standalone QIR unit tests.

## Phase 6 — Executor closure evaluation
- [x] Update `yelang-qir/src/exec/kernels.rs` aggregate kernel to evaluate `init`/`step`/`finish` closures.
  - *Current:* closure evaluation lives in `MemoryExecutor`/`exec/memory.rs`.
- [x] Implement `hash_aggregate` for `AggregateGroupBy` using `step`/`finish` closures.
- [ ] Add runtime value helpers for `Option<T>`, tuples, and user structs.
- [ ] Ensure empty input behaves correctly for `min`/`max` (`None`).

## Phase 7 — Decorrelation framework
- [ ] Lower scalar subqueries to `DependentJoin` + `Aggregate`.
- [ ] Lower `exists` / `not exists` to `DependentJoin` + `Filter` + `SemiJoin`/`AntiJoin` normalization.
- [ ] Implement `yelang-qir/src/logical/rewrite/decorrelate.rs`:
  - [ ] Identify non-trivial `DependentJoin`s and compute correlation domains.
  - [ ] Top-down rewrite pass.
  - [ ] Push domain through filter, map, join, group-by, aggregate.
  - [ ] Convert trivial `DependentJoin` to `Join`.
  - [ ] Convert to `SemiJoin`/`AntiJoin` for exists/not-exists.
- [ ] Add `LirOp::SemiJoin` and `AntiJoin` (or encode via `Join` kind).

## Phase 8 — Physical planning
- [ ] Create `yelang-qir/src/physical/` layer.
- [ ] Define `PirOp`, `PhysicalAggregate`, `AggregatePhase`, `ExchangeKind`.
- [ ] Define `StorageCapabilities` and `DistributionMode`.
- [ ] Implement `LIR -> PIR` lowering:
  - [ ] `Aggregate` → partial/final/full depending on class.
  - [ ] `AggregateGroupBy` → hash partial → exchange → hash final.
  - [ ] `OrderBy` → sort or distributed sort.
  - [ ] `Slice` on ordered input.
  - [ ] `Join` → hash join / nested loop join heuristic.
- [ ] Add exchange placement for distributive/algebraic/holistic aggregates.

## Phase 9 — Tests
- [x] `aggregate_closure_tests.rs`:
  - [x] `sum` on `i32`, `f64`.
  - [x] `avg` output type `f64`.
  - [x] `count` on `i32`.
  - [ ] `min`/`max` on `Option<T>`.
  - [x] `product` on integers and floats.
  - [ ] User-defined `Percentile`.
- [ ] `queryable_trait_tests.rs`:
  - [ ] Sugar methods inline to aggregate.
  - [ ] `map.filter.sum` chain.
  - [ ] `group_by` + aggregate.
  - [ ] `order_by` + `range`.
- [ ] `decorrelation_tests.rs`:
  - [ ] Scalar subquery in projection.
  - [ ] Exists in filter.
  - [ ] Not exists in filter.
  - [ ] Nested correlated subqueries.
  - [ ] Correlated aggregate subquery.
- [ ] `distributed_plan_tests.rs`:
  - [ ] Distributive aggregate plan.
  - [ ] Algebraic aggregate plan.
  - [ ] Holistic aggregate plan.
  - [ ] Group-by distributive plan.
  - [ ] Group-by holistic plan.
- [x] Update and run `end_to_end_query_tests.rs`.
- [x] Run `cargo test -p yelang-qir` and fix all regressions.
- [ ] Run `cargo test -p yelang-tycheck` after MethodResolution changes.

## Documentation
- [ ] Update `notes/architectures/query_expression_final_design.md` if deviations occur.
- [ ] Add inline rustdoc to new modules.
- [ ] Add `.ye` stdlib doc comments.
