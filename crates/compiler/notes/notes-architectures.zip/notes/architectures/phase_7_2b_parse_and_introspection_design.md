# Phase 7.2b — Public Parse Helpers & Token Introspection

This document describes the second half of Phase 7.2: the lightweight parsing
helpers and token-tree introspection API exposed by `yelang-proc-macro`.

It is informed by the `proc_macro2`/`syn` parsing model (cheaply forkable
cursors, a `Parse` trait, and combinators on a `Parser` handle) but is kept
intentionally smaller and Yelang-specific.

---

## 1. Goals

- Give macro authors a small, composable toolkit for reading
  `yelang_proc_macro::TokenStream` values.
- Support common patterns: peek/consume, lookahead/fork, expect a token,
  parse a custom AST node, parse a delimited group, parse a separated list.
- Provide a visitor (`TokenWalker`) for inspecting token trees without writing
  manual recursion.
- Keep the API forward-compatible with future compiler-hosted `quote!` and
  diagnostics.

---

## 2. Core concepts

### 2.1 `Cursor`

`Cursor<'a>` is a cheap, cloneable index into a `TokenStream`. It owns a
snapshot of the stream (a `Vec<TokenTree>`) and an offset, so forking is a
shallow clone plus an integer copy.

It provides the low-level operations:

- `new(stream: &TokenStream)` — create a cursor over a stream.
- `peek()`, `peek_n(n)` — inspect upcoming tokens without consuming.
- `next()` — consume and return the current token.
- `advance(n)` — advance by `n` tokens.
- `is_empty()`, `position()`, `remaining()` — cursor state.
- `span()` — span of the current token (or `Span::call_site()` at EOF).
- `fork()` — clone the cursor for speculative parsing.
- `remaining_stream()` — collect unconsumed tokens into a `TokenStream`.
- `parse<T: Parse>()` — drive a `Parse` implementation.

### 2.2 `Parse`

The `Parse` trait is the canonical way to turn a cursor into a typed value:

```rust
pub trait Parse: Sized {
    fn parse(cursor: &mut Cursor) -> Result<Self, ParseError>;
}
```

Implementations are provided for the built-in token types (`TokenStream`,
`TokenTree`, `Group`, `Ident`, `Literal`, `Punct`). Macro authors implement
`Parse` for their own AST nodes.

### 2.3 `Parser`

`Parser<'a>` wraps a `Cursor<'a>` and adds higher-level combinators. It is the
object macro authors usually hold while parsing:

```rust
let mut p = Parser::new(&stream);
let name: Ident = p.parse()?;
p.expect_punct(':')?;
let ty: MyType = p.parse()?;
```

Combinators include:

- `new(stream)`, `from_cursor(cursor)`
- `parse<T: Parse>()`, `peek()`, `peek_n(n)`, `is_empty()`, `next()`
- `expect(msg)`, `expect_ident()`, `expect_punct(ch)`, `expect_literal()`,
  `expect_group(delimiter)`, `expect_keyword(name)`
- `matches_punct(ch)`, `matches_ident(name)` — non-consuming predicates
- `consume_punct(ch)`, `consume_ident(name)` — consume if matched
- `parse_optional<T: Parse>()` (uses a fork; returns `None` on any error)
- `parse_group()` — parse and consume a group of any delimiter
- `parse_terminated<T>(is_end, separator)` — parse `T` repeatedly until an
  end predicate returns true, optionally consuming separators
- `parse_many0<T: Parse>()`, `parse_many1<T: Parse>()` — zero/one-or-more
- `parse_separated0<T: Parse>(separator)`, `parse_separated1<T: Parse>(separator)`
- `parse_delimited(delimiter)` — parse a group and return a `Parser` over its
  inner stream

### 2.4 `BufferedCursor`

`BufferedCursor<'a>` supports lookahead and speculative parsing on top of
`Cursor`. Because `Cursor` is already cloneable and supports arbitrary `peek_n`,
the buffer is primarily an ergonomic wrapper: it keeps a snapshot of the
underlying cursor that can be cheaply forked and restored or committed.

```rust
let mut buf = BufferedCursor::new(Cursor::new(&stream));
let snapshot = buf.fork();
if let Ok(node) = buf.cursor_mut().parse::<MyNode>() {
    buf.commit(buf.cursor().fork());
} else {
    buf.reset(snapshot);
}
```

API:

- `new(cursor)`, `from_cursor(cursor)`
- `fork()` — return a cheap clone of the primary cursor
- `commit(cursor)` — replace the primary cursor with an advanced fork
- `reset(cursor)` — restore the primary cursor to a snapshot
- `cursor()`, `cursor_mut()` — accessors
- `into_cursor()` — consume and return the underlying cursor

### 2.5 `ParseError`

`ParseError` carries a `Span` and a message. It implements `Display` and
`std::error::Error`, and can be converted to a `Diagnostic` for emission.

---

## 3. Token introspection

### 3.1 `TokenWalker`

`TokenWalker` is a trait with overridable callbacks for each token-tree kind.
The default implementations forward to `visit_token`, so a walker that only
cares about every token tree can override just that one method.

Methods return `ControlFlow<()>` so traversal can short-circuit by returning
`ControlFlow::Break(())`.

```rust
pub trait TokenWalker {
    fn visit_token(&mut self, tree: &TokenTree) -> ControlFlow<()> { ... }
    fn visit_ident(&mut self, ident: &Ident) -> ControlFlow<()> { ... }
    fn visit_punct(&mut self, punct: &Punct) -> ControlFlow<()> { ... }
    fn visit_literal(&mut self, literal: &Literal) -> ControlFlow<()> { ... }
    fn visit_group(&mut self, group: &Group) -> ControlFlow<()> { ... }
    fn visit_enter_group(&mut self, group: &Group) -> ControlFlow<()> { ... }
    fn visit_leave_group(&mut self, group: &Group) -> ControlFlow<()> { ... }
}
```

Helper functions:

- `walk_stream(stream, &mut walker)`
- `walk_tree(tree, &mut walker)`
- `count_tokens(stream)`
- `find_idents(stream)` — returns all identifier values

Groups are visited twice: `visit_enter_group` before recursion and
`visit_leave_group` after. The group itself is also passed to `visit_group`
and `visit_token` at the enter point.

---

## 4. Exhaustive file tree

```text
crates/compiler/yelang-proc-macro/src/
├── parse/
│   ├── mod.rs              # re-exports Cursor, BufferedCursor, ParseError,
│   │                       # Parse, Parser
│   ├── cursor.rs           # Cursor<'a>
│   ├── buffered.rs         # BufferedCursor<'a>
│   ├── error.rs            # ParseError
│   └── parser.rs           # Parse trait, Parser<'a>
└── introspect/
    ├── mod.rs              # re-exports TokenWalker, walk_stream, walk_tree,
    │                       # count_tokens, find_idents
    └── token_walker.rs     # TokenWalker trait and walk helpers

crates/compiler/yelang-proc-macro/tests/
├── parse_tests.rs          # Cursor, Parser, BufferedCursor, Parse impl tests
└── introspect_tests.rs     # TokenWalker and helper tests
```

---

## 5. Examples

### 5.1 Parsing a custom derive input

```rust
use yelang_proc_macro::{
    parse::{Cursor, Parse, ParseError, Parser},
    Ident, TokenStream,
};

struct Field {
    name: Ident,
    ty: TokenStream,
}

impl Parse for Field {
    fn parse(cursor: &mut Cursor) -> Result<Self, ParseError> {
        let mut parser = Parser::from_cursor(cursor.fork());
        let name = parser.expect_ident()?;
        parser.expect_punct(':')?;
        let ty = parser.parse::<TokenStream>()?;
        *cursor = parser.into_cursor();
        Ok(Field { name, ty })
    }
}
```

### 5.2 Walking tokens

```rust
use std::ops::ControlFlow;

use yelang_proc_macro::introspect::{walk_stream, TokenWalker};
use yelang_proc_macro::{Ident, TokenTree};

struct CollectIdents(Vec<String>);

impl TokenWalker for CollectIdents {
    fn visit_ident(&mut self, ident: &Ident) -> ControlFlow<()> {
        self.0.push(ident.value().to_string());
        ControlFlow::Continue(())
    }
}

let mut collector = CollectIdents(Vec::new());
walk_stream(&stream, &mut collector)?;
```

---

## 6. Design decisions

- **Cheap forks.** `Cursor` keeps only a `Vec<TokenTree>` snapshot and an
  offset. Forking is a shallow clone of the snapshot plus an integer copy.
- **Parse trait takes `&mut Cursor`.** This is the simplest ownership model and
  matches the `syn` style. `Parser` builds convenience on top without forcing
  macro authors to use it.
- **`BufferedCursor` is a wrapper, not the core.** The core `Cursor` already
  supports arbitrary lookahead; the buffered wrapper adds explicit snapshot
  management for speculative parsing.
- **Errors carry spans.** Every parse error is anchored to a token span so it
  can be rendered at the correct source location.
- **No `util` modules.** `lib.rs` and `mod.rs` files only re-export.
- **Visitor uses `ControlFlow`.** Short-circuiting traversal is built in from
  the start rather than added later as a breaking change.
