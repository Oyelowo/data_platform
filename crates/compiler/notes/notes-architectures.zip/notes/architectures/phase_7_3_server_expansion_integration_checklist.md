# Phase 7.3 — Server-Based Expansion Integration Checklist

Status legend:
- `[ ]` not started
- `[/]` in progress / skeleton / partial
- `[x]` done

---

## 1. Design

- [x] Document server-expansion integration goals and token pipeline.
- [x] Document adversarial considerations and failure modes.
- [x] Exhaustive file tree for changed modules and tests.
- [x] API change list (registry, resolver, client, expander).

---

## 2. Registry cleanup

- [x] Remove `library: LibraryHandle` from `ProcMacroDef`.
- [x] Keep `name`, `kind`, `macro_index`, `library_path`.
- [x] Update any callers/tests that constructed the old struct.

---

## 3. `ProcMacroRuntime`

- [x] Define `ResolvedProcMacro` struct.
- [x] Define `ProcMacroRuntime` with `RefCell<ProcMacroClient>`, resolver, and
      `RefCell<HashMap<String, LibraryHandle>>` load cache.
- [x] `ProcMacroRuntime::new(client, resolver)` constructor.
- [x] `load_library(path)` method that talks to the client and caches handles.
- [x] `resolve(name)` method that returns `Option<Result<ResolvedProcMacro, ProcMacroClientError>>`.
- [x] `expand_proc_macro` method that delegates to the client.
- [x] Tests for lazy loading, cache reuse, and load-failure caching.

---

## 4. Client diagnostic collection

- [x] Change `expand_fn_like` return type to include `Vec<WireDiagnostic>`.
- [x] Change `expand_attr` return type to include `Vec<WireDiagnostic>`.
- [x] Change `expand_derive` return type to include `Vec<WireDiagnostic>`.
- [x] Update `read_expanded` to collect `Response::Diagnostic` messages.
- [x] Tests for diagnostic collection and ordering.

---

## 5. Wire conversion helpers

- [x] Implement `core_to_wire` using `from_core_stream` + `bridge::into_wire`.
- [x] Implement `wire_to_core` using `bridge::from_wire` + render + tokenize +
      `from_lexer_tokens`.
- [x] Remove broken `ast_to_wire`, `ast_tree_to_wire`, `ast_span_to_wire`.
- [x] Tests for identifier round-trip, delimiter round-trip, punctuation spacing
      round-trip, literal round-trip, compound operators.

---

## 6. Expander integration

- [x] Add `proc_macro_runtime: Option<ProcMacroRuntime>` to `MacroExpander`.
- [x] Add `with_proc_macro_runtime` builder.
- [x] Add `expand_program_with_proc_macros(program, interner, runtime)`.
- [x] Add `expand_server_fn_like` helper.
- [x] Add `expand_server_attr` helper.
- [x] Add `expand_server_derive` helper.
- [x] Add `push_server_diagnostics` helper that converts `WireDiagnostic` to
      `ExpandError`.
- [x] Wire server macros into `expand_macro_invocation` after in-process and
      before declarative.
- [x] Wire server macros into `expand_user_attribute_macro` after in-process and
      before declarative.
- [x] Wire server macros into `expand_user_derive_macro` after in-process and
      before declarative.
- [x] Tests for all three macro kinds via the server.

---

## 7. End-to-end tests

- [x] Test function-like macro expands through server.
- [x] Test attribute macro expands through server.
- [x] Test derive macro expands through server.
- [x] Test derive macro returning non-items reports parse error.
- [x] Test diagnostic from server reaches user as expansion error.
- [x] Test server panic is recovered and reported.
- [x] Test missing library path is reported as expansion error.
- [x] Test runtime library-load caching.

---

## 8. Fixture updates

- [x] Add `generate_const` derive macro to fixture.
- [x] Add `emit_warning` function-like macro to fixture.
- [x] Update server integration tests for new fixture macros and shifted indices.

---

## 9. Integration and verification

- [x] `cargo fmt`.
- [x] `cargo check -p yelang-macro -p yelang-proc-macro-server` clean (existing
      warnings allowed).
- [x] `cargo test -p yelang-macro -p yelang-proc-macro-server` passes.
- [x] Update main macro-system checklist sections 7.3.
