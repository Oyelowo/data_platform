
# COMPLETE TYPE SYSTEM & NEXT-GEN TRAIT SOLVER DESIGN DOCUMENT
## For a Rust-like Language Without Lifetimes, With HRTB for Type Parameters

---

## TABLE OF CONTENTS

1. [Design Philosophy & Goals](#1-design-philosophy--goals)
2. [Type Representation (TyKind)](#2-type-representation-tykind)
3. [Variables: The Complete Taxonomy](#3-variables-the-complete-taxonomy)
4. [Binders & De Bruijn Indices](#4-binders--de-bruijn-indices)
5. [Placeholders & Universes](#5-placeholders--universes)
6. [The TyCtxt: Global Type Context](#6-the-tyctxt-global-type-context)
7. [Inference Engine](#7-inference-engine)
8. [Canonicalization](#8-canonicalization)
9. [Next-Gen Trait Solver](#9-next-gen-trait-solver)
10. [HIR Type Checker](#10-hir-type-checker)
11. [Coherence](#11-coherence)
12. [Well-Formedness](#12-well-formedness)
13. [Variance](#13-variance)
14. [Complete File Tree](#14-complete-file-tree)
15. [Algorithm Reference](#15-algorithm-reference)
16. [Syntax Mapping](#16-syntax-mapping)

---

## 1. DESIGN PHILOSOPHY & GOALS

### 1.1 Core Decisions

| Decision | Rationale |
|----------|-----------|
| No lifetimes | Simplifies the type system significantly; borrow checking omitted |
| HRTB for type parameters | Enables `for<T> fn(T) -> T` and universal closure traits |
| Next-gen goal-driven solver | Cleaner architecture than old fulfillment-based approach |
| Full rustc compatibility | Can express everything Rust can (minus lifetimes) |
| Arena allocation + interning | Pointer equality for type equality; cache-friendly |

### 1.2 What We Keep from rustc

- `TyKind` with `Param`, `Infer`, `Placeholder`, `Bound`, `Binder`
- `DebruijnIndex` + `BoundVar` for nested binders
- `UniverseIndex` for placeholder soundness
- Canonical goal-driven trait solving
- Coherence checking with overlap detection
- Variance inference

### 1.3 What We Omit

- All region/lifetime variants (`ReEarlyParam`, `ReLateParam`, `ReVar`, etc.)
- MIR type checker (no borrow checking)
- Outlives predicates
- Drop check (simplified)

---

## 2. TYPE REPRESENTATION (TyKind)

### 2.1 Core Type Enum

```rust
/// The kind of a type. All types are interned via TyCtxt.
pub enum TyKind<I: Interner> {
    // ─── Base Types ─────────────────────────────────────────────────
    Bool,
    Int(IntTy),           // i8, i16, i32, i64, i128, isize, u8, u16, u32, u64, u128, usize
    Float(FloatTy),       // f32, f64
    String,
    Char,

    // ─── Composite Types ──────────────────────────────────────────────
    Adt(AdtId<I>, GenericArgs<I>),   // Structs, enums, unions
    Tuple(Vec<Ty<I>>),
    Array(Ty<I>, Const<I>),
    Slice(Ty<I>),

    // ─── Function Types ─────────────────────────────────────────────
    /// Function definition: `fn foo<T>() {}` — has a DefId and early-bound generics
    FnDef(FnDefId<I>, GenericArgs<I>),

    /// Function pointer: `for<T> fn(T) -> T` — wrapped in Binder for late-bound generics
    FnPtr(Binder<I, FnSig<I>>),

    // ─── Variables ──────────────────────────────────────────────────
    /// Early-bound type parameter: `T` in `fn foo<T>(x: T)`
    /// Declared by the user, substituted at call sites.
    Param(ParamTy),

    /// Inference variable: `?0` — to be solved by the trait solver
    Infer(InferTy),

    /// Placeholder: `!1_0` — skolemized variable from `for<T>`
    /// Rigid, universe-scoped, cannot be unified.
    Placeholder(PlaceholderTy),

    /// Bound variable: `^0_1` — De Bruijn index + parameter index inside a Binder
    /// Only valid inside a Binder<T>. Replaced during instantiation.
    Bound(DebruijnIndex, BoundVar),

    // ─── Associated Types ───────────────────────────────────────────
    Alias(AliasTy<I>),

    // ─── Error Recovery ─────────────────────────────────────────────
    Error,
}

/// A type is just an interned pointer to a TyKind.
pub struct Ty<I: Interner>(pub I::InternedTy);
```

### 2.2 Type Flags

```rust
bitflags! {
    pub struct TypeFlags: u32 {
        const HAS_TY_INFER      = 1 << 0;   // Contains InferTy
        const HAS_CT_INFER      = 1 << 1;   // Contains InferConst
        const HAS_PLACEHOLDER   = 1 << 2;   // Contains PlaceholderTy
        const HAS_BOUND_VARS    = 1 << 3;   // Contains Bound (inside Binder)
        const HAS_PARAMS        = 1 << 4;   // Contains ParamTy
        const HAS_ALIAS         = 1 << 5;   // Contains AliasTy
        const HAS_ERROR         = 1 << 6;   // Contains Error
        const HAS_FNPTR         = 1 << 7;   // Contains FnPtr (with potential Binder)
    }
}
```

### 2.3 Function Signature

```rust
/// Function signature: inputs and output.
/// When inside a Binder, the inputs/output may contain Bound variables.
pub struct FnSig<I: Interner> {
    pub inputs: Vec<Ty<I>>,
    pub output: Ty<I>,
}

/// A function pointer type is `Binder<FnSig>` because it can have
/// late-bound parameters: `for<T> fn(T) -> T`
/// 
/// Example: `for<T, U> fn(T) -> U` is:
/// Binder {
///     bound_vars: [Ty, Ty],           // T, U
///     value: FnSig {
///         inputs: [Bound(^0_0)],      // T
///         output: [Bound(^0_1)]       // U
///     }
/// }
```

---

## 3. VARIABLES: THE COMPLETE TAXONOMY

### 3.1 Five Kinds of Variables

```
┌─────────────────┬─────────────┬─────────────────────────────────────────────────────────────┐
│ Name            │ Symbol      │ Description                                                 │
├─────────────────┼─────────────┼─────────────────────────────────────────────────────────────┤
│ Param           │ T, U        │ Early-bound generic parameter. User-declared. Named.        │
│                 │             │ Scope: item-level. Substituted at reference sites.          │
├─────────────────┼─────────────┼─────────────────────────────────────────────────────────────┤
│ Infer           │ ?0, ?1      │ Inference variable. Existential. To be solved.              │
│                 │             │ Scope: per-InferCtxt. Lives in unification table.           │
├─────────────────┼─────────────┼─────────────────────────────────────────────────────────────┤
│ Bound           │ ^0_0, ^1_1  │ De Bruijn variable. Inside Binder<T>.                     │
│                 │             │ ^DEPTH_INDEX. Replaced during instantiation.              │
├─────────────────┼─────────────┼─────────────────────────────────────────────────────────────┤
│ Placeholder     │ !1_0, !2_1  │ Skolemized variable. Rigid. Universe-scoped.              │
│                 │             │ Created from Bound during solver canonicalization.        │
├─────────────────┼─────────────┼─────────────────────────────────────────────────────────────┤
│ Canonical Bound │ ∃0, ∀0      │ Canonical query variable. Existential or Universal.       │
│                 │             │ Used only in Canonical<Goal>. Not in TyKind.              │
└─────────────────┴─────────────┴─────────────────────────────────────────────────────────────┘
```

### 3.2 Param (Early-Bound Generic)

```rust
/// A user-declared generic parameter like `T` in `fn foo<T>(x: T)`.
/// Early-bound: substituted when the item is referenced.
pub struct ParamTy {
    /// Index into the generic parameter list of the defining item.
    pub index: u32,
    /// Human-readable name for diagnostics.
    pub name: Symbol,
}

// Example: `fn foo<T, U>(x: T, y: U)`
// T = ParamTy { index: 0, name: "T" }
// U = ParamTy { index: 1, name: "U" }
```

### 3.3 Infer (Inference Variable)

```rust
/// An unknown type to be inferred.
pub struct InferTy {
    pub vid: TyVid,  // Variable ID into the unification table
}

pub struct TyVid(pub u32);

// Created by the type checker when it sees an unannotated expression.
// Example: `let x = 42;` — x's type is Infer(?0), later resolved to i32.
```

### 3.4 Bound (De Bruijn Variable)

```rust
/// A variable inside a Binder<T>, represented as a De Bruijn index pair.
/// 
/// DebruijnIndex: how many binders to skip outward to find the binder that introduced this var.
/// BoundVar: which parameter within that binder's bound_vars list.
/// 
/// Example: `for<T, U> fn(T) -> U`
///   T is represented as Bound(DebruijnIndex(0), BoundVar(0))  — nearest binder, 0th param
///   U is represented as Bound(DebruijnIndex(0), BoundVar(1))  — nearest binder, 1st param
/// 
/// Example: `for<T> fn(for<U> fn(T, U) -> U)`
///   T in inner position: Bound(DebruijnIndex(1), BoundVar(0)) — 1 binder outward, 0th param
///   U in inner position: Bound(DebruijnIndex(0), BoundVar(0)) — nearest binder, 0th param

pub struct DebruijnIndex(pub u32);
pub struct BoundVar(pub u32);
```

### 3.5 Placeholder (Skolemized Variable)

```rust
/// A skolemized variable created when entering a Binder during solving.
/// Rigid: only equal to itself. Cannot be unified away.
/// Universe-scoped: prevents escaping to outer scopes.
/// 
/// Example: `for<T> fn(T) -> T` skolemized:
///   T becomes PlaceholderTy { universe: U1, bound: BoundVar(0) }
///   The type becomes: fn(!1_0) -> !1_0

pub struct PlaceholderTy {
    /// Which universe this placeholder belongs to.
    /// U0 = root (always visible)
    /// U1 = one binder deep
    /// U2 = two binders deep
    pub universe: UniverseIndex,

    /// Which parameter in the original binder this corresponds to.
    pub bound: BoundVar,
}

pub struct UniverseIndex(pub u32);

// Debug format: !UNIVERSE_BOUNDVAR
// !1_0 = universe 1, bound var 0
// !2_1 = universe 2, bound var 1
```

### 3.6 Why Five Different Variable Types?

| Variable | Phase | Role | Can Unify? |
|----------|-------|------|------------|
| Param | Parsing/Lowering | User generics | No (rigid) |
| Infer | Type Checking | Unknowns to solve | Yes |
| Bound | Type Representation | Inside Binder<T> | No (replaced, not unified) |
| Placeholder | Trait Solving | Skolemized HRTB vars | No (rigid) |
| Canonical | Solver Cache | Canonical query vars | N/A (solver operates on these) |

---

## 4. BINDERS & DE BRUIJN INDICES

### 4.1 What is a Binder?

A `Binder<T>` is a **scope wrapper** that introduces bound variables. It is NOT a type itself — it wraps a type.

```rust
/// A binder wraps a value and lists the variables bound in that scope.
/// 
/// Example: `for<T, U> fn(T) -> U`
/// Binder {
///     bound_vars: [Ty(T), Ty(U)],
///     value: FnSig { inputs: [Bound(^0_0)], output: [Bound(^0_1)] }
/// }
pub struct Binder<I: Interner, T> {
    pub bound_vars: Vec<BoundVariableKind>,
    pub value: T,
}

pub enum BoundVariableKind {
    Ty,
    Const,
}
```

### 4.2 Where Binders Appear

| Location | Example | Binder Wraps |
|----------|---------|--------------|
| Function pointer | `for<T> fn(T) -> T` | `Binder<FnSig>` |
| Trait bound | `F: for<T> Fn(T)` | `Binder<TraitRef>` |
| Trait object | `dyn for<T> Trait<T>` | `Binder<ExistentialPredicate>` |
| Projection | `<T as for<U> Trait<U>>::Assoc` | `Binder<ProjectionPredicate>` |
| Closure signature | Closure env captures | `Binder<FnSig>` |

### 4.3 De Bruijn Index Explained

**De Bruijn index** = a number counting how many `Binder` wrappers to skip outward to find the binder that introduced a variable.

```
for<T> fn(T) -> T
│     │  │     │
│     │  │     └── Bound(DebruijnIndex(0), BoundVar(0)) = T
│     │  └──────── Bound(DebruijnIndex(0), BoundVar(0)) = T
│     └─────────── Binder { bound_vars: [Ty], value: FnSig { ... } }
└───────────────── The type itself

for<T> fn(for<U> fn(T, U) -> U)
│     │  │      │  │  │     │
│     │  │      │  │  │     └── Bound(DebruijnIndex(0), BoundVar(0)) = U
│     │  │      │  │  └──────── Bound(DebruijnIndex(0), BoundVar(0)) = U
│     │  │      │  └─────────── Bound(DebruijnIndex(1), BoundVar(0)) = T
│     │  │      └────────────── Binder { bound_vars: [Ty], value: FnSig { ... } }
│     │  └───────────────────── FnSig { inputs: [^1_0, ^0_0], output: ^0_0 }
│     └──────────────────────── Binder { bound_vars: [Ty], value: FnSig { ... } }
└────────────────────────────── The type itself
```

### 4.4 Why De Bruijn Indices?

**Problem without De Bruijn:** Named variables require alpha-renaming when substituting.

```
Named:   for<T> fn(T) -> for<U> fn(T, U)
Subst T = U:  for<U> fn(U) -> for<U> fn(U, U)  // Name collision!

De Bruijn: for<T> fn(T) -> for<U> fn(^1_0, ^0_0)
Subst:     fn(!1_0) -> fn(!2_0, !2_0)  // No collision, indices are absolute
```

### 4.5 Binder Shifting

When moving a type under a NEW binder, existing bound variables must have their De Bruijn indices incremented.

```rust
/// Shift all De Bruijn indices in a type by `amount`.
/// Called when wrapping a type in a new Binder.
fn shift_vars<I: Interner>(ty: Ty<I>, amount: u32) -> Ty<I> {
    ty.fold_with(&mut Shifter { amount })
}

// Example:
// Before: fn(^0_0) -> ^0_0   (from for<T>)
// Wrap in for<U>: for<U> fn(^0_0) -> ^0_0
//   The ^0_0 now refers to T, but T is 1 binder outward.
//   Shift: fn(^1_0) -> ^1_0
//   Then add U: for<U> fn(^1_0, ^0_0) -> ^1_0
```

---

## 5. PLACEHOLDERS & UNIVERSES

### 5.1 What is a Placeholder?

A **placeholder** is a **skolemized** variable: a fresh constant representing "some arbitrary value" that cannot be unified.

**Skolemization** (from logician Thoralf Skolem): To prove `forall X. P(X)`, assume `c` is an arbitrary constant and prove `P(c)`. If `P(c)` holds for arbitrary `c`, it holds for all `X`.

### 5.2 Why Placeholders Instead of Just Using Bound?

**The Problem with Bound in Solving:**

```rust
// Goal: prove `for<'a> fn(&'a str) : SomeTrait`
// 
// If we use Bound directly:
//   fn(&^0_0 str) : SomeTrait
// 
// Now we find an impl: impl<T> SomeTrait for fn(&T str)
//   We unify T = ^0_0
//   But ^0_0 is a bound variable — what does T = ^0_0 mean outside the binder?
//   UNSOUND: T would capture the bound variable.

// With Placeholder:
//   Skolemize: fn(&!1_0 str) : SomeTrait
//   Try impl: impl<T> SomeTrait for fn(&T str)
//   Unify T = !1_0
//   !1_0 is rigid — it cannot escape. The impl applies.
//   Since it works for arbitrary !1_0, it works for all 'a.
```

### 5.3 Why UniverseIndex?

**Problem:** A placeholder from an inner binder must not unify with something from an outer scope.

```rust
// We have: T: for<'a> Trait<'a>   (where-clause, assumption)
// We want: T: Trait<'static>      (goal)
//
// BAD (unsound): "'a must be 'static" — no! The where-clause says T works
//   for ALL 'a, not that 'a is 'static.

// With universes:
//   'a skolemized to !1_0 (universe U1)
//   'static is in U0
//   !1_0 (U1) cannot unify with 'static (U0) because U1 > U0
//   Instead: we check if the goal is satisfied by the where-clause
//   The where-clause gives us T: Trait<!1_0> for arbitrary !1_0
//   Our goal is T: Trait<'static>
//   We instantiate the binder with an infer var: T: Trait<'?0>
//   '?0 = 'static
//   Now check: does T: Trait<'static> follow from T: Trait<'?0> where '?0='static?
//   Yes! The where-clause applies.
```

### 5.4 Universe Rules

```
U0 = root universe (always visible)
U1 = one binder deep
U2 = two binders deep
...

Rule: A placeholder in universe UN can only unify with:
  - Other placeholders in the SAME universe
  - Types that do NOT contain placeholders from OUTER (lower-numbered) universes

This prevents placeholders from "escaping" their scope.
```

### 5.5 Placeholder vs Param: Side-by-Side

| | Param | Placeholder |
|---|---|---|
| **Represents** | User-declared generic | Skolemized HRTB variable |
| **Created by** | Parser | Solver (`enter_forall`) |
| **Scope** | Item-level | Local to inference context |
| **Has name?** | Yes (`Symbol`) | No (just universe + index) |
| **Has universe?** | No | Yes |
| **Substituted?** | Yes (at call sites) | No (rigid) |
| **Example** | `T` in `fn foo<T>` | `!1_0` from `for<T>` |

---

## 6. THE TYCTXT: GLOBAL TYPE CONTEXT

### 6.1 Purpose

`TyCtxt` is the central hub of the compiler. It:
- Interns all types (pointer equality = type equality)
- Stores query results (demand-driven compilation)
- Provides access to definitions, traits, impls

### 6.2 Structure

```rust
pub struct TyCtxt<I: Interner> {
    /// Arena allocator for types and other interned data
    pub arenas: &'I WorkerLocal<Arenas<I>>,

    /// The interner: maps TyKind -> Ty (deduplicated)
    pub interner: &'I I::Interner,

    /// Query engine: caches and executes compiler queries
    pub queries: &'I I::QueryEngine,

    /// Definitions: maps DefId -> definition data
    pub definitions: &'I Definitions,

    /// Trait system data
    pub trait_impls: &'I TraitImpls<I>,
}
```

### 6.3 Type Creation

```rust
impl<I: Interner> TyCtxt<I> {
    /// Create or retrieve an interned type.
    pub fn mk_ty(self, kind: TyKind<I>) -> Ty<I> {
        let flags = compute_flags(&kind);
        self.interner.intern(kind, flags)
    }

    pub fn mk_param(self, index: u32, name: Symbol) -> Ty<I> {
        self.mk_ty(TyKind::Param(ParamTy { index, name }))
    }

    pub fn mk_infer(self, vid: TyVid) -> Ty<I> {
        self.mk_ty(TyKind::Infer(InferTy { vid }))
    }

    pub fn mk_fn_ptr(self, sig: Binder<I, FnSig<I>>) -> Ty<I> {
        self.mk_ty(TyKind::FnPtr(sig))
    }

    pub fn mk_placeholder(self, universe: UniverseIndex, bound: BoundVar) -> Ty<I> {
        self.mk_ty(TyKind::Placeholder(PlaceholderTy { universe, bound }))
    }

    pub fn mk_bound(self, debruijn: DebruijnIndex, var: BoundVar) -> Ty<I> {
        self.mk_ty(TyKind::Bound(debruijn, var))
    }
}
```

---

## 7. INFERENCE ENGINE

### 7.1 Unification Table

```rust
/// Union-find based unification table for type variables.
pub struct UnificationTable<T: UnifyValue> {
    values: Vec<VarValue<T>>,
}

pub trait UnifyValue: Clone + PartialEq {
    /// Attempt to merge two values. Returns the merged value or an error.
    fn unify_values(a: &Self, b: &Self) -> Result<Self, UnifyError>;
}

enum VarValue<T> {
    Known(T),
    Unknown { parent: u32, rank: u32 },
}
```

### 7.2 InferCtxt

```rust
pub struct InferCtxt<'tcx, I: Interner> {
    pub tcx: TyCtxt<I>,

    // Unification tables
    pub type_table: UnificationTable<TypeValue<I>>,
    pub int_table: UnificationTable<TypeValue<I>>,    // Integer literal vars
    pub float_table: UnificationTable<TypeValue<I>>,  // Float literal vars
    pub const_table: UnificationTable<ConstValue<I>>,

    // Variable counters
    pub type_var_counter: u32,
    pub int_var_counter: u32,
    pub float_var_counter: u32,
    pub const_var_counter: u32,

    // Current universe (for placeholder creation)
    pub universe: UniverseIndex,

    // Pending obligations to prove
    pub obligations: Vec<Obligation<I>>,
}
```

### 7.3 Key Operations

```rust
impl<'tcx, I: Interner> InferCtxt<'tcx, I> {
    /// Create a fresh type inference variable.
    pub fn new_ty_var(&mut self) -> Ty<I> {
        let vid = self.type_var_counter;
        self.type_var_counter += 1;
        self.type_table.new_key();
        self.tcx.mk_infer(TyVid(vid))
    }

    /// Shallow resolve: look up infer var in table.
    pub fn shallow_resolve(&self, ty: Ty<I>) -> Ty<I> {
        match ty.kind() {
            TyKind::Infer(v) => match self.type_table.probe_value(v.vid) {
                Some(TypeValue { ty }) => self.shallow_resolve(ty),
                None => ty,
            }
            _ => ty,
        }
    }

    /// Full resolve: recursively resolve all inference variables.
    pub fn fully_resolve(&self, ty: Ty<I>) -> Ty<I> {
        // Also resolve nested types (tuple fields, fn sigs, etc.)
    }

    /// Enter a new binder scope, creating fresh placeholders.
    pub fn enter_forall<T, R>(&mut self, binder: &Binder<I, T>, f: impl FnOnce(&T) -> R) -> R {
        let old_universe = self.universe;
        self.universe = UniverseIndex(old_universe.0 + 1);

        // Create placeholders for each bound var
        let placeholders: Vec<Ty<I>> = binder.bound_vars.iter().enumerate()
            .map(|(i, _)| self.tcx.mk_placeholder(self.universe, BoundVar(i as u32)))
            .collect();

        // Substitute Bound variables with placeholders in the value
        let instantiated = substitute_bound_vars(&binder.value, &placeholders);
        let result = f(&instantiated);

        self.universe = old_universe;
        result
    }

    /// Unify two types.
    pub fn eq_types(&mut self, a: Ty<I>, b: Ty<I>) -> Result<(), TypeError<I>> {
        let a = self.shallow_resolve(a);
        let b = self.shallow_resolve(b);

        if a == b { return Ok(()); }

        match (a.kind(), b.kind()) {
            (TyKind::Infer(v), _) => {
                self.type_table.assign(v.vid, TypeValue { ty: b })
                    .map_err(|_| TypeError::Mismatch(a, b))
            }
            (_, TyKind::Infer(v)) => {
                self.type_table.assign(v.vid, TypeValue { ty: a })
                    .map_err(|_| TypeError::Mismatch(a, b))
            }
            (TyKind::Param(p1), TyKind::Param(p2)) if p1 == p2 => Ok(()),
            (TyKind::Placeholder(p1), TyKind::Placeholder(p2)) if p1 == p2 => Ok(()),
            (TyKind::Tuple(ts1), TyKind::Tuple(ts2)) if ts1.len() == ts2.len() => {
                for (t1, t2) in ts1.iter().zip(ts2.iter()) {
                    self.eq_types(*t1, *t2)?;
                }
                Ok(())
            }
            (TyKind::Adt(d1, args1), TyKind::Adt(d2, args2)) if d1 == d2 => {
                self.eq_generic_args(args1, args2)
            }
            // ... more cases
            _ => Err(TypeError::Mismatch(a, b)),
        }
    }
}
```

---

## 8. CANONICALIZATION

### 8.1 Purpose

Canonicalization transforms a goal into a form where:
- All inference variables are replaced with **existential bound vars** (∃0, ∃1, ...)
- All params are replaced with **universal bound vars** (∀0, ∀1, ...)
- The result is **independent of any specific inference context**
- Therefore **cacheable** across different solver invocations

### 8.2 Canonical Structure

```rust
/// A canonicalized value: all free variables replaced with bound vars.
pub struct Canonical<I: Interner, V> {
    pub value: V,
    pub binders: Vec<CanonicalVarInfo<I>>,
}

pub struct CanonicalVarInfo<I: Interner> {
    pub kind: CanonicalVarKind,
}

pub enum CanonicalVarKind {
    Ty(CanonicalTyVarKind),
    Const,
}

pub enum CanonicalTyVarKind {
    /// Existential: to be inferred by the solver
    General,
    /// Universal: rigid parameter
    Param,
}
```

### 8.3 Canonicalization Process

```rust
/// Map from local variables to canonical variable indices.
struct Canonicalizer<'a, I: Interner> {
    tcx: TyCtxt<I>,
    binder_depth: u32,
    var_mapping: Vec<(LocalVarId, CanonicalVarIndex)>,
}

impl<'a, I: Interner> TypeFolder<I> for Canonicalizer<'a, I> {
    fn fold_ty(&mut self, ty: Ty<I>) -> Ty<I> {
        match ty.kind() {
            TyKind::Infer(infer) => {
                // Map inference var to existential bound var
                let index = self.canonicalize_infer(infer);
                self.tcx.mk_bound(DebruijnIndex(self.binder_depth), BoundVar(index))
            }
            TyKind::Param(param) => {
                // Map param to universal bound var
                let index = self.canonicalize_param(param);
                self.tcx.mk_bound(DebruijnIndex(self.binder_depth), BoundVar(index))
            }
            TyKind::Placeholder(placeholder) => {
                // Placeholders stay as placeholders (they're already rigid)
                ty
            }
            TyKind::Bound(debruijn, var) => {
                // Existing bound vars: adjust De Bruijn index for new binder
                if debruijn.0 >= self.binder_depth {
                    // Variable is free (not bound by an inner binder)
                    // Map to canonical var
                }
                ty
            }
            _ => ty.super_fold_with(self),
        }
    }
}
```

### 8.4 Response

```rust
pub struct CanonicalResponse<I: Interner> {
    pub certainty: Certainty,
    /// Values for existential variables (the ones the solver found)
    pub var_values: CanonicalVarValues<I>,
}

pub enum Certainty {
    Yes,    // Goal definitely holds
    Maybe,  // Goal might hold (ambiguous)
    No,     // Goal definitely does not hold
}
```

---

## 9. NEXT-GEN TRAIT SOLVER

### 9.1 Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│  EVALUATE_ROOT_GOAL(Goal)                                  │
│  ├── Canonicalize Goal → Canonical<Goal>                   │
│  ├── Check global cache                                     │
│  ├── Check search graph (cycle detection)                   │
│  └── COMPUTE_GOAL(Canonical<Goal>)                         │
│       ├── Assemble candidates                               │
│       │   ├── Impl candidates (user-written)                │
│       │   ├── ParamEnv candidates (where clauses)           │
│       │   └── Built-in candidates                         │
│       ├── For each candidate:                               │
│       │   └── PROBE { evaluate_candidate }                   │
│       └── MERGE_RESPONSES(all candidate responses)           │
└─────────────────────────────────────────────────────────────┘
```

### 9.2 Goal Structure

```rust
pub struct Goal<I: Interner> {
    pub param_env: ParamEnv<I>,
    pub predicate: Predicate<I>,
}

pub enum Predicate<I: Interner> {
    /// T: Trait<Args>
    Trait(TraitRef<I>),
    /// <T as Trait>::Assoc == U
    Projection(ProjectionPredicate<I>),
    /// T == U
    Eq(Ty<I>, Ty<I>),
    /// T <: U (subtyping)
    Subtype(Ty<I>, Ty<I>),
    /// WellFormed(T)
    WellFormed(Ty<I>),
}

pub struct TraitRef<I: Interner> {
    pub def_id: TraitId<I>,
    pub args: GenericArgs<I>,
}
```

### 9.3 EvalCtxt

```rust
pub struct EvalCtxt<'a, 'tcx, I: Interner> {
    pub tcx: TyCtxt<I>,
    pub infcx: &'a mut InferCtxt<'tcx, I>,
    pub search_graph: &'a mut SearchGraph<I>,
    pub global_cache: &'a mut GlobalCache<I>,
    pub recursion_depth: usize,
    pub max_depth: usize,
}

pub struct SearchGraph<I: Interner> {
    pub stack: Vec<SearchGraphNode<I>>,
}

pub struct SearchGraphNode<I: Interner> {
    pub goal: Canonical<I, Goal<I>>,
    pub response: Option<CanonicalResponse<I>>,
    pub stack_depth: usize,
}

pub struct GlobalCache<I: Interner> {
    pub entries: HashMap<Canonical<I, Goal<I>>, CanonicalResponse<I>>,
}
```

### 9.4 Core Algorithm

```rust
impl<'a, 'tcx, I: Interner> EvalCtxt<'a, 'tcx, I> {
    pub fn evaluate_root_goal(&mut self, goal: Goal<I>) -> Result<CanonicalResponse<I>, NoSolution> {
        let canonical = self.canonicalize_goal(goal);
        self.evaluate_canonical_goal(&canonical)
    }

    fn evaluate_canonical_goal(&mut self, canonical_goal: &Canonical<I, Goal<I>>) 
        -> Result<CanonicalResponse<I>, NoSolution> 
    {
        // 1. Check global cache
        if let Some(resp) = self.global_cache.entries.get(canonical_goal) {
            return Ok(resp.clone());
        }

        // 2. Check for cycles
        if let Some(stack_idx) = self.search_graph.contains(canonical_goal) {
            // Coinductive cycle: return provisional (ambiguous)
            return Ok(CanonicalResponse {
                certainty: Certainty::Maybe,
                var_values: CanonicalVarValues::default(),
            });
        }

        if self.recursion_depth > self.max_depth {
            return Err(NoSolution);
        }

        // 3. Push onto search graph
        self.search_graph.stack.push(SearchGraphNode {
            goal: canonical_goal.clone(),
            response: None,
            stack_depth: self.recursion_depth,
        });
        self.recursion_depth += 1;

        // 4. Instantiate canonical goal into local inference context
        let goal = self.instantiate_canonical_goal(canonical_goal);

        // 5. Compute
        let result = self.compute_goal(&goal);

        // 6. Pop from search graph
        self.recursion_depth -= 1;
        self.search_graph.stack.pop();

        let response = result?;

        // 7. Cache successful results
        if response.certainty != Certainty::No {
            self.global_cache.entries.insert(canonical_goal.clone(), response.clone());
        }

        Ok(response)
    }

    fn compute_goal(&mut self, goal: &Goal<I>) -> Result<CanonicalResponse<I>, NoSolution> {
        match &goal.predicate {
            Predicate::Trait(trait_ref) => self.compute_trait_goal(goal, trait_ref),
            Predicate::Projection(proj) => self.compute_projection_goal(goal, proj),
            Predicate::Eq(a, b) => {
                self.infcx.eq_types(*a, *b)?;
                Ok(self.make_response(Certainty::Yes))
            }
            Predicate::WellFormed(ty) => self.compute_wf_goal(ty),
            Predicate::Subtype(a, b) => {
                self.infcx.eq_types(*a, *b)?;  // Simplified: treat as equality
                Ok(self.make_response(Certainty::Yes))
            }
        }
    }

    fn compute_trait_goal(&mut self, goal: &Goal<I>, trait_ref: &TraitRef<I>) 
        -> Result<CanonicalResponse<I>, NoSolution> 
    {
        let candidates = self.assemble_candidates(goal, trait_ref)?;

        if candidates.is_empty() {
            return Err(NoSolution);
        }

        let mut responses = Vec::new();
        for candidate in candidates {
            if let Some(resp) = self.probe(|| self.evaluate_candidate(goal, &candidate)) {
                responses.push(resp);
            }
        }

        self.merge_responses(responses)
    }

    fn assemble_candidates(&mut self, goal: &Goal<I>, trait_ref: &TraitRef<I>) 
        -> Result<Vec<Candidate<I>>, NoSolution> 
    {
        let mut candidates = Vec::new();

        // 1. ParamEnv candidates (where clauses)
        for (idx, bound) in goal.param_env.caller_bounds.iter().enumerate() {
            if let Predicate::Trait(bound_trait) = bound {
                if self.trait_refs_match(bound_trait, trait_ref) {
                    candidates.push(Candidate {
                        source: CandidateSource::ParamEnv(idx),
                        nested_goals: vec![],
                    });
                }
            }
        }

        // 2. Impl candidates (user-written)
        for impl_def in self.tcx.find_impls(trait_ref.def_id, &trait_ref.args.types[0]) {
            candidates.push(Candidate {
                source: CandidateSource::Impl(impl_def),
                nested_goals: self.impl_nested_goals(impl_def, trait_ref)?,
            });
        }

        // 3. Built-in candidates
        if self.is_builtin_trait(trait_ref.def_id) {
            if let Some(candidate) = self.builtin_candidate(trait_ref) {
                candidates.push(candidate);
            }
        }

        Ok(candidates)
    }

    fn evaluate_candidate(&mut self, _goal: &Goal<I>, candidate: &Candidate<I>) 
        -> Result<CanonicalResponse<I>, NoSolution> 
    {
        for nested in &candidate.nested_goals {
            let nested_canonical = self.canonicalize_goal(nested.clone());
            self.evaluate_canonical_goal(&nested_canonical)?;
        }
        Ok(self.make_response(Certainty::Yes))
    }

    fn merge_responses(&mut self, responses: Vec<CanonicalResponse<I>>) 
        -> Result<CanonicalResponse<I>, NoSolution> 
    {
        if responses.is_empty() {
            return Err(NoSolution);
        }

        let all_yes = responses.iter().all(|r| r.certainty == Certainty::Yes);
        let all_maybe = responses.iter().all(|r| r.certainty == Certainty::Maybe);

        if all_yes {
            // Check constraints agree (simplified)
            Ok(self.make_response(Certainty::Yes))
        } else if all_maybe {
            Ok(self.make_response(Certainty::Maybe))
        } else {
            Ok(self.make_response(Certainty::Maybe))  // Ambiguous
        }
    }

    /// Evaluate a closure in an isolated inference snapshot.
    /// If it fails, rollback all changes.
    fn probe<F, R>(&mut self, f: F) -> Option<R>
    where
        F: FnOnce(&mut Self) -> Result<R, NoSolution>,
    {
        let snapshot = self.infcx.snapshot();
        let result = f(self);
        match result {
            Ok(r) => Some(r),
            Err(_) => {
                self.infcx.rollback_to(snapshot);
                None
            }
        }
    }
}
```

### 9.5 Projection (Associated Type Normalization)

```rust
fn compute_projection_goal(&mut self, _goal: &Goal<I>, proj: &ProjectionPredicate<I>) 
    -> Result<CanonicalResponse<I>, NoSolution> 
{
    // Normalize `<T as Trait>::Assoc` to a concrete type.
    // 
    // Steps:
    // 1. Find the applicable impl for the trait.
    // 2. Extract the associated type definition from the impl.
    // 3. Substitute the impl's generic args.
    // 4. Return the normalized type.

    let normalized = self.normalize_alias(&proj.projection_ty)?;
    self.infcx.eq_types(normalized, proj.term)?;
    Ok(self.make_response(Certainty::Yes))
}

fn normalize_alias(&mut self, alias: &AliasTy<I>) -> Result<Ty<I>, NoSolution> {
    // Look up the trait impl and extract the associated type.
    // This requires finding the selected impl for the trait,
    // then looking up the type definition.
    todo!()
}
```

---

## 10. HIR TYPE CHECKER

### 10.1 FnCtxt

```rust
pub struct FnCtxt<'a, 'tcx, I: Interner> {
    pub tcx: TyCtxt<I>,
    pub infcx: InferCtxt<'tcx, I>,
    pub body_id: DefId,
    pub ret_ty: Ty<I>,
    pub locals: HashMap<LocalId, Ty<I>>,
    pub node_types: HashMap<ExprId, Ty<I>>,
    pub param_env: ParamEnv<I>,
}
```

### 10.2 Expression Checking

```rust
impl<'a, 'tcx, I: Interner> FnCtxt<'a, 'tcx, I> {
    pub fn check_expr(&mut self, expr: &Expr) -> Ty<I> {
        let ty = self.check_expr_kind(&expr.kind);
        self.node_types.insert(expr.id, ty);
        ty
    }

    fn check_expr_kind(&mut self, kind: &ExprKind) -> Ty<I> {
        match kind {
            ExprKind::Lit(lit) => self.check_lit(lit),
            ExprKind::Path(path) => self.check_path(path),
            ExprKind::Call(func, args) => self.check_call(func, args),
            ExprKind::MethodCall(receiver, method, args) => {
                self.check_method_call(receiver, *method, args)
            }
            ExprKind::Binary(op, lhs, rhs) => self.check_binary(*op, lhs, rhs),
            ExprKind::Block(stmts, tail) => self.check_block(stmts, tail.as_ref()),
            ExprKind::Tuple(exprs) => {
                let tys: Vec<Ty<I>> = exprs.iter().map(|e| self.check_expr(e)).collect();
                self.tcx.mk_tuple(tys)
            }
            // ... more cases
        }
    }

    fn check_call(&mut self, func: &Expr, args: &[Expr]) -> Ty<I> {
        let func_ty = self.check_expr(func);
        let func_ty = self.infcx.shallow_resolve(func_ty);

        match func_ty.kind() {
            TyKind::FnPtr(sig) => {
                let sig = self.infcx.instantiate_binder_with_fresh_vars(sig);
                if sig.inputs.len() != args.len() {
                    // Error: argument count mismatch
                    return self.tcx.mk_error();
                }
                for (arg, expected) in args.iter().zip(sig.inputs.iter()) {
                    let arg_ty = self.check_expr(arg);
                    self.infcx.eq_types(arg_ty, *expected)?;
                }
                sig.output
            }
            TyKind::FnDef(def_id, args) => {
                // Look up function signature and instantiate generics
                let sig = self.tcx.fn_sig(*def_id);
                let sig = sig.instantiate(self.tcx, args);
                // ... similar to FnPtr
                sig.output
            }
            TyKind::Infer(_) => {
                // Create expected fn type and unify
                let arg_tys: Vec<Ty<I>> = args.iter().map(|a| self.check_expr(a)).collect();
                let ret_ty = self.infcx.new_ty_var();
                let expected = self.tcx.mk_fn_ptr(
                    Binder::dummy(FnSig { inputs: arg_tys, output: ret_ty })
                );
                self.infcx.eq_types(func_ty, expected)?;
                ret_ty
            }
            _ => {
                // Error: not callable
                self.tcx.mk_error()
            }
        }
    }

    fn check_method_call(&mut self, receiver: &Expr, method: Symbol, args: &[Expr]) -> Ty<I> {
        let recv_ty = self.check_expr(receiver);
        let recv_ty = self.infcx.shallow_resolve(recv_ty);

        // Method probe: find applicable methods
        // This involves searching inherent impls and trait impls
        // For each candidate, check if the trait bound is satisfied

        let ret_ty = self.infcx.new_ty_var();

        // Register trait obligation for method resolution
        // The actual resolution happens later when obligations are processed
        self.infcx.register_obligation(Obligation {
            cause: ObligationCause::MethodCall,
            predicate: Predicate::Trait(TraitRef {
                def_id: self.tcx.find_trait_for_method(method, recv_ty),
                args: GenericArgs { types: vec![recv_ty], consts: vec![] },
            }),
        });

        ret_ty
    }
}
```

---

## 11. COHERENCE

### 11.1 Purpose

Ensure that for any given trait and type, there is at most one applicable impl. This prevents ambiguity in trait resolution.

### 11.2 Overlap Check

```rust
pub struct CoherenceChecker<'tcx, I: Interner> {
    pub tcx: TyCtxt<I>,
}

impl<'tcx, I: Interner> CoherenceChecker<'tcx, I> {
    pub fn check_impl_overlap(&self, trait_id: TraitId<I>) -> Result<(), CoherenceError<I>> {
        let impls = self.tcx.trait_impls(trait_id);

        for i in 0..impls.len() {
            for j in (i + 1)..impls.len() {
                if self.impls_overlap(&impls[i], &impls[j])? {
                    return Err(CoherenceError::OverlappingImpls(impls[i], impls[j]));
                }
            }
        }
        Ok(())
    }

    fn impls_overlap(&self, a: &ImplDef<I>, b: &ImplDef<I>) -> Result<bool, CoherenceError<I>> {
        let mut infcx = InferCtxt::new(self.tcx);

        // Get the Self types of both impls
        let a_self = a.trait_ref.args.types[0];
        let b_self = b.trait_ref.args.types[0];

        // Try to unify the Self types
        if infcx.eq_types(a_self, b_self).is_ok() {
            // Check if where clauses are mutually exclusive
            // (negative reasoning — simplified)
            Ok(true)
        } else {
            Ok(false)
        }
    }
}
```

---

## 12. WELL-FORMEDNESS

### 12.1 WF Goals

```rust
fn compute_wf_goal(&mut self, ty: Ty<I>) -> Result<CanonicalResponse<I>, NoSolution> {
    match ty.kind() {
        TyKind::Adt(def_id, args) => {
            // Check that args satisfy the ADT's bounds
            let adt_def = self.tcx.adt_def(*def_id);
            for (i, param) in adt_def.generics.params.iter().enumerate() {
                let arg = &args.types[i];
                for bound in &param.bounds {
                    self.register_obligation(...)?;
                }
            }
            Ok(self.make_response(Certainty::Yes))
        }
        TyKind::Tuple(ts) => {
            for t in ts { self.compute_wf_goal(*t)?; }
            Ok(self.make_response(Certainty::Yes))
        }
        _ => Ok(self.make_response(Certainty::Yes)),
    }
}
```

---

## 13. VARIANCE

### 13.1 Variance Kinds

```rust
pub enum Variance {
    Covariant,      // T<A> <: T<B> if A <: B
    Contravariant,  // T<A> <: T<B> if B <: A
    Invariant,      // T<A> <: T<B> only if A == B
    Bivariant,      // T<A> <: T<B> always (unused in most languages)
}
```

### 13.2 Variance Inference

```rust
pub fn infer_variance<I: Interner>(tcx: TyCtxt<I>, def_id: AdtId<I>) -> Vec<Variance> {
    let adt_def = tcx.adt_def(def_id);
    let mut solver = VarianceSolver::new(tcx);

    // Collect constraints from field types
    for variant in adt_def.variants() {
        for field in variant.fields() {
            solver.add_constraints(field.ty, Variance::Covariant);
        }
    }

    solver.solve()
}
```

---

## 14. COMPLETE FILE TREE

```
compiler/
├── Cargo.toml
│
├── compiler_middle/                    # Core type representation
│   ├── src/
│   │   ├── lib.rs
│   │   ├── def_id.rs                   # DefId, LocalDefId, CrateNum
│   │   ├── span.rs                     # Source spans
│   │   ├── hir/                        # HIR definitions
│   │   │   ├── mod.rs
│   │   │   ├── expr.rs
│   │   │   ├── stmt.rs
│   │   │   ├── item.rs
│   │   │   ├── pat.rs
│   │   │   ├── ty.rs
│   │   │   └── map.rs
│   │   │
│   │   ├── ty/                         # === TYPE SYSTEM CORE ===
│   │   │   ├── mod.rs                  # Ty, TyKind, TyCtxt
│   │   │   ├── sty.rs                  # TyKind variants
│   │   │   ├── consts.rs               # Const, ConstKind
│   │   │   ├── generic_args.rs         # GenericArgs, substs
│   │   │   ├── predicate.rs            # Predicate, PredicateKind
│   │   │   ├── param_env.rs            # ParamEnv
│   │   │   ├── trait_ref.rs            # TraitRef
│   │   │   ├── projection.rs           # AliasTy, ProjectionPredicate
│   │   │   ├── list.rs                 # InternedList<T>
│   │   │   ├── context.rs              # TyCtxt, GlobalCtxt
│   │   │   ├── flags.rs                # TypeFlags
│   │   │   ├── print.rs                # Debug/formatting
│   │   │   └── util.rs                 # Type utilities
│   │   │
│   │   ├── binder.rs                   # Binder<T>, BoundVariableKind
│   │   ├── debruijn.rs                 # DebruijnIndex
│   │   ├── bound_var.rs                # BoundVar
│   │   ├── placeholder.rs              # PlaceholderTy, UniverseIndex
│   │   ├── param.rs                    # ParamTy
│   │   ├── infer_var.rs                # InferTy, TyVid
│   │   │
│   │   ├── fold/                       # TypeFolder, TypeFoldable
│   │   │   ├── mod.rs
│   │   │   ├── folder.rs
│   │   │   └── visitor.rs
│   │   │
│   │   ├── query/                      # Query system
│   │   │   ├── mod.rs
│   │   │   ├── keys.rs
│   │   │   ├── values.rs
│   │   │   └── engine.rs
│   │   │
│   │   └── error/                      # Common errors
│   │       └── mod.rs
│   └── Cargo.toml
│
├── compiler_typeck/                    # === TYPE CHECKER ===
│   ├── src/
│   │   ├── lib.rs
│   │   │
│   │   ├── check/                      # HIR body type checking
│   │   │   ├── mod.rs                  # Entry points
│   │   │   ├── fn_ctxt.rs            # FnCtxt
│   │   │   ├── expr.rs               # Expression checking
│   │   │   ├── stmt.rs               # Statement checking
│   │   │   ├── block.rs              # Block expressions
│   │   │   ├── pat.rs                # Pattern checking
│   │   │   ├── item.rs               # Item checking
│   │   │   ├── cast.rs               # Cast checking
│   │   │   ├── coercion.rs           # Coercion logic
│   │   │   ├── autoderef.rs          # Autoderef chain
│   │   │   ├── method/               # Method resolution
│   │   │   │   ├── mod.rs
│   │   │   │   ├── probe.rs
│   │   │   │   ├── confirm.rs
│   │   │   │   └── suggest.rs
│   │   │   ├── closure.rs            # Closure checking
│   │   │   ├── builtin.rs            # Built-in operators
│   │   │   ├── demand.rs             # Type demand
│   │   │   ├── writeback.rs          # Write inferred types
│   │   │   └── expectation.rs        # Expected types
│   │   │
│   │   ├── infer/                      # === INFERENCE ENGINE ===
│   │   │   ├── mod.rs
│   │   │   ├── context.rs            # InferCtxt
│   │   │   ├── variable.rs           # Variable kinds
│   │   │   ├── table.rs              # Unification table
│   │   │   ├── unify.rs              # Unification logic
│   │   │   ├── freshen.rs            # Type freshening
│   │   │   ├── generalize.rs         # Generalization
│   │   │   ├── lattice.rs            # Type lattice
│   │   │   ├── resolve.rs            # Variable resolution
│   │   │   ├── error_report.rs       # Error reporting
│   │   │   ├── combine.rs            # Type combining
│   │   │   ├── sub.rs                # Subtyping
│   │   │   ├── at.rs                 # Snapshot combinators
│   │   │   ├── snapshot.rs           # Inference snapshots
│   │   │   ├── opaque.rs             # Opaque types
│   │   │   └── canonical.rs          # Local canonicalization
│   │   │
│   │   ├── trait_solver/               # === NEXT-GEN SOLVER ===
│   │   │   ├── mod.rs
│   │   │   ├── entry.rs              # evaluate_root_goal
│   │   │   ├── eval_ctxt.rs          # EvalCtxt
│   │   │   ├── goal.rs               # Goal, GoalKind
│   │   │   ├── candidate.rs          # Candidate, CandidateSource
│   │   │   ├── assemble.rs           # Candidate assembly
│   │   │   ├── probe.rs              # Probe isolation
│   │   │   ├── merge.rs              # Response merging
│   │   │   ├── cache.rs              # Global + provisional cache
│   │   │   ├── canonical.rs          # Canonicalization
│   │   │   ├── response.rs           # CanonicalResponse
│   │   │   ├── delegate.rs           # Goal delegation
│   │   │   ├── normalize.rs          # Normalization
│   │   │   ├── builtin.rs            # Built-in traits
│   │   │   ├── coherence.rs          # Coherence solving
│   │   │   ├── fixpoint.rs           # Cycle handling
│   │   │   └── search_graph.rs       # Search graph
│   │   │
│   │   ├── coherence/                  # === COHERENCE ===
│   │   │   ├── mod.rs
│   │   │   ├── orphan.rs             # Orphan rule
│   │   │   ├── overlap.rs            # Overlap detection
│   │   │   ├── solve.rs              # Coherence solving
│   │   │   └── builtin.rs            # Built-in impls
│   │   │
│   │   ├── wf/                         # Well-formedness
│   │   │   ├── mod.rs
│   │   │   ├── types.rs
│   │   │   └── bounds.rs
│   │   │
│   │   ├── lower/                      # AST/HIR → Ty lowering
│   │   │   ├── mod.rs
│   │   │   ├── ty.rs
│   │   │   └── generic.rs
│   │   │
│   │   ├── collect/                    # Type collection
│   │   │   ├── mod.rs
│   │   │   ├── item.rs
│   │   │   ├── generics.rs
│   │   │   └── bounds.rs
│   │   │
│   │   ├── variance/                   # Variance inference
│   │   │   ├── mod.rs
│   │   │   ├── constraints.rs
│   │   │   └── solve.rs
│   │   │
│   │   ├── error/                      # Diagnostics
│   │   │   ├── mod.rs
│   │   │   ├── mismatch.rs
│   │   │   ├── unsatisfied.rs
│   │   │   ├── ambiguity.rs
│   │   │   ├── recursive.rs
│   │   │   ├── suggestion.rs
│   │   │   └── structured.rs
│   │   │
│   │   └── results.rs                  # TypeckResults
│   │
│   └── Cargo.toml
│
└── compiler_driver/
    └── src/
        └── main.rs
```

---

## 15. ALGORITHM REFERENCE

### 15.1 Type Checking Algorithm

```
for each item in crate:
    if item is a function:
        create FnCtxt with:
            - ret_ty = declared return type (or () if none)
            - param_env = collect where clauses
            - locals = map parameter names to their types

        for each parameter:
            lower HIR type to Ty
            add to locals

        for each expression in body:
            check_expr(expr)

        resolve all pending obligations using trait solver
        resolve all inference variables
        write types to TypeckResults
```

### 15.2 Trait Solving Algorithm

```
function EVALUATE_GOAL(goal):
    canonical = CANONICALIZE(goal)

    if canonical in global_cache:
        return global_cache[canonical]

    if canonical in search_graph.stack:
        return MAYBE  // coinductive cycle

    push canonical onto search_graph

    instantiate canonical into local infcx

    candidates = ASSEMBLE_CANDIDATES(goal)

    responses = []
    for candidate in candidates:
        snapshot = infcx.snapshot()
        result = EVALUATE_CANDIDATE(candidate)
        if result == SUCCESS:
            responses.append(result)
        else:
            infcx.rollback(snapshot)

    pop from search_graph

    response = MERGE_RESPONSES(responses)

    if response.certainty == YES:
        global_cache[canonical] = response

    return response
```

### 15.3 Canonicalization Algorithm

```
function CANONICALIZE(goal):
    create empty mapping
    create empty binder list

    for each variable in goal:
        if variable is Infer:
            index = mapping.add(Infer -> index)
            binders.add(Existential)
        if variable is Param:
            index = mapping.add(Param -> index)
            binders.add(Universal)

    replace all variables in goal with Bound(0, index)

    return Canonical { value: goal, binders }
```

---

## 16. SYNTAX MAPPING

### 16.1 Your Language Syntax → Internal Representation

| Syntax | Internal | Notes |
|--------|----------|-------|
| `fn foo<T>(x: T) -> T` | `FnDef(id, [Param(T)])` | Early-bound, no Binder |
| `for<T> fn(T) -> T` | `FnPtr(Binder<FnSig>)` | Late-bound, Binder wrapper |
| `for<T, U> fn(T) -> U` | `Binder { bound_vars: [Ty, Ty], ... }` | Multiple params |
| `dyn Trait<T>` | `Dyn(Binder<ExistentialPredicates>)` | Trait object |
| `T: for<U> Fn(U)` | `ParamEnv bound: Binder<TraitRef>` | HRTB in where clause |
| `let x = 42` | `Infer(?0)`, later `Int(i32)` | Inference variable |
| `x.clone()` | `MethodCall` + `Trait(T: Clone)` obligation | Method resolution |

### 16.2 Complete Example: HRTB Function

```rust
// User code:
fn apply<F>(f: F)
where
    F: for<T> Fn(T) -> T,
{
    f(10);
    f("hello");
}

// Internal representation of the where clause:
// ParamEnv {
//     caller_bounds: [
//         Trait(Binder {
//             bound_vars: [Ty],  // T
//             value: TraitRef {
//                 def_id: FnTrait,
//                 args: GenericArgs {
//                     types: [
//                         Param(F),           // F
//                         Bound(^0_0),        // T (late-bound)
//                         Bound(^0_0)         // T (return)
//                     ]
//                 }
//             }
//         })
//     ]
// }

// When checking f(10):
// 1. f has type Param(F)
// 2. We need F: Fn(i32) -> ?Ret
// 3. We find where clause: F: for<T> Fn(T) -> T
// 4. Instantiate binder with infer var: F: Fn(?T) -> ?T
// 5. Unify: ?T = i32, ?Ret = ?T = i32
// 6. Check succeeds

// When checking f("hello"):
// 1. Same process
// 2. Instantiate binder with fresh infer var: F: Fn(?U) -> ?U
// 3. Unify: ?U = String, ?Ret = ?U = String
// 4. Check succeeds
// Note: Each call instantiates the binder independently!
```

### 16.3 Complete Example: Nested HRTB

```rust
// User code:
type Nested = for<T> fn(for<U> fn(T, U) -> U) -> T;

// Internal representation:
// FnPtr(Binder {
//     bound_vars: [Ty],  // T
//     value: FnSig {
//         inputs: [
//             FnPtr(Binder {
//                 bound_vars: [Ty],  // U
//                 value: FnSig {
//                     inputs: [
//                         Bound(^1_0),  // T (1 binder outward)
//                         Bound(^0_0)   // U (nearest binder)
//                     ],
//                     output: Bound(^0_0)  // U
//                 }
//             })
//         ],
//         output: Bound(^0_0)  // T
//     }
// })
```

---

## APPENDIX A: GLOSSARY

| Term | Definition |
|------|------------|
| **Binder** | A scope wrapper that introduces bound variables. `Binder<T>` wraps a value T and lists the variables bound in that scope. |
| **BoundVar** | A `u32` index identifying which parameter in a binder's `bound_vars` list. Used with `DebruijnIndex`. |
| **Canonical** | A form of a goal where all free variables are replaced with bound variables, making it cacheable. |
| **De Bruijn Index** | A `u32` counting how many binders to skip outward to find the binder that introduced a variable. |
| **Early-bound** | Variables declared at the item level (e.g., `T` in `fn foo<T>`). Substituted at reference sites. |
| **HRTB** | Higher-Ranked Trait Bound. A trait bound with a `for<...>` binder, e.g., `for<T> Fn(T)`. |
| **Infer** | Inference variable. An unknown type to be solved. Existentially quantified. |
| **Late-bound** | Variables introduced by a `Binder` inside a type. Skolemized during solving. |
| **Param** | Early-bound generic parameter. User-declared, named, rigid. |
| **Placeholder** | Skolemized variable. A fresh constant representing "some arbitrary value." Rigid, universe-scoped. |
| **Skolemization** | Replacing a universally quantified variable with a fresh constant placeholder. |
| **Universe** | A nesting level for binders. Prevents placeholders from escaping their scope. |

---

## APPENDIX B: DECISION SUMMARY

| Feature | Decision | Rationale |
|---------|----------|-----------|
| Lifetimes | Omitted | Simplifies system; no borrow checker |
| HRTB for types | Included | Enables universal function traits; `non_lifetime_binders` exists in rustc nightly |
| De Bruijn indices | Included | Required for nested binders |
| Universe indices | Included | Required for placeholder soundness |
| Next-gen solver | Included | Cleaner architecture than old fulfillment |
| Coherence | Included | Required for sound trait system |
| Variance | Included | Required for subtyping |
| MIR type checker | Omitted | No borrow checking |
| Drop check | Simplified | No lifetimes means simpler destruction |
