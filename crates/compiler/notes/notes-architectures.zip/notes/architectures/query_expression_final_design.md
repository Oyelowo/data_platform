# Yelang Query Expression Final Design

**Status:** design + implementation roadmap  
**Scope:** `.ye` stdlib traits, QIR logical/physical/execution layers, decorrelation, distributed aggregation, exhaustive test checklist.

---

## 1. Goals and Non-Goals

### Goals
- No hardcoded `DecoratorKind` (`Table`, `Link`, etc.) in the query layer. Decorators are only metadata; the query layer works on `Queryable` values.
- No hardcoded `QueryableMethod` enum or name tables. Operator shapes are inferred from the `@lang("queryable")` trait definition loaded from `stdlib/core/src/query.ye`.
- Generic aggregates. `Sum<T>`, `Avg<T>`, `Min<T>`, `Max<T>`, `Product<T>`, `Percentile<T>` all live in `.ye` stdlib and are recognized by trait impl introspection.
- User-defined aggregates work end-to-end: a user writes `impl Aggregate for MyAgg` and `q.aggregate(MyAgg { ... })` and the planner/executor use it without compiler changes.
- Distributed-aware aggregation via `Aggregate::class() -> AggregateClass` only. The compiler does not special-case `sum`, `avg`, `percentile`.
- Decorrelation (Neumann 2025 top-down holistic unnesting) is a first-class QIR rewrite pass, not a one-off.
- The same logical plan lowers to in-memory, embedded storage, distributed, and remote SQL backends.

### Non-Goals
- We do not implement a full cost-based optimizer in this phase. We implement the logical/physical operator framework and rule-based rewrites.
- We do not implement the storage engine itself. We define the storage *capability* interface that the physical planner consults.
- We do not implement full SQL generation. We implement an abstract physical plan that a future SQL backend can stringify.

---

## 2. Source of Truth: `.ye` Standard Library

The compiler must run real `.ye` stdlib through the pipeline. The Rust side only knows about lang items and generic trait-introspection rules.

### 2.1 `stdlib/core/src/query.ye`

```ye
@lang("queryable")
trait Queryable<T> {
    // Lazy transformations.
    fn filter(self, pred: fn(T) -> bool) -> Self;
    fn map<U>(self, f: fn(T) -> U) -> Queryable<U>;
    fn flat_map<U>(self, f: fn(T) -> Queryable<U>) -> Queryable<U>;

    // Ordering, grouping, slicing.
    fn order_by<K>(self, key: fn(T) -> K) -> Seq<T>;
    fn group_by<K>(self, key: fn(T) -> K) -> Queryable<Group<K, T>>;
    fn distinct(self) -> Self;
    fn take(self, n: usize) -> Self;
    fn skip(self, n: usize) -> Self;

    // Eager aggregations. Default bodies are inlined by the QIR lowering.
    fn aggregate<A, Acc, Out>(self, agg: A) -> Out
    where A: Aggregate<T, Acc, Out>;

    fn sum(self) -> T where T: Add, Self: Sized {
        self.aggregate(Sum)
    }

    fn product(self) -> T where T: Mul, Self: Sized {
        self.aggregate(Product)
    }

    fn count(self) -> usize where Self: Sized {
        self.aggregate(Count)
    }

    fn avg(self) -> f64 where T: Numeric, Self: Sized {
        self.aggregate(Avg)
    }

    fn min(self) -> Option<T> where T: Ord, Self: Sized {
        self.aggregate(Min)
    }

    fn max(self) -> Option<T> where T: Ord, Self: Sized {
        self.aggregate(Max)
    }

    fn fold<Acc>(self, init: Acc, f: fn(Acc, T) -> Acc) -> Acc;
    fn reduce(self, f: fn(T, T) -> T) -> Option<T>;

    // Force materialization.
    fn execute(self) -> Vec<T>;
}

@lang("seq")
struct Seq<T> { inner: Queryable<T> }

@lang("group")
struct Group<K, T> { key: K, items: Queryable<T> }
```

### 2.2 `stdlib/core/src/aggregate.ye`

```ye
@lang("aggregate")
trait Aggregate<In, Acc, Out> {
    // `self` is the aggregate *config* (e.g., `Percentile { p: 0.5 }`).
    // It is cloned/shipped to every worker in distributed execution.
    fn init(self: &Self) -> Acc;
    fn step(self: &Self, acc: Acc, item: In) -> Acc;
    fn merge(self: &Self, a: Acc, b: Acc) -> Acc;
    fn finish(self: &Self, acc: Acc) -> Out;
    fn class(self: &Self) -> AggregateClass;
}

enum AggregateClass {
    Distributive,
    Algebraic,
    Holistic,
}

struct Sum;
struct Product;
struct Count;
struct Avg;
struct Min;
struct Max;

struct SumAcc<T> { value: T }
struct ProductAcc<T> { value: T }
struct CountAcc { count: usize }
struct AvgAcc<T> { sum: T, count: usize }

impl<T: Add + Zero> Aggregate<T, SumAcc<T>, T> for Sum {
    fn init(self: &Self) -> SumAcc<T> { SumAcc { value: T::zero() } }
    fn step(self: &Self, acc: SumAcc<T>, item: T) -> SumAcc<T> {
        SumAcc { value: acc.value + item }
    }
    fn merge(self: &Self, a: SumAcc<T>, b: SumAcc<T>) -> SumAcc<T> {
        SumAcc { value: a.value + b.value }
    }
    fn finish(self: &Self, acc: SumAcc<T>) -> T { acc.value }
    fn class(self: &Self) -> AggregateClass { AggregateClass::Distributive }
}

impl<T: Mul + One> Aggregate<T, ProductAcc<T>, T> for Product { ... }

impl<T> Aggregate<T, CountAcc, usize> for Count { ... }

impl<T: Add + Zero + ToF64> Aggregate<T, AvgAcc<T>, f64> for Avg { ... }

impl<T: Ord> Aggregate<T, Option<T>, Option<T>> for Min {
    fn init(self: &Self) -> Option<T> { None }
    fn step(self: &Self, acc: Option<T>, item: T) -> Option<T> {
        match acc { None => Some(item), Some(a) => if item < a { Some(item) } else { acc } }
    }
    fn merge(self: &Self, a: Option<T>, b: Option<T>) -> Option<T> {
        match (a, b) {
            (None, x) | (x, None) => x,
            (Some(a), Some(b)) => if b < a { Some(b) } else { Some(a) },
        }
    }
    fn finish(self: &Self, acc: Option<T>) -> Option<T> { acc }
    fn class(self: &Self) -> AggregateClass { AggregateClass::Distributive }
}

impl<T: Ord> Aggregate<T, Option<T>, Option<T>> for Max { ... }
```

### 2.3 User-defined aggregate example

```ye
struct Percentile { p: f64 }
struct PercentileAcc<T> { values: Vec<T>, p: f64 }

impl<T: Ord + Clone> Aggregate<T, PercentileAcc<T>, T> for Percentile {
    fn init(self: &Self) -> PercentileAcc<T> {
        PercentileAcc { values: Vec::new(), p: self.p }
    }
    fn step(self: &Self, mut acc: PercentileAcc<T>, item: T) -> PercentileAcc<T> {
        acc.values.push(item);
        acc
    }
    fn merge(self: &Self, mut a: PercentileAcc<T>, b: PercentileAcc<T>) -> PercentileAcc<T> {
        a.values.extend(b.values);
        a
    }
    fn finish(self: &Self, mut acc: PercentileAcc<T>) -> T {
        acc.values.sort();
        let idx = ((acc.values.len() as f64) * acc.p) as usize;
        acc.values[idx].clone()
    }
    fn class(self: &Self) -> AggregateClass { AggregateClass::Holistic }
}

let median_age = users.map(|u| u.age as f64).aggregate(Percentile { p: 0.5 });
```

### 2.4 `stdlib/core/src/iter.ye`

`Iterator`/`IntoIterator` remain local, eager, single-node traits. They are **not** the query optimization surface. A type can implement both `IntoIterator` and `Queryable`.

```ye
@lang("iterator")
trait Iterator<T> {
    fn next(self) -> Option<(Self, T)>;
    fn map<U>(self, f: fn(T) -> U) -> MapIter<Self, T, U>;
    fn filter(self, pred: fn(&T) -> bool) -> FilterIter<Self, T>;
    fn fold<U>(self, init: U, f: fn(U, T) -> U) -> U;
    fn take(self, n: usize) -> TakeIter<Self, T>;
    fn skip(self, n: usize) -> SkipIter<Self, T>;
}

@lang("into_iterator")
trait IntoIterator<T> {
    fn into_iter(self) -> Iterator<T>;
}
```

---

## 3. QIR Logical Layer (LIR)

### 3.1 Principles
- A small, fixed set of operators.
- No per-method operators. `sum`, `avg`, `percentile` all lower to `Aggregate`/`AggregateGroupBy` with different closures.
- Aggregates are closures extracted from the `.ye` trait impl.
- Correlated subqueries lower to `DependentJoin`, then a rewrite pass unnests them.

### 3.2 Logical operator set

| Operator | Purpose |
|----------|---------|
| `Scan` | Read a named collection or in-memory value. |
| `Values` | Inline array/record literal. |
| `Filter` | Predicate on current row. |
| `Map` | One-to-one transform. |
| `FlatMap` | One-to-many transform. |
| `OrderBy` | Sort by keys; output is `Seq`. |
| `Slice` | Offset/limit (requires `Seq` for deterministic offset). |
| `Distinct` | Duplicate elimination. |
| `GroupBy` | Group by key; output `{ key, vals }`. |
| `Aggregate` | Reduce to scalar. |
| `AggregateGroupBy` | Group + aggregate in one pass. |
| `Join` | Inner/left/right/full/cross/semi/anti. |
| `DependentJoin` | Correlated subquery (lateral). |
| `SetOp` | Union/Intersect/Except (all/distinct variants). |
| `Construct` | Build record/tuple/array from subplans. |
| `AttachField` | Attach a nested subplan as a field. |
| `Window` | Window functions. |
| `Expr` | Scalar expression embedded in plan. |

### 3.3 `AggregateOp` (carries closures)

```rust
pub struct AggregateOp {
    /// DefId of the aggregate config type (e.g., `Sum`, `Percentile`).
    pub agg_def: DefId,
    /// DefId of the selected `Aggregate` trait impl.
    pub impl_def: DefId,
    /// Classification.
    pub class: AggregateClass,
    /// Per-row input expression fed to `step`.
    pub per_row: QExprId,
    /// Closure `() -> Acc` (or zero-arg function) from `init`.
    pub init: QExprId,
    /// Closure `(Acc, In) -> Acc` from `step`.
    pub step: QExprId,
    /// Closure `(Acc, Acc) -> Acc` from `merge`.
    pub merge: QExprId,
    /// Closure `Acc -> Out` from `finish`.
    pub finish: QExprId,
    /// Aggregate config value (e.g., `Percentile { p: 0.5 }`). Zero-sized for Sum/etc.
    pub config: QExprId,
    pub acc_ty: TyId,
    pub out_ty: TyId,
}
```

The closures are lowered from the `.ye` impl bodies. They capture the aggregate config (`self`) and any generic parameters.

---

## 4. Lowering Path: HIR → LIR

### 4.1 Method resolution enrichment

`MethodResolution` currently records `trait_def_id`, `method_def_id`, `impl_def_id`. For trait methods it does **not** record the selected impl or substitution. We extend it:

```rust
pub struct MethodResolution {
    pub trait_def_id: Option<DefId>,
    pub method_def_id: Option<DefId>,
    pub impl_def_id: Option<DefId>,
    /// The trait ref (with concrete Self + generic args) that was proven.
    pub trait_ref: Option<TraitRef>,
    /// Substitution that maps the impl's generic params to concrete types.
    pub impl_subst: Option<Substitution>,
}
```

The typechecker's `confirm_and_record` must populate these for both inherent and trait candidates by asking the trait solver.

### 4.2 Trait introspection: `Queryable` operator shapes

Instead of `QueryableMethod` enum, we introspect the `Queryable` trait definition:

- `filter(fn(T) -> bool) -> Self` → `Filter`
- `map<U>(fn(T) -> U) -> Queryable<U>` → `Map`
- `flat_map<U>(fn(T) -> Queryable<U>) -> Queryable<U>` → `FlatMap`
- `order_by<K>(fn(T) -> K) -> Seq<T>` → `OrderBy`
- `group_by<K>(fn(T) -> K) -> Queryable<Group<K, T>>` → `GroupBy`
- `distinct() -> Self` → `Distinct`
- `take(usize) -> Self` → `Slice` (offset 0, limit n)
- `skip(usize) -> Self` → `Slice` (offset n, limit None)
- `aggregate<A, Acc, Out>(A) -> Out where A: Aggregate<T, Acc, Out>` → `Aggregate`
- `fold<Acc>(Acc, fn(Acc, T) -> Acc) -> Acc` → `Aggregate` with `Fold` aggregate
- `reduce(fn(T, T) -> T) -> Option<T>` → `Aggregate` with `Reduce` aggregate
- `execute() -> Vec<T>` → no-op / materialization boundary

Sugar methods (`sum`, `avg`, etc.) are recognized by their **default bodies**: the lowering inlines the body, which always reduces to `self.aggregate(Marker)`. If a user overrides `sum` in a downstream impl, the override body is used instead, preserving generality.

The operator-shape table is built once per compilation from the `Queryable` trait AST, not hardcoded.

### 4.3 Aggregate impl introspection

When lowering `.aggregate(marker_expr)`:

1. Lower `marker_expr` to a `QExpr` (`config`).
2. Determine the marker type `M` from `config.ty()`.
3. Build the trait ref `Aggregate<T, Acc, Out>` for `M: Aggregate<T, Acc, Out>`:
   - `T` is the element type of the input pipeline.
   - `Acc` and `Out` are unknown; use the trait solver to find the impl and infer them.
4. From the selected impl, extract `init`/`step`/`merge`/`finish`/`class` method bodies.
5. Lower each body into a `QExpr` closure:
   - Replace the impl method params with fresh `BinderId`s.
   - Substitute generic parameters from `impl_subst`.
   - Bind `self` to the `config` expression.
6. Build `AggregateOp` with the closures.

This is implemented in `yelang-qir/src/logical/aggregate_impl.rs`.

### 4.4 `BinderId` and row naming

`BinderId` is a QIR-internal row identifier generated during lowering. It is **not** the same as a trait/aggregate abstraction. Each pipeline operator that transforms rows introduces a fresh binder for the current row. Closures in `Map`/`Filter`/`Aggregate` use these binders.

Example:

```ye
users.filter(|u| u.age > 18).map(|u| u.name)
```

- `Scan users` emits binder `b0` of type `User`.
- `Filter` closure `|b0| b0.age > 18`.
- `Map` closure `|b1| b1.name` where `b1` is the row type after filter (still `User`).

---

## 5. Decorrelation (Neumann 2025)

### 5.1 Representation

Correlated subqueries lower to `DependentJoin { outer, inner, predicate }`, where `inner` may reference columns from `outer`.

Examples:

```ye
// scalar subquery
select (select sum(o.amount) from orders@o where o.cust_id = c.id) from customers@c

// existential
select c.name from customers@c where exists (select 1 from orders@o where o.cust_id = c.id)

// universal
select c.name from customers@c where not exists (...)
```

All become `DependentJoin` plus `Map`/`Filter`/`Aggregate`.

### 5.2 Top-down holistic unnesting algorithm

Based on Neumann 2025 "Improving Unnesting of Complex Queries" and its 2024 formalization.

1. **Preparation**: walk the plan and identify all non-trivial `DependentJoin`s. For each, compute `D = Π_{free_vars(inner)}(outer)`, the domain of correlation bindings.
2. **Top-down rewrite**: process `DependentJoin`s from outermost to innermost.
3. **Domain pushdown**: for each operator `op` under the dependent join, apply rewrite rules:
   - `D ⋈ σ_p(T)` → `σ_p(D ⋈ T)`
   - `D ⋈ (T1 × T2)` → `(D ⋈ T1) ⋈_natural (D ⋈ T2)` if both sides depend on D
   - `D ⋈ Γ_{A; agg}(T)` → `Γ_{A ∪ A(D); agg}(D ⋈ T)`
   - `D ⋈ (T1 ⋈_p T2)` → similar split rules
   - etc.
4. **Elimination**: when the dependent join reaches a leaf whose free vars are empty, convert to regular `Join`.
5. **Semi/anti joins**: rewrite `DependentJoin` + `Filter(exists(...))` to `SemiJoin`; `not exists` to `AntiJoin`.

The algorithm is implemented as a rewrite pass over `LogicalPlan`:

```rust
// yelang-qir/src/logical/decorrelate.rs
pub fn unnest_dependent_joins(plan: &mut LogicalPlan) -> Result<(), DecorrelationError>;
```

### 5.3 Group-by aggregation over correlated inputs

When an aggregate inside a subquery references outer columns, the domain pushdown rule adds those outer columns to the group-by keys. This is the standard Neumann transformation:

```
D ⋈ Γ_{A; agg}(T)  →  Γ_{A ∪ A(D); agg}(D ⋈ T)
```

Then the outer query joins the result on `D`.

---

## 6. Physical Layer (PIR)

### 6.1 Physical operators

```rust
pub enum PirOp {
    Scan { source: ScanSource, pushdown: Pushdown },
    Filter { input: PirId, predicate: QExprId },
    Map { input: PirId, projection: QExprId },
    FlatMap { input: PirId, projection: QExprId },
    LocalHashAggregate { input: PirId, agg: PhysicalAggregate },
    LocalSortAggregate { input: PirId, agg: PhysicalAggregate },
    HashAggregate { input: PirId, group_keys: Vec<QExprId>, aggregates: Vec<PhysicalAggregate> },
    SortAggregate { input: PirId, group_keys: Vec<QExprId>, aggregates: Vec<PhysicalAggregate> },
    Sort { input: PirId, keys: Vec<OrderKey> },
    Slice { input: PirId, offset: QExprId, limit: Option<QExprId> },
    HashJoin { kind: JoinKind, left: PirId, right: PirId, keys: Vec<(QExprId, QExprId)> },
    NestedLoopJoin { kind: JoinKind, left: PirId, right: PirId, predicate: QExprId },
    Exchange { input: PirId, partition: ExchangeKind },
    Gather { input: PirId },
    Materialize { input: PirId },
    Construct { kind: ConstructKind, fields: Vec<(Symbol, PirId)> },
    Expr(QExprId),
}

pub enum ExchangeKind {
    Hash(Vec<QExprId>),
    Broadcast,
    Single,
}

pub struct PhysicalAggregate {
    pub agg_op: AggregateOp, // logical aggregate with closures
    pub phase: AggregatePhase,
}

pub enum AggregatePhase {
    Partial,   // step only, emit Acc
    Final,     // merge + finish
    Full,      // step + finish (for holistic or single-node)
}
```

### 6.2 Aggregate physical planning by class

| Class | Strategy |
|-------|----------|
| Distributive | `Partial` per partition → `Exchange` → `Final` |
| Algebraic | same as Distributive (fixed-size Acc) |
| Holistic | `Exchange(Single)` or `Gather` then `Full` |

For group-by with distributive/algebraic aggregates:
- `Partial` with group-by keys + hash aggregate per partition.
- `Exchange(Hash(keys))`.
- `Final` aggregate per group.

For group-by with holistic aggregates:
- `Exchange(Hash(keys))` first (group all values for same key on one node).
- `Full` aggregate per group.

### 6.3 Storage capabilities

The physical planner asks the backend about its capabilities:

```rust
pub struct StorageCapabilities {
    pub can_pushdown_filter: bool,
    pub can_pushdown_project: bool,
    pub supports_hash_aggregate: bool,
    pub supports_streaming_aggregate: bool,
    pub distribution: DistributionMode,
}

pub enum DistributionMode {
    SingleNode,
    Partitioned(Vec<QExprId>), // current partitioning keys
    Shuffled(Vec<QExprId>),    // after exchange
}
```

---

## 7. Execution Layer

### 7.1 In-memory executor

The existing `MemoryExecutor` is extended to evaluate aggregate closures:

```rust
fn eval_aggregate(
    &mut self,
    input: &mut dyn Iterator<Item = Value>,
    agg: &AggregateOp,
) -> Value {
    let mut acc = self.eval_expr(&agg.init, &[])?; // init closure
    for row in input {
        let per_row = self.eval_expr(&agg.per_row, &[row.clone()])?;
        acc = self.eval_expr(&agg.step, &[acc, per_row])?;
    }
    self.eval_expr(&agg.finish, &[acc])
}
```

For `AggregateGroupBy`:
1. Build hash map keyed by `group_keys`.
2. For each row, compute key and per-row value.
3. Call `step` closure to update the accumulator for that key.
4. After all rows, call `finish` for each group.

### 7.2 Distributed execution

For distributed backends, the physical plan is serialized. Each stage references the aggregate closures by symbol. The closures are compiled to native code or bytecode and shipped with the plan.

The serialized plan format (future) includes:
- Physical operator tree.
- Aggregate config value.
- Init/step/merge/finish bytecode or symbol references.

---

## 8. Logical Optimization Pipeline

Order matters. We run passes until fixpoint where noted.

1. **Normalize**. Convert sugar methods to `aggregate`. Flatten nested `Map`/`Filter`. Push `Distinct` down where possible.
2. **Decorrelate**. `DependentJoin` → `Join`/`SemiJoin`/`AntiJoin`/`AggregateGroupBy` (Neumann 2025).
3. **Predicate pushdown**. Push filters through maps, joins, group-bys.
4. **Projection pushdown**. Remove unused fields early.
5. **Aggregate merging**. Combine multiple aggregates over the same input into one `AggregateGroupBy`.
6. **Join reordering** (future cost-based; for now, heuristic: small-side-first).
7. **Subplan materialization**. Decide what must be materialized vs streamed.
8. **Physical planning**. Choose hash vs sort, partial vs full aggregate, exchange placement.

---

## 9. Exhaustive File Tree

```
yelang-qir/
├── src/
│   ├── lib.rs
│   ├── ids.rs                    # LirId, PirId, QExprId, BinderId
│   ├── expr.rs                   # QExpr, AggregateClass, OrderKey, etc.
│   ├── errors.rs                 # QIR error types
│   ├── volatility.rs             # Volatility/Boundedness
│   │
│   ├── logical/                  # LAYER 1: Logical plan (LIR)
│   │   ├── mod.rs
│   │   ├── plan.rs               # LogicalPlan arena + builders
│   │   ├── operator.rs           # LirOp enum
│   │   ├── props.rs              # LogicalProps (cardinality, ordering, etc.)
│   │   │
│   │   ├── lower.rs              # LoweringCtxt, lang traits, populate tables
│   │   ├── lower_query.rs        # Lower select/from/where/group/order/range
│   │   ├── lower_expr.rs         # Lower HIR expr to QExpr
│   │   ├── lower_method.rs       # Dispatch method calls to trait modules
│   │   │
│   │   ├── queryable.rs          # Queryable method lowering (no enum, shape-driven)
│   │   ├── aggregate.rs          # Aggregate operator construction
│   │   ├── aggregate_impl.rs     # Extract closures from Aggregate trait impl
│   │   ├── stdlib.rs             # Introspect real .ye stdlib (Queryable shapes, Aggregate class)
│   │   │
│   │   ├── rewrite/
│   │   │   ├── mod.rs
│   │   │   ├── normalize.rs      # Sugar inlining, flatten map/filter
│   │   │   ├── pushdown.rs       # Predicate/projection pushdown
│   │   │   ├── decorrelate.rs    # Neumann 2025 top-down unnesting
│   │   │   ├── aggregate_merge.rs# Merge aggregates over same input
│   │   │   └── simplify.rs       # Dead code, identity eliminations
│   │   │
│   │   └── optimize.rs           # Logical optimizer driver
│   │
│   ├── physical/                 # LAYER 2: Physical plan (PIR)
│   │   ├── mod.rs
│   │   ├── plan.rs               # PhysicalPlan arena + builders
│   │   ├── operator.rs           # PirOp enum, PhysicalAggregate, ExchangeKind
│   │   ├── capabilities.rs       # StorageCapabilities, DistributionMode
│   │   ├── lower.rs              # LIR -> PIR
│   │   ├── aggregate.rs          # Aggregate physical strategy by class
│   │   ├── join.rs               # Join physical strategy
│   │   └── cost.rs               # Cost model (heuristic for now)
│   │
│   ├── exec/                     # LAYER 3: Execution
│   │   ├── mod.rs
│   │   ├── memory.rs             # In-memory interpreter over PirOp
│   │   ├── kernels.rs            # Operator kernels (map, filter, aggregate, etc.)
│   │   ├── aggregate.rs          # Closure-based aggregate evaluation
│   │   ├── value.rs              # Runtime value representation
│   │   └── expr.rs               # QExpr interpreter
│   │
│   └── codegen/                  # LAYER 4: Future native/SQL backends
│       ├── mod.rs
│       └── sql.rs                # SQL string generation (placeholder)
│
└── tests/
    ├── end_to_end_query_tests.rs
    ├── aggregate_closure_tests.rs
    ├── queryable_trait_tests.rs
    ├── decorrelation_tests.rs
    ├── distributed_plan_tests.rs
    └── support/mod.rs

stdlib/core/src/
├── lib.ye
├── iter.ye
├── query.ye
└── aggregate.ye

notes/architectures/
├── query_expression_final_design.md   # this doc
└── query_expression_checklist.md      # implementation checklist
```

---

## 10. Implementation Phases

### Phase 0: Bootstrap typechecker support
- Ensure method-level generics in trait default bodies parse and typecheck.
- Ensure `Self: Sized` where clauses parse and typecheck.
- Test: `fn sum(self) -> T where T: Add, Self: Sized { self.aggregate(Sum) }` compiles.

### Phase 1: `.ye` stdlib update
- Rewrite `aggregate.ye` with `&self` methods and generic impls.
- Add sugar defaults to `query.ye`.
- Add `Min`, `Max`, `Product` aggregates.

### Phase 2: Method resolution enrichment
- Extend `MethodResolution` with `trait_ref` and `impl_subst`.
- Update `confirm_and_record` to populate them.
- Add `TyCtxt` helper to query the trait solver for a selected impl.

### Phase 3: Generic aggregate lowering
- Implement `aggregate_impl.rs` to extract closures from trait impls.
- Extend `AggregateOp` with `init/step/merge/finish/config` closures.
- Update `queryable.rs` lowering for `.aggregate(marker)`.

### Phase 4: Sugar inlining
- Inline default trait method bodies (`sum`, `avg`, etc.) to `self.aggregate(Marker)`.
- Remove `QueryableMethod::Sum/Avg/Count` and the aggregate sugar special cases.

### Phase 5: Trait-introspection operator shapes
- Replace `QueryableMethod` enum with operator-shape inference from `Queryable` trait signatures.
- Build shape table in `stdlib.rs` from trait AST.

### Phase 6: Executor closure evaluation
- Update `MemoryExecutor` to evaluate aggregate closures.
- Implement `hash_aggregate` with closure-based `step`/`finish`.
- Support `AggregateGroupBy`.

### Phase 7: Decorrelation framework
- Implement `DependentJoin` lowering for subqueries.
- Implement Neumann 2025 top-down rewrite pass.
- Add semi/anti join lowering.

### Phase 8: Physical planning
- Build PIR layer.
- Implement aggregate physical strategy by class.
- Add exchange operators for distributed planning.

### Phase 9: Tests
- Aggregate closure tests for all built-in aggregates.
- User-defined aggregate test (Percentile).
- Sugar inlining tests (`sum`, `avg`, `min`, `max`, `count`).
- Decorrelation tests (scalar, exists, not exists, nested).
- Distributed plan tests (distributive/algebraic/holistic strategies).

---

## 11. Test Checklist

### Stdlib
- [ ] `query.ye` typechecks with default method bodies.
- [ ] `aggregate.ye` typechecks with generic `Sum<T>`, `Avg<T>`, `Min<T>`, `Max<T>`.
- [ ] `Percentile` user aggregate typechecks.

### Lowering
- [ ] `users.sum()` lowers to `Aggregate` with `Sum` closures.
- [ ] `users.avg()` lowers to `Aggregate` with `Avg` closures.
- [ ] `users.count()` lowers to `Aggregate` with `Count` closures.
- [ ] `users.min()` / `users.max()` lower to `Aggregate` with `Min`/`Max` closures.
- [ ] `users.aggregate(Percentile { p: 0.5 })` lowers correctly.
- [ ] `.map().filter().sum()` chain lowers to single `Aggregate` over composed pipeline.
- [ ] `group by ... into g ... g.users.sum()` lowers to `AggregateGroupBy`.

### Execution
- [ ] `sum` on `[1,2,3]` returns 6.
- [ ] `avg` on `[1,2,3]` returns 2.0.
- [ ] `count` on `[1,2,3]` returns 3.
- [ ] `min`/`max` on `[]` returns `None`.
- [ ] `min`/`max` on `[3,1,2]` returns `Some(1)`/`Some(3)`.
- [ ] `percentile` on `[1,2,3,4,5]` with `p=0.5` returns 3.
- [ ] group-by + aggregate returns correct grouped results.

### Decorrelation
- [ ] Scalar subquery: `select (select sum(o.amount) ...) from customers@c`.
- [ ] Exists: `select c.name where exists (select 1 from orders where o.cust_id = c.id)`.
- [ ] Not exists: anti-join.
- [ ] Nested correlated subqueries (Neumann 2025 crash.sql pattern).
- [ ] Correlated aggregate subquery in filter.

### Distributed planning
- [ ] `sum` plan: partial → exchange → final.
- [ ] `avg` plan: partial (sum+count) → exchange → final.
- [ ] `percentile` plan: gather → full.
- [ ] Group-by + `sum`: hash partial → exchange(hash keys) → hash final.
- [ ] Group-by + `percentile`: exchange(hash keys) → full per group.

---

## 12. References

- Neumann 2025, "Improving Unnesting of Complex Queries" [PDF](https://15799.courses.cs.cmu.edu/spring2025/papers/11-unnesting/neumann-btw2025.pdf)
- Neumann 2024, "A Formalization of Top-Down Unnesting" [arXiv](https://arxiv.org/abs/2412.04294)
- Fegaras, "An Algebra for Distributed Big Data Analytics" (MRQL monoid algebra) [PDF](https://lambda.uta.edu/mrql-algebra.pdf)
- DuckDB aggregate function documentation — init/update/combine/finalize/serialize interface.
- DryadLINQ — distributed LINQ and exchange operators.
