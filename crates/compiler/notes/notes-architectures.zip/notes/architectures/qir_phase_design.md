# QIR Phase Design: First-Class Queries in Yelang

This document is the authoritative design for the current compiler phase. It
unifies query-syntax, method-call pipelines, aggregation, iteration, and
subqueries into a single, backend-agnostic query IR (QIR) that is produced from
THIR and lowered through logical (LIR), physical (PIR), and execution (Exec)
plans. It is intentionally greenfield: no legacy `DecoratorKind`, `ProjKind`, or
hardcoded operator enums survive in the new path.

## 1. Goals and principles

1. **Queries are ordinary expressions.** `select <proj> from <src>@<binder> …`
   has the same status as any other expression. It is type-checked by the
   normal trait solver and lowered by the normal THIR→QIR pass.
2. **No hardcoded operators.** The compiler recognizes `Queryable`,
   `Iterator`, `IntoIterator`, `FromIterator`, and `Aggregate` through lang
   items and trait resolution. The *shape* of each operator is derived from
   the stdlib method body (`@intrinsic(query_*, …)` or `aggregate(Marker {})`),
   not from a compiler-internal table of names.
3. **User-defined pipelines compose.** A user-defined function or method that
   calls recognized operators is transparently extracted; custom aggregates
   implement the `Aggregate` trait and are picked up automatically.
4. **One logical algebra, many physical plans.** LIR is small and
   backend-independent. PIR and the executor choose vectorized, code-generated,
   interpreted, or distributed strategies based on backend capabilities and
   data properties.
5. **Decorrelation is a logical rewrite.** All correlated subqueries are
   represented as `DependentJoin` and then unnested with a single-pass top-down
   algorithm (Neumann 2025) before physical planning.
6. **Projection determines shape.** The `select` expression is the final
   `Map`/`Construct` operator. If it evaluates to a scalar, the query returns a
   scalar; if it evaluates to a per-row record/array, the query returns that
   shape. `from`/`links` only bring binders into scope.
7. **Value semantics by default.** Structs and arrays behave as values.
   Mutation requires an explicit `mut` binding. The runtime uses reference
   counting + copy-on-write under the hood for large/shared payloads, but this
   is an implementation detail, not surface syntax.

## 2. Decisions

### 2.1 Memory model

- **Primitives and small structs (< 64 bytes, no heap):** `Copy` by default.
- **Large structs, arrays, closures, query results:** value semantics with
  transparent CoW. The stdlib exposes `Shared<T>` and `Arena<T>` for the rare
  cases where the programmer wants explicit shared ownership or region
  allocation.
- **Assignment (`let y = x`)** produces an independent value. If the payload is
  shared under the hood, mutation of `y` triggers `make_mut` and leaves `x`
  unchanged.
- **Variables must be declared `mut` to mutate.** This is enforced in the type
  checker and MIR.
- **No GC.** Deterministic destruction is required for storage cursors, sockets,
  file handles, and exchange channels.

This gives predictable “mutation does not affect the original” behavior without
requiring a borrow checker.

### 2.2 `Queryable` vs `Iterator`

| Trait | Purpose | When used |
|-------|---------|-----------|
| `Queryable<T>` | Lazy, optimizable, backend-aware pipeline | Sources that the compiler should plan (arrays, tables, streams) |
| `Iterator<T>` | Eager, pull-based, local iteration | `for` loops, explicit consumers, adapters |
| `IntoIterator<T>` | “convert to iterator” | `for x in xs` and `collect` |
| `FromIterator<T>` | build a collection | `collect::<Vec<T>>()` |

`Queryable` methods return `Queryable<U>` (existential/`impl Queryable<U>` once
supported). `Iterator` methods return concrete adapter structs (`MapIter`,
`FilterIter`, etc.). A type may implement both; the compiler uses
`Queryable` when a pipeline contains optimizable operators and falls back to
`Iterator` otherwise.

### 2.3 Projection and binders

`from users@u: User` introduces a **row binder** `u` of type `User` into the
projection scope. The source collection `users` is not directly visible as a
value in the projection; only the row binder is.

```ye
select u from users@u;                // stream of User
select { id: u.id, age: u.age }       // stream of anonymous records
  from users@u;
select users@u[*].{ id, age }         // explicit selector form; same result
```

`users@u[*]` is a selector expression that names both the collection and the
row binder. In `select <expr> from users@u`, the projection `<expr>` is
implicitly evaluated once per row from `users`, exactly as if the query were
`users.map(|u| <expr>)`.

### 2.4 Aggregates

Aggregates are ordinary structs implementing the `Aggregate` trait:

```ye
@lang("aggregate")
trait Aggregate<In, Acc, Out> {
    fn init(self: &Self) -> Acc;
    fn step(self: &Self, acc: Acc, value: In) -> Acc;
    fn merge(self: &Self, a: Acc, b: Acc) -> Acc;
    fn finish(self: &Self, acc: Acc) -> Out;
    fn class(self: &Self) -> AggregateClass;
}

enum AggregateClass { Distributive, Algebraic, Holistic }
```

- `Distributive`: partial state is the same as the output (`sum`, `min`, `max`).
- `Algebraic`: fixed-size intermediate state (`avg` = sum+count, `stddev`).
- `Holistic`: must see the whole group (`median`, `percentile`).

Built-in aggregates live in `stdlib/core/src/aggregate_impls.ye`. Users add new
aggregates by writing a struct + impl; no compiler recompilation is required.

### 2.5 Subqueries and links

A subquery in a `where`/`having`/projection clause is represented as a
`DependentJoin(L, R, correlated_vars)`. `links` graph traversals lower to
`EdgeExpand` joins. Both are unnested by the same top-down decorrelation pass.

## 3. Core abstractions

### 3.1 Lang items

The compiler recognizes these lang items in `yelang-resolve/src/lang_items.rs`:

- `Queryable`
- `Aggregate`
- `Iterator`
- `IntoIterator`
- `FromIterator`
- `Copy`, `Clone`, `Drop`, `Send`, `Sync` (memory model)

No other query-specific knowledge is baked into the compiler.

### 3.2 `@intrinsic` operator markers

The stdlib writes `Queryable` method bodies using `@intrinsic` placeholders:

```ye
fn map<U>(self, f: fn(T) -> U) -> Queryable<U> {
    let plan: PlanId = @intrinsic(query_map(self.plan, f));
    QueryArray { plan }
}
```

The QIR extractor recognizes the first argument of an `@intrinsic` call and
maps it to an operator *shape*. The shape records:
- logical operator kind (`Map`, `Filter`, `OrderBy`, `Aggregate`, …)
- which argument is the input plan
- which argument is the closure/predicate/key
- the return type transformation

Sugar methods such as `sum()` have no intrinsic; their body is
`self.aggregate(Sum {})`, which the extractor recognizes as an aggregate call.

### 3.3 Operator shapes from the trait definition

`ExtractCtxt::discover_queryable_methods` scans the `Queryable` trait and its
impls. For each method it prefers an impl body containing a recognized
`@intrinsic` call; otherwise it falls back to the trait default body. The
resulting `QueryableMethodInfo` is keyed by the method’s `DefId`, not by name.

The same mechanism applies to `Iterator` methods once the bootstrap compiler
supports the higher-kinded adapter impls.

## 4. End-to-end pipeline

```
.ye source
    │
    ▼
AST ──► resolver ──► HIR
    │
    ▼
type checker ──► THIR
    │
    ▼
yelang-qir::logical::lower_thir_body
    │
    ▼
LIR (LogicalPlan of LirOp + QExpr closures)
    │
    ▼
rewrite passes (normalize, simplify, push filters/projects, unnest)
    │
    ▼
PIR (PhysicalPlan of PirOp)
    │
    ▼
ExecPlan / operator tree
    │
    ▼
execute on MemoryBackend / StorageBackend / StreamBackend / DistributedBackend
```

The legacy HIR→LIR path is removed in this phase; `Driver::compile` and the
end-to-end tests use the THIR→QIR path exclusively.

## 5. THIR representation

`yelang-thir/src/expr.rs` keeps `ThirExpr::Query(QueryId)`. The side table in
`yelang-thir/src/query.rs` stores:

```rust
struct Query {
    kind: QueryKind,            // Select, Insert, Update, Delete, Upsert
    roots: Vec<QueryRoot>,      // from / links sources
    projection: ThirExprId,     // select expression
    where_clause: Option<ThirExprId>,
    group_by: Option<GroupBy>,
    order_by: Option<OrderBy>,
    range: Option<Range>,
}

struct QueryRoot {
    source: Source,             // path, array literal, subquery
    binder: ThirPatId,
    ty: TyId,
    modifiers: Vec<RootModifier>, // per-root filter/order/range
}
```

HIR→THIR lowering (`yelang-thir/src/lower_query.rs`) desugars query syntax
into this structure and resolves each source’s type. Method calls are lowered
as ordinary `ThirExpr::Call { func: Var(method_def_id), args: [receiver, …] }`.

## 6. QIR logical extraction

### 6.1 From THIR expression to LIR

`logical/extract.rs::extract_expr` handles:

- `ThirExpr::Call` — if the callee is a `Queryable`/`Iterator`/`Aggregate`
  method, delegate to `logical/queryable.rs` or `logical/aggregate.rs`;
  otherwise lower as a scalar `QExpr`.
- `ThirExpr::Intrinsic` — delegate to `logical/intrinsic.rs`.
- `ThirExpr::Query` — delegate to `logical/query_syntax.rs`.
- Everything else — lower to `QExpr` via `logical/scalar.rs`.

### 6.2 Queryable method lowering

`logical/queryable.rs` builds a `LirOp` from a resolved method call:

```rust
fn lower_queryable_call(
    plan: &mut LogicalPlan,
    ctx: &mut ExtractCtxt,
    receiver: LirId,
    method_info: &QueryableMethodInfo,
    args: &[ThirExprId],
) -> Result<LirId, LoweringError>
```

It reads the operator shape from `method_info` and emits the matching
`LirOp::Map` / `Filter` / `OrderBy` / `GroupBy` / `Slice` / `Aggregate` /
`DependentJoin` / `Execute`. Closures are lowered to `QExpr::Closure`.

### 6.3 Aggregate lowering

`logical/aggregate.rs` resolves the aggregate config struct (`Sum {}`,
`Avg {}`, user-defined `Percentile { p: 0.5 }`) to the matching `Aggregate`
trait impl, extracts `init`/`step`/`merge`/`finish`/`class`, and builds an
`AggregateOp` whose closures are `QExpr::Closure`. The per-row input is bound to
a fresh `BinderId` taken from the upstream operator’s `output_binder`.

### 6.4 Query syntax lowering

`logical/query_syntax.rs` converts a `ThirExpr::Query` into a LIR pipeline:

1. Build a `Scan` or `Values` for each `from` root.
2. Apply per-root modifiers (filter, order, range) as `Filter` / `OrderBy` /
   `Slice`.
3. If there are multiple roots, combine them with `Join` or `DependentJoin`
   depending on whether later roots reference earlier binders.
4. Apply global `where`.
5. Apply `group by` as `GroupBy` (which produces nested groups) followed by
   aggregation / projection over each group.
6. Apply global `order by` and `range`.
7. Apply the `select` projection as `Map` or `Construct`.

`links` paths lower to `EdgeExpand(join_kind, edge, direction)` joined with the
current pipeline.

## 7. Logical algebra

`yelang-qir/src/lir/operator.rs` defines the backend-independent algebra:

```rust
enum LirOp {
    // Sources
    Scan { source: DefId },
    Values { rows: Vec<QExprId> },

    // Row transforms
    Filter { input: LirId, pred: QExprId },
    Map { input: LirId, projection: QExprId },
    FlatMap { input: LirId, projection: QExprId },
    Construct { input: LirId, shape: ConstructShape },

    // Ordering / slicing
    OrderBy { input: LirId, key: QExprId, dir: Direction },
    Slice { input: LirId, offset: QExprId, limit: QExprId },

    // Grouping and aggregation
    GroupBy { input: LirId, key: QExprId },
    Aggregate { input: LirId, op: AggregateOp },
    AggregateGroupBy { input: LirId, key: QExprId, op: AggregateOp },

    // Joins
    Join { kind: JoinKind, left: LirId, right: LirId, on: QExprId },
    DependentJoin { left: LirId, right: LirId, correlated: Vec<BinderId> },
    EdgeExpand { input: LirId, edge: DefId, direction: Direction },

    // Set ops
    Union { inputs: Vec<LirId> },
    Intersect { inputs: Vec<LirId> },
    Except { left: LirId, right: LirId },

    // Materialization
    Execute { input: LirId },
}
```

`AggregateOp` holds the closures from the `Aggregate` trait impl plus the
`AggregateClass`.

## 8. Decorrelation / unnesting

All correlated execution is represented by `LirOp::DependentJoin`. The rewrite
pass `rewrite/unnest.rs` implements Neumann’s top-down algorithm:

1. Collect the set `D` of binders produced by the left input that are
   referenced by the right input.
2. If `D` is empty, replace `DependentJoin(L, R)` with `Join(L, R, true)`.
3. Otherwise push `D` down the right subtree:
   - Through `Filter`: add `D` to the predicate’s free variables; the filter
     becomes a join predicate.
   - Through `Map`/`Project`: add `D` columns to the projection.
   - Through `Join`: duplicate `D` on both sides or pull it above if the join
     eliminates it.
   - Through `Aggregate`: group by `D` plus the original group key, producing
     one aggregate result per correlation row.
   - Through `GroupBy`: include `D` in the key.
4. When the right input becomes a simple `Scan`/`Filter` over a base source
   that uses only `D` and its own columns, replace the dependent join with a
   regular `Join(L, R, predicate)`.

The pass runs to a fixed point before join reordering and physical planning.

## 9. Physical planning

`yelang-qir/src/pir/planner.rs` maps LIR to PIR. This phase is allowed to be
backend-aware via `BackendCapability`.

```rust
enum PirOp {
    TableScan, Values,
    Filter, Project, FlatMap,
    Sort, TopK, Slice,
    HashJoin, MergeJoin, NestedLoopJoin,
    GroupBy, HashAggregate, SortAggregate, StreamingAggregate,
    Exchange, LocalRepartition,
    EdgeExpand,
    Construct, AttachField,
    Expr,
}
```

Physical properties tracked:
- **Order**: sorted columns and direction.
- **Partitioning**: hash/range/single/broadcast on a set of columns.
- **Distribution**: local, remote, replicated, sharded.
- **Boundedness**: finite or unbounded.

The planner inserts `Sort` and `Exchange` enforcers when an operator requires a
property the input does not provide.

### 9.1 Aggregate physical strategies

Based on `AggregateClass` and backend distribution:

| Class | Local | Distributed |
|-------|-------|-------------|
| Distributive | single pass | partial per shard → exchange by group key → final merge |
| Algebraic | single pass with struct state | partial per shard → merge struct states → finalize |
| Holistic | sort or full materialization | gather all data to coordinator → aggregate |

Multiple aggregates over the same grouping key are fused into one state object.

## 10. Execution

`yelang-qir/src/exec/` lowers PIR to an executable operator tree. The default
interpreter (`exec/interpreter.rs`) is a pull-based row iterator over `Value`.
Backends can override:

- **MemoryBackend**: row-at-a-time interpreter, with optional vectorized batches.
- **StorageBackend**: push scan predicates and projections into the LSM/cursor.
- **StreamBackend**: push dataflow with watermarks and windows.
- **DistributedBackend**: fragment the PIR at `Exchange` boundaries, compile each
  fragment to native code or bytecode, and ship to workers.

The exec layer exposes:

```rust
trait Executor {
    fn execute(&mut self, plan: &ExecPlan, params: &[Value]) -> Result<ValueStream, ExecError>;
}
```

## 11. Backends and capabilities

`yelang-qir/src/backend/` defines:

```rust
struct BackendCapability {
    pub can_pushdown_filter: bool,
    pub can_pushdown_project: bool,
    pub supports_exchange: bool,
    pub supports_streaming: bool,
    pub max_batch_rows: Option<usize>,
    pub preferred_execution: ExecutionModel, // Interpreted | Vectorized | Compiled
}
```

Physical planning picks operators consistent with the selected backend. The
user selects the backend by constructing the source (`in_memory(...)`,
`lsm_table(...)`, `distributed(...)`, `stream(...)`), not via query syntax.

## 12. Exhaustive file tree

```
crates/compiler/
├── yelang-thir/
│   └── src/
│       ├── lib.rs
│       ├── expr.rs              # ThirExpr, including Query(QueryId)
│       ├── query.rs             # Query side table + QueryKind/QueryRoot
│       ├── lower_expr.rs        # HIR expr -> THIR expr
│       ├── lower_query.rs       # HIR Query -> THIR Query
│       ├── lower_pat.rs
│       ├── body.rs
│       └── context.rs
│
├── yelang-qir/
│   └── src/
│       ├── lib.rs
│       ├── errors.rs
│       ├── ids.rs               # LirId, PirId, ExecId, QExprId, BinderId, PlanId
│       ├── expr.rs              # QExpr, QLit, QBinaryOp, QUnaryOp, CastKind, Pattern, MatchArm
│       │
│       ├── logical/             # THIR -> LIR
│       │   ├── mod.rs           # lower_thir_body, lower_thir_expr public API
│       │   ├── context.rs       # ExtractCtxt, LangTraits, QueryableMethodInfo, AggregateImplInfo
│       │   ├── extract.rs       # main THIR expr dispatcher
│       │   ├── query_syntax.rs  # ThirExpr::Query -> LIR pipeline
│       │   ├── queryable.rs     # Queryable/Iterator method calls -> LirOp
│       │   ├── aggregate.rs     # Aggregate trait impl -> AggregateOp
│       │   ├── iterator.rs      # IntoIterator/Iterator lowering
│       │   ├── intrinsic.rs     # @intrinsic placeholder -> operator shape
│       │   ├── inline.rs        # inline user wrapper methods into pipeline
│       │   ├── scalar.rs        # non-query THIR expr -> QExpr
│       │   └── convert.rs       # THIR pattern/expr <-> QIR helpers
│       │
│       ├── lir/                 # logical plan
│       │   ├── mod.rs
│       │   ├── plan.rs          # LogicalPlan, allocation, properties
│       │   ├── operator.rs      # LirOp enum
│       │   ├── props.rs         # LogicalProps (cardinality, order, bounded, volatility)
│       │   ├── builder.rs       # ergonomic plan construction
│       │   └── visit.rs         # traversal / folding / free-var analysis
│       │
│       ├── rewrite/             # logical-to-logical rewrites
│       │   ├── mod.rs           # pass manager, fixed-point driver
│       │   ├── normalize.rs
│       │   ├── simplify.rs
│       │   ├── push_filter.rs
│       │   ├── push_project.rs
│       │   ├── predicate_pushdown.rs
│       │   ├── projection_pushdown.rs
│       │   ├── unnest.rs        # top-down decorrelation (Neumann 2025)
│       │   ├── decorrelate.rs   # dependent-join -> regular join
│       │   └── fuse_aggregates.rs
│       │
│       ├── pir/                 # physical plan
│       │   ├── mod.rs
│       │   ├── plan.rs          # PhysicalPlan
│       │   ├── operator.rs      # PirOp enum + AggMode
│       │   ├── properties.rs    # physical properties + enforcers
│       │   ├── cost.rs          # cost model + statistics
│       │   ├── planner.rs       # LIR -> PIR (Cascades or single-candidate)
│       │   └── enforce.rs       # sort/exchange enforcer insertion
│       │
│       ├── exec/                # execution runtime
│       │   ├── mod.rs
│       │   ├── plan.rs          # ExecPlan / ExecOp
│       │   ├── value.rs         # Value enum
│       │   ├── pipeline.rs      # PirOp -> ExecOp lowering
│       │   ├── interpreter.rs   # fallback pull interpreter
│       │   ├── batch.rs         # columnar batch representation
│       │   ├── morsel.rs        # morsel-driven scheduling
│       │   ├── spill.rs         # external sort/aggregation spill
│       │   ├── exchange.rs      # distributed exchange operator
│       │   ├── operators/       # physical operator implementations
│       │   │   ├── scan.rs
│       │   │   ├── filter.rs
│       │   │   ├── project.rs
│       │   │   ├── map.rs
│       │   │   ├── flat_map.rs
│       │   │   ├── aggregate.rs
│       │   │   ├── group_by.rs
│       │   │   ├── sort.rs
│       │   │   ├── slice.rs
│       │   │   ├── join.rs
│       │   │   ├── construct.rs
│       │   │   └── exchange.rs
│       │   └── codegen/         # optional compiled backend
│       │       ├── mod.rs
│       │       ├── cranelift.rs
│       │       └── llvm.rs
│       │
│       ├── backend/             # backend capability descriptions
│       │   ├── mod.rs
│       │   ├── capability.rs
│       │   ├── memory.rs
│       │   ├── storage.rs
│       │   ├── stream.rs
│       │   └── distributed.rs
│       │
│       └── stdlib.rs            # discover Queryable/Aggregate/Iterator from .ye stdlib
│
├── yelang-driver/
│   └── src/
│       ├── lib.rs               # Driver::run(src) -> Value
│       ├── driver.rs            # pipeline orchestration
│       └── compile.rs           # HIR -> THIR -> QIR -> PIR -> Exec
│
└── stdlib/core/src/
    ├── query.ye                 # @lang("queryable") trait + QueryArray + Array/Seq impls
    ├── aggregate.ye             # @lang("aggregate") trait + AggregateClass enum
    ├── aggregate_impls.ye       # Sum, Product, Count, Avg, Min, Max
    ├── iter.ye                  # @lang("iterator") trait + adapters
    ├── array.ye                 # Array<T> impls
    ├── share.ye                 # Shared<T> reference-counted CoW handle
    ├── arena.ye                 # Arena<T> region allocator
    └── register.ye              # @operator / @aggregate decorators (sugar only)
```

## 13. Implementation checklist

### 13.1 Foundation

- [ ] Remove the legacy HIR→LIR path; route `Driver::compile` through
      `CompiledCrate::lower_thir_function`.
- [ ] Move `Queryable`/`Aggregate`/`Iterator` lang-item discovery into
      `yelang-qir/src/stdlib.rs`.
- [ ] Make `ExtractCtxt` derive operator shapes from `@intrinsic` bodies and
      sugar bodies, keyed by `DefId`.
- [ ] Delete `lir/lower/queryable.rs`, `lir/lower/query.rs`,
      `lir/lower/selector.rs`, `lir/lower/links.rs`, `lir/aggregate_impl.rs`,
      and the `QueryableMethod` enum.

### 13.2 THIR

- [ ] Finalize `ThirExpr::Query(QueryId)` and the query side table in
      `yelang-thir/src/query.rs`.
- [ ] Implement `lower_query.rs` so all query syntax reaches THIR.
- [ ] Ensure THIR stores expression types in `expr_tys` for all nodes QIR needs.

### 13.3 QIR logical extraction

- [ ] Implement `logical/query_syntax.rs` (select/from/where/group/order/range).
- [ ] Implement `logical/queryable.rs` for all `Queryable` methods.
- [ ] Implement `logical/iterator.rs` for `IntoIterator`/`Iterator` fallback.
- [ ] Generalize `logical/aggregate.rs` to any `Aggregate` impl, not only
      built-in markers.
- [ ] Implement `logical/inline.rs` for transparent user-defined wrapper methods.
- [ ] Implement `logical/scalar.rs` with full THIR→QExpr coverage.

### 13.4 Rewrites

- [ ] Implement `rewrite/unnest.rs` (top-down dependent-join unnesting).
- [ ] Implement `rewrite/decorrelate.rs` (dependent-join -> join).
- [ ] Implement pushdown passes for filters, projections, and predicates.
- [ ] Implement `rewrite/fuse_aggregates.rs`.

### 13.5 Physical planning

- [ ] Complete PIR operator set and physical properties.
- [ ] Implement `pir/planner.rs` with sort/exchange enforcer insertion.
- [ ] Implement aggregate physical strategies by `AggregateClass` and backend.
- [ ] Add cost model stubs that can be extended with statistics.

### 13.6 Execution

- [ ] Implement `exec/pipeline.rs` (PIR -> ExecOp).
- [ ] Implement all `exec/operators/*.rs` stubs.
- [ ] Add vectorized batch path for `MemoryBackend`.
- [ ] Add storage pushdown hooks in `backend/storage.rs`.

### 13.7 Stdlib

- [ ] Keep `query.ye`, `aggregate.ye`, `aggregate_impls.ye`, `iter.ye` as the
      source of truth.
- [ ] Add `share.ye` and `arena.ye` for the memory model.
- [ ] Ensure all built-in aggregate markers implement `Aggregate` generically
      where the bootstrap compiler supports it.

### 13.8 Driver and tests

- [ ] Update `Driver::run` to use the new pipeline end-to-end.
- [ ] Port existing end-to-end tests to the new pipeline.
- [ ] Add tests for every logical operator, every aggregate class, every join
      kind, every rewrite, and every backend capability.

## 14. Test plan

All cases must be exercised. Target test files:

```
yelang-qir/tests/
  logical/
    query_syntax_tests.rs       # select/from/where/order/range/project
    queryable_method_tests.rs   # map/filter/take/skip/order/group
    aggregate_tests.rs          # sum/count/avg/min/max + user-defined
    iterator_tests.rs           # fallback to Iterator for non-Queryable
    scalar_tests.rs             # closures, patterns, casts, records
    decorrelation_tests.rs      # correlated subqueries, links, exists/in
  rewrite/
    unnest_tests.rs
    pushdown_tests.rs
    fuse_tests.rs
  pir/
    planner_tests.rs
    aggregate_strategy_tests.rs
  exec/
    memory_backend_tests.rs
    storage_backend_tests.rs
    distributed_backend_tests.rs

yelang-driver/tests/
  end_to_end_query_tests.rs     # full source -> result
  source_aggregate_tests.rs     # already exists; expand to all classes
  stdlib_parse_tests.rs         # already exists
```

Each test should:
1. Parse and type-check a `.ye` snippet.
2. Lower through THIR → LIR and assert the expected operator tree.
3. Run rewrites and assert correlation-free shape.
4. Lower to PIR and assert physical operator choice.
5. Execute and assert the result value.

## 15. Sources and further reading

- Neumann, *Efficiently Compiling Efficient Query Plans for Modern Hardware* (VLDB 2011)
- Neumann & Kemper, *The Complete Story of Joins in HyPer* (BTW 2017)
- Neumann, *Improving Unnesting of Complex Queries* (BTW 2025)
- *A Formalization of Top-Down Unnesting* (arXiv 2024)
- Fegaras et al., *An Optimization Framework for Map-Reduce Queries* (EDBT 2012)
- Yu et al., *Distributed Aggregation for Data-Parallel Computing* (SOSP 2009)
- Yu et al., *DryadLINQ* (OSDI 2008)
- Shaikhha et al., *Push vs. Pull-Based Loop Fusion in Query Engines*
- Tahboub et al., *How to Architect a Query Compiler, Revisited* (SIGMOD 2018)
- Ding, Narasayya, Chaudhuri, *Extensible Query Optimizers in Practice* (2024)
- Rust reference on special types and traits; Swift ARC and CoW documentation
