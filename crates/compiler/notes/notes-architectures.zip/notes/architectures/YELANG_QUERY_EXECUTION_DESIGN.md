# Yelang Query Execution Design — Final
## Unified LIR / PIR / Exec layers, trait-driven aggregation, and Neumann decorrelation

**Version:** 2.0 — final  
**Status:** Implementation-ready. Supersedes all prior `query-aggregation*.md`, `query-iterarion.md`, and the v1.0 QIR design.  
**Based on:** `query_language_and_execution_design.md` (the canonical semantic design), Neumann 2024/2025/2026 decorrelation papers, DryadLINQ/Spark Aggregator accumulator model, and Calcite/Cascades physical-property enforcement.

---

## 1. Executive decisions

| Question | Final decision |
|---|---|
| Hardcoded `DecoratorKind` / `ProjKind` / `AggregateKind`? | **No.** The compiler knows only lang-item traits (`Iterator`, `Queryable`, `Aggregate`, `Copy`, …) and aggregate *classes* (`Distributive/Algebraic/Holistic`). Tables, edges, `sum`, `avg`, `percentile`, etc. live in stdlib/user code and are recognized by resolved `DefId`, never by name or kind enum. |
| Manual `extract_queryable_expr` over HIR method-call trees? | **No.** Typed HIR is lowered directly into the Logical IR (LIR) during the normal HIR→LIR pass. The lowering pass asks the trait solver "what trait/method does this call resolve to?" — it never pattern-matches method names. |
| `Queryable` vs `Iterator`? | Separate. `Iterator` = eager local pull. `Queryable` = lazy, optimizable, backend-agnostic pipeline. Same source can implement both. |
| Aggregation generalized? | One trait `Aggregate[In]` with `Acc`, `Out`, `init/step/merge/finish/class`. Built-ins and user-defined aggregates use the same mechanism. Distributed planning keys off `class()` only. |
| Memory model | Value semantics; assignment is logically copy. `Share<T>` + Copy-on-Write is the runtime optimization. `let mut` required to mutate. No `Box`/`Rc`/`Arc` in surface syntax. |
| Reference vs clone by default? | References are an optimization, not a user-visible concept. `Share<T>` is the unified reference-like type; mutation triggers CoW when aliased. |
| `.iter` / `.collect` necessary without borrow checker? | `.iter()` is unnecessary — iteration is uniform (`for x in coll`). `.collect()` is needed as an explicit terminal that forces materialization and chooses a target collection type. |
| Execution engine | Push-based, vectorized, batch-granular (Arrow). Interpreted vectorized v1; JIT later for hot expression kernels only. |
| Distributed execution | Exchange operators + partial/final aggregates. Ship versioned plan fragments, not closures. |
| Decorrelation | Neumann 2024/2025 top-down domain-table algorithm, extended with 2026 IN-predicate handling (null-aware mark joins where needed). |

---

## 2. No manual extractor: lowering is trait-driven

### 2.1 Why the extractor was the wrong shape

A separate pass that walks typed HIR and recognizes `.filter`, `.map`, `.aggregate` by name/method-id is brittle:
- It duplicates trait-resolution knowledge.
- It breaks the moment a user shadows or extends a method.
- It cannot see through generic helpers.

The right place to recognize query-shaped code is **during HIR lowering / typed HIR traversal**, using the same trait-resolution facts that type checking already produced.

### 2.2 What the compiler hardcodes

Only these lang items:

```yed
@lang("iterator")
trait Iterator[T] { fn next(self) -> Option[(Self, T)]; }

@lang("into_iter")
trait IntoIterator[T] { fn into_iter(self) -> impl Iterator[T]; }

@lang("queryable")
trait Queryable[T] {
    fn filter(self, pred: fn(T) -> Bool) -> Self;
    fn map[U](self, f: fn(T) -> U) -> Queryable[U];
    fn flat_map[U](self, f: fn(T) -> impl Queryable[U]) -> Queryable[U];
    fn order_by[K: Ord](self, key: fn(T) -> K) -> Seq[T];
    fn group_by[K](self, key: fn(T) -> K) -> Queryable[Group[K, T]];
    fn aggregate[A: Aggregate[T]](self, agg: A) -> A::Out;
    fn take(self, n: usize) -> Self;       // Seq only
    fn skip(self, n: usize) -> Self;       // Seq only
}

@lang("aggregate")
trait Aggregate[In] {
    type Acc;
    type Out;
    fn init() -> Self::Acc;
    fn step(acc: Self::Acc, item: In) -> Self::Acc;
    fn merge(a: Self::Acc, b: Self::Acc) -> Self::Acc;
    fn finish(acc: Self::Acc) -> Self::Out;
    fn class() -> AggregateClass;
}

enum AggregateClass { Distributive, Algebraic, Holistic }
```

The compiler does **not** hardcode `sum`, `count`, `avg`, `min`, `max`, `percentile`, `table`, `edge`, `stream`. Those are ordinary stdlib/user definitions whose `DefId` the LIR carries.

### 2.3 Lowering pipeline

```text
Source
  → AST (parse)
  → HIR (resolve + desugar select/where/group/order/range into method calls)
  → Type check (trait resolution produces `TyId`, method `DefId`, impl facts)
  → LIR lowering (HIR → LirOp, reading tycheck results)
  → LIR rewrites (normalization, decorrelation, pushdown)
  → PIR (Cascades goal-driven physical planning)
  → Exec plan (vectorized push operators + backend fragments)
```

The LIR lowering pass is a normal recursive function over typed HIR. When it sees a method call, it asks:

```rust
// In yelang-qir/src/logical/lower.rs
match tcx.method_resolution(expr_id) {
    Some(MethodRes { trait_id, method_id, .. }) if trait_id == lang.queryable => {
        lower_queryable_call(method_id, receiver, args)
    }
    Some(MethodRes { trait_id, method_id, .. }) if trait_id == lang.aggregate => { ... }
    _ => lower_as_normal_expr(expr)
}
```

No string matching. No registry of method names. The trait solver already decided what the call means.

### 2.4 Example

Surface:
```yed
select users@u[*].{ id, age }
from users@u:User
where u.age > 18
order by u.age desc
range 20..30
```

Typed HIR (already done in `yelang-hir`):
```yed
users
  .filter(|u| u.age > 18)
  .order_by(|u| u.age, desc)
  .take(30)
  .skip(20)
  .map(|u| { id: u.id, age: u.age })
```

LIR lowering sees each `.` call resolves to `Queryable` methods and emits:
```text
LirOp::Map {
  input: LirOp::Slice {
    input: LirOp::Sort {
      input: LirOp::Filter {
        input: LirOp::Scan { source: users, item_ty: User },
        predicate: |u| u.age > 18
      },
      keys: [u.age desc]
    },
    offset: 20,
    limit: Some(10)
  },
  projection: |u| { id: u.id, age: u.age }
}
```

---

## 3. LIR — Logical Intermediate Representation

### 3.1 Design

LIR is backend-agnostic. It represents the query as a tree of operators with scalar expressions (`QExpr`) attached. Each operator carries logical properties (cardinality class, boundedness, keys, demand set).

### 3.2 Operator enum

```rust
// yelang-qir/src/logical/operator.rs

pub enum LirOp {
    /// Source.
    Scan {
        source: SourceId,        // resolved DefId of collection/value
        item_ty: TyId,
    },

    /// Local inline collection (e.g., array literal in a query).
    Values {
        rows: Vec<QExprId>,
        item_ty: TyId,
    },

    /// Filter rows by predicate.
    Filter {
        input: LirId,
        predicate: QExprId,
    },

    /// Map / project each row.
    Map {
        input: LirId,
        projection: QExprId,     // fn(In) -> Out
    },

    /// Flatten one level.
    FlatMap {
        input: LirId,
        projection: QExprId,     // fn(In) -> Queryable[U]
    },

    /// Order a collection. Output is Seq[In].
    OrderBy {
        input: LirId,
        keys: Vec<OrderKey>,
    },

    /// Slice a Seq. Input must be Seq.
    Slice {
        input: LirId,
        offset: QExprId,         // usize
        limit: Option<QExprId>,  // usize
    },

    /// Group rows. Output rows are `{ key: K, groups: Queryable[Row] }`.
    GroupBy {
        input: LirId,
        key: QExprId,            // fn(In) -> K
        key_ty: TyId,
    },

    /// Reduce to a scalar using an aggregate.
    Aggregate {
        input: LirId,
        agg: AggregateOp,
    },

    /// Joins.
    InnerJoin { left: LirId, right: LirId, predicate: QExprId },
    LeftOuterJoin { left: LirId, right: LirId, predicate: QExprId },
    RightOuterJoin { left: LirId, right: LirId, predicate: QExprId },
    FullOuterJoin { left: LirId, right: LirId, predicate: QExprId },
    Cross { left: LirId, right: LirId },

    /// Correlated subquery / lateral.
    DependentJoin {
        outer: LirId,
        inner: LirId,
        predicate: Option<QExprId>,
    },

    /// Semi/anti joins (produced by EXISTS / NOT EXISTS lowering).
    SemiJoin { left: LirId, right: LirId, predicate: QExprId },
    AntiJoin { left: LirId, right: LirId, predicate: QExprId },

    /// Attach a nested field to each outer row (links / nested projections).
    AttachField {
        input: LirId,
        field: Symbol,
        value_plan: LirId,
    },

    /// Construct a record/tuple/array result.
    Construct {
        kind: ConstructKind,
        fields: Vec<(Symbol, LirId)>,
    },

    /// Scalar expression embedded in a plan.
    Expr(QExprId),
}

pub struct AggregateOp {
    /// DefId of the aggregate config type (e.g., `Sum`, `Avg`, `Percentile`).
    pub agg_def: DefId,
    /// DefId of the `Aggregate` trait impl (used to find init/step/merge/finish functions).
    pub impl_def: DefId,
    /// Classification read from `Aggregate::class()`.
    pub class: AggregateClass,
    /// Per-row input expression fed to `step`.
    pub input_expr: QExprId,
    /// Output type.
    pub out_ty: TyId,
}

pub enum ConstructKind { Record, Tuple, Array }

pub struct OrderKey {
    pub expr: QExprId,
    pub dir: Direction,     // Asc / Desc
    pub nulls: NullOrdering, // First / Last
}

pub enum Direction { Asc, Desc }
pub enum NullOrdering { First, Last }
```

### 3.3 Scalar expressions (`QExpr`)

`QExpr` is already in `yelang-qir/src/expr.rs`. It needs only minor extension to reference aggregate/window functions by `DefId`. Columns are referred to by binder id, not name.

```rust
pub enum QExpr {
    Literal(Lit, TyId),
    Column(BinderId, TyId),          // reference to a pipeline binding
    Field(Box<QExpr>, Symbol, TyId), // field access
    Index(Box<QExpr>, Box<QExpr>, TyId),
    Call(DefId, Vec<QExprId>, TyId), // ordinary function call
    MethodCall {                      // fallback for non-queryable methods
        receiver: QExprId,
        method: DefId,
        args: Vec<QExprId>,
        ty: TyId,
    },
    AggregateCall(AggregateOp, QExprId), // q.aggregate(Sum) or q.sum()
    WindowCall { ... },                   // later
    If(Box<QExpr>, Box<QExpr>, Box<QExpr>, TyId),
    Match { ... },
    Closure { params: Vec<BinderId>, body: QExprId, ty: TyId },
    Let { name: BinderId, value: QExprId, body: QExprId, ty: TyId },
    // ... etc
}
```

### 3.4 Logical properties

Every `LirOp` node computes/propagates:

```rust
pub struct LogicalProps {
    pub output_ty: TyId,
    pub ordered: bool,            // true => Seq semantics
    pub bounded: bool,            // false => stream
    pub cardinality: CardinalityClass,
    pub unique_keys: Vec<Vec<BinderId>>,
    pub non_null_columns: Vec<BinderId>,
    pub demand: DemandSet,        // fields consumed downstream
    pub volatility: Volatility,   // pure / stable / volatile
}
```

---

## 4. PIR — Physical Intermediate Representation

### 4.1 Design

PIR is produced by a Cascades-style goal-driven planner. Physical properties (`Ordering`, `Partitioning`, `Location`, `Boundedness`) are enforced by inserting operators (`Sort`, `Exchange`, `Gather`).

Network transfer is just an enforcer satisfying a `Location` property — Calcite's `Convention` trait, generalized.

### 4.2 Operator enum

```rust
// yelang-qir/src/physical/operator.rs

pub enum PirOp {
    // --- Scans ---
    TableScan {
        source: SourceId,
        predicate: Option<QExprId>,   // pushed-down filter
        projection: DemandSet,        // pushed-down column demand
    },
    Values {
        rows: Vec<QExprId>,
    },

    // --- Row-level operators ---
    Filter {
        input: PirId,
        predicate: QExprId,
    },
    Project {
        input: PirId,
        projection: QExprId,
    },
    FlatMap {
        input: PirId,
        projection: QExprId,
    },

    // --- Sorting / slicing ---
    Sort {
        input: PirId,
        keys: Vec<OrderKey>,
    },
    TopK {
        input: PirId,
        keys: Vec<OrderKey>,
        k: usize,
    },
    Slice {
        input: PirId,
        offset: usize,
        limit: Option<usize>,
    },

    // --- Joins ---
    HashJoin {
        build: PirId,
        probe: PirId,
        build_key: QExprId,
        probe_key: QExprId,
        kind: JoinKind,
    },
    MergeJoin {
        left: PirId,
        right: PirId,
        left_keys: Vec<OrderKey>,
        right_keys: Vec<OrderKey>,
        kind: JoinKind,
    },
    NestedLoopJoin {
        outer: PirId,
        inner: PirId,
        predicate: QExprId,
        kind: JoinKind,
    },

    // --- Aggregations ---
    HashAggregate {
        input: PirId,
        group_keys: Vec<QExprId>,
        aggregates: Vec<PhysicalAggregateOp>,
        mode: AggMode,
    },
    SortAggregate {
        input: PirId,
        group_keys: Vec<QExprId>,
        aggregates: Vec<PhysicalAggregateOp>,
        mode: AggMode,
    },
    StreamingAggregate {
        input: PirId,
        group_keys: Vec<QExprId>,
        aggregates: Vec<PhysicalAggregateOp>,
        watermark: WatermarkSpec, // v2
    },

    // --- Set ops ---
    Union { inputs: Vec<PirId> },
    UnionAll { inputs: Vec<PirId> },
    Intersect { left: PirId, right: PirId },
    Except { left: PirId, right: PirId },
    Distinct { input: PirId },

    // --- Exchange / distribution enforcers ---
    Exchange {
        input: PirId,
        kind: ExchangeKind,
    },
    LocalRepartition {
        input: PirId,
        kind: RepartitionKind,
    },

    // --- Graph traversal ---
    EdgeExpand {
        input: PirId,
        edge: SourceId,
        direction: EdgeDirection,
        predicate: Option<QExprId>,
    },

    // --- Materialization / construction ---
    Construct {
        kind: ConstructKind,
        fields: Vec<(Symbol, PirId)>,
    },
    AttachField {
        input: PirId,
        field: Symbol,
        value_plan: PirId,
    },

    // --- Scalar ---
    Expr(QExprId),
}

pub enum JoinKind { Inner, Left, Right, Full, Semi, Anti }

pub enum AggMode {
    Partial,   // per-node/local: emit accumulators
    Final,     // merge partial accumulators
    Full,      // holistic / single-node
}

pub struct PhysicalAggregateOp {
    pub agg_def: DefId,
    pub impl_def: DefId,
    pub class: AggregateClass,
    pub input_expr: QExprId,
    pub acc_ty: TyId,
    pub out_ty: TyId,
}

pub enum ExchangeKind {
    Gather,                              // all tuples to one node
    Broadcast,                           // to all nodes (size-capped)
    RepartitionBy(Vec<QExprId>),         // hash shuffle
    RangePartition(Vec<OrderKey>),       // sorted ranges
}

pub enum RepartitionKind {
    Hash(Vec<QExprId>),
    Range(Vec<OrderKey>),
}
```

### 4.3 Aggregate distribution rules

```rust
// Scalar aggregate
match agg.class {
    Distributive | Algebraic => {
        let partial = hash_agg(input, group_keys=[], [agg], mode=Partial);
        let gathered = exchange(partial, Gather);
        hash_agg(gathered, group_keys=[], [agg], mode=Final)
    }
    Holistic => {
        let gathered = exchange(input, Gather);
        hash_agg(gathered, group_keys=[], [agg], mode=Full)
    }
}

// Grouped aggregate
match agg.class {
    Distributive | Algebraic => {
        let partial = hash_agg(input, group_keys, [agg], mode=Partial);
        let shuffled = exchange(partial, RepartitionBy(group_keys));
        hash_agg(shuffled, group_keys, [agg], mode=Final)
    }
    Holistic => {
        let shuffled = exchange(input, RepartitionBy(group_keys));
        hash_agg(shuffled, group_keys, [agg], mode=Full)
    }
}
```

Grouped Holistic aggregates do **not** need a full gather — they only need all rows for each group key co-located.

### 4.4 Range / limit / offset

- `range a..b` on a `Coll` is a **compile error** — unordered source cannot be sliced.
- On a `Seq`, `range a..b` lowers to `Slice { offset: a, limit: Some(b - a) }`.
- `range a..` → `Slice { offset: a, limit: None }`.
- When an `order by` immediately precedes a `Slice`, the planner may use `TopK` instead of full sort.

### 4.5 Ordering / sorting

- `order by` is a logical-to-physical property request: output must be `Seq` with the required ordering.
- The planner inserts `Sort` enforcers only when required ordering is not already satisfied by an input (e.g., merge join, index scan, sorted group-by).
- `TopK` is a physical optimization for `order by + slice`.

---

## 5. Exec layer — runtime plan

### 5.1 Design

Exec is PIR with concrete kernels and runtime handles. The same operator enum can be used (PIR → Exec is mostly monomorphization + backend binding), but Exec adds:

- Concrete Arrow schema per operator.
- Bound function pointers for scalar kernels and aggregate step/merge/finish.
- Pipeline IDs and exchange endpoints.
- Memory-pool reservations.

### 5.2 Operator enum (skeleton)

```rust
// yelang-qir/src/exec/operator.rs  (new file)

pub enum ExecOp {
    Scan(ScanKernel),
    Filter(FilterKernel),
    Project(ProjectKernel),
    HashJoin(HashJoinExec),
    MergeJoin(MergeJoinExec),
    HashAggregate(HashAggregateExec),
    Sort(SortExec),
    TopK(TopKExec),
    Slice(SliceExec),
    Exchange(ExchangeExec),
    Union(Vec<ExecId>),
    Distinct(DistinctExec),
    EdgeExpand(EdgeExpandExec),
    Construct(ConstructExec),
}

pub struct HashAggregateExec {
    pub input: ExecId,
    pub group_key_indices: Vec<usize>,
    pub aggregates: Vec<BoundAggregate>,
    pub mode: AggMode,
    pub spill_manager: Option<SpillManager>,
}

pub struct BoundAggregate {
    pub agg_def: DefId,
    pub input_column: usize,
    pub init_fn: extern "C" fn() -> *mut c_void,
    pub step_fn: extern "C" fn(*mut c_void, *const u8),
    pub merge_fn: extern "C" fn(*mut c_void, *const c_void),
    pub finish_fn: extern "C" fn(*const c_void, *mut u8),
    pub acc_layout: ArrowSchema,
    pub out_layout: ArrowSchema,
}

pub struct ExchangeExec {
    pub input: ExecId,
    pub kind: ExchangeKind,
    pub endpoint: ExchangeEndpoint,
}
```

### 5.3 Push-based vectorized execution

- Operators implement `Operator: consume(batch: RecordBatch) -> Result<()>`.
- Sources call `produce(batch)` on their downstream consumer.
- Pipeline-breakers (hash agg, sort, hash join build) materialize state; then emit.
- Batches are Arrow RecordBatches (~1–4K rows).
- Credit-based flow control on every exchange edge.

### 5.4 Morsel-driven parallelism

- Work unit = (pipeline × ~100K values).
- Dispatcher assigns morsels to pinned workers; NUMA-local first, work-stealing fallback.
- Degree of parallelism is elastic at runtime.

---

## 6. Decorrelation — Neumann 2024/2025/2026

### 6.1 Core idea: the domain table `D`

A correlated subquery is a `DependentJoin`. The Neumann framework replaces it with a regular join against a duplicate-free domain table `D` built from the outer bindings referenced by the inner side:

```text
L ⧑_p R  ≡  L ⋈_{p ∧ eq_D} (D ⧑ R)
where D = DISTINCT Π_{F(R) ∩ A(L)}(L)
```

Then `D ⧑ R` is pushed down through `R` using operator-specific rules until the dependent join disappears.

### 6.2 Top-down algorithm (Neumann 2025)

```rust
// yelang-qir/src/rewrite/decorrelate.rs

pub fn decorrelate(root: LirId, ctx: &mut LirCtxt) -> LirId {
    let mut pass = Decorrelator::new(ctx);
    pass.remove_dependent_joins(root)
}

struct Decorrelator<'a> {
    ctx: &'a mut LirCtxt,
    // Maps an outer binder to the representative column in the current domain.
    domain: HashMap<BinderId, DomainColumn>,
    // Union-find for equivalent expressions.
    equivalences: EquivalenceClasses,
    fresh: usize,
}

impl<'a> Decorrelator<'a> {
    fn remove_dependent_joins(&mut self, node: LirId) -> LirId {
        match self.ctx.op(node) {
            LirOp::DependentJoin { outer, inner, predicate } => {
                let outer = self.remove_dependent_joins(*outer);
                let domain = self.build_domain(outer, *inner);
                let (new_inner, join_pred) = self.push_down(*inner, domain);
                self.ctx.mk_inner_join(outer, new_inner, merge_pred(predicate, join_pred))
            }
            other => self.rewrite_children(other, node)
        }
    }

    fn push_down(&mut self, node: LirId, domain: Domain) -> (LirId, Option<QExprId>) {
        match self.ctx.op(node) {
            LirOp::Filter { input, predicate } => {
                let (input, pred) = self.push_down(*input, domain);
                (self.ctx.mk_filter(input, predicate), pred)
            }
            LirOp::Map { input, projection } => {
                let (input, pred) = self.push_down(*input, domain);
                // Keep domain columns in projection.
                (self.ctx.mk_map_with_domain(input, projection, &domain), pred)
            }
            LirOp::GroupBy { input, key, key_ty } => {
                let (input, pred) = self.push_down(*input, domain);
                // Domain columns become additional grouping keys.
                let new_key = self.ctx.mk_tuple(key, domain.key_expr());
                (self.ctx.mk_group_by(input, new_key, *key_ty), pred)
            }
            LirOp::Aggregate { input, agg } => {
                let (input, pred) = self.push_down(*input, domain);
                let new_agg = agg.clone();
                // Scalar aggregate becomes grouped by domain columns.
                let group = self.ctx.mk_group_by_aggregate(input, domain.key_expr(), new_agg);
                (group, pred)
            }
            LirOp::OrderBy { input, keys } => {
                let (input, pred) = self.push_down(*input, domain);
                // Slice/range per outer binding: partition by domain keys.
                let new_keys = domain.keys.clone().into_iter().chain(keys.iter().cloned()).collect();
                (self.ctx.mk_order_by(input, new_keys), pred)
            }
            LirOp::Slice { input, offset, limit } => {
                let (input, pred) = self.push_down(*input, domain);
                // Convert slice to ranking window partitioned by domain keys.
                let ranked = self.ctx.mk_window_rank(input, domain.keys.clone(), /*order=*/vec![]);
                let filtered = self.ctx.mk_filter(ranked, slice_predicate(offset, limit));
                (filtered, pred)
            }
            LirOp::InnerJoin { left, right, predicate } => {
                // Push into correlated side(s).
                self.push_join(left, right, predicate, domain)
            }
            LirOp::Scan { .. } | LirOp::Values { .. } => {
                // No more correlation — join domain to the leaf.
                let joined = self.ctx.mk_cross_or_inner_join(domain.as_scan(), node, None);
                (joined, domain.equality_predicate())
            }
            _ => todo!("handle other operators")
        }
    }
}
```

### 6.3 Key rewrite rules

| Operator | Rule |
|---|---|
| Filter | `D ⧑ σ_p(R) ≡ σ_p(D ⧑ R)` |
| Map | `D ⧑ Π_A(R) ≡ Π_{A ∪ A(D)}(D ⧑ R)` |
| Inner join (one side correlated) | push `D ⧑` into correlated side only |
| Inner join (both correlated) | replicate `D` into both sides, join on `D` attrs |
| Group by | add `A(D)` to grouping keys |
| Aggregate (scalar) | implicit grouping by `A(D)` |
| Order by / Slice | partition by `A(D)` via window rank |
| Semi/anti join | push `D` into both sides, reconnect on `D` attrs |
| Outer join | push into preserved side; if both depend, replicate `D` |

### 6.4 `ORDER BY ... LIMIT` per outer binding

Correlated top-N must be enforced per outer binding. Rewrite to `ROW_NUMBER()` partitioned by `D` attributes:

```text
D ⧑ (OrderBy(keys) + Slice(offset, limit))(R)
  ≡ Filter(rn in [offset+1, offset+limit])(
      Window(
        partition = keys ∪ A(D),
        order = keys,
        D ⧑ R
      )
    )
```

### 6.5 `IN` / `NOT IN` — Neumann 2026

Birler & Neumann, *On the Vexing Difficulty of Evaluating IN Predicates* (CIDR 2026), show that `IN` with nullable expressions cannot be blindly rewritten as semi/anti join because SQL 3VL differs. Yelang has no `NULL`; absence is `Option[T]` with ordinary equality. Therefore:

- `x IN (subquery)` → semi join (no null-awareness needed).
- `x NOT IN (subquery)` → anti join (no null-awareness needed).

If we ever add a SQL-compatible backend, we must implement null-aware mark joins for that backend only.

### 6.6 Substitution optimization

When a domain attribute is equivalent to an inner attribute (e.g., `o.user_id = u.id`), the domain table can be eliminated by substitution. This is cost-based: keeping `D` may prune inner rows earlier; eliminating it may reduce intermediate cardinality.

---

## 7. Grouping, aggregation, ordering, range — complete example

Surface:
```yed
select groups@g[*].{
  city_lower: g.city_lower,
  decade: g.decade,
  avg_age: g.users.avg(u => u.age),
  total: g.users.count(),
  median_salary: g.users.percentile(0.5, u => u.salary),
}
from users@u:User
group by {
  city_lower: string::lower(u.city),
  decade: (u.age / 10) * 10,
} into groups
```

Typed HIR method chain:
```yed
users
  .group_by(|u| { city_lower: string::lower(u.city), decade: (u.age / 10) * 10 })
  .map(|g| {
    city_lower: g.key.city_lower,
    decade: g.key.decade,
    avg_age: g.vals.map(|u| u.age).avg(),
    total: g.vals.count(),
    median_salary: g.vals.map(|u| u.salary).percentile(0.5),
  })
```

LIR:
```text
Map(
  GroupBy(
    Scan(users),
    key = |u| { city_lower, decade }
  ),
  projection = |g| {
    city_lower: g.key.city_lower,
    decade: g.key.decade,
    avg_age: Aggregate(Avg, g.vals, |u| u.age, Algebraic),
    total: Aggregate(Count, g.vals, |u| _, Distributive),
    median_salary: Aggregate(Percentile{0.5}, g.vals, |u| u.salary, Holistic)
  }
)
```

After normalization (pull aggregates into `GroupBy`):
```text
Map(
  AggregateGroupBy(
    Scan(users),
    group_keys = [city_lower, decade],
    aggregates = [
      avg_age: Aggregate(Avg, |u| u.age, Algebraic),
      total: Aggregate(Count, |u| _, Distributive),
      median_salary: Aggregate(Percentile{0.5}, |u| u.salary, Holistic)
    ]
  ),
  projection = |g| { city_lower, decade, avg_age, total, median_salary }
)
```

PIR (distributed, 3 nodes):
```text
Map(
  HashAggregate(
    input = Exchange(
      HashAggregate(
        input = Scan(users),
        group_keys = [city_lower, decade],
        aggregates = [avg_age Partial, total Partial, median_salary Full],
        mode = Partial
      ),
      kind = RepartitionBy([city_lower, decade])
    ),
    group_keys = [city_lower, decade],
    aggregates = [avg_age Final, total Final],
    mode = Final
  ),
  projection = ...
)
```

Note: `median_salary` runs in `Full` mode inside the per-node partial aggregate because, after repartitioning by group key, all rows for each `(city_lower, decade)` are local. It passes through unchanged after the exchange.

---

## 8. Stdlib trait surface

```yed
// stdlib/core/iter.fl
@lang("iterator")
trait Iterator[T] {
    fn next(self) -> Option[(Self, T)];

    // Default combinators (ordinary methods, not plan nodes).
    fn map[U](self, f: fn(T) -> U) -> Map[Self, T, U];
    fn filter(self, pred: fn(&T) -> Bool) -> Filter[Self, T];
    fn take(self, n: usize) -> Take[Self, T];
    fn skip(self, n: usize) -> Skip[Self, T];
    fn fold[U](self, init: U, f: fn(U, T) -> U) -> U;
    fn collect[C](self) -> C where C: FromIterator[T];
}

// stdlib/core/queryable.fl
@lang("queryable")
trait Queryable[T] {
    fn filter(self, pred: fn(T) -> Bool) -> Self;
    fn map[U](self, f: fn(T) -> U) -> Queryable[U];
    fn flat_map[U](self, f: fn(T) -> impl Queryable[U]) -> Queryable[U];
    fn order_by[K: Ord](self, key: fn(T) -> K) -> Seq[T];
    fn group_by[K](self, key: fn(T) -> K) -> Queryable[Group[K, T]];
    fn aggregate[A: Aggregate[T]](self, agg: A) -> A::Out;

    // Sugar — all default methods calling aggregate().
    fn sum(self) -> T where T: Add, Self: Sized { self.aggregate(Sum) }
    fn count(self) -> usize where Self: Sized { self.aggregate(Count) }
    fn avg(self) -> f64 where T: Numeric, Self: Sized { self.aggregate(Avg) }
    fn min(self) -> Option[T] where T: Ord, Self: Sized { self.aggregate(Min) }
    fn max(self) -> Option[T] where T: Ord, Self: Sized { self.aggregate(Max) }
}

// stdlib/core/aggregate.fl
@lang("aggregate")
trait Aggregate[In] {
    type Acc;
    type Out;
    fn init() -> Self::Acc;
    fn step(acc: Self::Acc, item: In) -> Self::Acc;
    fn merge(a: Self::Acc, b: Self::Acc) -> Self::Acc;
    fn finish(acc: Self::Acc) -> Self::Out;
    fn class() -> AggregateClass;
}

enum AggregateClass { Distributive, Algebraic, Holistic }

// Built-ins are ordinary types implementing Aggregate.
struct Sum;
struct Count;
struct Avg;
struct Min;
struct Max;
struct Percentile { p: f64 }
```

User-defined aggregates:
```yed
@derive(Aggregate, class = Holistic)
fn percentile(values: Iterator[f64], p: f64) -> f64 { ... }
```

The `@derive(Aggregate)` macro (a compiler intrinsic) expands to a struct with the function's parameters and an `impl Aggregate` that uses the function body for `finish` and stores intermediate state in `Acc`. It also registers the aggregate in the function registry for remote deployment.

---

## 9. Memory model recap

- Primitives and small structs (< 64 bytes, no heap) are `Copy`.
- Large structs, collections, closures, query results use `Share<T>`.
- Mutation requires `let mut`.
- If strong refcount > 1 on mutation, the compiler emits a CoW deep clone.
- Queries produce region-allocated results; the region is freed when the value is dropped.
- No GC; deterministic destruction for cursors, sockets, file handles.

---

## 10. File tree

```
yelang/
├── compiler/
│   ├── yelang-ast/
│   │   └── src/query/              # query syntax AST
│   ├── yelang-resolve/
│   │   └── src/lang_items.rs       # lang-item registry
│   ├── yelang-hir/
│   │   └── src/
│   │       ├── hir/query.rs        # HIR query nodes
│   │       └── lowering/
│   │           └── expr.rs         # desugar select/syntax to method calls
│   ├── yelang-tycheck/
│   │   └── src/
│   │       ├── check.rs            # type-check query method calls
│   │       ├── method.rs           # method resolution
│   │       └── typeck_results.rs   # stores resolved method DefIds
│   ├── yelang-trait-solver/
│   │   └── src/                    # trait resolution
│   └── yelang-qir/
│       └── src/
│           ├── lib.rs              # query driver
│           ├── ids.rs              # LirId, PirId, ExecId, QExprId
│           ├── expr.rs             # QExpr
│           ├── errors.rs
│           ├── logical/
│           │   ├── mod.rs
│           │   ├── operator.rs     # LirOp, AggregateOp, ConstructKind
│           │   ├── lower.rs        # typed HIR -> LIR (trait-driven)
│           │   ├── props.rs        # LogicalProps, CardinalityClass, Boundedness
│           │   ├── shape.rs        # NestedShape, CorrelationMode
│           │   └── links.rs        # links -> EdgeExpand / AttachField
│           ├── physical/
│           │   ├── mod.rs
│           │   ├── operator.rs     # PirOp, ExchangeKind, AggMode
│           │   ├── planner.rs      # Cascades memo + goal-driven search
│           │   ├── properties.rs   # Ordering, Partitioning, Location, Boundedness
│           │   ├── enforcers.rs    # Sort, Exchange, Gather insertion
│           │   ├── joins.rs        # join algorithm selection
│           │   ├── aggregations.rs # partial/final/full selection
│           │   └── exchanges.rs    # exchange insertion
│           ├── exec/
│           │   ├── mod.rs
│           │   ├── operator.rs     # ExecOp, BoundAggregate
│           │   ├── interface.rs    # QueryExecutor, Value
│           │   ├── memory.rs       # in-memory vectorized executor
│           │   ├── morsel.rs       # morsel-driven scheduler
│           │   ├── pipeline.rs     # pipeline builder
│           │   ├── exchange.rs     # local/shuffle/broadcast exchange
│           │   ├── kernels.rs      # scalar kernel registry
│           │   └── spill.rs        # radix-partitioned spilling
│           ├── rewrite/
│           │   ├── mod.rs
│           │   ├── normalize.rs    # batch normalization to fixpoint
│           │   ├── push_filter.rs
│           │   ├── push_project.rs
│           │   ├── merge_maps.rs
│           │   ├── decorrelate.rs  # Neumann 2024/2025 top-down
│           │   ├── unnest_subqueries.rs
│           │   └── simplify.rs
│           ├── backend/
│           │   ├── mod.rs
│           │   ├── capability.rs   # BackendCapability trait
│           │   ├── memory_backend.rs
│           │   ├── storage_backend.rs
│           │   ├── remote_backend.rs
│           │   └── stream_backend.rs
│           └── util/
│               ├── arena.rs
│               ├── graph.rs
│               └── print.rs
│
├── stdlib/
│   └── core/
│       ├── iter.fl                 # Iterator / IntoIterator
│       ├── queryable.fl            # #[lang("queryable")] trait
│       ├── aggregate.fl            # #[lang("aggregate")] trait + AggregateClass
│       ├── aggregate_impls.fl      # Sum, Avg, Count, Min, Max, Percentile
│       ├── share.fl                # Share<T> runtime type
│       ├── arena.fl                # region allocator
│       └── decorators.fl           # @derive(Aggregate), @derive(Queryable)
│
├── runtime/
│   └── src/
│       ├── value.rs                # Arrow-backed runtime values
│       ├── rc.rs                   # Share<T> / CoW runtime
│       ├── arena.rs                # region allocator
│       ├── aggregate_registry.rs   # DefId -> dyn ErasedAggregateFn
│       └── storage.rs              # storage node runtime
│
└── transport/
    └── src/
        ├── fragment.rs             # versioned plan-fragment format
        ├── function_registry.rs    # URI/versioned function registry
        └── arrow_ipc.rs            # Arrow IPC wire format
```

---

## 11. Implementation phases

**Phase 0 — semantic groundwork (now):**
- `Seq[T]` / `Coll[T]` split in `yelang-ty`.
- `Option[T]` in queries; remove `QLit::Null`.
- Volatility declarations.
- Query-typed-by-projection formalization.

**Phase 1 — in-memory end-to-end:**
- LIR operator enum and lowering from typed HIR.
- Reference executor (dumb, correct interpreter over LIR).
- Vectorized push executor over `Seq`/`Coll`.
- Group-by/aggregates via `Aggregate` trait.
- Differential testing harness.

**Phase 2 — rewrites + decorrelation:**
- Normalization batches.
- Push filter/project.
- Neumann top-down decorrelation.
- Reference vs optimized result testing.

**Phase 3 — physical planning:**
- Cascades memo.
- Physical properties + enforcers.
- Join algorithm selection.
- Aggregate partial/final/full modes.

**Phase 4 — embedded storage:**
- Storage engine v1.
- Pushdown rules.
- Morsel scheduler + spilling.

**Phase 5 — remote/distributed:**
- Fragment format + function registry.
- Exchanges + credit-based flow control.
- Arrow IPC.

**Phase 6 — streaming:**
- Boundedness end-to-end.
- Windows/watermarks/triggers.

---

## 12. References

1. **Neumann, T. & Kemper, A.** "Unnesting Arbitrary Queries." BTW 2015. Bottom-up decorrelation foundation.
2. **Neumann, T.** "A Formalization of Top-Down Unnesting." arXiv 2024. [arxiv:2412.04294](https://arxiv.org/abs/2412.04294)
3. **Neumann, T.** "Improving Unnesting of Complex Queries." BTW 2025. Top-down algorithm handling deep nesting and recursive SQL.
4. **Birler, A. & Neumann, T.** "On the Vexing Difficulty of Evaluating IN Predicates." CIDR 2026. [cidrdb.org](https://www.cidrdb.org/cidr2026/papers.html)
5. **Yu, Y., et al.** "DryadLINQ." SOSP 2009.
6. **Apache Spark.** UDAF `Aggregator` API.
7. **Graefe, G.** "Volcano/Cascades." IEEE TKDE 1994 / Graefe & McKenna.
8. **Apache Arrow.** IPC format.
9. **Leis, V., et al.** "Morsel-Driven Parallelism." SIGMOD 2014.
10. **Neumann, T. & Leis, V.** "A Critique of Modern SQL And A Proposal Towards SaneQL." CIDR 2024.

---

*This document is the final design for Yelang query execution. Implementation should align `yelang-qir` with the LIR/PIR/Exec operators and trait-driven lowering described here.*
