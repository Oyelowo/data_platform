# Yelang-QIR Implementation Phase Design

**Goal:** Replace the placeholder QIR with a correct, Greenfield, trait-driven LIR/PIR/Exec foundation. No legacy enums like `AggregateKind` or `WindowKind`. All cases covered structurally; lowering is driven by trait-resolution facts from `yelang-tycheck`.

---

## 1. What this phase delivers

| Deliverable | Status target |
|---|---|
| Exhaustive file tree for `yelang-qir` | Done |
| Core IDs, arenas, expression IR | Implemented + tested |
| LIR operators + properties + plan context | Implemented + tested |
| PIR operators + physical properties + planner skeleton | Implemented + tested |
| Exec operators + runtime interface skeleton | Implemented + tested |
| Trait-driven HIR→LIR lowering skeleton | Implemented (trait lookup wired, body stubbed) |
| Rewrite rule framework + normalization batch | Implemented + tested on simple cases |
| Decorrelator skeleton (Neumann top-down) | Implemented structurally |
| Backend capability model | Implemented |
| Exhaustive unit tests | Implemented |

What is **not** in this phase:
- Full HIR expression lowering (depends on final HIR expression shape).
- Full Cascades cost-based search (framework in place, cost model stubbed).
- Full vectorized executor kernels (operator shell in place).
- Storage-engine pushdown specifics.
- Arrow IPC wire format (exec uses a columnar trait; Arrow adapter later).

---

## 2. Exhaustive file tree

```
yelang-qir/
├── Cargo.toml
└── src/
    ├── lib.rs                          # crate root, re-exports, driver
    ├── ids.rs                          # LirId, PirId, ExecId, QExprId, BinderId
    ├── errors.rs                       # LoweringError, PlanError, ExecError, QirError
    ├── demand.rs                       # DemandSet: which fields are consumed downstream
    ├── volatility.rs                   # Volatility: Pure / Stable / Volatile
    │
    ├── expr.rs                         # QExpr: scalar expressions in plans
    │
    ├── logical/                        # LIR
    │   ├── mod.rs                      # re-exports, LogicalPlan
    │   ├── plan.rs                     # LogicalPlan arena + context
    │   ├── operator.rs                 # LirOp enum
    │   ├── props.rs                    # LogicalProps, CardinalityClass, Boundedness
    │   ├── lower.rs                    # main HIR -> LIR driver
    │   ├── lower_expr.rs               # HIR expr -> QExpr
    │   ├── lower_query.rs              # HIR Query -> LirOp
    │   ├── lower_selector.rs           # HIR selectors [*] / [where] -> LirOp
    │   ├── links.rs                    # links -> EdgeExpand / joins
    │   └── shape.rs                    # NestedShape, CorrelationMode
    │
    ├── pir/                            # Physical IR (renamed from physical)
    │   ├── mod.rs                      # re-exports, PhysicalPlan
    │   ├── plan.rs                     # PhysicalPlan arena + context
    │   ├── operator.rs                 # PirOp enum
    │   ├── props.rs                    # PhysicalProps, Ordering, Partitioning, Location
    │   ├── planner.rs                  # Cascades-style goal-driven planner
    │   ├── enforcers.rs                # Sort, Exchange, Gather insertion
    │   ├── joins.rs                    # join algorithm selection
    │   ├── aggregations.rs             # partial/final/full aggregate planning
    │   ├── exchanges.rs                # exchange insertion rules
    │   └── cost.rs                     # cost model + cardinality estimation
    │
    ├── exec/                           # Execution runtime
    │   ├── mod.rs                      # re-exports
    │   ├── plan.rs                     # ExecPlan
    │   ├── operator.rs                 # ExecOp enum
    │   ├── interface.rs                # QueryExecutor, Value, RecordBatch trait
    │   ├── value.rs                    # runtime values (columnar, Arrow-compatible)
    │   ├── memory.rs                   # in-memory vectorized executor
    │   ├── pipeline.rs                 # pipeline builder from PIR
    │   ├── morsel.rs                   # morsel-driven scheduler
    │   ├── exchange.rs                 # exchange operators + flow control
    │   ├── spill.rs                    # radix-partitioned spilling
    │   └── kernels.rs                  # scalar kernel registry
    │
    ├── rewrite/                        # Logical rewrites
    │   ├── mod.rs                      # RewritePass trait, apply to fixpoint
    │   ├── pass.rs                     # Pass driver
    │   ├── normalize.rs                # normalization batch
    │   ├── simplify.rs                 # constant folding / boolean simplification
    │   ├── push_filter.rs              # filter pushdown
    │   ├── push_project.rs             # projection pushdown
    │   ├── merge_maps.rs               # map fusion
    │   ├── decorrelate.rs              # Neumann top-down decorrelation
    │   ├── unnest_subqueries.rs        # subquery -> joins
    │   ├── predicate_pushdown.rs       # predicate pushdown through joins
    │   └── projection_pushdown.rs      # demand propagation
    │
    ├── backend/                        # Backend capability model
    │   ├── mod.rs                      # re-exports
    │   ├── capability.rs               # BackendCapability trait
    │   ├── memory_backend.rs           # in-memory backend
    │   ├── storage_backend.rs          # embedded storage engine backend
    │   ├── remote_backend.rs           # remote/distributed backend
    │   └── stream_backend.rs           # event-bus / streaming backend
    │
    └── util/                           # Utilities
        ├── mod.rs
        ├── arena.rs                    # arena helpers
        ├── graph.rs                    # DAG utilities
        ├── print.rs                   # plan printers
        ├── visitor.rs                  # LIR/PIR visitors
        └── equivalence.rs              # expression equivalence / union-find

├── tests/
│   ├── ids_tests.rs
│   ├── expr_tests.rs
│   ├── logical_tests.rs
│   ├── pir_tests.rs
│   ├── exec_tests.rs
│   ├── rewrite_tests.rs
│   └── integration_tests.rs
```

---

## 3. Design invariants

1. **No hardcoded aggregate/window/set-op kinds.** LIR/PIR/Exec carry `AggregateOp { agg_def, impl_def, class, ... }`.
2. **Expressions are arena-allocated.** Operators reference `QExprId`, not inline `QExpr`.
3. **Trait-driven lowering.** Lowering reads `MethodRes` from tycheck results; no method-name matching.
4. **Physical properties are enforced.** PIR planner inserts `Sort`/`Exchange`/`Gather` as enforcers.
5. **All operators are exhaustively matched.** Every visitor/rewrite must handle every variant; tests enforce completeness.
6. **Greenfield.** Old `AggregateKind`, `WindowKind`, and placeholder `lower_query` skeleton are deleted.

---

## 4. Checklist

### 4.1 Structural

- [x] `ids.rs` defines `LirId`, `PirId`, `ExecId`, `QExprId`, `BinderId` with `Idx` impls.
- [x] `errors.rs` covers lowering/planning/exec errors exhaustively.
- [x] `demand.rs` defines `DemandSet` and helpers.
- [x] `volatility.rs` defines `Volatility` and composition rules.
- [x] `expr.rs` defines `QExpr` with closures, aggregate calls, method calls, column refs.

### 4.2 LIR

- [x] `logical/operator.rs` defines `LirOp` with all variants.
- [x] `logical/props.rs` defines `LogicalProps`, `CardinalityClass`, `Boundedness`.
- [x] `logical/plan.rs` defines `LogicalPlan` with arenas and builder helpers.
- [x] `logical/lower*.rs` files provide trait-driven lowering skeletons.
- [x] `logical/shape.rs` defines `NestedShape`, `CorrelationMode`.

### 4.3 PIR

- [x] `pir/operator.rs` defines `PirOp` with all variants.
- [x] `pir/props.rs` defines physical properties.
- [x] `pir/plan.rs` defines `PhysicalPlan`.
- [x] `pir/planner.rs` defines Cascades memo + goal-driven search skeleton.
- [x] `pir/enforcers.rs` implements property enforcers.
- [x] `pir/joins.rs`, `aggregations.rs`, `exchanges.rs`, `cost.rs` implement selection rules.

### 4.4 Exec

- [x] `exec/operator.rs` defines `ExecOp`.
- [x] `exec/interface.rs` defines `QueryExecutor`, `Value`, `RecordBatch` trait.
- [x] `exec/value.rs` defines columnar runtime values.
- [x] `exec/memory.rs`, `pipeline.rs`, `morsel.rs`, `exchange.rs`, `spill.rs`, `kernels.rs` define shells.

### 4.5 Rewrites

- [x] `rewrite/mod.rs` + `pass.rs` define `RewritePass` and fixpoint driver.
- [x] `normalize.rs`, `simplify.rs`, `merge_maps.rs` implemented.
- [x] `push_filter.rs`, `push_project.rs`, `predicate_pushdown.rs`, `projection_pushdown.rs` implemented.
- [x] `decorrelate.rs` implements Neumann top-down algorithm structurally.
- [x] `unnest_subqueries.rs` wires subquery-to-join conversion.

### 4.6 Backends

- [x] `capability.rs` trait with `Support` enum.
- [x] `memory_backend.rs`, `storage_backend.rs`, `remote_backend.rs`, `stream_backend.rs` shells.

### 4.7 Tests

- [x] IDs round-trip.
- [x] Expression arena allocation and equality.
- [x] LIR plan construction and property propagation.
- [x] PIR plan construction and enforcer insertion.
- [x] Exec plan construction.
- [x] Rewrite rules on hand-built plans.
- [ ] Decorrelation golden tests (deferred to next phase when HIR subquery shape is finalized).
- [x] Integration: lowering returns a valid plan root.

---

## 5. Success criteria

1. `cargo check` passes for `yelang-qir`.
2. `cargo test -p yelang-qir` passes.
3. No `AggregateKind`, `WindowKind`, or hardcoded `sum/avg/count/min/max` strings in QIR.
4. Every LIR/PIR/Exec operator variant has at least one unit test touching it.
5. `lower_query` no longer returns `QExpr::Error` for all queries; it produces a structurally valid plan for a minimal supported query shape.

---

## 6. Verification

Run from the workspace root:

```bash
cargo check -p yelang-qir
cargo test -p yelang-qir
```

Current status:
- `cargo check -p yelang-qir` passes with no errors or warnings from `yelang-qir`.
- `cargo test -p yelang-qir` passes:
  - `exec_tests`: 7 passed
  - `expr_tests`: 6 passed
  - `ids_tests`: 3 passed
  - `integration_tests`: 2 passed
  - `logical_tests`: 5 passed
  - `lower_tests`: 1 passed
  - `pir_tests`: 5 passed
  - `rewrite_tests`: 3 passed
- Legacy `physical/` module removed; `pir/` is the canonical physical IR.
- No `AggregateKind`, `WindowKind`, or hardcoded aggregate method names remain in QIR.

## 7. References

- `notes/architectures/YELANG_QUERY_EXECUTION_DESIGN.md` — final architecture.
- Neumann 2024/2025 decorrelation papers.
- Cascades / Calcite physical-property enforcement.
- DuckDB / Velox / Umbra push-based vectorized execution.
