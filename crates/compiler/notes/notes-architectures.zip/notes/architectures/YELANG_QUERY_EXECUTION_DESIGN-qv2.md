# Yelang Query Execution Design
## Unified Iteration, Aggregation, and Storage-Aware Execution

**Version:** 1.0  
**Status:** Design proposal — supersedes ad-hoc QIR operator registry  
**Based on:** `flott_design_doc.md`, `yelang_query_system_design_doc.md`, Phase H/I QIR work, DryadLINQ, Spark `Aggregator`, Volcano/Cascades, Apache Arrow, Swift ARC, and Fegaras' monoid algebra.

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Design Principles](#2-design-principles)
3. [Memory Model: `Share<T>` + CoW](#3-memory-model-sharet--cow)
4. [Iteration: `Iterator` vs `Queryable`](#4-iteration-iterator-vs-queryable)
5. [Aggregation: The `Aggregate` Trait](#5-aggregation-the-aggregate-trait)
6. [From Surface Syntax to QIR](#6-from-surface-syntax-to-qir)
7. [QIR Logical Model](#7-qir-logical-model)
8. [Decorrelation](#8-decorrelation)
9. [Physical Planning & Distributed Execution](#9-physical-planning--distributed-execution)
10. [Storage Backend Integration](#10-storage-backend-integration)
11. [User-Defined Aggregates](#11-user-defined-aggregates)
12. [Mixed Example: Grouped Query with Distributive + Holistic Aggregates](#12-mixed-example-grouped-query-with-distributive--holistic-aggregates)
13. [File Tree](#13-file-tree)
14. [References](#14-references)

---

## 1. Executive Summary

This document defines the final architecture for Yelang's query execution layer. It unifies iteration and aggregation under a small set of traits and operators, avoids hardcoded method registries, and stays backend-agnostic while remaining efficient for in-memory, embedded-storage, and distributed execution.

**Core decisions:**

| Concern | Decision |
|---------|----------|
| Reference semantics | One surface type: `Share<T>`; mutation requires `mut`; writes trigger Copy-on-Write. |
| Iteration | `Iterator<T>` for concrete pull-based iteration; `Queryable<T>` for lazy, optimizable, backend-agnostic pipelines. |
| Aggregation | One trait: `Aggregate<T, Acc, Out>` with `init/iterate/merge/finalize/classify`. `Queryable::aggregate` is the single hook. Built-ins are normal impls. |
| Compiler recognition | Lang items (`#[lang = "queryable"]`, `#[lang = "aggregate"]`) + normal trait resolution. No hardcoded list of aggregate names. |
| Backend polymorphism | One `Queryable` trait, multiple impls (`VecQueryable`, `LsmQueryable`, `DistributedQueryable`). |
| Distributed execution | Exchange operators + partial/final aggregate modes. Distributive/Algebraic aggregates parallelize; Holistic aggregates gather first. |
| Cross-node data | Apache Arrow IPC for zero-copy columnar transfer. Aggregate states serialize separately. |
| Decorrelation | Neumann 2025 top-down algorithm; `DependentJoin` logical operator. |

---

## 2. Design Principles

1. **Queries are expressions, not a DSL.** `select ... from ... where` desugars to ordinary method calls on `Queryable`. The optimizer recognizes optimizable patterns; unoptimized code still runs.
2. **No compiler knowledge of domain concepts.** The compiler knows `Queryable` and `Aggregate` as lang-item traits. It does not know what a "table", "edge", "stream", or "sum" is.
3. **Generalize through algebra, not registries.** Aggregation is a monoid homomorphism ([Fegaras 2017](#references)); the compiler lowers to a generic `Aggregate` QIR operator parameterized by an aggregate impl.
4. **Backend capabilities, not backend operators.** The logical/physical planner uses capabilities (`can_push_down_filter`, `supports_hash_join`, `supports_exchange`) to decide where work runs. The QIR operator set stays small and backend-agnostic.
5. **Lazy until terminal.** `Queryable` transformations are lazy. Materialization happens at terminal operations: `execute()`, `aggregate()`, `collect()`, `fold()`.
6. **Fail static, not dynamic.** If an aggregate cannot be distributed, the compiler marks it `Holistic` and the planner gathers data before running it. No runtime surprise.

---

## 3. Memory Model: `Share<T>` + CoW

### 3.1 Surface semantics

There is one reference-like surface type: `Share<T>`. The compiler lowers it to the appropriate representation.

```yed
let users = load_users();        // Share<Users>
let active = users.filter(...);   // shares underlying data, no copy
let total = active.sum();         // i32 (primitive, copied)

// Mutation triggers CoW:
let mut modified = users;         // Share, refcount may be > 1
modified[0].name = "Alice";       // deep copy triggered if needed, then mutate
```

Rules:

- Primitives and small structs (< 64 bytes, no heap) are `Copy`.
- Large structs, collections, closures, and query results use `Share<T>`.
- Assignment of `Share<T>` increments the reference count (or shares a borrow if escape analysis permits).
- Mutation requires `mut`. If the strong refcount is greater than one, the compiler emits a CoW clone before the write.
- No `Box`, `Rc`, or `Arc` in surface syntax. The compiler selects stack / unique-heap / ref-counted / atomic-ref-counted as an optimization.

### 3.2 MIR representation

```rust
// MIR for `let mut modified = users; modified[0].name = "Alice";`
%0 = load users                 // Share<Users>
%1 = rc_check %0              // returns strong_count
%2 = branch %1 > 1, cow, inplace

cow:
  %3 = deep_clone %0          // recursive copy
  %4 = store %3 -> modified
  jmp write

inplace:
  %5 = store %0 -> modified

write:
  %6 = field_write modified[0].name = "Alice"
```

### 3.3 Why this model

- **No GC:** Deterministic destruction for file handles, sockets, and storage cursors; no stop-the-world pauses.
- **No borrow checker:** Programmers do not write lifetime annotations.
- **No alias bugs by default:** Shared mutation requires `mut` and is visible; if you want shared mutable aliases, use an explicit `RefCell`-like opt-in.
- **Cheap reads:** Read-only sharing is just reference counting (often optimized away by escape analysis).

This is the model used by Swift ARC and by Ori ([OriLang memory model](https://ori-lang.com/docs/compiler-design/11-runtime/)) with the addition of explicit CoW on mutation.

---

## 4. Iteration: `Iterator` vs `Queryable`

### 4.1 `Iterator<T>` — concrete pull-based iteration

`Iterator` is the standard Rust-like trait for concrete, in-memory, single-threaded iteration. It is **not** query-optimized.

```yed
// stdlib/core/iter.yed
trait Iterator<T> {
    fn next(self: &mut Self) -> Option<T>;

    // Lazy adapters
    fn map<U>(self, f: impl Fn(T) -> U) -> Map<Self, T, U>;
    fn filter(self, pred: impl Fn(&T) -> bool) -> Filter<Self, T>;
    fn flat_map<U>(self, f: impl Fn(T) -> impl Iterator<U>) -> FlatMap<Self, T, U>;

    // Terminals
    fn fold<U>(self, init: U, f: impl Fn(U, T) -> U) -> U;
    fn reduce(self, f: impl Fn(T, T) -> T) -> Option<T>;
    fn collect<C>(self) -> C where C: FromIterator<T>;
}

trait IntoIterator<T> {
    fn into_iter(self) -> impl Iterator<T>;
}
```

Use `Iterator` for:

- `for` loops.
- User code that wants explicit, sequential control.
- Cases where the compiler cannot prove query-shaped structure.

### 4.2 `Queryable<T>` — lazy, optimizable, backend-agnostic pipelines

`Queryable` is the trait the query optimizer understands. It abstracts over where the data lives.

```yed
// stdlib/core/queryable.yed
#[lang = "queryable"]
trait Queryable<T> {
    // --- Lazy transformations ---
    fn map<U>(self, f: impl Fn(T) -> U) -> impl Queryable<U>;
    fn filter(self, pred: impl Fn(&T) -> bool) -> impl Queryable<T>;
    fn flat_map<U>(self, f: impl Fn(T) -> impl Queryable<U>) -> impl Queryable<U>;
    fn take(self, n: usize) -> impl Queryable<T>;
    fn skip(self, n: usize) -> impl Queryable<T>;

    // --- Grouping / ordering (still lazy) ---
    fn group_by<K>(self, key: impl Fn(&T) -> K) -> impl Queryable<Group<K, T>>;
    fn order_by(self, key: impl Fn(&T) -> impl Ord, dir: Direction) -> impl Queryable<T>;

    // --- Aggregation hook ---
    fn aggregate<A, Acc, Out>(self, agg: A) -> Out
    where A: Aggregate<T, Acc, Out>;

    // --- Sugar (default impls calling aggregate) ---
    fn sum(self) -> T where T: Add, Self: Sized {
        self.aggregate(Sum)
    }

    fn count(self) -> usize where Self: Sized {
        self.aggregate(Count)
    }

    fn avg(self) -> f64 where T: Numeric, Self: Sized {
        self.aggregate(Avg)
    }

    // --- Sequential terminal (local only) ---
    fn fold<U>(self, init: U, f: impl Fn(U, T) -> U) -> U;

    // --- Materialization ---
    fn execute(self) -> Vec<T>;
    fn collect<C>(self) -> C where C: FromIterator<T>;
}
```

Key design points:

- **One hook for aggregation:** `aggregate`. Everything else is sugar.
- **`fold` is local-only.** It consumes the queryable sequentially. The compiler does **not** try to distribute an arbitrary `fold`.
- **Built-ins are marker types implementing `Aggregate`.** The compiler does not special-case `sum`, `avg`, etc.

### 4.3 Why separate `Iterator` and `Queryable`?

| Property | `Iterator` | `Queryable` |
|----------|-----------|-------------|
| Abstraction | Concrete data source | Abstract pipeline |
| Laziness | Adapter chains are lazy | Entire pipeline is lazy |
| Backend | In-memory only | In-memory, LSM, distributed, SQL |
| Optimization | None | Predicate push-down, fusion, decorrelation, exchange insertion |
| Aggregation | `fold`/`reduce` | `aggregate` with `Aggregate` trait |
| Use case | `for` loops, user algorithms | Query expressions, data pipelines |

`Iterator` is what the user reaches for when writing ordinary code. `Queryable` is what the compiler recognizes when it sees query syntax or storage-backed collections.

A type can implement both. For example, `Vec<T>` implements `IntoIterator` for `for` loops and `Queryable` for query optimization.

---

## 5. Aggregation: The `Aggregate` Trait

### 5.1 Core trait

```yed
// stdlib/core/aggregate.yed
#[lang = "aggregate"]
trait Aggregate<T, Acc, Out> {
    fn init(self: &Self) -> Acc;
    fn iterate(self: &Self, acc: Acc, value: T) -> Acc;
    fn merge(self: &Self, left: Acc, right: Acc) -> Acc;
    fn finalize(self: &Self, acc: Acc) -> Out;
    fn classify(self: &Self) -> AggregateClass;
}

enum AggregateClass {
    Distributive,  // partial states merge directly: sum, count, min, max, bool_and, bool_or
    Algebraic,     // fixed-size intermediate state: avg, stddev, variance
    Holistic,      // must see all input: median, percentile, mode
}
```

**Design rationale:**

- `init/iterate/merge/finalize` is the universal accumulator contract used by Spark `Aggregator` ([Spark UDAFs](https://spark.apache.org/docs/latest/sql-ref-functions-udf-aggregate.html)), Apache Derby `Aggregator` ([Derby Aggregator](https://db.apache.org/derby//docs/10.14/publishedapi/org/apache/derby/agg/Aggregator.html)), and DryadLINQ distributed aggregation ([Yu et al. SOSP 2009](https://www.sigops.org/s/conferences/sosp/2009/papers/yu-sosp09.pdf)).
- `classify` tells the distributed planner whether partial aggregation is valid.
- The aggregate **config** type (e.g., `Sum`, `Avg`, `Percentile { p: f64 }`) is separate from the **accumulator** type (`SumAcc<T>`, `AvgAcc<T>`, `PercentileAcc<T>`). The config is small and sent to nodes; the accumulator is what gets serialized back.

### 5.2 Built-in aggregates

```yed
// stdlib/core/aggregate_impls.yed

// ---------- Sum ----------
struct Sum;  // zero-sized marker

struct SumAcc<T> { value: T }

impl<T: Add + Zero> Aggregate<T, SumAcc<T>, T> for Sum {
    fn init(self: &Self) -> SumAcc<T> { SumAcc { value: T::zero() } }
    fn iterate(self: &Self, acc: SumAcc<T>, value: T) -> SumAcc<T> {
        SumAcc { value: acc.value + value }
    }
    fn merge(self: &Self, a: SumAcc<T>, b: SumAcc<T>) -> SumAcc<T> {
        SumAcc { value: a.value + b.value }
    }
    fn finalize(self: &Self, acc: SumAcc<T>) -> T { acc.value }
    fn classify(self: &Self) -> AggregateClass { AggregateClass::Distributive }
}

// ---------- Avg ----------
struct Avg;

struct AvgAcc<T> { sum: T, count: usize }

impl<T: Add + Zero + ToF64> Aggregate<T, AvgAcc<T>, f64> for Avg {
    fn init(self: &Self) -> AvgAcc<T> { AvgAcc { sum: T::zero(), count: 0 } }
    fn iterate(self: &Self, acc: AvgAcc<T>, value: T) -> AvgAcc<T> {
        AvgAcc { sum: acc.sum + value, count: acc.count + 1 }
    }
    fn merge(self: &Self, a: AvgAcc<T>, b: AvgAcc<T>) -> AvgAcc<T> {
        AvgAcc { sum: a.sum + b.sum, count: a.count + b.count }
    }
    fn finalize(self: &Self, acc: AvgAcc<T>) -> f64 {
        acc.sum.to_f64() / acc.count as f64
    }
    fn classify(self: &Self) -> AggregateClass { AggregateClass::Algebraic }
}

// ---------- Count ----------
struct Count;

impl<T> Aggregate<T, usize, usize> for Count {
    fn init(self: &Self) -> usize { 0 }
    fn iterate(self: &Self, acc: usize, _value: T) -> usize { acc + 1 }
    fn merge(self: &Self, a: usize, b: usize) -> usize { a + b }
    fn finalize(self: &Self, acc: usize) -> usize { acc }
    fn classify(self: &Self) -> AggregateClass { AggregateClass::Distributive }
}

// ---------- Percentile (Holistic) ----------
struct Percentile { p: f64 }

struct PercentileAcc<T> { values: Vec<T>, p: f64 }

impl<T: Ord + Clone> Aggregate<T, PercentileAcc<T>, T> for Percentile {
    fn init(self: &Self) -> PercentileAcc<T> {
        PercentileAcc { values: Vec::new(), p: self.p }
    }
    fn iterate(self: &Self, mut acc: PercentileAcc<T>, value: T) -> PercentileAcc<T> {
        acc.values.push(value);
        acc
    }
    fn merge(self: &Self, mut a: PercentileAcc<T>, b: PercentileAcc<T>) -> PercentileAcc<T> {
        a.values.extend(b.values);
        a
    }
    fn finalize(self: &Self, mut acc: PercentileAcc<T>) -> T {
        acc.values.sort();
        let idx = (acc.values.len() as f64 * acc.p) as usize;
        acc.values[idx].clone()
    }
    fn classify(self: &Self) -> AggregateClass { AggregateClass::Holistic }
}
```

### 5.3 `reduce` on `Queryable`

`reduce(f)` is sugar for `aggregate` when `f` can be proven associative and has a known identity. If not, it falls back to local sequential reduction.

```yed
// In Queryable default impl:
fn reduce(self, f: impl Fn(T, T) -> T) -> Option<T>
where T: Clone, Self: Sized
{
    // If the compiler can prove f is associative and T has an identity,
    // this is rewritten to aggregate(ReduceAgg { f }).
    // Otherwise, it executes locally:
    self.into_iter().reduce(f)
}
```

The compiler's query extractor recognizes only the optimizable form.

---

## 6. From Surface Syntax to QIR

### 6.1 Surface syntax desugars to `Queryable` method calls

```yed
// Surface:
select users@u[*].{ id, age }
from users@u:User
where u.age > 18
order by u.age desc
range 20..30

// Lowered HIR (method-call chain):
users
    .filter(|u| u.age > 18)
    .order_by(|u| u.age, desc)
    .range(20..30)
    .map(|u| { id: u.id, age: u.age })
```

The `from users@u:User` clause:

1. Resolves `users` to a value of type `Queryable<User>` (or `IntoQueryable<User>`).
2. Introduces the binder `u` in scope.
3. The projection `users@u[*].{ id, age }` is the terminal `map`.

### 6.2 Query extraction from typed HIR

The query extractor walks typed HIR and recognizes `Queryable` method-call trees. It uses normal trait resolution, not a string registry.

```rust
// yelang-qir/src/logical/extract.rs

pub fn extract_queryable_expr(
    tcx: &TyCtxt,
    body_id: BodyId,
    expr_id: ExprId,
) -> Option<Operator> {
    let expr = tcx.expr(expr_id)?;
    let ty = tcx.typeck_results(body_id).expr_ty(expr_id)?;

    match expr {
        // .map(f)
        Expr::MethodCall { receiver, method, args, .. }
            if is_queryable_method(tcx, method, "map") =>
        {
            let input = extract_queryable_expr(tcx, body_id, *receiver)?;
            let projection = lower_to_qexpr(tcx, body_id, args[0])?;
            Some(Operator::Map { input: alloc(input), projection })
        }

        // .filter(p)
        Expr::MethodCall { receiver, method, args, .. }
            if is_queryable_method(tcx, method, "filter") =>
        {
            let input = extract_queryable_expr(tcx, body_id, *receiver)?;
            let predicate = lower_to_qexpr(tcx, body_id, args[0])?;
            Some(Operator::Filter { input: alloc(input), predicate })
        }

        // .aggregate(agg)
        Expr::MethodCall { receiver, method, args, .. }
            if is_queryable_method(tcx, method, "aggregate") =>
        {
            let input = extract_queryable_expr(tcx, body_id, *receiver)?;
            let (agg_id, class, input_expr) = resolve_aggregate(tcx, body_id, &args[0], ty)?;
            Some(Operator::Aggregate {
                input: alloc(input),
                aggregate: AggregateOp { agg_id, input_expr, class },
            })
        }

        // Source: a path resolving to a Queryable value
        Expr::Path { res } if is_queryable_source(tcx, res, ty) => {
            Some(Operator::Scan { source: scan_source_from_res(res), item_ty: ty })
        }

        // Not a queryable expression — fall back to normal evaluation.
        _ => None,
    }
}
```

`is_queryable_method` checks that the method resolves through the lang-item `Queryable` trait, not by name.

### 6.3 Sugar methods (`.sum()`, `.avg()`)

Sugar methods are ordinary `Queryable` default methods. The query extractor can pattern-match them for convenience, but correctness does not depend on it.

```rust
// Recognize .sum() as aggregate(Sum)
Expr::MethodCall { receiver, method, args, .. }
    if is_queryable_method(tcx, method, "sum") =>
{
    let input = extract_queryable_expr(tcx, body_id, *receiver)?;
    let sum_id = tcx.lang_item(LangItem::AggregateSum)?;
    Some(Operator::Aggregate {
        input: alloc(input),
        aggregate: AggregateOp {
            agg_id: sum_id,
            input_expr: QExpr::Var { index: 0, ty: element_type },
            class: AggregateClass::Distributive,
        },
    })
}
```

If the extractor does not recognize a sugar method, the call falls back to normal HIR evaluation (which still works, just not optimized as a QIR operator).

---

## 7. QIR Logical Model

### 7.1 Operators

QIR is the bridge between typed HIR and physical execution. It is backend-agnostic.

```rust
// yelang-qir/src/logical/operator.rs

pub enum Operator {
    /// Scan a named collection or an in-memory array value.
    Scan { source: ScanSource, item_ty: TyId },

    /// Filter a collection by a predicate over its element.
    Filter { input: QirId, predicate: QExpr },

    /// Map each element to a new value.
    Map { input: QirId, projection: QExpr },

    /// flat_map one or more levels.
    FlatMap { input: QirId, projection: QExpr },

    /// Order a collection.
    OrderBy { input: QirId, keys: Vec<OrderKey> },

    /// Slice/range a collection.
    Range { input: QirId, start: Option<QExpr>, end: Option<QExpr>, inclusive: bool },

    /// Group an input collection by key expressions.
    GroupBy { input: QirId, keys: Vec<(Symbol, QExpr)>, aggregates: Vec<AggregateOp> },

    /// Reduce a collection to a scalar using an aggregate.
    Aggregate { input: QirId, aggregate: AggregateOp },

    /// Join operators.
    InnerJoin { left: QirId, right: QirId, predicate: QExpr },
    LeftOuterJoin { left: QirId, right: QirId, predicate: QExpr },
    SemiJoin { left: QirId, right: QirId, predicate: QExpr },
    AntiJoin { left: QirId, right: QirId, predicate: QExpr },
    DependentJoin { outer: QirId, inner: QirId, predicate: QExpr },

    /// Attach a nested field to each upstream element (for `links` materialization).
    AttachField { input: QirId, field: Symbol, value_plan: QirId },

    /// Combine independent plans into a struct/object result.
    Construct { kind: ConstructKind, fields: Vec<(Symbol, QirId)> },

    /// Return a scalar value produced by a sub-expression.
    Expr(QExpr),
}

pub struct AggregateOp {
    /// DefId of the aggregate config type (e.g., Sum, Avg, Percentile).
    pub agg_id: DefId,
    /// Expression applied to each input element before accumulate.
    pub input_expr: QExpr,
    /// Classification used by the physical planner.
    pub class: AggregateClass,
}

pub enum ScanSource {
    Named(Symbol),
    Expr(QExprId),
}

pub enum ConstructKind {
    Record,
    Facet,
    Tuple,
}
```

### 7.2 Scalar expressions inside operators

`QExpr` is already defined in `yelang-qir/src/expr.rs`. It should be extended to reference aggregate functions by `DefId` for code generation, but the logical plan only needs the `AggregateOp` wrapper.

### 7.3 `AggregateOp` replaces `AggregateKind`

The current code has:

```rust
pub enum AggregateKind {
    Count,
    Sum,
    Min,
    Max,
    Avg,
}
```

This is replaced by `AggregateOp`. New aggregates require no QIR changes — only a new trait impl in stdlib or user code.

---

## 8. Decorrelation

### 8.1 `links` creates dependent joins

```yed
select users@u[*].{
    name: u.name,
    posts: u.writes@w[*].title,
}
from users@u:User
links (users)->[writes]->(posts)
```

Initially lowers to:

```text
Project(
  name: u.name,
  posts: Subquery(
    DependentJoin(
      outer = users (with u bound),
      inner = Filter(w.user_id == u.id, posts),
      projection = w.title
    )
  )
)
```

### 8.2 Neumann 2025 top-down decorrelation

Use the algorithm from the YeLang Query System doc and from Neumann's 2025 paper. The core rule:

```text
L ⋈D R  ≡  L ⋈_D (D ⋈D R)
```

where `D` is the distinct domain of outer-column values referenced by `R`.

Key rewrite rules:

| Operator | Rule |
|----------|------|
| Selection | `D ⋈D σ_p(R)` → `σ_p(D ⋈D R)` |
| Projection | `D ⋈D Π_A(R)` → `Π_{A ∪ D}(D ⋈D R)` |
| Inner Join | push domain to dependent side |
| Group By | outer refs become additional grouping keys |
| Order By / Limit | add domain columns to partition |

The doc's `Decorrelator` struct is the right shape:

```rust
pub struct Decorrelator<'tcx> {
    pub tcx: &'tcx QueryCtxt,
    pub scope_stack: Vec<HashMap<Column, ScalarExpr>>,
    pub equivalences: EquivalenceClasses,
    fresh_counter: usize,
}
```

The implementation in `yelang_query_system_design_doc.md` is a good skeleton but needs completion:

- `current_outer_refs` must track actual outer references.
- `EquivalenceClasses` should use union-find with path compression.
- The `build_domain` operator must deduplicate outer-column combinations.

---

## 9. Physical Planning & Distributed Execution

### 9.1 Physical operators

```rust
// yelang-qir/src/physical/operator.rs

pub enum PhysOperator {
    TableScan { source: ScanSource, predicate: Option<QExpr> },
    Filter { input: PhysId, predicate: QExpr },
    Map { input: PhysId, projection: QExpr },
    FlatMap { input: PhysId, projection: QExpr },
    Sort { input: PhysId, keys: Vec<OrderKey> },
    Slice { input: PhysId, start: usize, end: Option<usize> },

    HashGroupBy { input: PhysId, keys: Vec<OrderKey>, aggregates: Vec<PhysicalAggregateOp> },
    SortGroupBy { input: PhysId, keys: Vec<OrderKey>, aggregates: Vec<PhysicalAggregateOp> },
    Aggregate { input: PhysId, aggregate: PhysicalAggregateOp, mode: AggregateMode },

    HashJoin { build: PhysId, probe: PhysId, build_key: QExpr, probe_key: QExpr },
    MergeJoin { left: PhysId, right: PhysId, keys: Vec<(QExpr, QExpr)> },
    NestedLoopJoin { outer: PhysId, inner: PhysId, predicate: QExpr },

    AttachField { input: PhysId, field: Symbol, value_plan: PhysId },
    Construct { kind: ConstructKind, fields: Vec<(Symbol, PhysId)> },

    Exchange { input: PhysId, kind: ExchangeKind },
    Gather { inputs: Vec<PhysId> },
    Expr(QExpr),
}

pub struct PhysicalAggregateOp {
    pub agg_id: DefId,
    pub input_expr: QExpr,
    pub class: AggregateClass,
}

pub enum AggregateMode {
    Partial,  // per-node/local accumulator
    Final,    // merge partials
    Full,     // holistic: must see all data
}

pub enum ExchangeKind {
    Single,              // no movement
    Broadcast,           // send to all workers
    RepartitionBy(Vec<QExpr>), // hash shuffle by key
    Gather,              // collect to coordinator
}
```

### 9.2 Aggregate distribution rules

```rust
// yelang-qir/src/physical/planner.rs

fn plan_aggregate(
    &mut self,
    input: PhysId,
    agg: &AggregateOp,
    group_keys: Option<Vec<OrderKey>>,
) -> PhysId {
    match (agg.class, group_keys) {
        // Scalar distributive/algebraic: partial per node, gather, final merge.
        (AggregateClass::Distributive | AggregateClass::Algebraic, None) => {
            let partial = self.alloc(PhysOperator::Aggregate {
                input,
                aggregate: agg.clone().into(),
                mode: AggregateMode::Partial,
            });
            let gathered = self.alloc(PhysOperator::Exchange {
                input: partial,
                kind: ExchangeKind::Gather,
            });
            self.alloc(PhysOperator::Aggregate {
                input: gathered,
                aggregate: agg.clone().into(),
                mode: AggregateMode::Final,
            })
        }

        // Grouped distributive/algebraic: repartition by key, partial agg, final agg.
        (AggregateClass::Distributive | AggregateClass::Algebraic, Some(keys)) => {
            let partial = self.alloc(PhysOperator::HashGroupBy {
                input,
                keys: keys.clone(),
                aggregates: vec![agg.clone().into()],
            });
            let shuffled = self.alloc(PhysOperator::Exchange {
                input: partial,
                kind: ExchangeKind::RepartitionBy(keys.iter().map(|k| k.expr.clone()).collect()),
            });
            self.alloc(PhysOperator::HashGroupBy {
                input: shuffled,
                keys,
                aggregates: vec![agg.clone().into()],
            })
        }

        // Scalar holistic: must gather all data to one node.
        (AggregateClass::Holistic, None) => {
            let gathered = self.alloc(PhysOperator::Exchange {
                input,
                kind: ExchangeKind::Gather,
            });
            self.alloc(PhysOperator::Aggregate {
                input: gathered,
                aggregate: agg.clone().into(),
                mode: AggregateMode::Full,
            })
        }

        // Grouped holistic: repartition by key so each key is local,
        // then run full aggregate per partition. No cross-key data movement.
        (AggregateClass::Holistic, Some(keys)) => {
            let shuffled = self.alloc(PhysOperator::Exchange {
                input,
                kind: ExchangeKind::RepartitionBy(keys.iter().map(|k| k.expr.clone()).collect()),
            });
            self.alloc(PhysOperator::HashGroupBy {
                input: shuffled,
                keys,
                aggregates: vec![agg.clone().into()],
            })
        }
    }
}
```

### 9.3 Cross-node data format

- **Data batches:** Apache Arrow IPC. Record batches are transferred with shared buffers; zero-copy deserialization on the receiver when possible ([Apache Arrow IPC](https://arrow.apache.org/docs/10.0/python/ipc.html)).
- **Aggregate states:** Serialized to bytes using the `AccumulatorState` trait. For primitive accumulators (`SumAcc<i32>`, `AvgAcc<i64>`), this is a fixed-size byte blob. For `PercentileAcc<T>`, it is a length-prefixed array.
- **Plans:** Serialized to a compact message format (FlatBuffers / Cap'n Proto) referencing aggregate `DefId`s. Storage nodes load the compiled aggregate by symbol.

---

## 10. Storage Backend Integration

### 10.1 Capability trait

```rust
// yelang-qir/src/backend/capability.rs

pub trait BackendCapability {
    fn can_push_down_filter(&self, source: &ScanSource) -> bool;
    fn can_push_down_project(&self, source: &ScanSource) -> bool;
    fn can_push_down_order(&self, source: &ScanSource) -> bool;
    fn can_push_down_limit(&self, source: &ScanSource) -> bool;
    fn supports_index_lookup(&self, source: &ScanSource, key: &[QExpr]) -> bool;
    fn supports_hash_join(&self) -> bool;
    fn supports_merge_join(&self) -> bool;
    fn supports_exchange(&self, kind: &ExchangeKind) -> bool;
    fn supports_partial_aggregate(&self, agg_id: DefId) -> bool;
    fn estimated_cardinality(&self, source: &ScanSource) -> Cardinality;
}
```

### 10.2 `Queryable` implementations per backend

```yed
// stdlib/infra/storage/lsm.yed

struct LsmCollection<T> {
    storage: Share<LsmStorage>,
    name: String,
}

impl<T> Queryable<T> for LsmCollection<T> {
    fn filter(self, pred: impl Fn(&T) -> bool) -> impl Queryable<T> {
        // Predicate may be pushed down if representable as QExpr.
        LsmFilter { source: self, pred, pushed: can_push_down(&pred) }
    }

    fn fold<U>(self, init: U, f: impl Fn(U, T) -> U) -> U {
        // Local sequential fallback.
        let mut acc = init;
        for item in self {
            acc = f(acc, item);
        }
        acc
    }

    fn aggregate<A, Acc, Out>(self, agg: A) -> Out
    where A: Aggregate<T, Acc, Out>
    {
        if self.storage.capabilities().supports_partial_aggregate(A::def_id()) {
            self.storage.engine.aggregate(self.name, agg)
        } else {
            // Fallback: scan and aggregate locally.
            let mut acc = agg.init();
            for item in self {
                acc = agg.iterate(acc, item);
            }
            agg.finalize(acc)
        }
    }

    fn execute(self) -> Vec<T> {
        self.into_iter().collect()
    }
}
```

```yed
// stdlib/infra/storage/distributed.yed

struct DistributedQueryable<T> {
    shard_key: Expr,
    nodes: Vec<NodeId>,
    plan_fragment: LogicalPlan,
}

impl<T> Queryable<T> for DistributedQueryable<T> {
    fn map<U>(self, f: impl Fn(T) -> U) -> impl Queryable<U> {
        DistributedQueryable {
            shard_key: self.shard_key,
            nodes: self.nodes,
            plan_fragment: LogicalPlan::Map {
                input: Box::new(self.plan_fragment),
                projection: f,
            },
        }
    }

    fn aggregate<A, Acc, Out>(self, agg: A) -> Out
    where A: Aggregate<T, Acc, Out>
    {
        match agg.classify() {
            AggregateClass::Distributive | AggregateClass::Algebraic => {
                let partials: Vec<Acc> = self.nodes.map(|node| {
                    node.execute(LogicalPlan::Aggregate {
                        input: Box::new(self.plan_fragment.clone()),
                        aggregate: agg.clone(),
                        mode: AggregateMode::Partial,
                    })
                });

                let final_acc = partials.into_iter()
                    .fold(agg.init(), |a, b| agg.merge(a, b));

                agg.finalize(final_acc)
            }

            AggregateClass::Holistic => {
                let all_data: Vec<T> = self.execute();
                let mut acc = agg.init();
                for item in all_data {
                    acc = agg.iterate(acc, item);
                }
                agg.finalize(acc)
            }
        }
    }

    fn execute(self) -> Vec<T> {
        // Gather all shards.
        self.nodes.flat_map(|node| node.execute(self.plan_fragment.clone()))
    }
}
```

### 10.3 Backend selection

At compile time or deployment time, the compiler/linker pairs a `Queryable<T>` source with the backend that produces it:

```yed
// stdlib/infra/storage/registry.yed (runtime, not compiler)

fn open_collection<T>(storage: Share<dyn StorageBackend>, name: String) -> impl Queryable<T> {
    match storage.capabilities().kind {
        StorageKind::InMemory => VecQueryable::from(memory_table(name)),
        StorageKind::Lsm => LsmCollection { storage: storage.downcast(), name },
        StorageKind::Distributed => DistributedQueryable::from(storage.shard_plan(name)),
        StorageKind::Sql => SqlQueryable::from(storage.sql_table(name)),
    }
}
```

---

## 11. User-Defined Aggregates

### 11.1 Manual trait impl

```yed
struct GeometricMean;

struct GmAcc { product: f64, count: usize }

impl Aggregate<f64, GmAcc, f64> for GeometricMean {
    fn init(self: &Self) -> GmAcc { GmAcc { product: 1.0, count: 0 } }
    fn iterate(self: &Self, acc: GmAcc, value: f64) -> GmAcc {
        GmAcc { product: acc.product * value, count: acc.count + 1 }
    }
    fn merge(self: &Self, a: GmAcc, b: GmAcc) -> GmAcc {
        GmAcc { product: a.product * b.product, count: a.count + b.count }
    }
    fn finalize(self: &Self, acc: GmAcc) -> f64 {
        acc.product.powf(1.0 / acc.count as f64)
    }
    fn classify(self: &Self) -> AggregateClass { AggregateClass::Algebraic }
}

let gm = values.aggregate(GeometricMean);
```

### 11.2 `@aggregate` decorator

```yed
@aggregate(class = Holistic)
fn percentile(values: Iterator<f64>, p: f64) -> f64 {
    let mut sorted = values.collect::<Vec<f64>>();
    sorted.sort();
    sorted[(sorted.len() as f64 * p) as usize]
}
```

Expansion:

```yed
struct Percentile { p: f64 }

impl Aggregate<f64, PercentileAcc<f64>, f64> for Percentile { /* ... */ }

trait QueryablePercentileExt<T> {
    fn percentile(self, p: f64) -> f64;
}

impl<T> QueryablePercentileExt<T> for Queryable<T>
where T: Into<f64>
{
    fn percentile(self, p: f64) -> f64 {
        self.aggregate(Percentile { p })
    }
}
```

The compiler registers the `Percentile` aggregate so that storage nodes can load it by `DefId`.

---

## 12. Mixed Example: Grouped Query with Distributive + Holistic Aggregates

```yed
select groups@g[*].{
    city: g.city,
    avg_age: g.users.avg(u => u.age),
    total: g.users.count(),
    median_salary: g.users.percentile(0.5, u => u.salary),
}
from users@u:User
group by { city: u.city } into groups
```

### 12.1 Lowered HIR

```yed
users
    .group_by(|u| u.city)
    .map(|g| {
        city: g.key,
        avg_age: g.users.map(|u| u.age).avg(),
        total: g.users.count(),
        median_salary: g.users.map(|u| u.salary).percentile(0.5),
    })
```

### 12.2 Logical QIR

```text
Map(
  GroupBy(
    Scan(users),
    keys: [(city, u.city)],
    aggregates: [
      avg_age = AggregateOp { agg_id: Avg, input_expr: u.age, class: Algebraic },
      total = AggregateOp { agg_id: Count, input_expr: _, class: Distributive },
      median_salary = AggregateOp { agg_id: Percentile, input_expr: u.salary, class: Holistic }
    ]
  ),
  projection: { city: g.city, avg_age: g.avg_age, total: g.total, median_salary: g.median_salary }
)
```

### 12.3 Physical plan (distributed)

Because `median_salary` is grouped by `city`, the Holistic aggregate does **not** need to gather all raw data to a single node. It only needs all rows for each `city` to land on the same node. The plan is:

```text
// Step 1: repartition by city so each city is on one node.
Exchange(RepartitionBy(city),
  Scan(users)
)

// Step 2: per-node grouped aggregation.
//         Distributive/Algebraic run in partial mode.
//         Holistic runs in full mode (it has all rows for its city).
HashGroupBy(
  input: ^^^,
  keys: [city],
  aggregates: [
    avg_age: Aggregate(Avg, u.age, mode = Partial),
    total: Aggregate(Count, _, mode = Partial),
    median_salary: Aggregate(Percentile, u.salary, mode = Full),
  ]
)

// Step 3: final merge for Distributive/Algebraic only.
HashGroupBy(
  input: ^^^,
  keys: [city],
  aggregates: [
    avg_age: Aggregate(Avg, _, mode = Final),
    total: Aggregate(Count, _, mode = Final),
    // median_salary already complete; pass through
  ]
)

// Step 4: final map projection.
Map(
  input: ^^^,
  projection: { city, avg_age, total, median_salary }
)
```

This shows why `classify` matters: Distributive/Algebraic aggregates use a two-phase partial/final pattern, while grouped Holistic aggregates can stop after one phase once data is partitioned by key. Scalar Holistic aggregates, however, still require a full `Gather`.

---

## 13. File Tree

```
yelang/
├── compiler/
│   ├── yelang-ast/
│   ├── yelang-resolve/
│   ├── yelang-hir/
│   │   └── src/
│   │       └── lowering/
│   │           └── query.rs        # desugar select/syntax to Queryable calls
│   ├── yelang-tycheck/
│   │   └── src/
│   │       ├── check.rs            # type-check Queryable/Aggregate method calls
│   │       └── aggregate_solver.rs # prove aggregate properties (future)
│   ├── yelang-trait-solver/
│   │   └── src/                    # lang-item trait resolution
│   └── yelang-qir/
│       └── src/
│           ├── lib.rs              # query driver
│           ├── ids.rs
│           ├── expr.rs             # QExpr
│           ├── errors.rs
│           ├── logical/
│           │   ├── mod.rs
│           │   ├── operator.rs     # Operator enum, AggregateOp
│           │   ├── lower.rs        # HIR -> logical QIR
│           │   ├── extract.rs      # Queryable tree extraction
│           │   ├── shape.rs        # NestedShape, CorrelationMode
│           │   └── links.rs        # links -> joins/AttachField
│           ├── physical/
│           │   ├── mod.rs
│           │   ├── operator.rs     # PhysOperator, AggregateMode, ExchangeKind
│           │   ├── planner.rs      # logical -> physical
│           │   ├── properties.rs   # ordering, distribution, streaming unit
│           │   ├── exchanges.rs    # exchange insertion
│           │   ├── joins.rs        # join algorithm selection
│           │   └── aggregations.rs # aggregate implementation selection
│           ├── rewrite/
│           │   ├── mod.rs
│           │   ├── push_filter.rs
│           │   ├── merge_maps.rs
│           │   ├── decorrelate.rs  # Neumann 2025
│           │   └── unnest_subqueries.rs
│           ├── exec/
│           │   ├── mod.rs
│           │   ├── interface.rs    # QueryExecutor, Value (Arrow-backed)
│           │   ├── memory.rs       # in-memory VM
│           │   └── kernels.rs      # scalar kernel registry
│           ├── backend/
│           │   ├── mod.rs
│           │   ├── capability.rs   # BackendCapability
│           │   ├── memory_backend.rs
│           │   └── remote_backend.rs
│           └── util/
│               ├── arena.rs
│               ├── graph.rs
│               └── print.rs
│
├── stdlib/
│   ├── core/
│   │   ├── queryable.fl            # #[lang = "queryable"] trait
│   │   ├── aggregate.fl            # #[lang = "aggregate"] trait + AggregateClass
│   │   ├── aggregate_impls.fl      # Sum, Avg, Count, Min, Max, Any, All
│   │   ├── iter.fl                 # Iterator / IntoIterator traits
│   │   ├── share.fl                # Share<T> unified reference
│   │   ├── arena.fl                # region allocator
│   │   └── decorators.fl           # @aggregate, @operator
│   │
│   └── infra/
│       ├── storage/
│       │   ├── lsm.fl              # LsmQueryable
│       │   ├── distributed.fl      # DistributedQueryable
│       │   ├── remote_sql.fl       # SqlQueryable
│       │   └── backend.fl          # StorageBackend trait
│       └── stream.fl               # event-bus / streaming Queryable
│
└── runtime/
    └── src/
        ├── value.rs                # Arrow-backed runtime values
        ├── rc.rs                   # Share<T> runtime
        ├── arena.rs                # region allocator
        ├── aggregate_registry.rs   # DefId -> dyn ErasedAggregateFn
        └── storage.rs              # storage node runtime
```

---

## 14. References

1. **Fegaras, L.** "An Algebra for Distributed Big Data Analytics." 2017. [MRQL Monoid Algebra](https://lambda.uta.edu/mrql-algebra.pdf) — monoid homomorphisms as the foundation for distributed aggregation.
2. **Yu, Y., et al.** "DryadLINQ: A System for General-Purpose Distributed Data-Parallel Computing Using a High-Level Language." SOSP 2009. [DryadLINQ distributed aggregation](https://www.sigops.org/s/conferences/sosp/2009/papers/yu-sosp09.pdf).
3. **Apache Spark.** "User-Defined Aggregate Functions (UDAFs)." [Spark Aggregator API](https://spark.apache.org/docs/latest/sql-ref-functions-udf-aggregate.html) — `init`/`reduce`/`merge`/`finish` contract.
4. **Apache Derby.** `org.apache.derby.agg.Aggregator` — UDAF `init`/`accumulate`/`merge`/`terminate` contract. [Derby API](https://db.apache.org/derby//docs/10.14/publishedapi/org/apache/derby/agg/Aggregator.html).
5. **Graefe, G.** "Volcano — An Extensible and Parallel Query Evaluation System." IEEE TKDE 1994. [Volcano iterator model](https://github.com/clflushopt/eocene) — `open-next-close` operator protocol.
6. **Apache Arrow.** "Streaming, Serialization, and IPC." [Arrow IPC zero-copy transfer](https://arrow.apache.org/docs/10.0/python/ipc.html).
7. **Swift / OriLang.** Automatic Reference Counting + CoW patterns. [Ori runtime overview](https://ori-lang.com/docs/compiler-design/11-runtime/).
8. **Neumann, T.** "Improving Unnesting of Complex Queries." BTW 2025. Top-down decorrelation.
9. **Neumann & Kemper.** "Unnesting Arbitrary Queries." BTW 2015. Bottom-up decorrelation foundation.

---

*This document is the canonical design for Yelang query execution. Implementation work should align the current `yelang-qir` skeleton, the `AggregateKind` enum, and the HIR query lowering with the traits and operators described here.*
