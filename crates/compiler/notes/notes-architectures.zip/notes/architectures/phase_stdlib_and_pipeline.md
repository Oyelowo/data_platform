# Phase: `.ye` Standard Library + End-to-End Query Pipeline

**Status:** Phase I complete. Logical/physical planning phase is now active.  
**Goal:** Move the query subsystem from hand-constructed HIR and synthetic DefIds to a real `.ye` standard library that is parsed, resolved, type-checked, and lowered through the same pipeline as user code. After this phase, `yelang-qir` consumes trait-resolution facts from the real stdlib instead of a hardcoded registry.

**Supersedes / updates:** `notes/architectures/query_language_and_execution_design.md` (this phase switches the file extension from `.yed` to `.ye` as requested and makes the stdlib concrete).

---

## 1. Why this phase first

The previous phase proved that HIR → LIR lowering can be driven by `MethodResolution` facts. But those facts were synthetic: tests injected `DefId(100)` for `Queryable`, `DefId(200)` for `filter`, etc. That is not a compiler; it is a unit-test scaffold.

Before logical optimizations or a physical planner can be trusted, the pipeline must consume real source. Specifically:

1. `Queryable`, `Aggregate`, `Iterator`, and `IntoIterator` must be ordinary Yelang traits in `stdlib/core/src/*.ye`, marked with `@lang("...")`.
2. Built-in aggregates (`Sum`, `Avg`, `Count`) must be ordinary Yelang structs/impls.
3. The QIR lowering layer must discover which `Queryable` method maps to which operator by inspecting the trait definition, not by a hardcoded `FxHashMap<DefId, QueryableMethod>`.
4. `AggregateClass` must come from evaluating the stdlib impl of `Aggregate::class()`, not from a registry.
5. End-to-end tests must parse Yelang source, run resolve → HIR → tycheck → QIR, and assert on the resulting `LogicalPlan`.

Logical rewrites, the Cascades planner, and the executor come **after** this phase. Trying to plan or execute plans produced from a fake stdlib would bake the fake assumptions into the optimizer.

---

## 2. Research foundations

### 2.1 Decorrelation / unnesting

- **Thomas Neumann & Alfons Kemper, "Unnesting Arbitrary Queries" (BTW 2015).** The baseline algorithm: represent correlated subqueries as dependent joins, push the dependent join down through the inner tree using rewrite identities, and replace with regular joins once free variables vanish. This is the algorithm DuckDB, Hyper, and Umbra use.
- **Thomas Neumann, "Improving Unnesting of Complex Queries" (BTW 2025).** Identifies the bottom-up algorithm's pathological behavior on deeply stacked dependent joins (cross-product blowup of binding domains). Proposes a **holistic top-down** strategy that processes all dependent joins in one pass and covers recursive SQL, ORDER BY, and LIMIT inside subqueries. [PDF](https://15799.courses.cs.cmu.edu/spring2025/papers/11-unnesting/neumann-btw2025.pdf)
- **Neumann, "A Formalization of Top-Down Unnesting" (arXiv 2412.04294).** Formal proof of correctness for the top-down variant. [arXiv](https://arxiv.org/abs/2412.04294)

Yelang adopts the **top-down holistic** variant because:
- It handles nested comprehensions and `links` traversals cleanly.
- It avoids the cross-product pathology when queries nest (common in graph-style queries).
- It fits a rule-based rewrite engine: each operator carries a *correlation context* (outer binders in scope) and rewrites itself accordingly.

### 2.2 Comprehension / monad algebra

- **Leonidas Fegaras, MRQL algebra (UTA).** MRQL compiles nested comprehensions to a small core of `concatMap`, `groupBy`, `join`, `union`, and `orderBy`. The key insight: map-reduce-style physical operators emerge from normalization rules on nested comprehensions, not from SQL surface patterns. [MRQL XML paper](https://lambda.uta.edu/mrql-xml.pdf)
- Yelang's selector syntax (`users@u[*]`, `users@u[where p]`, `[**]`) already desugars to `Expr::Comprehension`. The rewrite layer will normalize these using monad laws before decorrelation.

### 2.3 Distributed aggregation

- **DryadLINQ** accumulator pattern: `init`, `step`, `merge`, `finish`.
- **Aggregate classes:**
  - `Distributive`: partial states merge directly (sum, count, min, max).
  - `Algebraic`: fixed-size intermediate, merge works (avg = (sum, count); stddev = (sum, sumsq, count)).
  - `Holistic`: must see all values co-located (median, percentile, mode) → planner inserts `Gather` or `RepartitionBy(group_keys)` before final aggregation.

These are encoded in the stdlib `Aggregate` trait via the `class()` method, not in the compiler.

---

## 3. Compiler contract: what the compiler hardcodes

The compiler knows exactly these things and no others:

| Hardcoded concept | Rationale |
|---|---|
| `Iterator` / `IntoIterator` lang items | Recognize local eager iteration. |
| `Queryable` lang item | Recognize optimizable lazy pipelines. |
| `Aggregate` lang item + `AggregateClass` enum | Recognize aggregates and decide distributed strategy. |
| `DependentJoin` LIR operator | Represents correlation before decorrelation. |
| Physical properties: `Ordering`, `Partitioning`, `Location`, `Boundedness` | Drive enforcer insertion in the planner. |
| Comprehension core operators: `Scan`, `Filter`, `Map`, `FlatMap`, `OrderBy`, `Slice`, `GroupBy`, `Aggregate`, `Join`, `Distinct`, `Construct`, `Values` | One calculus for all backends. |

The compiler does **not** know: `Table`, `sum`, `avg`, `filter`, `map`, `users`, edges, indexes, storage engines. Those are stdlib / user code recognized by resolved identity.

---

## 4. Standard library surface

All files live under `stdlib/core/src/` and use extension `.ye`.

### 4.1 `iter.ye`

```ye
@lang("iterator")
trait Iterator[T] {
    // State-passing next. Returns (new iterator state, element) or None.
    fn next(self) -> Option[(Self, T)];

    // Default combinators are ordinary default methods.
    fn map[U](self, f: fn(T) -> U) -> MapIter[Self, T, U] { ... }
    fn filter(self, pred: fn(&T) -> Bool) -> FilterIter[Self, T] { ... }
    fn fold[U](self, init: U, f: fn(U, T) -> U) -> U { ... }
    fn take(self, n: usize) -> TakeIter[Self, T] { ... }
    fn skip(self, n: usize) -> SkipIter[Self, T] { ... }
}

@lang("into_iterator")
trait IntoIterator[T] {
    fn into_iter(self) -> impl Iterator[T];
}
```

For this phase, `Iterator`/`IntoIterator` methods are **not** lowered to QIR operators; they remain scalar `MethodCall` expressions. The `Queryable` trait is the QIR-optimizable surface.

### 4.2 `query.ye`

```ye
@lang("queryable")
trait Queryable[T] {
    fn filter(self, pred: fn(T) -> Bool) -> Self;
    fn map[U](self, f: fn(T) -> U) -> Queryable[U];
    fn flat_map[U](self, f: fn(T) -> Queryable[U]) -> Queryable[U];
    fn order_by[K: Ord](self, key: fn(T) -> K) -> Seq[T];
    fn group_by[K](self, key: fn(T) -> K) -> Queryable[Group[K, T]];
    fn distinct(self) -> Self;
    fn take(self, n: usize) -> Self;
    fn skip(self, n: usize) -> Self;
    fn aggregate[A: Aggregate[T]](self, agg: A) -> A::Out;

    // Sugar default methods.
    fn sum(self) -> T where T: Add { self.aggregate(Sum) }
    fn count(self) -> usize { self.aggregate(Count) }
    fn avg(self) -> f64 where T: Numeric { self.aggregate(Avg) }
}
```

Note: `Seq[T]` and `Group[K, T]` are stdlib types; `order_by` returns `Seq[T]` because `Slice` requires ordered input. The compiler does not special-case `Seq`; it is just a type the planner tracks ordering for.

### 4.3 `aggregate.ye`

```ye
@lang("aggregate")
trait Aggregate[In] {
    type Acc;
    type Out;
    fn init() -> Self::Acc;
    fn step(acc: Self::Acc, item: In) -> Self::Acc;
    fn merge(a: Self::Acc, b: Self::Acc) -> Self::Acc;
    fn finish(acc: Self::Acc) -> Self::Out;
    fn class() -> AggregateClass;
}

enum AggregateClass { Distributive, Algebraic, Holistic }

// Marker structs.
struct Sum;
struct Count;
struct Avg { p: f64 }  // configurable percentile, p=0.5 is median

impl Aggregate[i32, SumAcc[i32], i32] for Sum {
    type Acc = SumAcc[i32];
    type Out = i32;
    fn init() -> SumAcc[i32] { SumAcc { value: 0 } }
    fn step(acc, item) { SumAcc { value: acc.value + item } }
    fn merge(a, b) { SumAcc { value: a.value + b.value } }
    fn finish(acc) { acc.value }
    fn class() -> AggregateClass { AggregateClass::Distributive }
}

struct SumAcc[T] { value: T }

// Similar for Count and Avg.
```

For the first cut, the stdlib includes only enough to exercise the pipeline: `Sum`, `Count`, `Avg`, and `AggregateClass`.

### 4.4 `lib.ye`

Re-exports:

```ye
pub mod iter;
pub mod query;
pub mod aggregate;
```

---

## 5. Compiler integration

### 5.1 Loading the stdlib

There is no multi-crate system yet. For this phase, the compiler loads the stdlib as a **prelude module** that is prepended to every crate:

```rust
// In yelang-resolve or a new yelang-driver crate
pub fn load_stdlib_source() -> String {
    include_str!("../../stdlib/core/src/lib.ye")
}
```

The test harness concatenates stdlib source + user source before parsing. A real module/import system will replace this later, but concatenation is sufficient to prove the pipeline and keeps the stdlib in `.ye` files.

### 5.2 Discovering lang items

`yelang-resolve::def_collector` already scans `@lang("...")` attributes. Because the stdlib traits carry those attributes, `lang_items` will contain real `DefId`s for `Queryable`, `Aggregate`, `Iterator`, `IntoIterator`. QIR lowering reads them via `tcx.lang_item(LangItem::Queryable)` exactly as before; only the source of the DefIds changes.

### 5.3 Discovering `Queryable` method operators

Replace `FxHashMap<DefId, QueryableMethod>` with introspection of the `Queryable` trait definition:

```rust
// yelang-qir/src/logical/queryable.rs
pub fn queryable_method_from_def(
    ctx: &LoweringCtxt,
    method_def_id: DefId,
) -> Option<QueryableMethod> {
    let queryable_trait = ctx.lang_traits.queryable?;
    let trait_def = ctx.tcx.trait_def(queryable_trait)?;
    let method_name = ctx.tcx.item_name(method_def_id)?;
    // Map by canonical method name. This is still a small table, but it is
    // derived from the trait, not from test-injected DefIds.
    match method_name.as_str() {
        "filter" => Some(QueryableMethod::Filter),
        "map" => Some(QueryableMethod::Map),
        ...
        _ => None,
    }
}
```

The key difference: the mapping is **name-derived from the stdlib trait**, so adding a new queryable operator is a stdlib change, not a QIR code change (as long as the operator already exists in `LirOp`).

### 5.4 Discovering `Aggregate::class()`

Replace the `aggregate_classes` map with evaluation of the stdlib impl:

```rust
pub fn aggregate_class_from_impl(
    ctx: &LoweringCtxt,
    agg_def: DefId,
) -> Option<AggregateClass> {
    let aggregate_trait = ctx.lang_traits.aggregate?;
    // Find the Aggregate impl for `agg_def`.
    let impl_def = ctx.tcx.find_impl(aggregate_trait, agg_def)?;
    // Evaluate the associated `class()` method body. For the first cut,
    // if the body is `AggregateClass::Distributive`, return that.
    ctx.tcx.eval_assoc_const_or_simple_fn(impl_def, "class")
}
```

If the compiler cannot yet evaluate the method body, the test harness may provide an override for bootstrapping, but the design target is full const-evaluation of `class()`.

---

## 6. End-to-end test harness

Add `yelang-qir/tests/end_to_end_query_tests.rs`:

```rust
fn compile_query(src: &str) -> (TyCtxt, TypeckResults, LogicalPlan) {
    let stdlib = load_stdlib_source();
    let full = format!("{}\n{}", stdlib, src);
    let (program, interner) = parse_program(&full);
    let resolved = resolve_crate(&program, &interner);
    assert!(resolved.errors.is_empty());
    let hir_crate = lower_crate(&program, &resolved, &interner);
    let mut tcx = TyCtxt::new(hir_crate);
    let diagnostics = type_check_crate(&mut tcx);
    assert!(diagnostics.is_empty());
    let mut plan = LogicalPlan::empty();
    let mut ctx = LoweringCtxt::new(&tcx, ...);
    // lower the main query expression / body
    ...
    (tcx, ctx.results.clone(), plan)
}
```

Tests:

1. `users.filter(...).sum()` lowers to `Aggregate(Sum)` over `Filter` over `Scan`.
2. `users.map(...).avg()` lowers to `Aggregate(Avg)` over `Map`.
3. `select ... from ... where ... order by ... range ...` lowers to the correct operator stack.
4. Unregistered method on a queryable falls back to `MethodCall`.
5. User-defined aggregate (`P95`) implementing `Aggregate` is recognized and classified as `Holistic`.

---

## 7. What remains after this phase

| Next phase | Why it waits |
|---|---|
| Logical rewrites (decorrelate, unnest, pushdowns) | Need real LIR from real source first. |
| Cascades physical planner | Needs real LIR + properties. |
| PIR → Exec lowering + memory executor | Needs physical plans. |
| Storage / distributed backends | Needs executor. |
| Self-hosting stdlib compilation | Needs codegen to be able to compile Yelang; for now stdlib is parsed/resolved/tychecked but operators are recognized by the compiler. |

---

## 8. Checklist

- [x] Create `stdlib/core/src/iter.ye` with `@lang("iterator")` and `@lang("into_iterator")` traits.
- [x] Create `stdlib/core/src/query.ye` with `@lang("queryable")` trait.
- [x] Create `stdlib/core/src/aggregate.ye` with `@lang("aggregate")` trait, `AggregateClass`, `Sum`, `Count`, `Avg`.
- [x] Create `stdlib/core/src/lib.ye` re-exporting the modules.
- [x] Add `load_stdlib_source()` helper in `yelang-qir/tests/`.
- [x] Add end-to-end test harness: parse → resolve → HIR → tycheck → QIR.
- [x] Replace `QueryableMethod` registry with trait-name-derived mapping (`yelang-qir/src/logical/stdlib.rs`).
- [x] Replace `aggregate_classes` registry with introspection of `Aggregate::class()` impl bodies.
- [x] Update resolver to handle generic args/where-clauses so the stdlib resolves.
- [x] Add end-to-end tests covering `filter`, `map`, `order_by`, `range`, `group_by`, and aggregate classification.
- [x] Run `cargo test --workspace` and ensure no regressions.
