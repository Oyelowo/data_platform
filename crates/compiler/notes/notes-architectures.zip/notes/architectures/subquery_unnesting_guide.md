# Complete Guide to Subquery Unnesting / Decorrelation
## Based on Thomas Neumann's Papers (2015, 2024, 2025)

---

## 1. The Core Idea: The D-Table

From Neumann & Kemper 2015, the fundamental equivalence is:

```
L ⧑ R  ≡  L ⋈_{natural D} (D ⧑ R)

where D := Π_{F(R) ∩ A(L)}(L)
```

**What this means in SQL terms:**

- `L` = the outer query (left side of the dependent join)
- `R` = the inner query (right side, which references outer columns)
- `F(R)` = free variables in R (outer columns that R references)
- `A(L)` = attributes of L
- `D` = the **distinct projection** of L onto the columns that R references

**D is always a set (duplicate-free).** This is crucial — it allows push-down rewrites that would not hold for arbitrary tables.

---

## 2. The Algorithm (2025 Top-Down Version)

The 2025 paper improves on the 2015 bottom-up approach by using a **single top-down pass** that handles all nested dependent joins simultaneously.

### Steps:

1. **Identify all non-trivial dependent joins** — where the right-hand side actually accesses attributes from the left.
2. **Annotate each dependent join** with which outer columns it references.
3. **Process top-to-bottom**: For each dependent join, build D and push it down through the algebra tree.
4. **Apply operator-specific rewrite rules** (see below).
5. **When D reaches a leaf** where the right-hand side no longer depends on the left, replace the dependent join with a regular join.
6. **Optionally apply substitution** — if D attributes are equi-joined with existing attributes, eliminate D entirely.

---

## 3. Operator-Specific Rewrite Rules

### 3.1 Selection (WHERE)

```
D ⧑ (σ_p(R))  →  σ_p(D ⧑ R)
```

The D-table is pushed past the selection. The predicate `p` can reference both D and R attributes.

**SQL Example:**

```sql
-- Original correlated
SELECT u.name,
  (SELECT o.amount FROM orders o WHERE o.user_id = u.id AND o.amount > 100) AS amt
FROM users u;

-- After pushing D past selection
SELECT u.name, d.amount
FROM users u
LEFT JOIN (
  SELECT D.id, o.amount
  FROM (SELECT DISTINCT id FROM users) D
  LEFT JOIN orders o ON o.user_id = D.id AND o.amount > 100
) d ON u.id = d.id;
```

---

### 3.2 Projection (SELECT list)

```
D ⧑ (Π_A(R))  →  Π_{A ∪ A(D)}(D ⧑ R)
D ⧑ (Π⁺_A(R)) → Π⁺_{A ∪ A(D)}(D ⧑ R)
```

The projection attributes are extended to include D's attributes.

---

### 3.3 Cross Product / Inner Join (one side correlated)

```
D ⧑ (R1 × R2) → (D ⧑ R1) × R2     if F(R2) ∩ A(D) = ∅
D ⧑ (R1 × R2) → R1 × (D ⧑ R2)     if F(R1) ∩ A(D) = ∅
```

**SQL Example:**

```sql
-- Original correlated in JOIN condition
SELECT u.name, o.amount, p.price
FROM users u
WHERE u.id IN (
  SELECT o.id FROM orders o
  JOIN products p ON p.id = o.product_id AND p.category = u.region
);

-- After unnesting
SELECT u.name, d.amount, d.price
FROM users u
INNER JOIN (
  SELECT D.region, o.amount, p.price
  FROM (SELECT DISTINCT region FROM users) D
  INNER JOIN orders o ON TRUE
  INNER JOIN products p ON p.id = o.product_id AND p.category = D.region
) d ON u.region = d.region;
```

---

### 3.4 Cross Product / Inner Join (both sides correlated)

```
D ⧑ (R1 × R2) → (D ⧑ R1) ⋈_{natural} (D ⧑ R2)
D ⧑ (R1 ⋈_p R2) → (D ⧑ R1) ⋈_{p ∧ natural} (D ⧑ R2)
```

When both sides reference outer columns, D is replicated on both sides and a natural join merges them.

---

### 3.5 Group By (AGGREGATE)

```
D ⧑ (Γ_{A; agg}(R)) → Γ_{A ∪ A(D); agg}(D ⧑ R)
```

**Critical:** All outer references are added to the GROUP BY attributes.

**SQL Example:**

```sql
-- Original correlated aggregate
SELECT u.name,
  (SELECT SUM(o.amount) FROM orders o WHERE o.user_id = u.id) AS total
FROM users u;

-- After unnesting
SELECT u.name, d.total
FROM users u
LEFT JOIN (
  SELECT D.id, SUM(o.amount) AS total
  FROM (SELECT DISTINCT id FROM users) D
  LEFT JOIN orders o ON o.user_id = D.id
  GROUP BY D.id
) d ON u.id = d.id;
```

**Note:** The join from D to orders is **LEFT JOIN** because the algebra requires producing one tuple per D group even when the group is empty (SUM over empty set = NULL).

---

### 3.6 Static Group By (Aggregate without explicit GROUP BY)

When there is no explicit GROUP BY (e.g., `SELECT COUNT(*) FROM ...`), the algebra must produce a non-empty output even for empty input. Neumann 2015 and 2025 use an **outer join** to achieve this.

```sql
-- Original: scalar aggregate with no GROUP BY
SELECT u.name,
  (SELECT COUNT(*) FROM orders o WHERE o.user_id = u.id) AS c
FROM users u;

-- After unnesting
SELECT u.name, d.c
FROM users u
LEFT JOIN (
  SELECT D.id, COUNT(o.id) AS c
  FROM (SELECT DISTINCT id FROM users) D
  LEFT JOIN orders o ON o.user_id = D.id
  GROUP BY D.id
) d ON u.id = d.id;
```

**Important:** Use `COUNT(column)` not `COUNT(*)` because `COUNT(*)` would count the D row itself even when no orders match.

---

### 3.7 Window Functions (2025 extension)

```
D ⧑ (Window_{partition, order}(R)) → Window_{partition ∪ A(D), order}(D ⧑ R)
```

Outer references are added to the **PARTITION BY** clause.

**SQL Example:**

```sql
-- Original: correlated LIMIT
SELECT u.name,
  (SELECT o.amount FROM orders o
   WHERE o.user_id = u.id
   ORDER BY o.amount DESC LIMIT 2) AS top_two
FROM users u;

-- After unnesting (2025 approach)
SELECT u.name, d.amount
FROM users u
LEFT JOIN (
  SELECT D.id, o.amount,
    ROW_NUMBER() OVER (PARTITION BY D.id ORDER BY o.amount DESC) AS rn
  FROM (SELECT DISTINCT id FROM users) D
  LEFT JOIN orders o ON o.user_id = D.id
) d ON u.id = d.id AND d.rn <= 2;
```

---

### 3.8 Semi Join (EXISTS / IN)

```
D ⧑ (R1 ⋉_p R2) → (D ⧑ R1) ⋉_{p ∧ natural} (D ⧑ R2)
```

**SQL Example:**

```sql
-- Original: EXISTS
SELECT u.name FROM users u
WHERE EXISTS (SELECT 1 FROM orders o WHERE o.user_id = u.id);

-- After unnesting
SELECT u.name
FROM users u
WHERE EXISTS (
  SELECT 1
  FROM (SELECT DISTINCT id FROM users) D
  INNER JOIN orders o ON o.user_id = D.id
  WHERE D.id = u.id
);

-- Or equivalently
SELECT u.name
FROM users u
INNER JOIN (
  SELECT DISTINCT D.id
  FROM (SELECT DISTINCT id FROM users) D
  INNER JOIN orders o ON o.user_id = D.id
) d ON u.id = d.id;
```

---

### 3.9 Anti Join (NOT EXISTS / NOT IN)

```
D ⧑ (R1 ▹_p R2) → (D ⧑ R1) ▹_{p ∧ natural} (D ⧑ R2)
```

**SQL Example:**

```sql
-- Original: NOT EXISTS
SELECT u.name FROM users u
WHERE NOT EXISTS (SELECT 1 FROM orders o WHERE o.user_id = u.id);

-- After unnesting
SELECT u.name
FROM users u
LEFT JOIN (
  SELECT DISTINCT D.id
  FROM (SELECT DISTINCT id FROM users) D
  INNER JOIN orders o ON o.user_id = D.id
) d ON u.id = d.id
WHERE d.id IS NULL;
```

---

### 3.10 Left Outer Join

```
D ⧑ (R1 ⟕_p R2) → (D ⧑ R1) ⟕_{p ∧ natural} (D ⧑ R2)
```

**SQL Example:**

```sql
-- Original: correlated LEFT JOIN inside subquery
SELECT u.name,
  (SELECT COUNT(*) FROM orders o
   LEFT JOIN products p ON p.id = o.product_id AND p.category = u.region
   WHERE o.user_id = u.id) AS c
FROM users u;

-- After unnesting
SELECT u.name, d.c
FROM users u
LEFT JOIN (
  SELECT D.id, D.region, COUNT(o.id) AS c
  FROM (SELECT DISTINCT id, region FROM users) D
  LEFT JOIN orders o ON o.user_id = D.id
  LEFT JOIN products p ON p.id = o.product_id AND p.category = D.region
  GROUP BY D.id, D.region
) d ON u.id = d.id AND u.region = d.region;
```

---

### 3.11 Dependent Join (nested correlation)

```
D ⧑ (R1 ⧑_p R2) → (D ⧑ R1) ⧑_p R2
```

D is pushed down the left side only. The inner dependent join will be handled in a subsequent pass (or simultaneously in the top-down algorithm).

---

## 4. Complete Examples with Data

### Data

**users**

| id | name | region | min_spend |
|----|------|--------|-----------|
| 1 | Alice | US | 100 |
| 2 | Bob | EU | 50 |
| 3 | Carol | US | 200 |
| 4 | Dan | US | 300 |

**orders**

| id | user_id | region | amount |
|----|---------|--------|--------|
| 101 | 1 | US | 150 |
| 102 | 1 | US | 80 |
| 103 | 2 | EU | 60 |
| 104 | 1 | US | 250 |

**products**

| id | category | price |
|----|----------|-------|
| 10 | US | 120 |
| 20 | US | 40 |
| 30 | EU | 70 |
| 40 | US | 300 |

---

### Example 1: Scalar Aggregate, Equality on PK

**Original**
```sql
SELECT u.name,
  (SELECT SUM(o.amount) FROM orders o WHERE o.user_id = u.id) AS total
FROM users u;
```

**Result:**
| name | total |
|------|-------|
| Alice | 480 |
| Bob | 60 |
| Carol | NULL |
| Dan | NULL |

**Decorrelated (general form)**
```sql
SELECT u.name, d.total
FROM users u
LEFT JOIN (
  SELECT D.id, SUM(o.amount) AS total
  FROM (SELECT DISTINCT id FROM users) D
  LEFT JOIN orders o ON o.user_id = D.id
  GROUP BY D.id
) d ON u.id = d.id;
```

**Decorrelated (substitution optimization)**
```sql
SELECT u.name, d.total
FROM users u
LEFT JOIN (
  SELECT o.user_id, SUM(o.amount) AS total
  FROM orders o
  GROUP BY o.user_id
) d ON u.id = d.user_id;
```

The substitution optimization works because `D.id` is equi-joined with `o.user_id`, and `user_id` already exists in the inner table. The optimizer can skip building D explicitly.

---

### Example 2: Non-Equality Correlation

**Original**
```sql
SELECT u.name, u.min_spend,
  (SELECT SUM(o.amount) FROM orders o WHERE o.amount > u.min_spend) AS big_spend
FROM users u;
```

**Result:**
| name | min_spend | big_spend |
|------|-----------|-----------|
| Alice | 100 | 540 |
| Bob | 50 | 540 |
| Carol | 200 | 250 |
| Dan | 300 | NULL |

**Decorrelated**
```sql
SELECT u.name, u.min_spend, d.big_spend
FROM users u
LEFT JOIN (
  SELECT D.min_spend, SUM(o.amount) AS big_spend
  FROM (SELECT DISTINCT min_spend FROM users) D
  LEFT JOIN orders o ON o.amount > D.min_spend
  GROUP BY D.min_spend
) d ON u.min_spend = d.min_spend;
```

**Note:** D must be explicit because `min_spend` does not exist in `orders`. We cannot use substitution.

---

### Example 3: Multi-Column Correlation

**Original**
```sql
SELECT u.name,
  (SELECT SUM(o.amount)
   FROM orders o
   WHERE o.region = u.region AND o.amount > u.min_spend) AS total
FROM users u;
```

**Decorrelated**
```sql
SELECT u.name, d.total
FROM users u
LEFT JOIN (
  SELECT D.region, D.min_spend, SUM(o.amount) AS total
  FROM (SELECT DISTINCT region, min_spend FROM users) D
  LEFT JOIN orders o ON o.region = D.region AND o.amount > D.min_spend
  GROUP BY D.region, D.min_spend
) d ON u.region = d.region AND u.min_spend = d.min_spend;
```

---

### Example 4: GROUP BY with Outer Reference

**Original**
```sql
SELECT u.name,
  (SELECT 
     CASE WHEN o.amount > u.min_spend THEN 'big' ELSE 'small' END AS bucket,
     SUM(o.amount) AS total
   FROM orders o
   WHERE o.user_id = u.id
   GROUP BY CASE WHEN o.amount > u.min_spend THEN 'big' ELSE 'small' END
  ) AS spend_buckets
FROM users u;
```

**Decorrelated**
```sql
SELECT u.name, d.bucket, d.total
FROM users u
LEFT JOIN (
  SELECT 
    D.id,
    D.min_spend,
    CASE WHEN o.amount > D.min_spend THEN 'big' ELSE 'small' END AS bucket,
    SUM(o.amount) AS total
  FROM (SELECT DISTINCT id, min_spend FROM users) D
  LEFT JOIN orders o ON o.user_id = D.id
  GROUP BY D.id, D.min_spend,
           CASE WHEN o.amount > D.min_spend THEN 'big' ELSE 'small' END
) d ON u.id = d.id AND u.min_spend = d.min_spend;
```

---

### Example 5: HAVING with Outer Reference

**Original**
```sql
SELECT u.name,
  (SELECT SUM(o.amount)
   FROM orders o
   WHERE o.user_id = u.id
   HAVING SUM(o.amount) > u.min_spend) AS total
FROM users u;
```

**Decorrelated**
```sql
SELECT u.name, d.total
FROM users u
LEFT JOIN (
  SELECT D.id, D.min_spend, SUM(o.amount) AS total
  FROM (SELECT DISTINCT id, min_spend FROM users) D
  LEFT JOIN orders o ON o.user_id = D.id
  GROUP BY D.id, D.min_spend
  HAVING SUM(o.amount) > D.min_spend
) d ON u.id = d.id AND u.min_spend = d.min_spend;
```

---

### Example 6: ORDER BY + LIMIT (Window Function)

**Original**
```sql
SELECT u.name,
  (SELECT o.amount
   FROM orders o
   WHERE o.user_id = u.id
   ORDER BY o.amount DESC
   LIMIT 1) AS top
FROM users u;
```

**Decorrelated (2025 approach)**
```sql
SELECT u.name, d.amount AS top
FROM users u
LEFT JOIN (
  SELECT D.id, o.amount,
    ROW_NUMBER() OVER (PARTITION BY D.id ORDER BY o.amount DESC) AS rn
  FROM (SELECT DISTINCT id FROM users) D
  LEFT JOIN orders o ON o.user_id = D.id
) d ON u.id = d.id AND d.rn = 1;
```

---

### Example 7: Correlated LIMIT > 1

**Original**
```sql
SELECT u.name,
  (SELECT o.amount
   FROM orders o
   WHERE o.user_id = u.id
   ORDER BY o.amount DESC
   LIMIT 2) AS top_two
FROM users u;
```

**Decorrelated (as array)**
```sql
SELECT u.name, d.amounts
FROM users u
LEFT JOIN (
  SELECT D.id, ARRAY_AGG(o.amount ORDER BY o.amount DESC) AS amounts
  FROM (
    SELECT D2.id, o.amount,
      ROW_NUMBER() OVER (PARTITION BY D2.id ORDER BY o.amount DESC) AS rn
    FROM (SELECT DISTINCT id FROM users) D2
    LEFT JOIN orders o ON o.user_id = D2.id
  ) ranked
  WHERE ranked.rn <= 2
  GROUP BY ranked.id
) d ON u.id = d.id;
```

---

### Example 8: Correlation in JOIN Condition

**Original**
```sql
SELECT u.name,
  (SELECT SUM(o.amount + p.price)
   FROM orders o
   JOIN products p ON p.id = o.product_id AND p.category = u.region
   WHERE o.user_id = u.id) AS total
FROM users u;
```

**Decorrelated**
```sql
SELECT u.name, d.total
FROM users u
LEFT JOIN (
  SELECT D.id, D.region, SUM(o.amount + p.price) AS total
  FROM (SELECT DISTINCT id, region FROM users) D
  LEFT JOIN orders o ON o.user_id = D.id
  LEFT JOIN products p ON p.id = o.product_id AND p.category = D.region
  GROUP BY D.id, D.region
) d ON u.id = d.id AND u.region = d.region;
```

---

### Example 9: Multiple Interdependent Subqueries

**Original**
```sql
SELECT u.name,
  (SELECT SUM(o.amount)
   FROM orders o
   WHERE o.user_id = u.id
     AND o.amount > (SELECT AVG(p.price) FROM products p WHERE p.category = u.region)
  ) AS total
FROM users u;
```

**Decorrelated (fully inlined)**
```sql
SELECT u.name, d.total
FROM users u
LEFT JOIN (
  SELECT D2.id, D2.region, SUM(o.amount) AS total
  FROM (SELECT DISTINCT id, region FROM users) D2
  INNER JOIN (
    SELECT D1.region, AVG(p.price) AS avg_price
    FROM (SELECT DISTINCT region FROM users) D1
    LEFT JOIN products p ON p.category = D1.region
    GROUP BY D1.region
  ) inner_most ON inner_most.region = D2.region
  LEFT JOIN orders o 
    ON o.user_id = D2.id 
   AND o.amount > inner_most.avg_price
  GROUP BY D2.id, D2.region
) d ON u.id = d.id AND u.region = d.region;
```

**Why INNER JOIN to inner_most?** The inner_most derived table has exactly one row per region (guaranteed by GROUP BY). Every D2 row matches exactly one inner_most row. INNER JOIN is safe.

**Why LEFT JOIN to orders?** The original scalar subquery in SELECT list must return NULL when no orders qualify. LEFT JOIN preserves this.

---

### Example 10: LATERAL Join (FROM clause correlation)

**Original**
```sql
SELECT u.name, l.amount
FROM users u,
LATERAL (SELECT o.amount FROM orders o WHERE o.user_id = u.id) l;
```

**Decorrelated**
```sql
SELECT u.name, d.amount
FROM users u
INNER JOIN (
  SELECT D.id, o.amount
  FROM (SELECT DISTINCT id FROM users) D
  INNER JOIN orders o ON o.user_id = D.id
) d ON u.id = d.id;
```

**Original with LEFT JOIN LATERAL**
```sql
SELECT u.name, l.amount
FROM users u
LEFT JOIN LATERAL (SELECT o.amount FROM orders o WHERE o.user_id = u.id) l ON TRUE;
```

**Decorrelated**
```sql
SELECT u.name, d.amount
FROM users u
LEFT JOIN (
  SELECT D.id, o.amount
  FROM (SELECT DISTINCT id FROM users) D
  LEFT JOIN orders o ON o.user_id = D.id
) d ON u.id = d.id;
```

---

## 5. JOIN Type Decision Rules

| Situation | Inside derived table (D to base) | Final join to outer |
|-----------|----------------------------------|---------------------|
| Aggregate subquery in SELECT | `LEFT JOIN` from D to base tables | `LEFT JOIN` |
| Aggregate subquery in WHERE/HAVING | `LEFT JOIN` from D to base tables | `INNER JOIN` (or semi/anti join) |
| Non-aggregate subquery in SELECT | `LEFT JOIN` from D to base tables | `LEFT JOIN` |
| EXISTS / IN | `INNER JOIN` from D to base tables | `INNER JOIN` (or semi join) |
| NOT EXISTS / NOT IN | `INNER JOIN` from D to base tables | `LEFT JOIN` + `IS NULL` (or anti join) |
| LATERAL (CROSS JOIN) | `INNER JOIN` from D to base tables | `INNER JOIN` |
| LATERAL (LEFT JOIN) | `LEFT JOIN` from D to base tables | `LEFT JOIN` |
| Derived aggregate joined to next level | `INNER JOIN` (if 1:1 guaranteed by GROUP BY) | N/A |

---

## 6. Key Insights from the Papers

### 6.1 D is always a set (duplicate-free)

From 2015: "D is a set (i.e., duplicate free). D being a set allows for equivalences that do not hold in general."

This is why the push-down rules work. If D had duplicates, the natural join would produce duplicates.

### 6.2 Substitution Optimization

From 2015: "We can eliminate D if we can substitute it with values that already exist in the subtree... This is commonly the case with equi-joins."

When D's attributes are equi-joined with existing inner table columns, the optimizer can skip building D and group the inner table directly.

### 6.3 Top-Down vs Bottom-Up

From 2025: "The original bottom-up algorithm... the second unnesting pass increases the costs of the first join, leading to a performance degradation that becomes worse the deeper the nesting is."

The 2025 top-down algorithm processes all dependent joins in one pass, avoiding the cross-product explosion.

### 6.4 Window Functions for ORDER BY + LIMIT

From 2025: "We cover the remaining SQL constructs, in particular recursive SQL and ORDER BY LIMIT constructs."

The 2025 paper extends the framework to handle `ORDER BY ... LIMIT` inside subqueries using window functions (`ROW_NUMBER() OVER (PARTITION BY D.cols ORDER BY ...)`).

### 6.5 Formal Correctness

From 2024: "We provide the missing formalization by formally defining the operator semantics and proving that the unnesting algorithm is correct."

The 2024 paper proves all push-down rules using characteristic functions over multi-sets.

---

## 7. Common Pitfalls

### 7.1 COUNT(*) vs COUNT(column)

When using LEFT JOIN inside an aggregate derived table, `COUNT(*)` counts the D row even when no inner rows match. Use `COUNT(column_from_inner_table)` to get 0 for empty groups.

### 7.2 Forgetting D attributes in GROUP BY

All outer references must be added to the GROUP BY. If you forget one, the aggregate mixes values from different outer rows.

### 7.3 Using INNER JOIN inside when empty groups matter

For aggregates, INNER JOIN inside the derived table drops empty groups before the GROUP BY sees them. This gives wrong results for COUNT and can give wrong results if the derived table is reused.

### 7.4 Natural Join semantics with NULL

Neumann's natural join uses "IS semantics" — two NULLs compare as equal. Standard SQL natural join also treats NULLs as not matching. In practice, use explicit `ON` clauses with `IS NOT DISTINCT FROM` for NULL-safe matching, or rely on the optimizer to handle it.

---

## 8. Summary

The Neumann framework for subquery unnesting is:

1. **Build D** — distinct projection of outer table onto free variables referenced by inner query.
2. **Rewrite** — replace dependent join with regular join to D, then dependent join of D with inner query.
3. **Push D down** — apply operator-specific rules until the dependent join becomes trivial.
4. **Eliminate** — when the inner query no longer depends on the outer, replace with regular join.
5. **Optimize** — optionally apply substitution to eliminate D entirely when safe.

This works for arbitrary relational algebra, arbitrary nesting depth, and all SQL constructs including aggregates, GROUP BY, HAVING, ORDER BY, LIMIT, window functions, and recursive CTEs.
