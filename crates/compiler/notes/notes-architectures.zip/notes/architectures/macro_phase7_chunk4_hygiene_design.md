# Phase 7 Chunk 4 — Macro Hygiene Completion

**Status:** design ready for approval; implementation not started.  
**Scope:** complete end-to-end hygiene for declarative and procedural macros.  
**Prerequisite:** Chunk 3 (server limits, crash safety, quote, C ABI) is landed and tested.

---

## 1. Goals

1. Implement real `Span::call_site()`, `Span::def_site()`, and `Span::mixed_site()` semantics.
2. Make declarative macro expansion parent its `ExpnId` to the active outer expansion so nested macros isolate names correctly.
3. Serialize full hygiene context chains (`SyntaxContextData` + `ExpnData`) across the proc-macro server boundary.
4. Make `yelang-resolve` consider `SyntaxContextId` when resolving macro-introduced identifiers.
5. Add exhaustive positive, negative, and adversarial hygiene tests.

---

## 2. Background: the three-site model

Yelang follows the Rust three-site hygiene model, but implemented correctly from the start rather than retrofitted.

| Site | Meaning | Use case |
|---|---|---|
| `call_site()` | Resolves names at the macro invocation site. | Tokens that should behave as if the user typed them at the call site. |
| `def_site()` | Resolves names at the macro definition site. | Private helpers, items, and imports that the macro wants to reference from its own crate. |
| `mixed_site()` | Items/types resolve at the definition site; local bindings and labels resolve at the call site. | `macro_rules!`-style behavior for declarative macros and built-ins. |

**Transparency mapping:**

- `call_site()` → `Transparency::Transparent`.
- `def_site()` → `Transparency::Opaque`.
- `mixed_site()` → `Transparency::Mixed`.

A syntax context is a chain of `(parent_context, outer_expn, transparency)` marks. Name resolution walks this chain to decide which bindings are visible.

---

## 3. Current state

### 3.1 Data structures

`yelang-macro-core/src/id.rs` already defines:

- `ExpnId` — slotmap key in `ExpnArena`.
- `SyntaxContextId` — raw integer, serializable.
- `ExpnData { parent, call_site, def_site, kind, desc }`.
- `SyntaxContextData { parent, outer_expn, transparency }`.
- `Transparency { Opaque, Transparent, Mixed }`.

`yelang-macro-core/src/token_tree/span.rs` defines `Span { lo, hi, file, ctx }`.

### 3.2 Current gaps

1. `Span::def_site()` and `Span::mixed_site()` in `yelang-proc-macro/src/api/span.rs` alias `call_site()`.
2. Declarative macro expansion in `yelang-macro/src/expander.rs::transcribe_rule` always parents new `ExpnId`s to `root_expn()`.
3. `yelang-macro/src/proc_macro/expand.rs::span_to_wire` always sends `syntax_context: 0`.
4. The wire protocol carries raw `syntax_context` ids but no `ExpnData` or parent chains.
5. `yelang-resolve` uses `(Namespace, Symbol)` as the only lookup key; it ignores `SyntaxContextId`.

---

## 4. Detailed design

### 4.1 Track the active expansion context in `MacroExpander`

Add to `MacroExpander`:

```rust
/// Stack of active syntax contexts. The top is the context of the macro
/// expansion currently being performed.
hygiene_stack: Vec<SyntaxContextId>,
```

Helpers:

```rust
fn current_syntax_context(&self) -> SyntaxContextId {
    *self.hygiene_stack.last().unwrap_or(&self.hygiene.root_syntax_context())
}

fn with_hygiene_context<T>(&mut self, ctx: SyntaxContextId, f: impl FnOnce(&mut Self) -> T) -> T {
    self.hygiene_stack.push(ctx);
    let result = f(self);
    self.hygiene_stack.pop();
    result
}
```

Every macro expansion (declarative or procedural) pushes its generated context before transcribing or invoking the macro and pops it after.

### 4.2 Declarative macro hygiene

#### 4.2.1 `transcribe_rule`

Replace:

```rust
let expn_id = self.hygiene.fresh_expn(ExpnData {
    parent: self.hygiene.root_expn(), // BUG: always root
    ...
});
let generated_ctx = self.hygiene.apply_mark(
    self.hygiene.root_syntax_context(), // BUG: ignores active context
    expn_id,
    Transparency::Opaque,
);
```

With:

```rust
let parent_ctx = self.current_syntax_context();
let parent_expn = self.hygiene
    .syntax_context_data(parent_ctx)
    .and_then(|d| d.outer_expn)
    .unwrap_or_else(|| self.hygiene.root_expn());

let expn_id = self.hygiene.fresh_expn(ExpnData {
    parent: parent_expn,
    call_site: span,
    def_site: macro_def_span,
    kind: ExpnKind::MacroRules,
    desc: format!("expand {}", name),
});

let generated_ctx = self.hygiene.apply_mark(parent_ctx, expn_id, Transparency::Mixed);
```

Rationale: declarative macros default to mixed-site hygiene (items resolve at definition site, locals at call site), matching `macro_rules!`.

#### 4.2.2 Macro definition span

`MacroDefData` already stores `span`. `MacroResolver::macro_def_data(def_id)` returns it. Use this span as `def_site`.

#### 4.2.3 Captured tokens keep their original context

`transcribe.rs` already applies `generated_ctx` only to terminals and implicit punctuation. Substituted fragments (`TranscriberOp::Subst`) are emitted unchanged. This is correct; verify with tests.

#### 4.2.4 Nested expansion

When an expanded token stream contains another macro invocation, `expand_item` / `expand_expr` / etc. use `current_syntax_context()` as the parent. This gives nested macros the correct parent chain.

### 4.3 Procedural macro hygiene

#### 4.3.1 New wire payload

Add to `yelang-proc-macro-bridge/src/protocol/token.rs`:

```rust
/// Hygiene data sent alongside a token stream so the server can reconstruct
/// spans with their full syntax-context chains, and so the compiler can
/// reconstruct contexts returned by the macro.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct WireHygienePayload {
    /// Syntax contexts referenced by tokens in the accompanying stream.
    pub contexts: Vec<WireSyntaxContext>,
    /// Expansion data for every `ExpnId` referenced by the contexts.
    pub expansions: Vec<WireExpnData>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct WireSyntaxContext {
    pub id: u32,
    pub parent: Option<u32>,
    pub outer_expn: Option<u32>,
    pub transparency: WireTransparency,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct WireExpnData {
    pub id: u32,
    pub parent: u32,
    pub call_site: WireSpan,
    pub def_site: WireSpan,
    pub kind: WireExpnKind,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum WireTransparency { Opaque, Transparent, Mixed }

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum WireExpnKind { Root, MacroRules, Macro, ProcMacro, Comptime, AstPass }
```

#### 4.3.2 Send hygiene with each expansion request

Change `Request::ExpandFnLike` / `ExpandAttr` / `ExpandDerive` to carry a `hygiene: WireHygienePayload` in addition to `call_site`.

The compiler extracts the payload from the active syntax context and all its ancestors.

#### 4.3.3 Server reconstructs contexts

In `yelang-proc-macro-server/src/executor/invoke.rs`:

1. Before invoking the macro, call `reconstruct_hygiene(payload)` which inserts all `WireSyntaxContext` entries into a thread-local `HygieneData` and returns the root-to-call-site context map.
2. Set `Span::call_site()` from the request's `call_site` span, which now carries the correct `syntax_context`.
3. Clear the thread-local hygiene data after the macro returns.

#### 4.3.4 Return hygiene with the result

`WireExpansionResult` gains a `hygiene: WireHygienePayload` field. The dylib serializes any syntax contexts it created (e.g. from `Span::def_site()` or `Span::mixed_site()` used in the macro body) into this payload.

#### 4.3.5 Compiler reconstructs returned contexts

`wire_to_core` merges the returned payload into the compiler's `HygieneData`, remapping ids to avoid collisions. Every `WireSpan` in the returned stream is then resolved through the merged data.

### 4.4 `Span` API completion

Update `yelang-proc-macro/src/api/span.rs`:

```rust
impl Span {
    pub fn call_site() -> Self { /* existing thread-local */ }

    pub fn def_site() -> Self {
        DEF_SITE.with(|d| *d.borrow()).unwrap_or_else(Self::call_site)
    }

    pub fn mixed_site() -> Self {
        MIXED_SITE.with(|m| *m.borrow()).unwrap_or_else(Self::call_site)
    }
}
```

Add thread-locals for `def_site` and `mixed_site`, populated by the server from the macro definition span and a fresh mixed context.

`Span::resolved_at(self, other)` is already implemented; it should combine contexts using `HygieneData::apply_mark` semantics.

### 4.5 Name resolution integration

This is the largest piece. The goal is: an identifier with a non-root syntax context must not resolve to bindings introduced in incompatible contexts.

#### 4.5.1 Simplified first-pass model

For this phase we adopt a practical model that covers the common cases without requiring a full rustc-style resolver rewrite:

1. Bindings introduced by macro expansion carry the syntax context in which they were introduced.
2. A binding is visible to an identifier if the identifier's context is "compatible" with the binding's context.
3. Compatibility rules:
   - Root-context bindings are visible everywhere.
   - A binding at context `B` is visible from context `C` if `B` is an ancestor of `C` in the syntax-context tree, **or** `C` is an ancestor of `B`, **or** they share a recent common ancestor and the transparency of the marks between them permits it.

For Chunk 4 we implement the stricter, sufficient rule:

> A binding at context `B` is visible from context `C` only if `B` is an ancestor of `C` (including equality), unless the binding was introduced at the root context.

This prevents the most common hygiene leak: a macro introducing a local binding that escapes into the caller's scope.

#### 4.5.2 Resolver changes

1. `yelang-resolve/src/rib.rs`:
   - Change `Resolution` to carry an optional `SyntaxContextId`:
     ```rust
     pub enum Resolution {
         Def { def_id: DefId, context: Option<SyntaxContextId> },
         Local { local_id: u32, context: Option<SyntaxContextId> },
         Import { import_id: DefId, context: Option<SyntaxContextId> },
         Err,
     }
     ```
   - Or keep `Resolution` unchanged and store the context alongside in the rib map.

2. `yelang-resolve/src/scope.rs`:
   - Track the current `SyntaxContextId` in `Resolver`.
   - When inserting a binding, record `resolver.current_syntax_context()`.
   - When resolving a name, get the identifier's `SyntaxContextId` from its span and filter candidate resolutions.

3. `yelang-ast` identifiers:
   - `yelang_ast::Ident` carries a `yelang_lexer::Span`. We need to ensure macro-expanded identifiers preserve their `SyntaxContextId` through expansion so the resolver sees it.
   - `yelang_lexer::Span` currently does not carry `SyntaxContextId`. We need to either extend it or map `yelang_macro_core::Span -> yelang_lexer::Span` with context before resolution.

#### 4.5.3 Span bridge between macro core and lexer

`yelang-macro-core/src/token_tree/span.rs` has `impl From<Span> for yelang_lexer::Span` but it drops `ctx`. We need a way to keep the context.

Options:

A. Extend `yelang_lexer::Span` to carry `SyntaxContextId`. This touches the lexer and all AST spans.
B. Keep a side table mapping lexer spans to syntax contexts during expansion, and consult it in the resolver.
C. Convert macro-core tokens to AST tokens with context embedded before resolution.

**Recommended:** Option A is cleanest long-term. `yelang_lexer::Span` already has an internal representation; adding a `syntax_context: u32` field is a small breaking change that propagates correctly. It also lets diagnostics preserve hygiene info.

If Option A is too invasive for this phase, Option B is a narrower stopgap: maintain `HashMap<yelang_lexer::Span, SyntaxContextId>` in the expander and pass it to the resolver.

This design doc assumes **Option A**.

### 4.6 Test plan

#### 4.6.1 Declarative macro hygiene tests

- `decl_macro_introduced_local_not_visible_outside`
- `decl_macro_introduced_local_visible_inside`
- `decl_macro_nested_expansion_isolates_names`
- `decl_macro_item_with_def_site_resolves`
- `decl_macro_mixed_site_item_defines_at_def_site`
- `decl_macro_mixed_site_local_at_call_site`
- `decl_macro_captured_argument_keeps_call_site_context`

#### 4.6.2 Procedural macro hygiene tests

- `proc_macro_call_site_span_is_invocation_site`
- `proc_macro_def_site_span_is_definition_site`
- `proc_macro_mixed_site_item_resolves_at_def_site`
- `proc_macro_mixed_site_local_resolves_at_call_site`
- `proc_macro_nested_macro_preserves_hygiene_chain`

#### 4.6.3 Resolver integration tests

- `macro_introduced_binding_not_resolved_outside_invocation`
- `macro_introduced_item_visible_inside_invocation`
- `nested_macro_bindings_do_not_leak`

#### 4.6.4 Negative / adversarial tests

- `macro_generates_name_collision_with_user_name_is_isolated`
- `two_macros_use_same_generated_name_no_collision`

---

## 5. Exhaustive file tree changes

```text
crates/compiler/
├── yelang-macro-core/src/
│   ├── id.rs                         # add Wire* re-exports or keep bridge-only
│   ├── hygiene.rs                    # add context-chain helpers
│   └── token_tree/span.rs            # keep ctx field
│
├── yelang-proc-macro-bridge/src/protocol/
│   ├── token.rs                      # + WireHygienePayload, WireSyntaxContext, WireExpnData
│   └── message.rs                    # Expand* requests/result carry hygiene payload
│
├── yelang-proc-macro-server/src/executor/
│   ├── invoke.rs                     # reconstruct hygiene, clear after call
│   └── hygiene.rs                    # NEW: thread-local HygieneData + reconstruction
│
├── yelang-proc-macro/src/
│   ├── api/span.rs                   # real def_site / mixed_site
│   ├── api/token_stream.rs           # preserve context in into_core_stream_with_interner
│   └── bridge/serialize.rs           # send/receive hygiene payload
│
├── yelang-macro/src/
│   ├── expander.rs                   # hygiene_stack, parent contexts, def_site span
│   ├── proc_macro/
│   │   ├── expand.rs                 # extract/send hygiene payload, remap returned ids
│   │   └── client.rs                 # pass hygiene payload
│   └── transcribe.rs                 # verify captured tokens keep original context
│
└── yelang-resolve/src/
    ├── rib.rs                        # Resolution carries context
    ├── scope.rs                      # current_syntax_context, context-aware lookup
    └── late.rs                       # read ident span context during resolution
```

---

## 6. Implementation order

1. Extend `yelang_lexer::Span` with `syntax_context` (Option A) or add side table (Option B).
2. Add wire hygiene payload types.
3. Compiler extracts and sends hygiene payload; server reconstructs thread-local data.
4. Implement real `def_site` / `mixed_site` in `yelang-proc-macro`.
5. Fix declarative macro `ExpnId` parent chain.
6. Integrate `SyntaxContextId` into resolver.
7. Add tests.
8. Run `cargo fmt --all && cargo test --workspace`.

---

## 7. Design checklist (for agreement)

- [ ] Adopt three-site `call_site` / `def_site` / `mixed_site` model.
- [ ] Parent declarative macro `ExpnId`s to active outer expansion.
- [ ] Serialize full hygiene chains across proc-macro server boundary.
- [ ] Implement real `def_site` / `mixed_site` for proc macros.
- [ ] Integrate `SyntaxContextId` into `yelang-resolve`.
- [ ] Extend `yelang_lexer::Span` to carry `SyntaxContextId` (Option A).
- [ ] Approve implementation order.
- [ ] Approve exhaustive file tree.

---

## 8. Risks and mitigations

| Risk | Mitigation |
|---|---|
| Extending `yelang_lexer::Span` is invasive | Add a default value (root context) so existing constructors keep working; migrate call sites incrementally. |
| Resolver changes break existing tests | Keep old behavior as fallback when `SyntaxContextId` is root; add new tests for non-root contexts. |
| Hygiene payload bloats protocol | Only serialize contexts actually referenced by tokens; deduplicate. |
| Nested macro parent chains are subtle | Add dedicated tests for 3+ levels of nesting. |
