# HIR & Definition Storage Refactor — Design Document

**Status:** Implemented; workspace tests pass.  
**Scope:** Replace hash-map-backed and inline-wrapper storage with (1) dense `IndexVec` arenas for definitions and (2) generational `slotmap` arenas for HIR nodes, plus secondary maps for spans and type-check results.  
**Motivation:** The previous `FxHashMap<Id<T>, V>` and `Expr { kind: ExprKind, ... }` model had no allocation discipline, mixed node identity with inline metadata, and made it easy to synthesize overlapping IDs. Every downstream phase (type checking, trait solving, comptime, codegen) depends on a solid storage model.

---

## 1. Problem Statement

The compiler previously used:

- Typed integer IDs (`DefId`, `HirId`, `BodyId`) as newtyped `NonZeroU32` values.
- `FxHashMap<Id<T>, V>` as the backing store for almost everything.
- Manual per-phase counters (`next_def_id`, `next_body_id`, `next_hir_id`).
- Inline `ExprKind` / `PatKind` / `TyKind` / `StmtKind` enums wrapped in structs that also carried `hir_id`, `span`, and `ty`.

This had real bugs (e.g., `LoweringContext::next_def_id` aliasing the `BodyId` counter) and systemic weaknesses:

1. **No allocation discipline.** `DefId`s were minted in `yelang-resolve`, then again in `yelang-hir`, with only a manual `max + 1` guard.
2. **Inline metadata bloat.** Every expression carried a `ty` field even though the type is unknown during lowering.
3. **No stale-ID detection.** A dangling `DefId` silently returned `None` or the wrong value after the map was reused.
4. **Mixed concerns.** Node identity, source span, and inferred type were stored in the same struct.
5. **Monolithic `HirId`.** A single `HirId` space made it hard to know which arena a given ID referred to and forced every node into the same wrapper shape.

---

## 2. Design Goals

1. **Dense, typed-index storage for definitions.** Definitions live in contiguous `IndexVec<DefId, Definition>`.
2. **Generational arenas for HIR nodes.** Expressions, patterns, statements, types, and bodies live in `slotmap::SlotMap` arenas with distinct per-node IDs (`ExprId`, `PatId`, `StmtId`, `TyId`, `BodyId`).
3. **Secondary maps for metadata.** Source spans and type-check results are stored in `ArenaMap` secondary tables keyed by the same node IDs, not inline in the node.
4. **Single allocator per ID space.** A `DefId` comes from `definitions.push(def)`; a node ID comes from the corresponding arena insert. No manual counters.
5. **Stable IDs.** IDs are never reused or remapped during a compilation session.
6. **No ID collisions across phases or node kinds.** Definitions, HIR nodes of different kinds, and type-check results use separate typed ID spaces.
7. **No `*Kind` wrappers.** The expression/pattern/type/statement enums are the node types; child references are IDs, not inline structs.
8. **Testability.** Stubs allocate from arenas; no raw `DefId::new(n)` in production code.

---

## 3. Options Considered

### 3.1 Keep `FxHashMap<Id<T>, V>`

- **Pros:** Minimal churn.
- **Cons:** Keeps the collision, cache, and ownership problems. Rejected.

### 3.2 `slotmap::SlotMap` / generational arenas

`yelang-arena` wraps `SlotMap` and provides typed-key `Arena<K, V>`, `ArenaMap<K, V>`, and `SparseArenaMap<K, V>` ([slotmap comparison](https://github.com/slint-ui/slint/issues/5292)).

- **Pros:** Stable generational keys, built-in primary/secondary maps, removal safety (no ABA reuse), good locality.
- **Cons:**
  - Keys are 8 bytes (index + generation), inflating nodes that contain many IDs.
  - Cannot reserve a key without inserting a placeholder value.
- **Verdict:** Chosen for HIR expression/pattern/statement/type/body storage. Generational safety is valuable for incremental compilation, macro expansion, and comptime, where HIR subtrees may be replaced.

### 3.3 Typed-index vector (`IndexVec<K, V>`)

This is the model used by `rustc` (`IndexVec<I, T>`) for definitions.

- **Pros:**
  - Dense, contiguous storage.
  - 4-byte keys.
  - `push` returns the next typed key automatically.
  - Simple to implement and audit.
- **Cons:**
  - No generation safety.
  - Sparse maps need `IndexVec<K, Option<V>>` or a separate sparse map.
- **Verdict:** Chosen for `Definition` storage because definitions are dense, append-only, and keyed by the same `DefId` produced during name resolution.

---

## 4. ID Model

### 4.1 `DefId` remains the typed integer index

```rust
// yelang-arena/src/id.rs
pub struct Id<T> {
    raw: NonZeroU32,
    _marker: PhantomData<T>,
}
```

`DefId` remains 1-based, small, `Copy`, and type-safe. It is the single global entity identifier for items, modules, traits, impls, etc.

### 4.2 HIR node IDs are generational slotmap keys

```rust
// yelang-hir/src/ids.rs
use yelang_arena::new_key_type;

pub use yelang_arena::DefId;

new_key_type! {
    pub struct ExprId;
    pub struct PatId;
    pub struct StmtId;
    pub struct TyId;
    pub struct BodyId;
}
```

Each HIR node kind has its own key type, so it is impossible to pass a `PatId` where an `ExprId` is expected. The keys carry a generation and are allocated by `slotmap::SlotMap`.

### 4.3 Remove dead ID types

`HirId`, `LocalId`, and `CrateId` are removed. `HirId` is replaced by the per-kind IDs above. `LocalId` is no longer needed because local variables are tracked by `Symbol -> PatId` in the lowering context and resolved to `Res::Local` during name resolution. If multi-crate support needs `CrateId`, it will be reintroduced intentionally with its own storage.

### 4.4 `Idx` trait for `IndexVec`

```rust
// yelang-arena/src/index_vec.rs
pub trait Idx: Copy + Eq + std::hash::Hash + std::fmt::Debug {
    fn from_usize(idx: usize) -> Self;
    fn index(self) -> usize;
}
```

`Id<T>` implements `Idx` using 1-based raw values internally mapped to 0-based `Vec` indices.

---

## 5. `IndexVec<K, V>`

### 5.1 API

```rust
// yelang-arena/src/index_vec.rs
#[derive(Debug, Clone)]
pub struct IndexVec<K: Idx, V> {
    raw: Vec<V>,
    _marker: PhantomData<K>,
}

impl<K: Idx, V> IndexVec<K, V> {
    pub fn new() -> Self;
    pub fn with_capacity(capacity: usize) -> Self;

    /// Push a value and return its typed key.
    pub fn push(&mut self, value: V) -> K;

    pub fn pop(&mut self) -> Option<V>;

    pub fn get(&self, key: K) -> Option<&V>;
    pub fn get_mut(&mut self, key: K) -> Option<&mut V>;

    pub fn contains_key(&self, key: K) -> bool;

    pub fn len(&self) -> usize;
    pub fn is_empty(&self) -> bool;

    pub fn iter(&self) -> impl Iterator<Item = &V>;
    pub fn iter_enumerated(&self) -> impl Iterator<Item = (K, &V)>;
    pub fn keys(&self) -> impl Iterator<Item = K>;
    pub fn values(&self) -> impl Iterator<Item = &V>;

    pub fn clear(&mut self);
}

impl<K: Idx, V: Default> IndexVec<K, V> {
    /// Grow the vector so `key` is addressable, filling new slots with the default.
    pub fn resize_for_key(&mut self, key: K) -> &mut V;

    /// Insert at an arbitrary key. Returns the previous value if any.
    pub fn insert(&mut self, key: K, value: V) -> Option<V>;
}

impl<K: Idx, V> Index<K> for IndexVec<K, V> { /* panics on out-of-bounds */ }
impl<K: Idx, V> IndexMut<K> for IndexVec<K, V> { }
```

### 5.2 Invariants

- `K::index()` is always in `0..raw.len()` for valid keys.
- Keys are monotonically allocated by `push`.
- `insert` is only provided when `V: Default` and is intended for sparse `Option<T>` maps.

### 5.3 Example

```rust
let mut defs: IndexVec<DefId, Definition> = IndexVec::new();
let root = defs.push(definition_for_root_module());
assert_eq!(root, DefId::new(1));

let def = &defs[root];
```

---

## 6. `Arena<K, V>` and Secondary Maps

### 6.1 `Arena<K, V>`

```rust
// yelang-arena/src/arena.rs
#[derive(Debug, Clone)]
pub struct Arena<K: Key, T> {
    inner: SlotMap<K, T>,
}

impl<K: Key, T> Arena<K, T> {
    pub fn new() -> Self;
    pub fn with_capacity(capacity: usize) -> Self;
    pub fn insert(&mut self, value: T) -> K;
    pub fn get(&self, key: K) -> Option<&T>;
    pub fn get_mut(&mut self, key: K) -> Option<&mut T>;
    pub fn remove(&mut self, key: K) -> Option<T>;
    pub fn contains_key(&self, key: K) -> bool;
    pub fn len(&self) -> usize;
    pub fn iter(&self) -> impl Iterator<Item = (K, &T)>;
    pub fn keys(&self) -> impl Iterator<Item = K> + '_;
    pub fn values(&self) -> impl Iterator<Item = &T>;
}
```

### 6.2 `ArenaMap<K, V>`

```rust
// yelang-arena/src/arena.rs
#[derive(Debug, Clone)]
pub struct ArenaMap<K: Key, T> {
    inner: SecondaryMap<K, T>,
}

impl<K: Key, T> ArenaMap<K, T> {
    pub fn new() -> Self;
    pub fn insert(&mut self, key: K, value: T) -> Option<T>;
    pub fn get(&self, key: K) -> Option<&T>;
    pub fn get_mut(&mut self, key: K) -> Option<&mut T>;
    pub fn contains_key(&self, key: K) -> bool;
    pub fn remove(&mut self, key: K) -> Option<T>;
}
```

### 6.3 `SparseArenaMap<K, V>`

Sparse variant backed by `slotmap::SparseSecondaryMap`, used when the secondary data is sparse (e.g., inferred types for only a subset of nodes).

---

## 7. HIR Node Shapes

### 7.1 No more `*Kind` wrappers

Before:

```rust
pub struct Expr {
    pub hir_id: HirId,
    pub span: Span,
    pub ty: Ty,
    pub kind: ExprKind,
}
```

After:

```rust
// yelang-hir/src/hir_expr.rs
#[derive(Debug, Clone)]
pub enum Expr {
    Lit { lit: Lit },
    Path { res: Res },
    Binary { op: BinaryOp, left: ExprId, right: ExprId },
    // ...
}
```

The enum is the node. Child expressions, patterns, statements, and types are referenced by ID. Source spans live in a secondary map keyed by the same ID.

### 7.2 `Body`

```rust
// yelang-hir/src/hir_body.rs
#[derive(Debug, Clone)]
pub struct Body {
    pub params: Vec<Param>,
    pub value: ExprId,
    pub span: Span,
}
```

### 7.3 `Param`

```rust
// yelang-hir/src/hir_body.rs
#[derive(Debug, Clone)]
pub struct Param {
    pub pat: PatId,
    pub ty: TyId,
    pub span: Span,
}
```

---

## 8. Ownership Model

A fully unified cross-crate store is impossible without massive crate reorganization, because `Definition` lives in `yelang-resolve`, `Item`/`Body` live in `yelang-hir`, and neither crate can depend on a store that depends on both.

Therefore we use **two coordinated stores** with a strict rule: `DefId` is the single global entity ID, allocated from the definition arena in `yelang-resolve`; HIR lowering may allocate additional `DefId`s for synthesized items, but only by observing the current length of the definition arena.

### 8.1 `yelang-resolve` — definition store

```rust
// yelang-resolve/src/lib.rs
pub struct ResolvedCrate {
    pub module_tree: ModuleTree,
    pub definitions: IndexVec<DefId, Definition>,
    pub errors: Vec<ResolutionError>,
    pub def_resolutions: FxHashMap<Span, DefId>,
    pub enum_variants: FxHashMap<DefId, FxHashMap<Symbol, DefId>>,
    pub prelude: Option<Prelude>,
}
```

`DefCollector` no longer has a `next_def_id: u32` counter. It pushes definitions into `definitions` and receives back stable `DefId`s.

### 8.2 `yelang-hir` — HIR store

```rust
// yelang-hir/src/crate_hir.rs
#[derive(Debug, Clone)]
pub struct Crate {
    pub root_module: DefId,
    pub items: IndexVec<DefId, Option<Item>>,
    pub traits: IndexVec<DefId, Option<Trait>>,
    pub foreign_items: IndexVec<DefId, Option<ForeignItem>>,
    pub impls: Vec<Impl>,
    pub bodies: Arena<BodyId, Body>,
    pub exprs: Arena<ExprId, Expr>,
    pub pats: Arena<PatId, Pat>,
    pub stmts: Arena<StmtId, Stmt>,
    pub tys: Arena<TyId, Ty>,
    pub expr_spans: ArenaMap<ExprId, Span>,
    pub pat_spans: ArenaMap<PatId, Span>,
    pub stmt_spans: ArenaMap<StmtId, Span>,
    pub ty_spans: ArenaMap<TyId, Span>,
    pub body_spans: ArenaMap<BodyId, Span>,
}
```

- `items`, `traits`, and `foreign_items` are sparse-with-gaps `IndexVec`s keyed by `DefId`.
- `bodies`, `exprs`, `pats`, `stmts`, and `tys` are generational slotmap arenas keyed by their own ID types.
- `impls` remains a `Vec<Impl>` because impl blocks are not standalone item IDs.

Allocation helpers on `Crate`:

```rust
impl Crate {
    pub fn alloc_expr(&mut self, expr: Expr, span: Span) -> ExprId;
    pub fn alloc_pat(&mut self, pat: Pat, span: Span) -> PatId;
    pub fn alloc_stmt(&mut self, stmt: Stmt, span: Span) -> StmtId;
    pub fn alloc_ty(&mut self, ty: Ty, span: Span) -> TyId;
    pub fn alloc_body(&mut self, body: Body, span: Span) -> BodyId;

    pub fn expr_span(&self, id: ExprId) -> Span;
    pub fn pat_span(&self, id: PatId) -> Span;
    // ...
}
```

### 8.3 `LoweringContext`

```rust
pub struct LoweringContext<'a> {
    pub interner: &'a Interner,
    pub resolved: &'a ResolvedCrate,
    pub crate_hir: Crate,
    pub synthetic_def_count: u32,
    pub current_module: DefId,
    pub current_owner: DefId,
    pub local_map: FxHashMap<Symbol, PatId>,
    pub errors: Vec<LoweringError>,
    pub self_type: Option<DefId>,
}
```

Note the removal of `next_hir_id`, `next_body_id`, and `next_def_id`. Node IDs come from `crate_hir.alloc_*`. `BodyId`s come from `crate_hir.alloc_body`. Synthesized item `DefId`s come from `next_synthetic_def_id()`, which computes `self.resolved.definitions.len() as u32 + self.synthetic_def_count + 1` so that generated IDs are always above the definition arena.

For derived impls:

```rust
// Derive helpers allocate a fresh DefId in the item ID space.
let item_id = ctx.next_synthetic_def_id();
```

`next_synthetic_def_id` guarantees monotonicity and non-collision with resolved `DefId`s.

---

## 9. Allocation Discipline

| ID space | Owned by | How allocated | Stored in |
|---|---|---|---|
| `DefId` (resolved definitions) | `yelang-resolve::DefCollector` | `definitions.push(def)` | `ResolvedCrate::definitions` |
| `DefId` (synthesized HIR items) | `yelang-hir::LoweringContext` | `next_synthetic_def_id()` (above definition arena) | `Crate::items` |
| `BodyId` | `yelang-hir::Crate` | `crate_hir.alloc_body(body, span)` | `Crate::bodies` |
| `ExprId` | `yelang-hir::Crate` | `crate_hir.alloc_expr(expr, span)` | `Crate::exprs` |
| `PatId` | `yelang-hir::Crate` | `crate_hir.alloc_pat(pat, span)` | `Crate::pats` |
| `StmtId` | `yelang-hir::Crate` | `crate_hir.alloc_stmt(stmt, span)` | `Crate::stmts` |
| `TyId` | `yelang-hir::Crate` | `crate_hir.alloc_ty(ty, span)` | `Crate::tys` |

**Hard rule:** No `DefId::new(n)` outside of `yelang-arena` unit tests and intentionally frozen test data. No manual construction of `ExprId`/`PatId`/`StmtId`/`TyId`/`BodyId` outside of tests.

---

## 10. Visitor Model

The visitor trait operates on references (`&Expr`, `&Pat`, etc.) for ergonomic pattern matching. ID-based traversal is provided by an extension trait that looks up the node in the `Crate` arena and calls the reference-based hook.

```rust
// yelang-hir/src/visitor.rs
pub trait Visitor<'hir>: Sized {
    fn crate_hir(&self) -> Option<&'hir Crate> { None }

    fn visit_expr(&mut self, expr: &'hir Expr) { walk_expr(self, expr) }
    fn visit_pat(&mut self, pat: &'hir Pat) { walk_pat(self, pat) }
    // ...
}

pub trait VisitorExt<'hir>: Visitor<'hir> {
    fn visit_expr_by_id(&mut self, id: ExprId) {
        if let Some(crate_hir) = self.crate_hir() {
            if let Some(expr) = crate_hir.exprs.get(id) {
                self.visit_expr(expr);
            }
        }
    }
    // ...
}
```

This keeps the common case pattern-matchable while still allowing traversal from any ID.

---

## 11. Per-Crate Migration Plan

### 11.1 `yelang-arena`

1. Keep `index_vec.rs` with `Idx` trait and `IndexVec<K, V>`.
2. Keep `Id<T>` and `DefId`.
3. Add `arena.rs` with `Arena<K, V>`, `ArenaMap<K, V>`, `SparseArenaMap<K, V>` wrapping `slotmap`.
4. Re-export `slotmap::new_key_type` and `slotmap::Key` so callers can define domain keys.
5. Remove `LocalId`, `CrateId`, `TagHir`, `TagBody` (already done).

### 11.2 `yelang-resolve`

1. `DefCollector::definitions` is `IndexVec<DefId, Definition>`.
2. Remove `next_def_id` field and `next_def_id()` method.
3. Update `add_def` / `add_def_with_lang_item` to push into the arena.
4. Update `Prelude::new` and `seed_primitive_lang_items` to push into the arena.
5. Update `Resolver::definitions` and `ResolvedCrate::definitions` to `IndexVec<DefId, Definition>`.
6. Update iteration to use `iter_enumerated()` / `values()`.

### 11.3 `yelang-hir`

1. Define `ExprId`, `PatId`, `StmtId`, `TyId`, `BodyId` in `ids.rs` via `new_key_type!`.
2. Rename `ExprKind→Expr`, `PatKind→Pat`, `TyKind→Ty`, `StmtKind→Stmt`.
3. Replace all child `Box<Expr>` / `Expr` fields with `ExprId`; same for `Pat`, `Stmt`, `Ty`, `Body`.
4. Change `Crate` to use `Arena<…>` for exprs/pats/stmts/tys/bodies and `ArenaMap` for spans.
5. Add `alloc_*` helpers to `Crate`.
6. Update `LoweringContext`: remove `next_hir_id`/`next_body_id`/`next_def_id`; use `crate_hir.alloc_*`.
7. Update `local_map` to map `Symbol -> PatId`.
8. Update derive helpers to allocate through `Crate::alloc_*` and `next_synthetic_def_id`.
9. Update visitor to use `VisitorExt` for ID-based traversal.
10. Update tests to allocate from stub arenas.

### 11.4 `yelang-tycheck`, `yelang-ty`, `yelang-infer`, `yelang-trait-solver`

1. Update any code that reads `resolved.definitions` as a map.
2. Update test helpers that construct fake `DefId`s to allocate from a stub arena or use explicit `DefId::new(n)` only inside test modules.
3. Note: these crates have their own `Ty`/`TyKind` type system; only the HIR `TyKind` was renamed to `hir_ty::Ty`.

### 11.5 Tests

1. Update `yelang-hir/src/tests/common.rs`, `visitor.rs`, `desugaring.rs`, `lowering.rs` stub `ResolvedCrate` builders to allocate definitions from a stub `IndexVec`.
2. Update `yelang-tycheck/src/tests/mod.rs` `def_id(n)` helpers to be clearly test-only.
3. Add new tests for allocation invariants and slotmap behavior (see §13).

---

## 12. Exhaustive File Tree

```text
crates/compiler/
├── notes/architectures/
│   └── hir_storage_design.md            # this document
│
├── yelang-arena/src/
│   ├── lib.rs                           # re-exports
│   ├── id.rs                            # Id<T>, DefId, tags
│   ├── index_vec.rs                     # Idx trait + IndexVec
│   ├── arena.rs                         # Arena, ArenaMap, SparseArenaMap over slotmap
│   ├── map.rs                           # FxHashMap / OrderedMap wrappers
│   └── set.rs
│
├── yelang-resolve/src/
│   ├── def_collector.rs                 # definitions: IndexVec<DefId, Definition>
│   ├── scope.rs                         # definitions: IndexVec<DefId, Definition>
│   ├── module_tree.rs                   # unchanged (sparse map keyed by DefId)
│   ├── prelude.rs                       # pushes into definition arena
│   ├── lang_items.rs                    # pushes into definition arena
│   ├── lib.rs                           # ResolvedCrate.definitions: IndexVec
│   └── ...
│
└── yelang-hir/src/
    ├── ids.rs                           # ExprId, PatId, StmtId, TyId, BodyId slotmap keys
    ├── crate_hir.rs                     # Crate with arenas + secondary span maps
    ├── lowering.rs                      # LoweringContext, no next_* counters
    ├── lowering_item.rs                 # allocate items into IndexVec
    ├── lowering_body.rs                 # allocate bodies via Crate::alloc_body
    ├── lowering_expr.rs                 # allocate exprs via Crate::alloc_expr
    ├── lowering_pat.rs                  # allocate pats via Crate::alloc_pat
    ├── lowering_stmt.rs                 # allocate stmts via Crate::alloc_stmt
    ├── lowering_ty.rs                   # allocate tys via Crate::alloc_ty
    ├── hir.rs                           # core types: Block, Arm, Stmt, Item, Trait, Impl, ...
    ├── hir_expr.rs                      # Expr enum (formerly ExprKind)
    ├── hir_pat.rs                       # Pat enum (formerly PatKind)
    ├── hir_ty.rs                        # Ty enum (formerly TyKind)
    ├── hir_body.rs                      # Body, Param
    ├── hir_item.rs                      # Item, ItemKind
    ├── visitor.rs                       # Visitor + VisitorExt
    ├── map.rs                           # HIR map helpers
    ├── derive/                          # derive helpers using new allocation discipline
    ├── tests/common.rs                  # stub builders allocate from arenas
    └── ...
```

---

## 13. Exhaustive Test Matrix

### 13.1 `IndexVec` unit tests (`yelang-arena/src/index_vec.rs`)

| Test | Expected |
|---|---|
| `push_returns_monotonic_keys` | First key is `K::new(1)`, second `K::new(2)`, etc. |
| `get_returns_correct_value` | `vec[key] == inserted value`. |
| `get_out_of_bounds_returns_none` | `vec[K::new(100)]` returns `None`. |
| `iter_enumerated_pairs_keys_and_values` | Keys match insertion order. |
| `insert_sparse_grows_with_default` | `insert(K::new(5), v)` grows vec to length 5. |
| `index_trait_panics_on_invalid` | Debug-only panic for out-of-bounds. |

### 13.2 `Arena` / `ArenaMap` unit tests (`yelang-arena/src/arena.rs`)

| Test | Expected |
|---|---|
| `arena_basic` | Insert two values, get returns each correctly, len is 2. |
| `arena_map` | Secondary map keyed by arena keys returns correct values. |
| `arena_remove` | Remove a key, `contains_key` returns false, `get` returns None. |
| `arena_generational_safety` | Removed key does not access a later reinserted value at the same slot. |
| `arena_map_overwrite` | Inserting the same key twice returns the old value. |

### 13.3 HIR integration tests (`yelang-hir/src/tests/`)

| Test | Expected |
|---|---|
| `def_ids_are_dense` | `ResolvedCrate::definitions` has no gaps for resolved items. |
| `derived_impl_def_id_above_definitions` | Derived impl `DefId` > all resolved definition IDs. |
| `body_ids_are_generational` | `Crate::bodies` keys are slotmap keys with generation. |
| `expr_pat_stmt_ty_ids_are_separate_kinds` | Cannot mix `ExprId` and `PatId` at compile time. |
| `lookup_roundtrips` | Insert node via `alloc_*`, retrieve same node and span. |
| `span_secondary_map_consistent` | Every allocated node has a span; missing span panics in debug. |
| `visitor_walks_all_nodes` | Visitor visits every expr/pat/stmt/ty/body reachable from items. |
| `all_derives_still_pass` | Existing derive tests continue to pass after refactor. |

### 13.4 Adversarial tests

| Attack | Mitigation tested |
|---|---|
| Allocate many synthesized items | `next_synthetic_def_id` does not overflow `u32` and stays above definition arena. |
| Hold `DefId` after phase transition | Still resolves to same definition (IDs are append-only). |
| Manually construct `DefId::new(0)` | `NonZeroU32` panics in debug and release. |
| Use removed `ExprId` after arena clear | `get` returns None; no use-after-free. |
| Iterate over sparse items | `None` slots are skipped correctly. |
| Mix HIR node IDs across kinds | Compile-time type error. |

---

## 14. Risks & Mitigations

| Risk | Mitigation |
|---|---|
| Large cross-crate refactor breaks tests | Migrate crate-by-crate; run full workspace tests after each crate. |
| Stub tests still use raw `DefId::new(n)` | Update all stubs to allocate from stub arenas; add lint/clippy check. |
| Derived impl IDs collide with definition IDs | `next_synthetic_def_id` is computed from `definitions.len()`, not a separate counter. |
| Sparse `IndexVec<Option<T>>` wastes memory | Acceptable for now; can switch to `FxHashMap` later if profiling shows pressure. |
| Slotmap keys are 8 bytes | Slightly larger than 4-byte IDs, but generational safety and secondary maps outweigh the cost for HIR nodes. |
| Removed `HirId` breaks debug tooling | Replaced by per-kind IDs; tooling can use the `Crate` arena lookups. |

---

## 15. References

- `rustc` `IndexVec`: used throughout `rustc_index` and `rustc_hir` for dense typed-index storage.
- Rustc `HirId` design: composed of `owner + local_id` for stable incremental IDs ([HirId docs](https://doc.rust-lang.org/nightly/nightly-rustc/rustc_hir/hir/struct.HirId.html)). We intentionally diverge by using per-kind generational IDs.
- `slotmap` trade-offs: generational arenas vs. contiguous vectors ([Slint slotmap investigation](https://github.com/slint-ui/slint/issues/5292)).
