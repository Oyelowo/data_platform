# Phase 7 Chunk 4 — Macro Hygiene Completion Checklist

Status legend:
- `[ ]` not started
- `[/]` in progress / skeleton / partial
- `[x]` done

This checklist follows the design in
`notes/architectures/macro_phase7_chunk4_hygiene_design.md`.

---

## 1. Design and documentation

- [x] Research current hygiene implementation (`HygieneData`, `ExpnId`, `SyntaxContextId`, spans, wire protocol, resolver).
- [x] Write `notes/architectures/macro_phase7_chunk4_hygiene_design.md`.
- [x] Write `notes/architectures/macro_phase7_chunk4_hygiene_checklist.md`.
- [ ] Get explicit user approval on design, file tree, and implementation order.
- [ ] Update `macro_phase7_completion_checklist.md` to cross-reference this chunk.

---

## 2. Span context plumbing (lexer / macro-core bridge)

### 2.1 Extend `yelang_lexer::Span` to carry `SyntaxContextId`

- [ ] Add `syntax_context: u32` field to `yelang_lexer::Span` with default root context.
- [ ] Update `Span::new`, `Span::new_with_file_id`, and other constructors to accept/ default the context.
- [ ] Update `From<yelang_macro_core::Span> for yelang_lexer::Span` to copy the context.
- [ ] Update `From<yelang_lexer::Span> for yelang_macro_core::Span` to copy the context.
- [ ] Ensure existing non-macro code compiles with default root context.
- [ ] Add unit test: round-trip preserves syntax context.

### 2.2 Macro-core span conversions

- [ ] `yelang_macro_core::Span::from(yelang_lexer::Span)` preserves context.
- [ ] `yelang_lexer::Span::from(yelang_macro_core::Span)` preserves context.

---

## 3. Wire hygiene payload

### 3.1 New wire types in `yelang-proc-macro-bridge/src/protocol/token.rs`

- [ ] `WireHygienePayload` struct.
- [ ] `WireSyntaxContext` struct.
- [ ] `WireExpnData` struct.
- [ ] `WireTransparency` enum.
- [ ] `WireExpnKind` enum.
- [ ] `Serialize`/`Deserialize` derives on all new types.

### 3.2 Request/result protocol changes

- [ ] `Request::ExpandFnLike` carries `hygiene: WireHygienePayload`.
- [ ] `Request::ExpandAttr` carries `hygiene: WireHygienePayload`.
- [ ] `Request::ExpandDerive` carries `hygiene: WireHygienePayload`.
- [ ] `WireExpansionResult` carries `hygiene: WireHygienePayload`.
- [ ] Protocol round-trip tests for new request/result shapes.

---

## 4. Compiler-side hygiene extraction and remapping

### 4.1 Extract payload from active syntax context

- [ ] `yelang-macro/src/proc_macro/expand.rs` collects the chain of `SyntaxContextData` and `ExpnData` for the current expansion.
- [ ] Only contexts referenced by tokens in the input stream are included.
- [ ] `span_to_wire` sends the real `syntax_context` id.

### 4.2 Remap returned contexts

- [ ] On receiving a `WireExpansionResult`, merge returned contexts into the compiler's `HygieneData`.
- [ ] Remap wire ids to fresh compiler-side ids to avoid collisions.
- [ ] Build a mapping so every `WireSpan` in the returned stream resolves to the correct new context.

### 4.3 Pass def_site span to server

- [ ] `ResolvedProcMacro` carries the macro definition span.
- [ ] `expand_proc_macro` includes a `def_site` span in the request payload.

---

## 5. Server-side hygiene reconstruction

### 5.1 Thread-local hygiene data

- [ ] New `yelang-proc-macro-server/src/executor/hygiene.rs` module.
- [ ] Thread-local `HygieneData` for the dylib thread.
- [ ] `reconstruct_hygiene(WireHygienePayload) -> SyntaxContextId` inserts contexts and expansions.
- [ ] `clear_hygiene()` resets the thread-local data after expansion.

### 5.2 Invoke changes

- [ ] `invoke_fn_like`, `invoke_attr`, `invoke_derive` call `reconstruct_hygiene` before `set_call_site_from_wire`.
- [ ] They call `clear_hygiene` (and `clear_call_site`) in a `defer`/finally pattern.

### 5.3 Return hygiene from dylib

- [ ] `yelang-proc-macro/src/bridge/serialize.rs::result_into_wire` serializes any contexts created by the macro.
- [ ] `result_from_wire` reconstructs them on the compiler side.

---

## 6. Proc-macro `Span` API completion

### 6.1 Real `def_site` and `mixed_site`

- [ ] Add thread-locals `DEF_SITE` and `MIXED_SITE` in `yelang-proc-macro/src/api/span.rs`.
- [ ] `Span::def_site()` reads `DEF_SITE`.
- [ ] `Span::mixed_site()` reads `MIXED_SITE`.
- [ ] Server sets `DEF_SITE` and `MIXED_SITE` from request payload before invoking macro.
- [ ] Server clears them after invocation.

### 6.2 `Span::resolved_at`

- [ ] Verify it combines contexts using `HygieneData::apply_mark`.
- [ ] Add unit test for `resolved_at` behavior.

---

## 7. Declarative macro parent-chain fix

### 7.1 Track active context in `MacroExpander`

- [ ] Add `hygiene_stack: Vec<SyntaxContextId>` to `MacroExpander`.
- [ ] `current_syntax_context()` helper.
- [ ] `with_hygiene_context` helper.
- [ ] Push/pop context around every macro expansion.

### 7.2 Fix `transcribe_rule`

- [ ] Parent new `ExpnId` to the active outer expansion, not root.
- [ ] Apply mark to `current_syntax_context()`, not root.
- [ ] Use `Transparency::Mixed` for declarative macros.
- [ ] Use macro definition span as `def_site`.

### 7.3 Nested expansion

- [ ] `expand_item`, `expand_expr`, `expand_stmt`, `expand_type`, `expand_pattern` use `current_syntax_context()` as parent.
- [ ] Test: 3-level nested declarative macros isolate names.

---

## 8. Name resolution integration

### 8.1 Rib / Resolution changes

- [ ] `Resolution` variants carry `context: Option<SyntaxContextId>`.
- [ ] `Rib::insert` records the current syntax context.
- [ ] `Rib::get` supports context-aware lookup (or filtering done at resolver level).

### 8.2 Resolver changes

- [ ] `Resolver` tracks `current_syntax_context`.
- [ ] Push/pop context when entering/leaving macro-expanded subtrees.
- [ ] When resolving an identifier, read its `SyntaxContextId` from the span.
- [ ] Filter candidate resolutions: binding context must be an ancestor of identifier context (or root).

### 8.3 Identifier span preservation

- [ ] Macro-expanded identifiers in AST carry non-root syntax context.
- [ ] Resolver reads context from `yelang_lexer::Span`.

---

## 9. Tests

### 9.1 Declarative macro hygiene

- [ ] `decl_macro_introduced_local_not_visible_outside`
- [ ] `decl_macro_introduced_local_visible_inside`
- [ ] `decl_macro_nested_expansion_isolates_names`
- [ ] `decl_macro_item_with_def_site_resolves`
- [ ] `decl_macro_mixed_site_item_defines_at_def_site`
- [ ] `decl_macro_mixed_site_local_at_call_site`
- [ ] `decl_macro_captured_argument_keeps_call_site_context`

### 9.2 Procedural macro hygiene

- [ ] `proc_macro_call_site_span_is_invocation_site`
- [ ] `proc_macro_def_site_span_is_definition_site`
- [ ] `proc_macro_mixed_site_item_resolves_at_def_site`
- [ ] `proc_macro_mixed_site_local_resolves_at_call_site`
- [ ] `proc_macro_nested_macro_preserves_hygiene_chain`

### 9.3 Resolver integration

- [ ] `macro_introduced_binding_not_resolved_outside_invocation`
- [ ] `macro_introduced_item_visible_inside_invocation`
- [ ] `nested_macro_bindings_do_not_leak`

### 9.4 Negative / adversarial

- [ ] `macro_generates_name_collision_with_user_name_is_isolated`
- [ ] `two_macros_use_same_generated_name_no_collision`

---

## 10. Final verification

- [ ] `cargo fmt --all`.
- [ ] `cargo check --workspace` passes.
- [ ] `cargo clippy -p yelang-quote -p yelang-proc-macro -p yelang-proc-macro-bridge -p yelang-proc-macro-server -p yelang-macro -p yelang-macro-core --no-deps -- -D warnings` passes.
- [ ] `cargo test --workspace` passes.
- [ ] No new `TODO` / `FIXME` / `XXX` / `HACK` in touched files.
- [ ] Design doc and checklist updated if implementation diverged.
