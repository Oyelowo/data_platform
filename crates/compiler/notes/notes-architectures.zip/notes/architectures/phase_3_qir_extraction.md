# Phase 3: QIR Extraction from THIR

> Status: implementation in progress  
> Goal: lower typed THIR expressions into QIR logical plans (LIR) using the lang-item `Queryable`/`Aggregate` traits and `@intrinsic` hooks defined in the `.ye` stdlib. No hardcoded method registry; user-defined aggregates and pipeline extensions are first-class.

---

## 1. Architecture decisions

### 1.1 THIR is the canonical body IR for queries and ordinary code

`yelang-thir` sits between HIR and QIR. It is fully typed and desugared:

- Method calls are plain `Call` expressions with an explicit `self` argument.
- Query syntax becomes `ThirExpr::Query(QueryId)`; the query's clauses live in the existing HIR side table keyed by `QueryId`.
- Surface sugar (`for` loops, `?` try, etc.) is already lowered by HIR.

This supersedes the older statement in `thir_mir_qir_layering.md` that "queries bypass THIR entirely". That statement described an earlier, HIR-facade design. The final architecture uses THIR as the single typed body IR, and QIR as the first layer that thinks in operators.

```text
AST ──► HIR ──► THIR ──► QIR/LIR ──► QIR/PIR ──► Exec/MIR
                     │
                     ▼
            ThirExpr::Query(QueryId)
            query data in HIR side table
```

### 1.2 QIR operators hold closures as THIR body references (target)

The target design is that `Filter`, `Map`, `Aggregate`, `OrderBy`, etc. hold `ThirBodyId` references instead of `QExpr` closures. This means:

- The optimizer rewrites closures using the same typed IR it uses for ordinary code.
- MIR is the single codegen target for all expressions.
- Distributed plan fragments serialize THIR bodies (or their compiled form) rather than a parallel `QExpr` language.

**Phase 3A bootstrap:** the current implementation uses `QExpr` closures so that the in-memory executor can run plans immediately while the THIR→MIR bridge is being completed. Phase 3B migrates operator closures to `ThirBodyId`. This document describes the target; the implementation checklist tracks the migration.

### 1.3 No hardcoded `QueryableMethod` registry

The compiler does not contain an enum like `QueryableMethod::Filter`, `Map`, `Sum`, etc. Instead:

1. `Queryable` is a lang-item trait (`@lang("queryable")`) defined in `stdlib/core/src/query.ye`.
2. Each primitive pipeline method body calls `@intrinsic(query_*, ...)`.
3. The QIR extractor walks THIR, recognizes calls to `Queryable` methods, and inspects the `@intrinsic` call to decide the operator shape.
4. Sugar methods (`sum`, `avg`, `count`, `min`, `max`) have default bodies `self.aggregate(Marker {})`; the extractor expands them to `aggregate` and then resolves the `Aggregate` trait impl.

Adding a new primitive operator only requires adding a method to `Queryable` with an `@intrinsic(query_*, ...)` body. No compiler enum changes.

### 1.4 Aggregates are user-defined via the `Aggregate` trait

`Aggregate` is a lang-item trait (`@lang("aggregate")`) defined in `stdlib/core/src/aggregate.ye`:

```ye
@lang("aggregate")
trait Aggregate<In, Acc, Out> {
    fn init(&self) -> Acc;
    fn step(&self, acc: Acc, item: In) -> Acc;
    fn merge(&self, a: Acc, b: Acc) -> Acc;
    fn finish(&self, acc: Acc) -> Out;
    fn class(&self) -> AggregateClass;
}
```

Built-in aggregates (`Sum`, `Count`, `Avg`, `Min`, `Max`, `Product`) are ordinary `impl Aggregate<...>` blocks in `stdlib/core/src/aggregate_impls.ye`. A user-defined aggregate is just another `impl Aggregate<...>` block. The planner reads `class()` to choose distributed strategy:

| Class | Strategy |
|-------|----------|
| Distributive | partial per partition → exchange → final merge |
| Algebraic | same as Distributive (fixed-size accumulator) |
| Holistic | gather all data to one node → full aggregate |

### 1.5 `Iterator`/`IntoIterator` are separate from `Queryable`

- `Iterator<T>` is a regular trait for concrete, single-node, pull-based iteration.
- `IntoIterator<T>` lets slices/arrays produce iterators for `for` loops.
- `Queryable<T>` is the lazy, optimizable, backend-aware pipeline interface.

A type can implement both, but `Queryable` methods must take precedence over `Iterator` methods when the receiver is a known `Queryable` ADT. Method resolution must therefore check trait obligations and prefer candidates that are actually satisfiable.

---

## 2. IR layers

### 2.1 THIR (`yelang-thir/`)

Fully typed, desugared expression IR. Lives per body, produced on demand after type checking.

### 2.2 LIR (`yelang-qir/src/lir/`)

Backend-agnostic logical operators:

- `Scan`, `Values` — inputs.
- `Filter`, `Map`, `FlatMap` — row transformations.
- `OrderBy`, `Slice`, `Distinct` — ordering/slicing/set ops.
- `GroupBy`, `Aggregate` — grouping/aggregation.
- `Join`, `DependentJoin` — joins and correlated subqueries.
- `Construct`, `AttachField` — result shaping.
- `EdgeExpand` — graph traversal.
- `Window` — window functions.

### 2.3 PIR (`yelang-qir/src/pir/`)

Physical operators chosen by the planner:

- `TableScan`, `Values`.
- `Filter`, `Project`, `FlatMap`.
- `Sort`, `TopK`, `Slice`.
- `HashJoin`, `MergeJoin`, `NestedLoopJoin`.
- `HashAggregate`, `SortAggregate`, `StreamingAggregate` with `AggMode { Partial, Final, Full }`.
- `Exchange { Single, Broadcast, RepartitionBy, RangePartition, Gather }`.
- `Construct`, `AttachField`, `Window`, `Expr`.

### 2.4 Exec (`yelang-qir/src/exec/`)

Interpreter / runtime for in-memory execution and prototype storage backends.

---

## 3. THIR → LIR extraction

### 3.1 Entry point

```rust
// yelang-qir/src/logical/mod.rs
pub fn lower_thir_body(
    tcx: &TyCtxt,
    thir: ThirView<'_>,
    body_id: ThirBodyId,
    results: &TypeckResults,
) -> QirResult<LogicalPlan>;
```

The driver lowers the HIR function body to THIR first, then calls this function.

### 3.2 Extractor walk

```rust
pub fn extract_expr(
    plan: &mut LogicalPlan,
    ctx: &mut ExtractCtxt<'_>,
    expr: ThirExprId,
) -> Result<QExprId, LoweringError> {
    match ctx.thir.exprs.get(expr) {
        Some(ThirExpr::Call { func, args }) => {
            if let Some(method_info) = ctx.queryable_method(*func) {
                return lower_queryable_call(plan, ctx, method_info, args);
            }
            lower_scalar_call(plan, ctx, *func, args)
        }
        Some(ThirExpr::Intrinsic { name, args }) => {
            lower_intrinsic(plan, ctx, name, args)
        }
        Some(ThirExpr::Query(query_id)) => {
            lower_query_syntax(plan, ctx, *query_id)
        }
        _ => lower_scalar_expr(plan, ctx, expr),
    }
}
```

### 3.3 Lowering a `Queryable` method call

```rust
fn lower_queryable_call(
    plan: &mut LogicalPlan,
    ctx: &mut ExtractCtxt<'_>,
    info: &QueryableMethodInfo,
    args: &[ThirExprId],
) -> Result<QExprId, LoweringError> {
    let receiver = args[info.self_index];
    let input_expr = extract_expr(plan, ctx, receiver)?;
    let input_lir = expr_to_lir(plan, input_expr)?;

    match info.intrinsic {
        Some(QueryableIntrinsic::Map) => { ... }
        Some(QueryableIntrinsic::Filter) => { ... }
        Some(QueryableIntrinsic::Aggregate) => {
            let agg_arg = args[info.arg_index("agg")];
            lower_aggregate(plan, ctx, input_lir, agg_arg)
        }
        ...
        None => {
            // No recognized intrinsic: inline the method body and extract.
            let inlined = inline_method_body(ctx, info.def_id, args)?;
            extract_expr(plan, ctx, inlined)
        }
    }
}
```

### 3.4 Aggregate resolution

When the extractor sees `q.aggregate(Agg)` (or a sugar method that expands to it):

1. Resolve `Agg` to its config type `DefId`.
2. Find the selected `impl Aggregate<In, Acc, Out> for Agg` by scanning `tcx.trait_impls(aggregate_trait)`.
3. Extract `init`/`step`/`merge`/`finish` bodies.
4. Read the `class()` body to obtain `AggregateClass`.
5. Build an `AggregateOp`.

In Phase 3A the bodies are translated to `QExpr` closures so the executor can run them. In Phase 3B the bodies are kept as `ThirBodyId` and compiled through MIR.

---

## 4. Query syntax integration

`select <projection> from ... where ... group by ... order by ... range ...` lowers to:

```text
Scan(root) ──► Filter(where) ──► GroupBy(keys) ──► OrderBy(keys) ──► Slice(range) ──► Map(projection)
```

The projection determines the result shape; pipeline stages only determine what names/collections exist. `select 1 from users@u:User` returns `1`.

Correlated subqueries (`links`, nested `select`) lower to `DependentJoin` first; a Neumann top-down rewrite pass then unnests them.

---

## 5. Subquery decorrelation / unnesting

Following Neumann's work:

- [A Formalization of Top-Down Unnesting](https://arxiv.org/abs/2412.04294) (2024)
- [Improving Unnesting of Complex Queries](https://15799.courses.cs.cmu.edu/spring2025/papers/11-unnesting/neumann-btw2025.pdf) (2025)
- MRQL monoid algebra: [An Algebra for Distributed Big Data Analytics](https://lambda.uta.edu/mrql-algebra.pdf)

Correlated subqueries become `DependentJoin` operators in LIR. Logical rewrites then unnest them:

- **Scalar subquery** → single-row aggregation, then cross-join.
- **EXISTS / IN** → semi-join or anti-join.
- **LATERAL / linked selectors** → `DependentJoin`, then rewrite to regular join with predicate pull-up.

Key rewrite rules (Neumann):

```text
D ⋉ σ_p(T)          →  σ_p(D ⋉ T)
D ⋉ (T1 × T2)       →  (D ⋉ T1) ⋈_natural (D ⋉ T2)   if both sides depend on D
D ⋉ Γ_{A;agg}(T)    →  Γ_{A ∪ A(D); agg}(D ⋉ T)
D ⋉ δ(T)            →  δ(D ⋉ T)
```

Top-down processing avoids the cross-product blow-up of repeated bottom-up unnesting for stacked correlated subqueries.

---

## 6. Logical optimization pipeline

Order matters. Run passes to fixpoint where noted.

1. **Normalize** — sugar method inlining, flatten adjacent `Map`/`Filter`, push `Distinct` down.
2. **Decorrelate** — `DependentJoin` → `Join`/`SemiJoin`/`AntiJoin`/`AggregateGroupBy` (Neumann 2025).
3. **Predicate pushdown** — push filters through maps, joins, group-bys where safe.
4. **Projection pushdown** — remove unused fields early.
5. **Aggregate merging** — combine multiple aggregates over the same input into one `AggregateGroupBy`.
6. **Join reordering** — future cost-based; for now, heuristic small-side-first.
7. **Subplan materialization** — decide what must be materialized vs streamed.
8. **Physical planning** — choose hash vs sort, partial vs full aggregate, exchange placement.

---

## 7. Exhaustive file tree for Phase 3

```
crates/compiler/yelang-qir/src/
├── lib.rs                         # crate root, re-exports
├── ids.rs                         # LirId, PirId, QExprId, BinderId
├── expr.rs                        # QExpr (scalar expressions)
├── errors.rs                      # lowering/planning/exec errors
├── volatility.rs                  # volatility/boundedness
│
├── logical/                       # THIR → LIR extraction
│   ├── mod.rs                     # lower_thir_body entry point
│   ├── context.rs                 # ExtractCtxt, LangTraits, ThirView
│   ├── extract.rs                 # main THIR walk
│   ├── inline.rs                  # simple method-body inliner
│   ├── aggregate.rs               # Aggregate impl resolution
│   ├── aggregate_impl.rs          # extract closures from Aggregate impl
│   ├── intrinsic.rs               # recognized @intrinsic(query_*) names
│   ├── convert.rs                 # ThirExprId → QExprId, expr_to_lir
│   ├── query_syntax.rs            # lower ThirExpr::Query to LIR
│   └── lower_thir_expr.rs         # THIR → QExpr translator (bootstrap)
│
├── lir/                           # Logical IR
│   ├── mod.rs
│   ├── operator.rs
│   ├── plan.rs
│   ├── props.rs
│   └── lower/                     # legacy HIR-based lowering (to be removed)
│       ├── mod.rs
│       ├── query.rs
│       ├── queryable.rs           # MARK FOR DELETION
│       ├── aggregate_impl.rs      # MARK FOR DELETION
│       └── ...
│
├── pir/                           # Physical IR
│   └── ...
│
├── exec/                          # Execution
│   └── ...
│
└── rewrite/                       # Logical rewrites
    ├── mod.rs
    ├── pass.rs
    ├── normalize.rs
    ├── simplify.rs
    ├── push_filter.rs
    ├── push_project.rs
    ├── predicate_pushdown.rs
    ├── projection_pushdown.rs
    ├── decorrelate.rs              # Neumann top-down
    ├── unnest_subqueries.rs
    └── merge_maps.rs

yelang-driver/tests/
├── stdlib_parse_tests.rs          # existing
├── stdlib_queryable_tests.rs      # existing
├── qir_extract_tests.rs           # method-call pipelines → LIR
├── qir_aggregate_tests.rs         # built-in aggregates → LIR
└── qir_user_aggregate_tests.rs    # custom Aggregate impl → LIR

stdlib/core/src/
├── lib.ye
├── iter.ye                        # Iterator/IntoIterator
├── query.ye                       # Queryable trait + QueryArray
└── aggregate.ye                   # Aggregate trait + built-in impls

notes/architectures/
├── phase_3_qir_extraction.md      # this doc
└── phase_4_logical_rewrites.md    # next phase
```

---

## 8. Implementation checklist

### 8.1 Extractor scaffolding

- [x] Create `yelang-qir/src/logical/` module.
- [x] Define `ExtractCtxt`, `LangTraits`, `ThirView`.
- [x] Add `lower_thir_body` entry point.

### 8.2 Intrinsic framework

- [x] Define `QueryableIntrinsic` enum.
- [x] Implement discovery of `Queryable` methods and their `@intrinsic` bodies.
- [x] Recognize sugar method default bodies.

### 8.3 Core pipeline operators

- [ ] `map` extraction.
- [ ] `filter` extraction.
- [ ] `flat_map` extraction (with binder handling).
- [ ] `order_by` extraction.
- [ ] `group_by` extraction.
- [ ] `distinct` extraction.
- [ ] `take` / `skip` extraction.

### 8.4 Aggregates

- [x] Implement aggregate config resolution.
- [x] Implement `Aggregate` impl selection.
- [ ] Extract `init`/`step`/`merge`/`finish` via THIR lowering (Phase 3A uses QExpr closures).
- [x] Read `class()` body to obtain `AggregateClass`.
- [x] Handle sugar methods (`sum`, `count`, `avg`, `min`, `max`).

### 8.5 Method resolution

- [ ] Prefer `Queryable` over `Iterator` when both method names match and the receiver is a `Queryable` ADT.
- [ ] Check trait obligations during candidate selection.

### 8.6 Execution / materialization

- [ ] `execute` extraction.
- [ ] `fold` / `reduce` extraction.

### 8.7 Query syntax

- [ ] Add `lower_query_syntax` for `ThirExpr::Query`.
- [ ] Reproduce existing query tests through the new extractor.
- [ ] Delete legacy HIR query lowering once parity is reached.

### 8.8 Cleanup

- [ ] Delete `lir/lower/queryable.rs` (legacy registry).
- [ ] Delete `lir/lower/aggregate_impl.rs` (legacy built-in table).
- [ ] Remove transitional `impl Queryable<T> for Array<T>` once `QueryArray<T>` is the only wrapper.

### 8.9 Tests

- [x] `qir_aggregate_tests.rs`: `Sum`, `Avg`, `Count`, `Min`, `Max` produce correct `AggregateClass`.
- [ ] `qir_extract_tests.rs`: `QueryArray<i32>.filter(...).map(...).sum()` builds correct LIR.
- [ ] `qir_user_aggregate_tests.rs`: custom `Aggregate` impl is extracted.
- [ ] Existing end-to-end query tests still pass.
- [ ] `cargo test --workspace --no-fail-fast` passes.

---

## 9. Definition of done

Phase 3 is complete when:

1. A typed THIR body containing `QueryArray` method calls can be lowered to a `LogicalPlan`.
2. The lowering uses lang-item trait introspection and `@intrinsic` bodies, not a hardcoded method registry.
3. Built-in aggregates (`Sum`, `Count`, `Avg`, `Min`, `Max`) are resolved from their `Aggregate` impls in `.ye`.
4. Sugar methods (`sum`, `count`, etc.) work by inlining their default bodies to `aggregate(...)`.
5. Method resolution prefers `Queryable` methods over `Iterator` methods for `Queryable` receivers.
6. New tests verify method-call pipeline extraction and aggregate resolution.
7. `cargo test --workspace` passes.

Only then do we proceed to Phase 4 (logical rewrites and subquery decorrelation).

---

## 10. References

- Neumann 2025, "Improving Unnesting of Complex Queries": <https://15799.courses.cs.cmu.edu/spring2025/papers/11-unnesting/neumann-btw2025.pdf>
- Neumann 2024, "A Formalization of Top-Down Unnesting": <https://arxiv.org/abs/2412.04294>
- Fegaras, "An Algebra for Distributed Big Data Analytics" (MRQL): <https://lambda.uta.edu/mrql-algebra.pdf>
- DryadLINQ accumulator pattern and distributed aggregation.
- Apache Calcite extensible optimizer (`RelNode` design).
