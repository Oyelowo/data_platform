# Yelang Macro System — Phase 7 Design
## Procedural Macro Framework

---

## 1. Scope and Goal

Phase 6 completed the declarative macro story (function-like, attribute, and
derive rules, fragment fields, unsafe rules, and field-position expansion).
Phase 7 makes the macro story **complete and production-ready** by adding
**procedural macros**: user-defined compiler plugins written in Yelang that
operate on token streams.

**Goal**: A robust, forward-compatible, secure procedural macro framework that
matches the power of Rust proc macros while avoiding the legacy mistakes that
make the Rust ecosystem depend on `proc-macro2` + `syn` + `quote` shims,
separate macro crates, and JSON-based IDE servers.

**Non-goals for Phase 7**:
- Full `syn`-level AST parsing library (a lightweight parsing helper is provided;
  a full parser can be built later on top of the token API).
- Cross-crate macro import/export metadata format (Phase 8).
- `cfg`/`cfg_attr` integration (Phase 8).

---

## 2. Lessons from Rust (and what we do differently)

| Rust pain point | Root cause | Yelang choice |
|---|---|---|
| `proc-macro2` exists to abstract nightly `proc_macro` | `proc_macro` was tied to rustc internals | We design `yelang_proc_macro` as the one stable API from day one. |
| `syn` + `quote` required for almost every macro | Token API is too low-level | `quote!` is built into `yelang_proc_macro`; a typed token cursor/parsing helper ships in the same crate. |
| Proc macros run in-process and can crash rustc | Dynamic linking into the compiler | Proc macros run in a separate `yelang-proc-macro-server` process. |
| rust-analyzer uses a hand-rolled JSON RPC | Grew organically | We use a versioned binary protocol (postcard) from the start. |
| Helper attributes for derives have no namespacing | Historical accident | Derive helper attributes are resolved through normal name resolution and carry syntax-context hygiene. |
| No built-in compile-time reflection | Proc macros only see tokens | We keep the door open for `comptime`/reflection (Phase 8) but do not block Phase 7 on it. |

Key references:
- [RFC 1566 — Procedural Macros](https://rust-lang.github.io/rfcs/1566-proc-macros.html)
- [RFC 3697 — Declarative Attribute Macros](https://rust-lang.github.io/rfcs/3697-declarative-attribute-macros.html)
- [RFC 3698 — Declarative Derive Macros](https://rust-lang.github.io/rfcs/3698-declarative-derive-macros.html)
- [rust-analyzer proc-macro server redesign](https://github.com/rust-lang/rust-analyzer/issues/19205)
- [Kangrejos 2025 — Declarative Macro Improvements](https://kangrejos.com/2025/Rust%20Declarative%20Macro%20Improvements:%20A%20Step%20Forward%20for%20Rust%20Macros%20Usability.pdf)

---

## 3. Architectural Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│ Compiler (yelang-driver / yelang-macro)                                      │
│  - discovers proc macros from crate metadata                                 │
│  - sends expansion requests to the server                                    │
│  - integrates returned TokenStream back into the AST                         │
└──────────────────────────────┬──────────────────────────────────────────────┘
│                              │ binary IPC (postcard over stdin/stdout)
│                    ┌─────────▼──────────┐
│                    │ yelang-proc-macro- │
│                    │ server             │
│                    │  - loads .so/.dll  │
│                    │  - executes macro  │
│                    │  - enforces limits │
│                    └─────────┬──────────┘
│                              │ stable C ABI
│                    ┌─────────▼──────────┐
│                    │ proc-macro crate   │
│                    │ (compiled dylib)   │
│                    │  uses              │
│                    │  yelang_proc_macro │
│                    └────────────────────┘
└──────────────────────────────┴──────────────────────────────────────────────┘
```

**Design principles**:
1. **Crash isolation**: the server is a separate OS process; a panic in a proc
   macro kills only the server, and the compiler reports a clean error.
2. **Stable API**: `yelang_proc_macro` is the only API a macro author needs.
   There is no "proc-macro2" shim.
3. **Token-based bridge**: macros consume and produce `TokenStream`s, so the
   language grammar can evolve without breaking macros.
4. **Hygiene by default**: every identifier carries a `Span` with a syntax
   context; macros cannot accidentally shadow user names.
5. **Diagnostics**: macros emit structured diagnostics with spans, not raw
   strings.
6. **No `util` modules**: every module has a concrete name (`server`, `bridge`,
   `protocol`, etc.).
7. **lib.rs/mod.rs are routers**: implementation lives in named submodules.

---

## 4. Crate Graph

```
yelang-arena
   ↑
yelang-interner
   ↑
yelang-lexer
   ↑
yelang-macro-core          ← shared TokenTree, Span, HygieneData, IDs
   ↑
yelang-macro               ← declarative macro expansion (Phase 6)
   ↑
yelang-proc-macro          ← public API for macro authors
   ↑
yelang-proc-macro-bridge   ← stable ABI/protocol types
   ↑
yelang-proc-macro-server   ← executable server
```

`yelang-macro` depends on both `yelang-proc-macro` (for the public API types
used during integration) and `yelang-proc-macro-bridge` (for the protocol used
to talk to the server).

---

## 5. Exhaustive File Tree

```
yelang-proc-macro/
├── Cargo.toml
└── src/
    ├── lib.rs                 # re-exports only
    ├── api/
    │   ├── mod.rs             # re-exports
    │   ├── token_stream.rs    # TokenStream, IntoIterator, Display
    │   ├── token_tree.rs      # TokenTree, Group, Ident, Punct, Literal
    │   ├── delimiter.rs       # Delimiter enum
    │   ├── span.rs            # Span, SourceFile, LineColumn
    │   ├── literal.rs         # Literal constructors (string, int, float, ...)
    │   ├── punct.rs           # Punct, Spacing
    │   ├── ident.rs           # Ident constructors
    │   └── diagnostic.rs      # Diagnostic, Level, DiagnosticSpan
    ├── quote/
    │   ├── mod.rs             # re-export quote! macro
    │   ├── macro.rs           # quote! procedural macro implementation
    │   └── to_tokens.rs       # ToTokens trait + impls for primitives
    ├── parse/
    │   ├── mod.rs             # re-exports
    │   ├── cursor.rs          # low-level Peekable token cursor
    │   ├── parser.rs          # Parse trait, Parser combinator helpers
    │   ├── error.rs           # ParseError with span
    │   └── buffered.rs        # lookahead / fork support
    └── introspect/
        ├── mod.rs             # re-exports
        └── token_walker.rs    # high-level visitor over TokenStream

yelang-proc-macro-bridge/
├── Cargo.toml
└── src/
    ├── lib.rs                 # re-exports only
    ├── protocol/
    │   ├── mod.rs             # re-exports
    │   ├── message.rs         # Request / Response enums
    │   ├── version.rs         # protocol version negotiation
    │   ├── token.rs           # wire representation of TokenStream/Span
    │   └── serialize.rs       # postcard encode/decode helpers
    ├── abi/
    │   ├── mod.rs             # re-exports
    │   ├── symbols.rs         # exported symbol names (yelang_proc_macro_entry)
    │   ├── signature.rs       # ProcMacroKind, function signatures
    │   └── registrar.rs       # macro registration table
    └── sandbox/
        ├── mod.rs             # re-exports
        ├── limits.rs          # memory / time limits
        └── error.rs           # SandboxError

yelang-proc-macro-server/
├── Cargo.toml
└── src/
    ├── main.rs                # CLI entry point
    ├── server/
    │   ├── mod.rs             # re-exports
    │   ├── server.rs          # Server struct, request loop
    │   ├── session.rs         # per-client session state (slotmap)
    │   ├── library.rs         # dylib loading / unloading
    │   └── limits.rs          # process-level resource enforcement
    ├── executor/
    │   ├── mod.rs             # re-exports
    │   ├── invoke.rs          # call a macro function across the C ABI
    │   ├── panic.rs           # catch panics, convert to diagnostic
    │   └── context.rs         # thread-local MacroContext
    └── protocol/
        ├── mod.rs             # re-exports
        └── io.rs              # framed read/write over stdin/stdout

yelang-macro/                 (modifications)
├── src/
│   ├── proc_macro/
│   │   ├── mod.rs             # re-exports within yelang-macro
│   │   ├── client.rs          # ProcMacroClient, talk to server
│   │   ├── discovery.rs       # find proc macros in crate graph
│   │   ├── resolver.rs        # resolve macro paths to server handles
│   │   └── expand.rs          # expand function-like / attr / derive
│   └── lib.rs                 # add proc-macro re-exports
```

---

## 6. Public API (`yelang_proc_macro`)

### 6.1 Types

```rust
// yelang-proc-macro/src/api/token_stream.rs
pub struct TokenStream { ... }

impl TokenStream {
    pub fn new() -> Self;
    pub fn is_empty(&self) -> bool;
    pub fn iter(&self) -> Iter<'_, TokenTree>;
}

impl From<TokenTree> for TokenStream { ... }
impl FromIterator<TokenTree> for TokenStream { ... }
```

```rust
// yelang-proc-macro/src/api/token_tree.rs
pub enum TokenTree {
    Group(Group),
    Ident(Ident),
    Punct(Punct),
    Literal(Literal),
}

pub struct Group { ... }
pub struct Ident { ... }
pub struct Punct { ... }
pub struct Literal { ... }
```

```rust
// yelang-proc-macro/src/api/delimiter.rs
pub enum Delimiter {
    Parenthesis,
    Brace,
    Bracket,
    None,            // invisible group, used by macro expansion
}
```

```rust
// yelang-proc-macro/src/api/span.rs
pub struct Span { ... }

impl Span {
    pub fn call_site() -> Self;      // hygiene context of the macro call
    pub fn mixed_site() -> Self;     // mixed hygiene (like macro_rules! $crate)
    pub fn def_site() -> Self;       // hygiene context of the macro definition
    pub fn source_file(&self) -> SourceFile;
    pub fn start(&self) -> LineColumn;
    pub fn end(&self) -> LineColumn;
    pub fn resolved_at(self, other: Span) -> Self;
}
```

### 6.2 Macro Entry Points

A proc-macro crate defines exported functions with stable symbol names:

```rust
// function-like
#[yelang_proc_macro::macro_export]
pub fn my_macro(input: TokenStream) -> TokenStream { ... }

// attribute
#[yelang_proc_macro::macro_export]
pub fn my_attr(args: TokenStream, item: TokenStream) -> TokenStream { ... }

// derive
#[yelang_proc_macro::macro_export]
pub fn my_derive(input: TokenStream) -> TokenStream { ... }
```

The attribute `#[yelang_proc_macro::macro_export]` both:
1. Registers the macro in the dylib's registration table.
2. Derives the correct mangled symbol name for the compiler to call.

### 6.3 Quote

```rust
use yelang_proc_macro::{quote, Ident, TokenStream};

let name: Ident = ...;
let expanded: TokenStream = quote! {
    impl Clone for #name {
        fn clone(&self) -> Self { *self }
    }
};
```

`quote!` is implemented as a built-in proc macro that operates on the
`TokenStream` type defined in the same crate. There is no circularity problem
because the compiler hosts the macro expansion itself for the standard library.

### 6.4 Lightweight Parsing

```rust
use yelang_proc_macro::parse::{Parser, Parse};

struct Field { name: Ident, colon: Token![:], ty: TokenStream }
impl Parse for Field { ... }
```

This is intentionally much smaller than `syn`. It provides:
- `Cursor` for low-level peek/consume.
- `Parser` trait for combinators.
- `Parse` trait for user types.
- Lookahead / fork support.

Full AST parsing is out of scope; it can be built as a separate library on top
of this API.

### 6.5 Diagnostics

```rust
use yelang_proc_macro::Diagnostic;

Diagnostic::error()
    .with_message("expected a struct")
    .with_span(input.span())
    .emit();
```

Diagnostics are returned to the compiler through the bridge, not printed by the
macro.

---

## 7. Bridge ABI (`yelang_proc_macro_bridge`)

### 7.1 Stable C ABI

The server loads a dylib and looks up:

```c
YelangProcMacroExports* yelang_proc_macro_entry(uint32_t abi_version);
```

The returned structure contains:
- protocol version
- number of exported macros
- for each macro: name, kind, function pointer

Function pointer signatures:

```c
typedef YelangTokenStream* (*YelangFnLikeMacro)(YelangTokenStream* input);
typedef YelangTokenStream* (*YelangAttrMacro)(YelangTokenStream* args, YelangTokenStream* item);
typedef YelangTokenStream* (*YelangDeriveMacro)(YelangTokenStream* item);
```

`YelangTokenStream` is an opaque handle; the dylib calls back into the server
via a vtable to manipulate it. This avoids exposing the internal layout across
the ABI boundary and makes cross-language macro authors possible in the future.

### 7.2 Wire Protocol

The compiler spawns `yelang-proc-macro-server` and communicates over framed
messages on stdin/stdout.

```rust
// yelang-proc-macro-bridge/src/protocol/message.rs
pub enum Request {
    Handshake { protocol_version: u32, capabilities: Capabilities },
    LoadLibrary { path: String },
    ExpandFnLike { library: LibraryHandle, macro_index: u32, input: WireTokenStream },
    ExpandAttr { library: LibraryHandle, macro_index: u32, args: WireTokenStream, item: WireTokenStream },
    ExpandDerive { library: LibraryHandle, macro_index: u32, item: WireTokenStream },
    UnloadLibrary { library: LibraryHandle },
    Shutdown,
}

pub enum Response {
    HandshakeAck { protocol_version: u32 },
    LibraryLoaded { library: LibraryHandle, macros: Vec<MacroDescriptor> },
    Expanded { output: WireTokenStream },
    Diagnostic { diagnostic: WireDiagnostic },
    Panic { message: String },
    Error { code: ErrorCode, message: String },
}
```

Serialization: **postcard** (compact, no-std friendly, faster than JSON).
Framing: 8-byte little-endian length prefix.

### 7.3 Versioning

- Major protocol version bumps break compatibility.
- The server and compiler negotiate the highest shared version.
- Proc-macro crates declare the `yelang_proc_macro` API version they were
  compiled against; the server rejects mismatches.

---

## 8. Server (`yelang_proc_macro_server`)

### 8.1 Responsibilities

1. Accept one compiler connection on stdin/stdout.
2. Load/unload proc-macro dynamic libraries.
3. Dispatch expansion requests to the correct function.
4. Catch panics and convert them to `Response::Panic`.
5. Enforce memory and CPU limits per expansion.
6. Maintain a thread-local `MacroContext` for span/diagnostic callbacks.

### 8.2 Session State (SlotMap)

```rust
// yelang-proc-macro-server/src/server/session.rs
use slotmap::{SlotMap, DefaultKey};

slotmap::new_key_type! { pub struct LibraryHandle; }

pub struct Session {
    libraries: SlotMap<LibraryHandle, LoadedLibrary>,
    ...
}
```

Using `slotmap` satisfies the user's requirement for robust ID management and
makes unload-after-expansion safe.

### 8.3 Resource Limits

Per-expansion:
- Max heap size (configurable, default 512 MiB).
- Max CPU time (configurable, default 30 s).
- Max output token count (configurable, default 1M tokens).

Server-level:
- Max concurrent libraries loaded.
- Max total memory.

Violations produce `Response::Error` with a clear code (`ExpansionTooLarge`,
`ExpansionTimeout`, etc.).

---

## 9. Compiler Integration (`yelang_macro`)

### 9.1 Discovery

During crate graph construction, any crate with `crate-type = ["proc-macro"]`
is flagged. The compiler loads its metadata, finds exported macro symbols, and
records `(crate, name, kind, library_path, macro_index)`.

### 9.2 Resolution

Macro names are resolved in `MacroNS`. A name can resolve to:
- a declarative macro (`MacroDefId`), or
- a procedural macro (`ProcMacroId` → `(LibraryHandle, macro_index)`).

### 9.3 Expansion

When the expander encounters a proc-macro invocation, it currently follows the
in-process path (used for testing and bootstrapping):

1. Convert the invocation args/item from `yelang_macro_core::TokenStream` to
   `yelang_proc_macro::TokenStream` using the expander's interner
   (`TokenStream::from_core_stream`).
2. Invoke the registered `InProcessProcMacro` trait object.
3. Render the returned `yelang_proc_macro::TokenStream` to source text with
   `render_source`, which preserves punctuation spacing.
4. Re-tokenize the rendered source with the expander's interner and parse the
   resulting items/expressions/statements.
5. Continue expansion iteratively.

The out-of-process server path (serialize to `WireTokenStream`, send `Request`,
await `Response::Expanded`, convert back) is wired at the protocol and client
level but is not yet fully operational because the server does not yet load and
execute real dylibs.

### 9.3.1 In-Process Executor

`yelang_macro::InProcessExecutor` registers trait objects implementing
`InProcessProcMacro`. This lets the compiler exercise proc macros without a
separate server process or dylib build. It is used for:

- Unit and integration tests of the proc-macro expansion pipeline.
- Bootstrapping the standard library's proc macros before the server is ready.
- Fast iteration while the dylib loading path is still being hardened.

### 9.4 Hygiene Bridge

Spans from the compiler are sent to the server as `(file_id, lo, hi,
syntax_context)`. The server stores them opaquely and returns them unchanged
unless the macro constructs a new identifier, in which case it uses the
hygiene API (`Span::call_site()`, `Span::def_site()`, `Span::mixed_site()`).

---

## 10. Syntax Examples

### 10.1 Function-like proc macro

```rust
// crate my_macro, crate-type = ["proc-macro"]
use yelang_proc_macro::{TokenStream, quote};

#[yelang_proc_macro::macro_export]
pub fn make_answer(_input: TokenStream) -> TokenStream {
    quote! { 42 }
}
```

```rust
// user crate
use my_macro::make_answer;

const ANSWER: i32 = make_answer!();
```

### 10.2 Attribute proc macro

```rust
#[yelang_proc_macro::macro_export]
pub fn trace(args: TokenStream, item: TokenStream) -> TokenStream {
    // parse args for optional label
    quote! {
        #[doc = "instrumented"]
        #item
    }
}
```

```rust
use my_macro::trace;

#[trace]
fn foo() {}
```

### 10.3 Derive proc macro

```rust
#[yelang_proc_macro::macro_export]
pub fn answer(input: TokenStream) -> TokenStream {
    // lightweight parse to extract the name
    quote! {
        impl Answer for SelfTypeHere {  // simplified for the example
            fn answer(&self) -> u32 { 42 }
        }
    }
}
```

```rust
use my_macro::Answer;

#[derive(Answer)]
struct Foo;
```

### 10.4 Built-in `quote!`

```rust
let name = Ident::new("Foo", Span::call_site());
quote! { struct #name; }
```

---

## 11. Error Handling

| Failure | Behavior |
|---|---|
| Server fails to start | Compiler error: "could not start procedural macro server" |
| Dylib fails to load | Error points to the dependency with the load failure reason |
| Macro panics | Caught by server, returned as `Response::Panic`, compiler reports "proc macro panicked" with the message |
| Macro returns invalid tokens | Parser error pointing at the returned span |
| Macro emits diagnostics | Rendered with original spans |
| Timeout / OOM | Error with code and hint to increase limit |
| Protocol version mismatch | Clear error, no silent fallback |

---

## 12. Testing Strategy

Tests must be exhaustive and cover every public behavior.

### 12.1 Unit tests

- `yelang-proc-macro`: TokenStream construction, iteration, quote! expansion
  (with a mock expander), Diagnostic formatting.
- `yelang-proc-macro-bridge`: postcard round-trip for every `Request` and
  `Response` variant, version negotiation edge cases.
- `yelang-proc-macro-server`: session slotmap reuse after unload, panic
  conversion, limit enforcement.

### 12.2 Integration tests

- In-process mock server that loads a tiny dylib (or uses a test-only
  `#[yelang_proc_macro::macro_export]` function compiled into the test binary).
- End-to-end expansion of fn-like / attr / derive macros.
- Hygiene: a proc macro introduces a local variable; user code with the same
  name must not collide.
- Diagnostics: a proc macro emits an error; assert the span and message.
- Panic recovery: a proc macro panics; assert the compiler reports a clean
  error instead of crashing.

### 12.3 Negative tests

- Missing `macro_export`.
- Wrong signature for a proc macro.
- Returning tokens that do not parse in context.
- Recursive proc macro expansion (should hit expansion depth limit).
- Protocol corruption / server death.

---

## 13. Current State and Known Gaps

As of the latest implementation:

- [x] In-process procedural macros work end-to-end for function-like,
  attribute, and derive forms.
- [x] `yelang_proc_macro` API is stable and tested: tokens, spans, literals
  (including raw strings), diagnostics, and `quote!` bootstrap.
- [x] `yelang_proc_macro_bridge` protocol and `yelang_proc_macro_server`
  skeleton are in place with slotmap-based session management.
- [ ] Real dylib loading and execution in the server is not yet implemented;
  `LoadLibrary` returns `LibraryNotFound`.
- [ ] `Span::def_site()` and `Span::mixed_site()` currently resolve to
  `call_site()`; full hygiene context serialization/deserialization needs
  compiler/server cooperation.
- [ ] The lightweight `parse` helper module (`Cursor`, `Parser`, `Parse`) is
  present as a skeleton but not complete.
- [ ] `#[yelang_proc_macro::macro_export]` is not yet implemented; macros are
  currently registered manually via `InProcessExecutor` for tests.
- [ ] Cross-crate discovery of proc macros from workspace metadata is not yet
  wired into the driver.

These gaps are tracked in `macro_system_phase7_checklist.md`.

---

## 14. Migration / Future Work

Phase 8 will add:
- Cross-crate proc-macro metadata in compiled crate rlibs.
- `cfg` and `cfg_attr` integration with proc macros.
- Source-location macros (`file!`, `line!`, `column!`).
- Macro lints and deprecation.
- Comptime/introspection hooks (if chosen).

This Phase 7 design leaves clean extension points for all of these.

---

## 14. Design Checklist (pre-implementation)

- [x] Public API crate defined (`yelang-proc-macro`).
- [x] Bridge ABI crate defined (`yelang-proc-macro-bridge`).
- [x] Server executable defined (`yelang-proc-macro-server`).
- [x] Compiler integration points defined (`yelang-macro/proc_macro/`).
- [x] Protocol: postcard, framed, versioned.
- [x] Crash isolation: out-of-process server.
- [x] Hygiene model: spans with syntax contexts.
- [x] Diagnostic model: structured, span-aware.
- [x] Resource limits: memory, time, output size.
- [x] Quote! macro: built into the public API.
- [x] Lightweight parsing helper in public API.
- [x] SlotMap used for server session IDs.
- [x] No `util` modules; `lib.rs`/`mod.rs` are routers.
