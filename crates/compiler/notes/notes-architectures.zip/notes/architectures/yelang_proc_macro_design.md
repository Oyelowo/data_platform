# Yelang Procedural Macros — Production-Ready Design Document

> **⚠️ Direction change (2026-07-17):** After further review, the project has moved away from user-defined procedural and declarative macros. The macro implementation was archived to `archive/proc-macro-full` and removed from `main`. Built-in derives/attributes (e.g., `Copy`, `Clone`, `Debug`, `Eq`, `test`) are implemented as compiler intrinsics. User-extensible compile-time code generation will be provided by `comptime` once the backend is ready. This document is kept as a historical record and as a reference for the archived branch; the active design direction is documented in `adr_no_user_defined_macros.md`.

**Status:** Superseded. Phases A and B were implemented and then archived.  
**Scope:** Yelang-authored procedural macros (function-like, attribute, derive), the Yelang `proc_macro`/`quote` API, the compilation path from Yelang source to a loadable macro artifact, and the runtime integration with the compiler.

---

## 1. Executive Summary

This document describes the remaining work needed to make Yelang procedural macros **100% Yelang-native, production-ready, and free of Rust-legacy baggage**. It is based on an audit of the current workspace and on modern macro-system research (Rust `macro_attr`/`macro_derive` RFCs, the WASM proc-macro sandboxing initiative, and comptime-vs-macro discussions).

### What already exists
- **Declarative macros** in `yelang-macro` are implemented and tested (native `macro name { ... }` syntax; `macro_rules!` has been removed).
- **Proc-macro runtime/bridge/server** is implemented and tested. It can discover and invoke native dynamic libraries that expose the Yelang ABI (`yelang_proc_macro_entry`, `yelang_macro_*`, `yelang_alloc`/`free`).
- **Rust-facing proc-macro API** in `yelang-proc-macro` and `yelang-quote` lets authors write macros in Rust today.

### What is missing (the gap this design closes)
- A **Yelang standard-library `proc_macro` module** so that macro authors can write macros in Yelang itself.
- A **Yelang-native `quote!`** macro operating on Yelang tokens, replacing the current Rust `proc-macro2`-based `yelang-quote`.
- A **Yelang-to-loadable-artifact compilation path** (recommended: WASM sandbox; alternative: native dylib).
- **Build-system support** for marking a crate as a `proc-macro` crate and for invoking the Yelang compiler on it.
- Updates to the proc-macro **export expansion**, **bridge**, and **server** so they can consume Yelang-generated artifacts instead of Rust-generated ones.

### Recommendation at a glance
1. Macro authors write proc macros in **Yelang** using a standard-library module `proc_macro` and a built-in `quote!` macro.
2. Proc-macro crates compile to **WebAssembly (WASI preview1/2)** modules and execute inside the compiler via `wasmtime`.
3. This gives us **sandboxing, determinism, cross-compilation, and fast loading** — addressing the main long-term weakness of Rust's native-dylib proc macros.
4. If WASM is rejected, a fallback path compiles Yelang to native dylibs via Cranelift/LLVM, but that requires building a full native backend first.

---

## 2. Current-State Audit

### 2.1 Crates that exist

| Crate | Current role | State |
|-------|--------------|-------|
| `yelang-lexer` | Tokenizer and spans | Production-ready for current scope |
| `yelang-ast` | AST, parser, AST-to-source codegen | Production-ready; `MacroDef` accepts only native `macro` syntax |
| `yelang-macro-core` | Canonical token tree (`TokenStream`, `TokenTree`, spans, hygiene IDs) | Production-ready; single source of truth for token trees |
| `yelang-macro` | Declarative macro expansion + proc-macro integration | Declarative: tested. `quote!`/`quote_spanned!` built-ins implemented |
| `yelang-proc-macro` | Rust API for writing Rust proc macros | Complete for Rust authors; mirrored by Yelang `proc_macro` module in Phase A |
| `yelang-quote` | Rust `quote!`/`quote_spanned!` proc macro | Parses Rust/`proc_macro2` tokens; to be retired once Yelang backend is available |
| `yelang-proc-macro-bridge` | ABI registrar, protocol serialization, sandbox limits | Production-ready for native dylibs; needs WASM protocol adapter |
| `yelang-proc-macro-server` | Loads dylibs, invokes macros, enforces limits | Production-ready for native dylibs; needs WASM executor |
| `stdlib/core` | Rust crate exposing the Yelang standard library surface | `proc_macro` module implemented and tested in Phase A |

### 2.2 Critical missing pieces

1. **No Yelang backend.** The workspace has HIR and type-checking crates but no code-generation backend (no LLVM, Cranelift, WASM, or interpreter). Without a backend, Yelang code cannot be executed, so Yelang-authored proc macros cannot run.
2. **No Yelang `proc_macro` standard-library module.**
3. **No Yelang `quote!` macro.**
4. **No build-system concept of a `proc-macro` crate type.**
5. **No way for the compiler to compile a Yelang proc-macro crate and feed the resulting artifact to the existing runtime.**

### 2.3 Legacy baggage already removed

- `macro_rules!` syntax has been rejected in `yelang-ast/src/item/macro_def.rs`.
- The declarative macro engine uses only the native `macro name { ... }` form.

### 2.4 Remaining legacy surface that must change

- `yelang-quote` is a Rust proc-macro crate. It must be retired or repurposed as documentation/tests; the author-facing `quote!` must be Yelang-native.
- `yelang-proc-macro`'s public Rust API is a bootstrap aid. The long-term author-facing API lives in Yelang `proc_macro`.

---

## 3. Design Principles & Non-Goals

### 3.1 Principles

| # | Principle | Rationale |
|---|-----------|-----------|
| 1 | **Authors write macros in Yelang** | Avoids forcing users to learn a second language (Rust) and a second token model just to write macros. |
| 2 | **One canonical token model** | `yelang_macro_core::TokenStream` is the single representation. The Yelang `proc_macro` API, the compiler, and the wire protocol all use it. |
| 3 | **No `syn`/`quote`/`proc_macro2` clones** | Yelang macro authors parse/inspect tokens using the language's own AST/parser and construct output with built-in `quote!`. |
| 4 | **Sandboxed execution** | Learn from Rust's unsandboxed dylibs; use WASM for determinism, security, and cross-compilation. |
| 5 | **Minimal, explicit, stable ABI** | A small, versioned wire protocol (postcard-serialized token streams) between compiler and macro artifact. |
| 6 | `mod.rs`/`lib.rs` are for re-exports only | Implementation lives in descriptively named modules; no `util` modules. |

### 3.2 Non-goals (explicitly excluded)

- `macro_rules!` syntax or semantics.
- Rust-token `quote!` in the author-facing API.
- Allowing proc macros to perform arbitrary I/O, network access, or filesystem access outside the WASI sandbox.
- Backwards compatibility with Rust proc-macro crates.
- MIR/borrow-checker integration in this phase (Yelang has no lifetimes).

---

## 4. Architecture Decision Records

### ADR-1: Macro authors write in Yelang, not Rust

- **Decision:** The supported author language for Yelang proc macros is Yelang.
- **Consequences:** We must provide a Yelang standard-library module `proc_macro` and a Yelang `quote!` macro. We must compile macro crates with the Yelang compiler itself.
- **Rejected:** Continuing to require Rust-authored proc macros (current `yelang-proc-macro` approach).

### ADR-2: Proc macros execute in a WASM sandbox (primary)

- **Decision:** A proc-macro crate compiles to a WASI-compatible WebAssembly module. The compiler embeds a WASM runtime (recommended: `wasmtime`) to execute it.
- **Rationale:**
  - Rust's native dylibs are unsandboxed, cannot be cross-compiled easily, and are a perennial source of build fragility (ABI mismatches, panics, `cdylib` toolchain issues).
  - The Rust compiler team is actively exploring WASM proc macros ([compiler-team#876](https://github.com/rust-lang/compiler-team/issues/876), [internals thread](https://internals.rust-lang.org/t/pre-rfc-sandboxed-deterministic-reproducible-efficient-wasm-compilation-of-proc-macros/19359), [watt](https://docs.rs/watt/latest/watt/)).
  - A greenfield project should adopt the better architecture from the start.
- **Consequences:**
  - The macro artifact is a `.wasm` file, not a `.so`/`.dylib`/`.dll`.
  - The bridge needs a WASM invocation path alongside the native path.
  - WASI capabilities must be restricted: no filesystem, network, or clocks unless explicitly granted.

### ADR-3: Native dylib remains an optional compilation target (secondary)

- **Decision:** The Yelang backend may also support emitting native dynamic libraries for environments where WASM is unsuitable.
- **Rationale:** Some host toolchains or performance-sensitive scenarios may prefer native code.
- **Consequences:** The bridge/server keeps a pluggable `ProcMacroRuntime` abstraction. Native dylibs use the existing C-unwind ABI; WASM uses the WASI ABI.

### ADR-4: `quote!` is a compiler built-in macro

- **Decision:** `quote!` is implemented as a built-in macro in the compiler, not as a library macro.
- **Rationale:**
  - It needs special syntax (`#ident`, `#( ... )*`, `##` escape) that is easier to implement and diagnose at the compiler level.
  - It produces `proc_macro::TokenStream` values directly without needing a separate parser crate.
- **Consequences:** The compiler has a dedicated expansion for `quote!` and `quote_spanned!(span => ...)`. The Yelang `proc_macro` crate only needs to expose `TokenStream` and `ToTokens`.

### ADR-5: Built-in introspection helpers for common patterns

- **Decision:** Provide a small set of built-in helper functions/macros for the most common proc-macro tasks: parsing a `TokenStream` into an AST item, iterating fields of a struct/enum, emitting compiler diagnostics.
- **Rationale:** Eliminates the need for a `syn`-like external dependency for 80% of use cases (mirroring the spirit of Rust's declarative `macro_attr`/`macro_derive` work and the [Kangrejos 2025 declarative-macro improvements paper](https://kangrejos.com/2025/Rust%20Declarative%20Macro%20Improvements:%20A%20Step%20Forward%20for%20Rust%20Macros%20Usability.pdf)).
- **Consequences:** The compiler exposes a limited, stable introspection surface to macro code.

### ADR-6: Declarative and procedural macros coexist but stay separate

- **Decision:** Declarative macros (`macro name { ... }`) remain the lightweight, in-crate option. Procedural macros remain in separate `proc-macro` crates.
- **Rationale:** This matches Rust's proven separation and keeps the declarative engine simple.
- **Rejected:** Allowing procedural macros inside non-proc-macro crates.

---

## 5. Detailed Design

### 5.1 Yelang `proc_macro` standard-library module

Located in `stdlib/core/src/proc_macro/`. Because the standard library is currently a Rust crate, this module is initially a **Rust implementation of the Yelang-facing API** that mirrors the existing `yelang-proc-macro` API but is usable from compiled Yelang code.

**Core types:**

```yelang
// stdlib/core/src/proc_macro/token_stream.yel
pub struct TokenStream { ... }
impl TokenStream {
    pub fn new() -> TokenStream;
    pub fn is_empty(&self) -> bool;
    pub fn len(&self) -> usize;
    pub fn push(&mut self, tree: TokenTree);
    pub fn extend(&mut self, other: TokenStream);
    pub fn iter(&self) -> Iter<TokenTree>;
}

// stdlib/core/src/proc_macro/token_tree.yel
pub enum TokenTree {
    Group(Group),
    Ident(Ident),
    Punct(Punct),
    Literal(Literal),
}

// stdlib/core/src/proc_macro/ident.yel
pub struct Ident { ... }
impl Ident {
    pub fn new(text: string, span: Span) -> Ident;
    pub fn value(&self) -> string;
}

// stdlib/core/src/proc_macro/literal.yel
pub struct Literal { ... }
impl Literal {
    pub fn string(value: string, span: Span) -> Literal;
    pub fn integer(value: string, span: Span) -> Literal;
    pub fn float(value: string, span: Span) -> Literal;
    pub fn character(value: char, span: Span) -> Literal;
    pub fn byte(value: u8, span: Span) -> Literal;
    pub fn boolean(value: bool, span: Span) -> Literal;
}

// stdlib/core/src/proc_macro/span.yel
pub struct Span { ... }
impl Span {
    pub fn call_site() -> Span;
    pub fn def_site() -> Span;
    pub fn mixed_site() -> Span;
    pub fn line_column(&self) -> LineColumn;
}

// stdlib/core/src/proc_macro/group.yel
pub enum Delimiter { Parenthesis, Brace, Bracket, None }
pub struct Group { ... }
impl Group {
    pub fn new(delimiter: Delimiter, stream: TokenStream, span: Span) -> Group;
    pub fn delimiter(&self) -> Delimiter;
    pub fn stream(&self) -> TokenStream;
}

// stdlib/core/src/proc_macro/punct.yel
pub enum Spacing { Alone, Joint }
pub struct Punct { ... }
impl Punct {
    pub fn new(ch: char, spacing: Spacing, span: Span) -> Punct;
    pub fn as_char(&self) -> char;
    pub fn spacing(&self) -> Spacing;
}

// stdlib/core/src/proc_macro/diagnostic.yel
pub enum Level { Error, Warning, Note, Help }
pub struct Diagnostic { ... }
impl Diagnostic {
    pub fn error(message: string) -> Diagnostic;
    pub fn warning(message: string) -> Diagnostic;
    pub fn note(message: string) -> Diagnostic;
    pub fn help(message: string) -> Diagnostic;
    pub fn span(self, span: Span) -> Diagnostic;
    pub fn emit(self);
}
```

**Macro author signatures:**

```yelang
// Function-like
#[yelang_proc_macro::macro_export]
pub fn my_macro(input: proc_macro::TokenStream) -> proc_macro::TokenStream { ... }

// Attribute
#[yelang_proc_macro::macro_export_attribute]
pub fn my_attr(args: proc_macro::TokenStream, item: proc_macro::TokenStream) -> proc_macro::TokenStream { ... }

// Derive
#[yelang_proc_macro::macro_export_derive]
pub fn my_derive(item: proc_macro::TokenStream) -> proc_macro::TokenStream { ... }
```

### 5.2 Built-in `quote!` macro

`quote!` is a compiler built-in available inside proc-macro crates.

```yelang
let tokens = quote! {
    pub struct #name {
        #( #field_name: #field_type ),*
    }
};
```

**Syntax rules:**

| Pattern | Meaning |
|---------|---------|
| `#ident` | Interpolate a value implementing `ToTokens` (an identifier expression). |
| `#(expr)` | Interpolate an arbitrary expression implementing `ToTokens`. |
| `#( ... )*` | Repeat zero or more times. |
| `#( ... )+` | Repeat one or more times. |
| `#( ... ),*` / `#( ... ),+` | Repeat with `,` separator. |
| `##` | Escape to emit a literal `#`. |
| `#( #a #b ),*` | Multiple interpolations per repetition are allowed. |
| Nested `#(...)` | Repetitions may be nested. |

**`quote_spanned!`:**

```yelang
let tokens = quote_spanned!(span => #name: Copy);
```

Every token originating from the template body receives `span`; interpolated tokens keep their original spans.

### 5.3 `ToTokens` trait

```yelang
pub trait ToTokens {
    fn to_tokens(&self, stream: &mut TokenStream);
    fn to_token_stream(&self) -> TokenStream { ... }
}
```

Built-in implementations for `TokenTree`, `TokenStream`, `Ident`, `Literal`, `Punct`, `Group`, `Option<T>`, `Vec<T>`, `[T]`, string primitives, and integer primitives.

### 5.4 Compilation path: Yelang source → WASM module

```text
Yelang proc-macro crate source
        │
        ▼
Yelang lexer + parser → AST
        │
        ▼
Name resolution + HIR lowering
        │
        ▼
Type checking
        │
        ▼
Proc-macro export expansion (generates entry point + wrappers)
        │
        ▼
WASM code generation (new backend)
        │
        ▼
.wasm artifact
        │
        ▼
Compiler loads .wasm via wasmtime, invokes macro
```

**Required new crates:**

- `yelang-wasm` (or `yelang-codegen-wasm`): Yelang HIR → WebAssembly.
- `yelang-backend-common`: Shared backend utilities (register allocation helpers, ABI lowering, etc.) if needed by both WASM and native backends.

**Proc-macro crate type:**

```toml
# yelang.toml / Cargo.toml for a Yelang proc-macro crate
[package]
name = "my_derive"
version = "0.1.0"

crate-type = ["proc-macro"]

dependencies = {}
```

The build system:
1. Detects `crate-type = ["proc-macro"]`.
2. Compiles the crate with the Yelang compiler to a `.wasm` file (primary) or `.so`/`.dylib` (fallback).
3. Emits a sidecar manifest (`yelang-proc-macro.json`) describing exported macros.
4. When a downstream crate uses the macro, the compiler loads the artifact and invokes it via the bridge.

### 5.5 Proc-macro export expansion updates

`yelang-macro/src/proc_macro/export.rs` currently generates C-ABI wrappers that call into `yelang_proc_macro::run_*` helpers. For Yelang-authored macros, this generation must change:

- The expansion pass still scans for `#[yelang_proc_macro::macro_export]` etc.
- It validates that signatures use `proc_macro::TokenStream`.
- It generates the **WASM export table** or **native C-ABI wrappers** depending on target.
- For WASM, it emits a single `_start`/entry function and exported functions matching the ABI names.

The generated entry point must be deterministic and side-effect-free except for allocating the output buffer.

### 5.6 Bridge/server updates

- `yelang-proc-macro-bridge` adds a `wasm` module:
  - `WasiConfig`: restricted capability set (no filesystem, no network).
  - `WasmInstance`: owns a `wasmtime::Instance`.
  - `invoke_fn_like_wasm`, `invoke_attr_wasm`, `invoke_derive_wasm`.
- `yelang-proc-macro-server` adds a `runtime::wasm` executor.
- `ProcMacroRuntime` enum is extended:
  ```rust
  pub enum ProcMacroRuntime {
      NativeDylib,   // existing
      Wasm(WasmConfig), // new
  }
  ```
- Serialization stays postcard-based; token-stream wire format is unchanged.

### 5.7 Hygiene and spans

- Yelang's token tree already uses span and hygiene IDs from `yelang-macro-core`.
- The WASM runtime receives spans/hygiene as opaque wire payloads and restores them on the output token stream.
- Macro-generated identifiers use `Span::def_site()` by default to avoid shadowing user code.
- `Span::mixed_site()` falls back to call-site until full mixed-site transparency is implemented.

### 5.8 Introspection helpers (built-in)

To avoid a `syn`-like mega-dependency, the compiler exposes:

```yelang
// Parse a token stream into an AST item (returns Option<Item> and diagnostics).
proc_macro::parse_item(stream: TokenStream) -> Option<ast::Item>

// Parse a token stream into an AST expression.
proc_macro::parse_expr(stream: TokenStream) -> Option<ast::Expr>

// Iterate fields of a struct/enum from an Item.
proc_macro::fields_of(item: ast::Item) -> Vec<FieldInfo>

// Emit a diagnostic tied to a span.
proc_macro::diagnostic(level: Level, message: string, span: Span)
```

These are compiler intrinsics exposed through `proc_macro`. They are stable but minimal; complex parsing can still be done by hand over `TokenStream`.

### 5.9 Comptime vs macros

**Question:** Should Yelang also have `comptime` (Zig-style compile-time execution)?

**Answer:** Macros and comptime are complementary, but they are not the same thing.

| Feature | Proc macros | Comptime |
|---------|-------------|----------|
| Input | Tokens (pre-type-check) | Typed values and types |
| Output | Tokens | Values / types / generated items |
| Execution time | During expansion | During type-check/codegen |
| Capabilities | Token manipulation + limited introspection | Full language subset + type reflection |
| Use case | Syntax extension, derives, attributes | Generic specialization, type-level computation, contracts |

**Decision for this phase:** Implement proc macros first. Design comptime as a future phase, ensuring the macro API does not block a later `comptime` keyword. Specifically:
- Keep the token-based macro API stable.
- Do not conflate macro expansion with type-checking.
- Reserve the `comptime` keyword.

This is consistent with Rust's trajectory: proc macros solve syntax extension; `const` generics and inline const solve compile-time computation; and RFC discussions like [rfcs#3669](https://github.com/rust-lang/rfcs/issues/3669) explore deeper compile-time code execution without replacing macros.

### 5.10 WASM calling convention and memory ABI

To make the WASM path concrete, every proc-macro module exports:

```wat
(module
  ;; Allocate `size` bytes inside the module's linear memory.
  ;; Returns a 32-bit offset relative to the memory base.
  (func (export "yelang_alloc") (param i32) (result i32))

  ;; Free a previously allocated offset.
  (func (export "yelang_free") (param i32))

  ;; Entry point returning a pointer to the exports table.
  (func (export "yelang_proc_macro_entry") (param i32) (result i32))

  ;; Individual macro invokers (kind selected via descriptor table).
  (func (export "yelang_macro_<name>") ...)
)
```

**Memory layout rules:**

- The module owns one linear memory exported as `memory`.
- All string/token data passed to/from the module is a `(ptr: i32, len: i32)` pair where `ptr` is a byte offset into that memory.
- The host serializes the input `WireTokenStream` into the module's memory, calls the macro, then deserializes the returned `WireExpansionResult` from module memory.
- The module's allocator (`yelang_alloc`) must be deterministic and must not leak across invocations (host calls `yelang_free` on returned buffers).

**String ABI:**

- Yelang `string` in WASM is `(ptr, len)` of valid UTF-8 bytes. Invalid UTF-8 at API boundaries is rejected with a diagnostic.
- The runtime provides host functions for string concatenation and formatting only when deterministic and allocation-counted.

**Determinism subset:**

- Floating-point operations in proc macros are restricted to the deterministic WebAssembly subset (no `NaN` payload inspection, no target-dependent intrinsics).
- No access to wall-clock time, randomness, environment variables, or command-line arguments.

### 5.11 Dependencies between proc-macro crates

A proc-macro crate may depend on helper Yelang crates (e.g., a shared `derive_util` crate). Because WASM dynamic linking is not used, dependencies are **statically linked** into the final `.wasm` module. The build system:

1. Compiles each dependency to a WASM object/module.
2. Links them into a single `.wasm` artifact (using `wasm-ld` or a custom linker).
3. Deduplicates the runtime allocator and standard library.

If the native-dylib fallback is used, the same crates compile to native objects and link into a single shared library.

---

## 6. Exhaustive File Tree

The tree below shows **only the new and significantly changed files/modules** for this phase. Existing, untouched files are omitted for clarity.

```text
crates/compiler/
├── notes/architectures/
│   └── yelang_proc_macro_design.md          # this document
│
├── stdlib/core/
│   ├── Cargo.toml
│   └── src/
│       ├── lib.rs                           # re-exports proc_macro
│       ├── memory.rs
│       ├── panic.rs
│       ├── primitives.rs
│       └── proc_macro/                      # Yelang-facing API (Rust implementation)
│           ├── mod.rs                       # re-exports the yelang-proc-macro API
│           └── tests.rs                     # exhaustive unit tests for the API
│
├── yelang-quote/                            # RETIRE: kept only for Rust bootstrap tests
│   └── ...
│
├── yelang-proc-macro/                       # becomes Rust bootstrap mirror, not author-facing
│   └── src/
│       └── ...
│
├── yelang-macro-core/                       # already canonical token tree; add WASM helpers if needed
│   └── src/
│       └── token_tree/
│           └── wasm.rs                      # WASM-specific token-tree conversions (if any)
│
├── yelang-macro/
│   └── src/
│       ├── proc_macro/
│       │   ├── mod.rs
│       │   ├── client.rs
│       │   ├── discovery.rs
│       │   ├── executor.rs
│       │   ├── expand.rs
│       │   ├── export.rs                    # generate WASM exports OR native C wrappers
│       │   ├── manifest.rs
│       │   ├── registry.rs
│       │   ├── resolver.rs
│       │   └── runtime.rs                   # new: native vs wasm runtime selection
│       ├── builtin_macros.rs                # add quote! and quote_spanned! expansion
│       └── quote_macro/                     # built-in quote! implementation
│           ├── mod.rs
│           ├── parse.rs                     # template parser
│           └── expand.rs                    # AST code generator
│
├── yelang-proc-macro-bridge/
│   └── src/
│       ├── abi/
│       │   ├── mod.rs
│       │   ├── registrar.rs                 # add wasm-friendly descriptor layout
│       │   ├── signature.rs
│       │   └── symbols.rs
│       ├── protocol/
│       │   ├── mod.rs
│       │   ├── message.rs
│       │   ├── serialize.rs
│       │   ├── token.rs
│       │   └── version.rs
│       └── sandbox/
│           ├── mod.rs
│           ├── error.rs
│           ├── limits.rs
│           └── wasm.rs                      # WASI capability restrictions
│
├── yelang-proc-macro-server/
│   └── src/
│       ├── executor/
│       │   ├── mod.rs
│       │   ├── context.rs
│       │   ├── invoke.rs
│       │   ├── limits.rs
│       │   ├── panic.rs
│       │   └── wasm.rs                      # wasmtime invocation
│       ├── protocol/
│       │   ├── mod.rs
│       │   └── io.rs
│       ├── server/
│       │   ├── mod.rs
│       │   ├── library.rs                   # LoadedLibrary becomes enum Native|Wasm
│       │   ├── run.rs
│       │   └── session.rs
│       └── lib.rs
│
├── yelang-wasm/                             # NEW: Yelang HIR → WebAssembly backend
│   ├── Cargo.toml
│   └── src/
│       ├── lib.rs
│       ├── module.rs                        # WasmModule builder
│       ├── func.rs                          # function lowering
│       ├── expr.rs                          # expression lowering
│       ├── ty.rs                            # type lowering
│       ├── data.rs                          # globals, data segments
│       ├── export.rs                        # proc-macro export table generation
│       ├── runtime_link.rs                  # link against WASI/runtime helpers
│       └── tests/
│           ├── arithmetic.rs
│           ├── control_flow.rs
│           ├── structs.rs
│           ├── enums.rs
│           └── proc_macro_smoke.rs
│
└── yelang-backend-common/                   # NEW: shared backend pieces (optional)
    ├── Cargo.toml
    └── src/
        ├── lib.rs
        ├── abi.rs
        └── layout.rs
```

---

## 7. Implementation Checklist

### Phase A — Yelang `proc_macro` standard library

- [x] Create `stdlib/core/src/proc_macro/` directory.
- [x] Implement `TokenStream`, `TokenTree`, `Ident`, `Literal`, `Span`, `Group`, `Punct`, `Diagnostic`.
- [x] Implement `ToTokens` trait and built-in impls.
- [x] Add unit tests for every public type/method.
- [ ] Add property tests (round-trip token stream → wire → token stream).

### Phase B — Built-in `quote!`

- [x] Add `quote!` and `quote_spanned!` to the compiler built-in macro registry.
- [x] Implement template parser: literal tokens, `#ident`, `#(expr)`, `#(...)*`, `#(...)+`, separators, nesting, `##` escape.
- [x] Implement code generation that builds `proc_macro::TokenStream` values.
- [x] Add error messages for malformed templates.
- [x] Add tests covering all syntax cases.

### Phase C — Yelang-to-WASM backend

- [ ] Create `yelang-wasm` crate.
- [ ] Lower Yelang HIR to WebAssembly instructions.
- [ ] Support integers, floats, booleans, strings, tuples, structs, enums, arrays, functions, calls.
- [ ] Implement memory management for the WASM linear memory (allocator in WASM, free in host).
- [ ] Generate proc-macro export table from `@yelang_proc_macro::macro_export*` attributes.
- [ ] Define WASM memory ABI: string `(ptr, len)`, allocator interface, entry-point signatures.
- [ ] Add end-to-end smoke test: compile a tiny Yelang function to WASM and call it.
- [ ] Add test for statically linking a helper crate into a proc-macro `.wasm`.

### Phase D — Bridge/server WASM integration

- [ ] Add `wasmtime` dependency to `yelang-proc-macro-server`.
- [ ] Implement `WasmInstance` with zero capabilities.
- [ ] Implement `invoke_fn_like_wasm`, `invoke_attr_wasm`, `invoke_derive_wasm`.
- [ ] Add resource limits (fuel/instructions, memory, output tokens).
- [ ] Add fallback native dylib path behind `ProcMacroRuntime`.

### Phase E — Export expansion updates

- [ ] Update `yelang-macro/src/proc_macro/export.rs` to generate WASM export entries when target is WASM.
- [ ] Keep native C-ABI generation as fallback.
- [ ] Validate that macro signatures use `proc_macro::TokenStream`.

### Phase F — Build system integration

- [ ] Define `crate-type = ["proc-macro"]` in Yelang package manifest.
- [ ] Make the compiler compile proc-macro crates to `.wasm`.
- [ ] Statically link proc-macro crate dependencies into the final `.wasm`.
- [ ] Emit `yelang-proc-macro.json` sidecar manifest.
- [ ] Wire manifest discovery into `yelang-macro/src/proc_macro/discovery.rs`.

### Phase G — Introspection helpers

- [ ] Implement `proc_macro::parse_item`, `proc_macro::parse_expr`.
- [ ] Implement `proc_macro::fields_of`.
- [ ] Implement diagnostic emission intrinsics.

### Phase H — Cleanup and retirement

- [ ] Move `yelang-quote` to a `legacy/` or `bootstrap/` folder, or delete if no longer needed.
- [ ] Update `yelang-proc-macro` documentation to state it is a Rust bootstrap mirror, not the author API.
- [ ] Remove any remaining references to `macro_rules!` or Rust-token parsing from the author-facing path.

### Phase I — Documentation and examples

- [ ] Add `examples/proc_macro/` with function-like, attribute, and derive macros written in Yelang.
- [ ] Document the `quote!` syntax with examples.
- [ ] Document the WASM sandbox model and capability restrictions.

---

## 8. Exhaustive Test Matrix

### Unit tests

| Area | Test cases |
|------|------------|
| `TokenStream` | `new`, `push`, `extend`, `is_empty`, `len`, `iter`, `FromIterator`, `IntoIterator`, round-trip through wire format |
| `Ident` | creation, value retrieval, span preservation, invalid identifier rejection |
| `Literal` | string, integer, float, char, byte, bool; suffix handling; span preservation |
| `Group` | all delimiters; nested groups; stream extraction |
| `Punct` | char/spacing/span; joint vs alone |
| `Span` | call_site, def_site, mixed_site; line/column |
| `ToTokens` | for every built-in type; for `Option`; for `Vec`; for slices; for references |
| `Diagnostic` | all levels; span attachment; emission without panic |

### `quote!` tests

| Feature | Cases |
|---------|-------|
| Empty template | `quote!()` produces empty stream |
| Literal tokens | identifiers, punctuation, literals, groups |
| Interpolation | `#ident`, `#(expr)`, `#(self.field)` |
| Escaped hash | `##` produces `#` |
| Repetition star | `#(#x)*` with zero, one, many |
| Repetition plus | `#(#x)+` with one, many; error on zero |
| Separator | `#(#x),*`, `#(#x),+`, `#(#x);*` |
| Multiple interpolations per repetition | `#(#name: #ty),*` |
| Nested repetition | `#(#(#inner)*)*` |
| `quote_spanned!` | span applies to template tokens, not interpolations |
| Error cases | missing expr after `#`, empty repetition body, repetition without interpolation, invalid separator |

### Proc-macro export expansion tests

| Case | Expected |
|------|----------|
| Function-like export | Valid descriptor generated |
| Attribute export | Valid descriptor generated |
| Derive export | Valid descriptor generated |
| Wrong parameter count | Error diagnostic |
| Wrong parameter type | Error diagnostic |
| Wrong return type | Error diagnostic |
| Multiple exports in one crate | Descriptor array contains all |
| Missing export attribute | Item passes through unchanged |

### WASM backend tests

| Case | Expected |
|------|----------|
| Compile `fn add(a: i32, b: i32) -> i32` | Callable WASM function returning correct result |
| Compile `fn echo_string(s: string) -> string` | String round-trips through linear memory |
| Compile struct construction/access | Correct memory layout and field access |
| Compile enum match | Correct tag dispatch |
| Compile proc-macro crate | `.wasm` artifact produced with exported macro entry points |

### Integration tests

| Scenario | Expected |
|----------|----------|
| Yelang derive macro generates `impl Debug` | Downstream `#[derive(MyDebug)]` expands correctly |
| Yelang attribute macro wraps a function | Attribute expands and preserves item semantics |
| Yelang function-like macro | Invocation expands correctly |
| Macro emits diagnostic | Diagnostic rendered at correct span |
| Macro panics | Converted to error diagnostic, compiler remains stable |
| Macro exceeds token limit | `InvokeError::OutputTooLarge` |
| Macro exceeds memory limit | `InvokeError::MemoryLimitExceeded` |
| Macro exceeds fuel limit | `InvokeError::Timeout` |
| WASM macro cannot open files | WASI capability denial |

### Adversarial tests

| Attack | Mitigation tested |
|--------|-------------------|
| Return malformed wire bytes | `OutputDeserialization` error |
| Return null pointer | `NullOutput` error |
| Infinite loop | Fuel-based timeout |
| Memory bomb | Linear-memory limit |
| Stack overflow | WASM stack guard |
| Attempt filesystem access | WASI capability error |
| Attempt network access | WASI capability error |
| Identifier hygiene escape | Span/def-site checks |
| Very long generated token stream | Output token limit |
| Non-UTF8 identifier bytes | Rejected at API boundary |

---

## 9. Open Decisions for Approval

Before implementation begins, please confirm:

1. **Backend choice:** Approve WASM sandbox (`wasmtime`) as the primary compilation target for proc-macro crates? (Native dylib remains an optional fallback.)
2. **`quote!` as built-in:** Approve implementing `quote!`/`quote_spanned!` as compiler built-ins rather than library macros?
3. **Introspection surface:** Approve the minimal built-in helpers (`parse_item`, `parse_expr`, `fields_of`, diagnostic intrinsics) instead of a `syn`-like external library?
4. **Comptime scope:** Defer full `comptime` to a later phase, keeping proc macros token-based?
5. **Retire `yelang-quote`:** Approve moving the current Rust `quote!` implementation to a bootstrap/legacy location?

---

## 10. Risks, Mitigations, and Adversarial Review

This section records the adversarial review of the design against the requirements "greenfield, non-legacy, production-ready, battle-tested."

| Risk | Severity | Mitigation in design |
|------|----------|----------------------|
| No Yelang backend exists; WASM backend is a large new crate. | High | Documented as the primary missing dependency. The design does not pretend the backend already exists. |
| WASM slower than native dylibs for macro-heavy builds. | Medium | Native dylib kept as optional fallback. Benchmarking added to checklist. |
| `quote!` as a built-in creates compiler magic. | Low | Built-in is limited to token templating; all other macro logic is ordinary Yelang code. |
| Introspection helpers (`parse_item`) couple `proc_macro` to compiler AST. | Medium | Helpers return a small, stable "macro view" of items rather than full compiler AST. |
| Hygiene contexts serialized opaquely could become incompatible. | Medium | Wire protocol versioned; hygiene payloads tagged with format version. |
| WASM modules can still infinite-loop or allocate too much. | High | Fuel/instruction limit, memory limit, output-token limit enforced by executor. |
| Macro output could shadow user identifiers. | Medium | Default `def_site` span plus explicit `Span::call_site`/`mixed_site` controls. |
| `##` escape syntax could conflict with future operators. | Low | Escape is inside `quote!` only; lexer/parser unchanged. |
| Native dylib path retains Rust's unsandboxed risks. | Medium | Native path is opt-in and documented as legacy-equivalent; WASM is default. |
| Dependencies of proc-macro crates complicate linking. | Medium | Static linking into single `.wasm`/`.so` documented; component model deferred. |

**Review conclusion:** The design is internally consistent and addresses the identified risks. The main external dependency is building `yelang-wasm` (or equivalent backend), which is unavoidable for Yelang-authored macros.

## 11. References

- Rust declarative macro improvements (attribute + derive `macro_rules!`): [Kangrejos 2025 paper](https://kangrejos.com/2025/Rust%20Declarative%20Macro%20Improvements:%20A%20Step%20Forward%20for%20Rust%20Macros%20Usability.pdf)
- Rust WASM proc-macro sandboxing initiative: [compiler-team#876](https://github.com/rust-lang/compiler-team/issues/876)
- Pre-RFC discussion: [Sandboxed, deterministic, reproducible, efficient Wasm compilation of proc macros](https://internals.rust-lang.org/t/pre-rfc-sandboxed-deterministic-reproducible-efficient-wasm-compilation-of-proc-macros/19359)
- Existing WASM macro runtime for Rust: [watt](https://docs.rs/watt/latest/watt/)
- Rust comptime discussion: [rfcs#3669](https://github.com/rust-lang/rfcs/issues/3669)

---

## 12. Implementation Notes

### Phase A/B completion summary

- `stdlib/core/src/proc_macro/mod.rs` re-exports the `yelang-proc-macro` API as the Yelang `proc_macro` module.
- `stdlib/core/src/proc_macro/tests.rs` contains 36 unit tests covering `TokenStream`, `Ident`, `Literal`, `Punct`, `Group`, `Span`, `Diagnostic`, and round-trips.
- `yelang-macro/src/quote_macro/parse.rs` implements the `quote!`/`quote_spanned!` template parser using `yelang_macro_core` tokens.
- `yelang-macro/src/quote_macro/expand.rs` generates a Yelang block expression that builds a `proc_macro::TokenStream`.
- `yelang-macro/src/builtin_macros.rs` registers `Quote` and `QuoteSpanned` as compiler built-in macros and wires them into `expand_builtin_macro`.
- The `#` token is recognized by the lexer (`yelang-lexer/src/tokenizer/tokenize.rs`) so that `quote!` templates containing `#` parse correctly.
- Workspace tests and `cargo clippy --lib -p yelang-macro` pass.

### What remains

Phases C–I require a Yelang code-generation backend (WASM or native) and build-system support for `crate-type = ["proc-macro"]`. Those are outside the scope of the current goal and are blocked on backend work.

*End of design document.*
