# Comptime (`compile-time evaluation`) — Implementation Checklist

Design doc: `notes/architectures/comptime_design.md`.

Status legend:
- `[ ]` not started
- `[/]` in progress / skeleton / partial
- `[x]` done

---

## 1. Design and documentation

- [x] Write `notes/architectures/comptime_design.md`.
- [x] Write `notes/architectures/comptime_checklist.md`.
- [ ] Reserve `comptime` keyword in lexer/parser.
- [ ] Add comptime examples to `notes/syntax_grammar/`.

---

## 2. Syntax surface

- [ ] Parse `comptime { ... }` block expression.
- [ ] Parse `comptime fn name(...) -> T { ... }`.
- [ ] Parse `@comptime` item attribute.
- [ ] Parse `comptime` parameter modifier (future).
- [ ] Parse `@compileLog(...)` builtin.
- [ ] Parse `@typeInfo(T)`, `@typeName(T)` builtins.
- [ ] Parse `@setEvalBranchQuota(n)` builtin.

---

## 3. AST / HIR representation

- [ ] Add `ExprKind::ComptimeBlock` to AST.
- [ ] Add `ItemKind::ComptimeFn` to AST.
- [ ] Add `ExprKind::Comptime { block }` to HIR.
- [ ] Add `ItemKind::ComptimeFn` to HIR.
- [ ] Lower AST comptime nodes to HIR.

---

## 4. Type-system integration

- [ ] Track comptime-known values in `TypeckResults` (or `Const` nodes).
- [ ] Type-check `comptime { ... }` blocks with expected type.
- [ ] Type-check `comptime fn` bodies.
- [ ] Enforce comptime restrictions during type checking:
  - no I/O,
  - no environment access,
  - no network,
  - no unsafe host operations.
- [ ] Evaluate comptime expressions in const contexts:
  - `const` / `static` initializers,
  - array lengths,
  - const generic arguments,
  - enum discriminants.
- [ ] Splice evaluated `ConstValue` back into HIR.
- [ ] Splice generated types back into `yelang-ty` interner.

---

## 5. Comptime interpreter (`yelang-comptime` crate)

### 5.1 Crate skeleton

- [ ] Create `yelang-comptime/Cargo.toml`.
- [ ] Create `yelang-comptime/src/lib.rs` (router only).
- [ ] Wire crate into workspace `Cargo.toml`.

### 5.2 Core interpreter

- [ ] `interpreter.rs`: main evaluation loop over HIR `ExprKind`.
- [ ] `value.rs`: `CtValue` enum (`Const`, `Alloc`, `Type`, `Fn`, `Error`).
- [ ] `memory.rs`: comptime heap, `AllocId`, pointers, bounds checks.
- [ ] `environment.rs`: scopes, variable bindings, const params.
- [ ] `resolve.rs`: resolve paths to comptime-known definitions.
- [ ] `error.rs`: `EvalError` with span and comptime stack trace.

### 5.3 Supported language constructs

- [ ] Literals (`Lit`).
- [ ] Arithmetic, comparison, bitwise, logical operators.
- [ ] Path resolution (locals, consts, comptime fns).
- [ ] Block expressions.
- [ ] Local `let` and assignment.
- [ ] `if` / `match`.
- [ ] `loop` / `break` / `continue` / `return`.
- [ ] Function calls to `comptime fn`.
- [ ] Field access on structs/tuples.
- [ ] Array/tuple/struct literals.
- [ ] Array/slice indexing.
- [ ] Type casts that are valid at comptime.

### 5.4 Reflection and builtins

- [ ] `@typeInfo(T)` returns comptime-known type descriptor.
- [ ] `@typeName(T)` returns comptime-known string.
- [ ] `@compileLog(...)` prints value+type during compilation.
- [ ] `@setEvalBranchQuota(n)` raises branch quota.
- [ ] `@compileError(msg)` fails compilation from comptime.

### 5.5 Resource limits

- [ ] `EvalLimits` struct: branch quota, recursion depth, heap bytes, time.
- [ ] Default limits.
- [ ] `@setEvalBranchQuota(n)`.
- [ ] Quota exceeded → clear compile error.

### 5.6 Memoization

- [ ] Memoize comptime function calls by `(DefId, GenericArgs, args)`.
- [ ] Cache invalidation tied to compiler query system.

---

## 6. Compiler query integration

- [ ] Add `comptime_evaluate(hir_id, expected_ty) -> ConstValue` query.
- [ ] Invoke query from `yelang-tycheck::check` in const contexts.
- [ ] Handle generic substitutions before evaluation.
- [ ] Report comptime errors through the normal diagnostic system.

---

## 7. Splicing results back

- [ ] Replace `comptime { ... }` HIR nodes with `Const` nodes after evaluation.
- [ ] Materialize comptime-generated types into `Ty` / `AdtDef`.
- [ ] Add generated items to the crate with synthetic DefIds.
- [ ] Ensure runtime code never references comptime-only allocations.

---

## 8. Safety and sandboxing

- [ ] Explicit list of permitted comptime operations.
- [ ] Reject I/O, env, network, process spawn.
- [ ] Reject raw pointer casts that leak host addresses.
- [ ] Reject reading files except via future build-system API.
- [ ] Ensure target-independent `usize` semantics.
- [ ] Validate comptime heap pointers do not escape to runtime.

---

## 9. Tests

### 9.1 Unit tests (`yelang-comptime`)

- [ ] Literal evaluation.
- [ ] Arithmetic and comparison.
- [ ] Control flow.
- [ ] Function calls and recursion.
- [ ] Aggregate construction and access.
- [ ] Memory bounds errors.
- [ ] Branch quota enforcement.
- [ ] Memoization.

### 9.2 Integration tests (`yelang-tycheck` / `yelang-macro`)

- [ ] `comptime { ... }` in `const` initializer.
- [ ] `comptime { ... }` in array length.
- [ ] `comptime fn` called from `const`.
- [ ] `comptime fn` returning a type used in a declaration.
- [ ] `@compileLog` output capture.
- [ ] Reflection: `@typeInfo` on struct/enum.
- [ ] Error: comptime block depends on runtime value.
- [ ] Error: comptime branch quota exceeded.
- [ ] Error: disallowed host operation inside comptime.
- [ ] Interaction: macro emits `comptime { ... }` block.

### 9.3 Negative / adversarial tests

- [ ] Infinite loop hits branch quota.
- [ ] Deep recursion hits stack limit.
- [ ] Large allocation hits heap limit.
- [ ] Attempt to read file at comptime rejected.
- [ ] Attempt to access environment at comptime rejected.
- [ ] Comptime result used as runtime value rejected.

---

## 10. Final verification

- [ ] `cargo fmt`.
- [ ] `cargo check --workspace` clean (existing warnings allowed).
- [ ] `cargo test -p yelang-comptime` passes.
- [ ] `cargo test -p yelang-tycheck` passes.
- [ ] `cargo test -p yelang-macro` passes.
- [ ] Design doc and checklist updated for any deviations.
