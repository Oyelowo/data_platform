# Macro System Phase 4 Checklist: Hygiene Hardening

## Goal
Harden the declarative macro expansion engine: indirect recursion detection, `$crate`/`$package` hygiene, macro backtraces, span transparency kinds, and cross-crate macro context design.

## Research
- [x] Review rustc indirect recursion / cycle detection
- [x] Review `$crate` semantics in Rust
- [x] Review span kinds (`def_site`, `call_site`, `mixed_site`)
- [x] Review macro backtrace diagnostics

## Core data structures
- [ ] Add `CrateId` to `yelang-macro-core/src/id.rs`
- [ ] Extend `MacroDefData` with `defining_crate: CrateId`
- [ ] Add `IdentOrigin` enum (`Plain`, `Crate`, `Package`) to macro-core identifiers
- [ ] Add `Transparency::Transparent` and `Transparency::Mixed` variants
- [ ] Add hygiene helpers: `outer_transparency`, `is_descendant_of`

## Resolver
- [ ] Expose `MacroDefId` lookup by macro name from `MacroResolver`
- [ ] Track defining crate when collecting macro definitions

## Expander
- [ ] Change `expansion_stack` entries to `(String, Span, MacroDefId)`
- [ ] Detect indirect recursion by `MacroDefId` presence on stack
- [ ] Emit `ExpansionLoop` with full backtrace chain
- [ ] Attach backtrace snapshot to every `ExpandError`
- [ ] Thread current macro's `MacroDefId` / `CrateId` through transcription

## Transcriber
- [ ] Preserve `$crate` / `$package` tokens in macro body tokenization
- [ ] Emit `IdentOrigin::Crate` / `Package` with defining crate id
- [ ] Keep default `Opaque` transparency for declarative macros

## Name resolution
- [ ] Resolve paths starting with `IdentOrigin::Crate` to the macro's defining crate
- [ ] Resolve paths starting with `IdentOrigin::Package` to the package root
- [ ] Fall back to normal keyword behavior for plain `crate` / `package`

## Diagnostics
- [ ] Add `BacktraceFrame { name, span }` to `ExpandError`
- [ ] Implement display rendering of macro expansion chain

## Cross-crate design
- [ ] Design crate metadata entry for macro definitions
- [ ] Design `SyntaxContextId` remapping on import
- [ ] Document forward compatibility with proc macros

## Tests
- [ ] Create `yelang-macro/tests/declarative_macros_hygiene.rs`
- [ ] Direct recursion still detected
- [ ] Indirect two-macro recursion detected
- [ ] Indirect three-macro recursion detected
- [ ] Non-recursive deep nesting accepted
- [ ] Backtrace contains macro chain
- [ ] `$crate` generated code resolves to defining crate helper
- [ ] Hygienic generated binding does not collide with outer binding
- [ ] All existing tests still pass

## Verification
- [ ] `cargo fmt`
- [ ] `cargo test -p yelang-macro` passes
- [ ] `cargo test` (workspace) passes
