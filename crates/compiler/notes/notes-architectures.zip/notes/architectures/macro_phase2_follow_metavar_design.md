# Yelang Macro System — Phase 2 Design
## Follow-set validation, trailing separators, and metavariable expressions

## 1. Executive summary

Phase 1 made `yelang-macro` production-ready for all three declarative macro kinds (function-like, attribute, derive). Phase 2 hardens the matcher/transcriber to match the expressiveness and future-proofing of modern Rust `macro_rules!` without copying its legacy warts.

The three deliverables are:

1. **Follow-set validation** — reject macro definitions (and optionally invocations) where a fragment specifier is followed by a token that could become ambiguous as the language evolves. Based on the Rust Reference formal specification and RFC 550.
2. **Trailing separators** — allow `$(...),*` and `$(...),+` to accept an optional trailing separator without requiring the user to write a separate `$(,)?` workaround.
3. **Metavariable expressions** — expose repetition metadata inside transcribers: `${count(x)}`, `${count(x, depth)}`, `${index()}`, `${index(depth)}`, `${len()}`, `${len(depth)}`, `${ignore(x)}`, and `$$` (escaped dollar). Based on RFC 3086.

All three features are implemented inside `yelang-macro`; no new crates are required. The design keeps the existing two-token-system split (lexer tokens vs. macro-core token trees) and does not touch `mod.rs`/`lib.rs` beyond re-exports.

## 2. Research digest

### 2.1 Follow-set validation

Sources:
- [Rust Reference — Macros by example, Follow-set ambiguity restrictions](https://doc.rust-lang.org/reference/macros-by-example.html#follow-set-ambiguity-restrictions)
- [Rust Reference — Appendix: Macro follow-set ambiguity formal specification](https://doc.rust-lang.org/reference/macro-ambiguity.html)
- [RFC 550 — macro future-proofing](https://github.com/rust-lang/rfcs/blob/master/text/0550-macro-future-proofing.md)

Key follow sets for fragment specifiers:

| Fragment | Valid follows |
|----------|---------------|
| `expr`, `stmt` | `=>`, `,`, `;` |
| `pat` | `=>`, `,`, `=`, `\|`, `if`, `in` |
| `ty`, `path` | `=>`, `,`, `=`, `\|`, `;`, `:`, `>`, `>>`, `[`, `{`, `as`, `where`, and `block` nonterminals |
| `ident`, `block`, `item`, `tt`, `literal` | any token |
| others (`vis`, `lifetime`, `meta`) | see Rust Reference |

Important lessons from Rust:
- Follow-set violations are **definition-time errors**, not invocation-time errors. This future-proofs user macros.
- The third matcher invariant (unseparated `*`/`+` must have `FOLLOW(contents) ⊇ FIRST(contents)`) is documented but historically unenforced in Rust. We enforce it from day one to avoid future breakage.
- `pat_param` exists in Rust for edition compatibility; Yelang has only one `pat` fragment, so we use the 2021+ `pat` follow set (no `|`).

### 2.2 Metavariable expressions

Source: [RFC 3086 — macro metavariable expressions](https://rust-lang.github.io/rfcs/3086-macro-metavar-expr.html)

Syntax and semantics:

| Expression | Meaning |
|------------|---------|
| `${count(ident)}` | Total leaf captures of `$ident` (sum across all nesting depths). |
| `${count(ident, depth)}` | Number of direct children at `depth` outward from the outermost repetition (depth 0 = outermost layer). |
| `${index()}` | Current index of the inner-most repetition (0-based). |
| `${index(depth)}` | Index of the repetition `depth` steps outward from inner-most. |
| `${len()}` | Length of the inner-most repetition. |
| `${len(depth)}` | Length of the repetition `depth` steps outward. |
| `${ignore(ident)}` | Binds `$ident` for repetition counting but expands to nothing. |
| `$$` | Expands to a single `$` token (escaped dollar). |

Lessons from Rust:
- For `index`/`len`, `depth` counts **outward** from the inner-most repetition. This lets expressions be copied between nesting depths without modification.
- For `count`, `depth` counts **outward from the outermost** repetition: depth 0 is the outermost layer, depth 1 is the next layer inward, etc. The no-argument form sums leaf captures across all depths.
- `$$` is required for macros that emit macros with repetitions.
- Metavariable expressions are **transcriber directives**, not macro invocations, because by the time a normal macro would expand, repetition context is lost.

### 2.3 Trailing separators

Sources:
- [Rust Reference — Repetitions](https://doc.rust-lang.org/reference/macros-by-example.html#repetitions)
- [The Little Book of Rust Macros — Trailing separators](https://danielkeep.github.io/tlborm/book/pat-trailing-separators.html)

Rust allows users to write `$(x),* $(,)?` to accept an optional trailing comma. Modern expectation is that `$(x),*` should implicitly accept a trailing separator when it is unambiguous. We will accept trailing separators directly in `*` and `+` repetitions with a separator, removing the need for the `$(,)?` workaround.

## 3. Greenfield hindsight / what not to copy

1. **Enforce follow sets at definition time.** Rust’s historical underspecification and unenforced third invariant created edition-breakage risk. We validate every rule when it is parsed.
2. **Depth counts outward from inner-most for `index`/`len`, outward from outermost for `count`.** The original RFC counted inward; Rust changed it. We use the outward convention from the start.
3. **Make `$$` a first-class transcriber token**, not a string hack.
4. **Trailing separators are implicit** for `*`/`+` with separators, not an extra user-written `$(,)?` repetition.
5. **Keep the matcher engine deterministic.** Follow-set validation must not introduce backtracking or ambiguity; it is a linear structural check over `MatcherOp`.

## 4. Detailed design

### 4.1 File tree after Phase 2

```text
yelang-macro/src/
├── lib.rs                     # re-exports only
├── error.rs                   # ExpandError + new MatcherError variants
├── expander.rs                # iterative expansion (unchanged surface)
├── builtin_macros.rs
├── builtin_decorators.rs
├── paste.rs
├── quote.rs
├── resolver.rs
└── matcher/
    ├── mod.rs                 # re-exports
    ├── types.rs               # FragmentKind, MacroKind, MacroRule, MatcherOp, TranscriberOp, MetavarExpr
    ├── parser.rs              # parse_rules, parse_matcher_seq, parse_transcriber_seq
    ├── engine.rs              # try_match_rule, try_match_matcher, match_op
    ├── fragment.rs            # consume_fragment
    ├── bindings.rs            # Bindings, Binding
    ├── cursor.rs              # TokenCursor
    └── follow.rs              # NEW: follow-set validation
└── transcribe.rs              # transcribe, repetition expansion, metavar expr evaluation

yelang-macro/tests/
├── declarative_macros.rs
├── declarative_macros_exhaustive.rs   # Phase 1 tests
└── declarative_macros_phase2.rs       # NEW: Phase 2 tests
```

No new modules are added to `lib.rs` or `matcher/mod.rs` except the re-export of `follow::validate_rule`.

### 4.2 Data structure changes

#### 4.2.1 `FragmentKind` (already exists)

No changes, but follow sets must cover every variant:

```rust
pub enum FragmentKind {
    Ident, Expr, Stmt, Block, Tt, Literal, Ty, Path, Item, Pat,
}
```

#### 4.2.2 New `MetavarExpr`

```rust
#[derive(Debug, Clone, PartialEq)]
pub enum MetavarExpr {
    Count { name: Symbol, depth: Option<usize> },
    Index { depth: Option<usize> },
    Len { depth: Option<usize> },
    Ignore { name: Symbol },
}
```

Default depths:
- `count(x)` → total leaf captures across all nesting depths.
- `count(x, d)` → number of direct children at depth `d` outward from the outermost repetition (depth 0 = outermost layer).
- `index()` → inner-most repetition, equivalent to depth 0 counting outward from inner-most.
- `len()` → inner-most repetition, equivalent to depth 0 counting outward from inner-most.

#### 4.2.3 Extended `TranscriberOp`

```rust
pub enum TranscriberOp {
    Terminal(TokenTree),
    Group { delimiter: Delimiter, ops: Vec<TranscriberOp> },
    Subst(Symbol),
    Repeat { kind: RepetitionKind, sep: Option<TokenTree>, ops: Vec<TranscriberOp> },
    MetavarExpr(MetavarExpr),        // NEW
    DollarDollar,                    // NEW: expands to literal `$`
}
```

#### 4.2.4 New `MatcherError` variants

```rust
pub enum MatcherError {
    // ... existing ...
    FollowSetViolation {
        fragment: FragmentKind,
        followed_by: String,
        position: String,
    },
    InvalidMetavarExpr(String),
}
```

### 4.3 Follow-set validation

A new module `yelang-macro/src/matcher/follow.rs` computes `FIRST`, `LAST`, and `FOLLOW` sets over `MatcherOp` and validates the three matcher invariants.

#### 4.3.1 Sets

We model tokens as a small enum:

```rust
enum TokenClass {
    Terminal(TokenTree),
    Fragment(FragmentKind),
    Epsilon,              // can match empty
}
```

Sets are `BTreeSet<TokenClass>` with `Eq`/`Ord` derived from `TokenTree` equality on symbols/spacing (spans ignored).

#### 4.3.2 Functions

```rust
pub fn validate_rule(rule: &MacroRule, interner: &Interner) -> Result<(), MatcherError>;
```

Internally:
- `first(ops: &[MatcherOp]) -> Set` — FIRST set.
- `last(ops: &[MatcherOp]) -> Set` — LAST set.
- `follow_fragment(kind: FragmentKind) -> Set` — hard-coded follow set from Rust Reference.
- `follow(ops: &[MatcherOp]) -> Set` — FOLLOW of a sequence = intersection of `follow_fragment` for each non-epsilon LAST element.

Validation rules applied to each rule’s matcher:

1. **Successive token-tree invariant.** For every `... tt uu ...` where `uu` is non-empty:  
   `follow(tt).union({epsilon}) ⊇ first(uu)`.
2. **Separated repetition invariant.** For `$(tt ...) SEP OP ...`:  
   `SEP ∈ follow(tt ...)`.
3. **Unseparated repetition invariant.** For `$(tt ...) OP ...` where `OP ∈ {*, +}`:  
   `follow(tt ...) ⊇ first(tt ...) \ {epsilon}`.

For attribute/derive rules, validation runs on both `attr_args` and `matcher` independently.

#### 4.3.3 Fragment capture delimiter (known limitation)

The matcher engine currently consumes fragment nonterminals (`expr`, `ty`, `pat`, etc.) until it reaches a token that is either in the fragment's follow set or a comma. This means comma is treated as a universal separator for fragment capture, even though an `expr` fragment could legitimately contain a comma (e.g., a tuple expression `1, 2`).

This is a deliberate simplification for Phase 2: it makes `$( $x:expr ),*` work correctly and matches the common case, but it cannot distinguish a comma *inside* an expression from a comma *after* an expression. A future phase will replace comma-separated fragment capture with proper follow-set-driven capture (consume until a follow-set token is seen), which will allow tuple expressions inside `expr` fragments without ambiguity.

### 4.4 Trailing separators

Change `consume_repetition` in `engine.rs`:

For `*` and `+` repetitions with a separator `SEP`:
- After matching the last element, if the next token is `SEP` and the token after that is not a valid continuation of the element, consume the trailing `SEP` and stop.
- More concretely: after a successful element match, look ahead; if `SEP` is present and the following element match fails, accept the trailing `SEP` and finish the repetition.

This is implemented in `match_repeat` without backtracking beyond one element lookahead.

### 4.5 Metavariable expressions

#### 4.5.1 Parsing

In `parse_transcriber_seq`, when `$` is followed by `{`, parse a metavariable expression:

```text
${ count ( ident ) }
${ count ( ident , 0 ) }
${ index ( ) }
${ index ( 1 ) }
${ len ( ) }
${ len ( 1 ) }
${ ignore ( ident ) }
$$                                          // not inside ${ }, parsed as two `$` terminals
```

`$$` in the transcriber is stored as `TranscriberOp::DollarDollar` and expands to a single `Punct('$')` token.

#### 4.5.2 Repetition context

`transcribe` tracks a stack of active repetition frames:

```rust
struct RepeatFrame {
    index: usize,
    len: usize,
}
```

For nested repetitions, a frame is pushed each time a repetition body is entered, so the inner-most context is at the top of the stack. `depth` counts outward from the top:
- `index()` / `len()` with `depth = 0` → top of stack (inner-most).
- `index(1)` / `len(1)` → one step down (next outer).

`count` uses the same repetition-frame stack but reads it in the opposite direction for its depth argument: depth 0 is the outermost layer, matching the intuition that `${count(x, 0)}` asks “how many top-level repetitions of `$x` are there?”.

#### 4.5.3 Evaluating expressions

During transcription at iteration `i` of the inner-most repetition:

- `${count(x)}` — total number of leaf captures of `$x` across all nesting depths.
- `${count(x, d)}` — number of direct children of `$x` at depth `d` outward from the outermost repetition (depth 0 = outermost layer).
- `${index()}` → current `i` (inner-most).
- `${index(d)}` → index at depth `d` outward from inner-most.
- `${len()}` → length of inner-most repetition.
- `${len(d)}` → length at depth `d` outward from inner-most.
- `${ignore(x)}` → expands to nothing; used when `$x` is captured only to drive repetition counting.
- `$$` → literal `$` token.

All integer results expand to an unsuffixed integer literal token.

### 4.6 Interaction with attribute/derive rules

- Follow-set validation runs on `attr_args` matchers and `matcher` matchers separately.
- Trailing separators work in attribute arguments (e.g. `@derive(A, B,)`).
- Metavariable expressions work in attribute/derive transcribers.

## 5. Implementation plan / checklist

### 5.1 Follow-set validation

- [x] Create `yelang-macro/src/matcher/follow.rs`.
- [x] Define `TokenClass`, `first`, `last`, `follow_fragment`, `follow`.
- [x] Implement `validate_rule` applying the three invariants.
- [x] Call `validate_rule` from `parse_rules` after each rule is parsed.
- [x] Add unit tests for FIRST/LAST/FOLLOW computation.
- [x] Add definition-time error tests for each fragment specifier.

### 5.2 Trailing separators

- [x] Modify `match_repeat` in `engine.rs` to accept one trailing separator for `*`/`+`.
- [x] Ensure `?` is unchanged (no separator allowed).
- [x] Add tests for trailing comma, semicolon, and other separators.
- [x] Add tests ensuring non-trailing behavior still works.

### 5.3 Metavariable expressions

- [x] Extend `TranscriberOp` with `MetavarExpr` and `DollarDollar`.
- [x] Extend `parse_transcriber_seq` to parse `${...}` and `$$`.
- [x] Extend `transcribe` to track repetition contexts and iteration indices.
- [x] Implement evaluation for `count`, `index`, `len`, `ignore`, `$$`.
- [x] Add unit tests for each expression in isolation.
- [x] Add integration tests for nested repetitions.
- [x] Add integration tests for macros that emit macros (`$$`).

### 5.4 Integration and verification

- [x] Ensure `#![deny(...)]` in `lib.rs` remains satisfied.
- [x] Run `cargo fmt -p yelang-macro` and `cargo fmt --check -p yelang-macro`.
- [x] Run `cargo test -p yelang-macro`.
- [x] Run `cargo test --workspace --exclude yelang-tycheck --exclude yelang-infer --exclude yelang-trait-solver`.
- [x] Update `notes/architectures/macro_system_completeness_design.md` Phase 2 checklist.

## 6. Exhaustive test plan

A new test file `yelang-macro/tests/declarative_macros_phase2.rs` will cover:

### 6.1 Follow-set tests

| Test | Expected |
|------|----------|
| `expr_followed_by_comma_is_legal` | no error |
| `expr_followed_by_lbracket_is_illegal` | definition-time `FollowSetViolation` |
| `pat_followed_by_pipe_is_illegal` | definition-time error (modern Rust 2021 `pat` set excludes `\|`) |
| `pat_followed_by_comma_is_legal` | no error |
| `ty_followed_by_colon_is_legal` | no error |
| `ty_followed_by_minus_is_illegal` | definition-time error |
| `tt_followed_by_anything_is_legal` | no error |
| `separated_repetition_separator_in_follow_set` | no error |
| `separated_repetition_separator_not_in_follow_set` | definition-time error |
| `unseparated_star_tt_can_follow_itself` | no error for `tt` |
| `unseparated_star_expr_cannot_follow_itself` | definition-time error for `expr` |
| `complex_matcher_follow_set_nested_repetition_valid` | verify nested repetition validity |

### 6.2 Trailing separator tests

| Test | Expected |
|------|----------|
| `trailing_comma_in_star` | matches empty and non-empty with trailing comma |
| `trailing_comma_in_plus` | matches one+ elements with optional trailing comma |
| `trailing_semicolon_in_star` | works with `;` separator |
| `no_trailing_separator_still_works` | unchanged behavior |
| `trailing_separator_with_empty_star_rejected` | `list!(,)` emits match error |
| `double_trailing_separator_rejected` | `list!(1, 2, 3,,)` emits match error |
| `trailing_separator_in_attribute_args` | `@derive(A, B,)` works |

### 6.3 Metavariable expression tests

| Test | Expected |
|------|----------|
| `count_total_repetitions` | `${count(x)}` expands to `3` for `a, b, c` |
| `count_total_nested_repetitions` | `${count(x)}` sums across nested depths |
| `count_with_depth_outer` | `${count(x, 1)}` gives inner repetition count |
| `count_with_depth_inner_sum` | `${count(x, 0)}` gives outer repetition count |
| `index_in_inner_repetition` | expands to `0`, `1`, `2`, ... |
| `index_at_outer_depth` | `${index(1)}` tracks outer loop index |
| `len_in_inner_repetition` | expands to total inner length |
| `len_at_outer_depth` | `${len(1)}` expands to outer length |
| `ignore_expands_to_nothing` | repeats without emitting `$x` |
| `nested_mixed_index_len_count` | complex nested expression correctness |
| `metavar_expr_in_attribute_transcriber` | `${count(x)}` works in attribute macro output |

### 6.4 Negative / regression tests

| Test | Expected |
|------|----------|
| `unknown_metavar_expr_errors` | invalid `${foo(x)}` |
| `count_of_unbound_metavar_errors` | `${count(y)}` when `y` not in scope |
| `index_outside_repetition_errors` | `${index()}` with no repetition context |
| `len_outside_repetition_errors` | `${len()}` with no repetition context |

### 6.5 Unit tests added

- `yelang-macro/src/matcher/follow.rs`: `terminal_has_no_follow_restriction`, `pat_follow_excludes_pipe`, `pat_follow_allows_comma`.
- `yelang-macro/src/transcribe.rs`: `transcribe_dollar_dollar_escapes_to_literal_dollar`.

## 7. Open questions resolved

1. **Follow-set strictness for `pat`:** Use the modern Rust 2021+ set (no `\|`). Resolved.
2. **`vis` fragment:** Yelang does not currently have a `vis` fragment specifier. Skipped until added.
3. **`count` default depth:** No-argument `count(x)` returns the total leaf capture count. The explicit depth form counts outward from the outermost repetition.
4. **Trailing separator in `?`:** `?` cannot have a separator. Kept as restriction.

## 8. Completion notes

Phase 2 is complete as of the date in the workspace. All checklist items are done, all tests pass, and the crate remains warning-free under its configured lints. The only known limitation carried forward is comma-separated fragment capture (see §4.3.3), which will be addressed when expansion positions and full parser integration are implemented.

## 9. References

- [Rust Reference — Macros by example](https://doc.rust-lang.org/reference/macros-by-example.html)
- [Rust Reference — Macro follow-set ambiguity formal specification](https://doc.rust-lang.org/reference/macro-ambiguity.html)
- [RFC 550 — macro future-proofing](https://github.com/rust-lang/rfcs/blob/master/text/0550-macro-future-proofing.md)
- [RFC 3086 — macro metavariable expressions](https://rust-lang.github.io/rfcs/3086-macro-metavar-expr.html)
- [The Little Book of Rust Macros — Metavariable Expressions](https://lukaswirth.dev/tlborm/decl-macros/minutiae/metavar-expr.html)
- [The Little Book of Rust Macros — Trailing separators](https://danielkeep.github.io/tlborm/book/pat-trailing-separators.html)
