
# COMPLETE TYPE SYSTEM & TRAIT SOLVER PACKAGE

This package contains everything needed to implement a Rust-like type system
with next-generation trait solving, for a language without lifetimes but with
HRTB (higher-ranked trait bounds) for type parameters.

## Files

1. **type_system_design_document.md** — Exhaustive design document covering:
   - Design philosophy and goals
   - Complete type representation (TyKind)
   - Variable taxonomy (Param, Infer, Bound, Placeholder, Canonical)
   - Binders and De Bruijn indices
   - Placeholders and universes
   - TyCtxt (global type context)
   - Inference engine
   - Canonicalization
   - Next-gen trait solver algorithm
   - HIR type checker
   - Coherence
   - Well-formedness
   - Variance
   - Complete file tree
   - Algorithm reference
   - Syntax mapping

2. **type_system_complete_impl.rs** — Full Rust reference implementation:
   - Interner trait and infrastructure
   - All type kinds and variables
   - Binder<T> with De Bruijn indices
   - Placeholder with universe indices
   - Unification table (union-find)
   - InferCtxt with snapshot/rollback
   - Canonicalization
   - EvalCtxt (next-gen solver)
   - FnCtxt (HIR type checker)
   - Coherence checker
   - Variance solver

3. **syntax_examples_complete.md** — Annotated syntax examples:
   - Simple generic function (no HRTB)
   - Function pointer with HRTB (single param)
   - Function pointer with HRTB (multiple params)
   - Nested HRTB
   - HRTB in where clause
   - Skolemization walkthrough
   - Universe soundness check
   - Trait object with HRTB
   - Associated type normalization
   - Complete type checking walkthrough
   - Coherence check
   - Variance inference

## Architecture Overview

```
User Syntax → HIR → Type Lowering → InferCtxt → Canonicalization → 
Solver (EvalCtxt) → Response → Instantiation → TypeckResults
```

## Key Design Decisions

| Feature | Decision |
|---------|----------|
| Lifetimes | Omitted (no borrow checker) |
| HRTB for types | Included (`#![feature(non_lifetime_binders)]` exists in rustc nightly) |
| De Bruijn indices | Included (required for nested binders) |
| Universe indices | Included (required for placeholder soundness) |
| Next-gen solver | Included (goal-driven, canonical, cacheable) |
| Coherence | Included (overlap detection) |
| Variance | Included (subtyping support) |

## Variable Types Summary

| Name | Symbol | Quantifier | Created By | Can Unify? |
|------|--------|------------|------------|------------|
| Param | T | Universal (early-bound) | Parser | No |
| Infer | ?0 | Existential | Type checker | Yes |
| Bound | ^0_1 | — (inside Binder) | Binder construction | No (replaced) |
| Placeholder | !1_0 | Universal (late-bound) | Solver (skolemization) | No |
| Canonical | ∃0 / ∀0 | Existential / Universal | Canonicalizer | N/A |

## Core Concepts

### Binder<T>
A scope wrapper that introduces bound variables. Example: `for<T> fn(T) -> T`
is `Binder<FnSig>` with `bound_vars: [Ty]`.

### De Bruijn Index
A number counting how many `Binder` wrappers to skip outward. 
`DebruijnIndex(0)` = nearest binder, `DebruijnIndex(1)` = one binder outward.

### BoundVar
A `u32` identifying which parameter in a binder's `bound_vars` list.
`BoundVar(0)` = first param, `BoundVar(1)` = second param.

### Placeholder
A skolemized variable: a fresh constant representing "some arbitrary value."
Has a `UniverseIndex` to prevent escaping its scope.

### Skolemization
Replacing `for<T>` with a placeholder `!U_B` to prove properties about all T
by proving them for an arbitrary constant.

### Universe Index
A nesting level: U0 = root, U1 = one binder deep, U2 = two binders deep.
Prevents placeholders from unifying with things from outer scopes.

## Solver Algorithm

```
EVALUATE_GOAL(goal):
  canonical = CANONICALIZE(goal)
  if canonical in cache: return cache[canonical]
  if canonical in search_graph: return MAYBE (cycle)

  push onto search_graph
  instantiate canonical into local infcx
  candidates = ASSEMBLE_CANDIDATES(goal)

  responses = []
  for candidate in candidates:
    snapshot = infcx.snapshot()
    result = EVALUATE_CANDIDATE(candidate)
    if result == SUCCESS: responses.append(result)
    else: infcx.rollback(snapshot)

  pop from search_graph
  response = MERGE_RESPONSES(responses)
  if response.certainty == YES: cache[canonical] = response
  return response
```

## Next Steps for Implementation

1. Implement the interner and TyCtxt
2. Implement the unification table
3. Implement the inference context
4. Implement canonicalization
5. Implement the trait solver (EvalCtxt)
6. Implement the HIR type checker (FnCtxt)
7. Implement coherence checking
8. Implement variance inference
9. Wire everything together in the compiler driver

## References

- rustc-dev-guide: https://rustc-dev-guide.rust-lang.org/
- RFC 0387 (HRTB): https://rust-lang.github.io/rfcs/0387-higher-ranked-trait-bounds.html
- Issue #108185 (non_lifetime_binders): https://github.com/rust-lang/rust/issues/108185
- PR #107489 (implementation): https://github.com/rust-lang/rust/pull/107489
