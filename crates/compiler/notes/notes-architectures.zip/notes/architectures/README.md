# Yelang Architecture Notes

> **Current direction (2026-07-17):** The compiler no longer includes user-defined macros (declarative or procedural). The macro implementation was archived to `archive/proc-macro-full` and removed from `main`. The active direction is:
>
> 1. **Built-in attributes/derives** implemented as compiler intrinsics (`Copy`, `Clone`, `Debug`, `Eq`, `PartialEq`, `test`, `repr`, etc.).
> 2. **`comptime`** as the future mechanism for user-defined compile-time code generation.
>
> See `adr_no_user_defined_macros.md` for the decision record.

## Active documents

- `adr_no_user_defined_macros.md` — decision record for removing user-defined macros.

## Historical documents

All `macro_*` and `phase_7_*` documents describe the removed macro system. They are preserved for reference and because the full implementation exists on `archive/proc-macro-full`. Do not treat them as the active plan.

## Related research

- `comptime_design.md` / `comptime_checklist.md` — future compile-time execution design.
