# Macro System Phase 4 Checklist

## Goal
Add first-class statement-position macro invocations so that `foo! { ... }` at
statement position can expand to statements, items, or multiple statements,
while keeping `foo!()` and `foo![]` as expression macros per RFC 378.

## Research and design

- [x] Review RFC 378 (expr-macros) delimiter rule
- [x] Review Rust Reference macros-by-example statement/item expansion rules
- [x] Review rustc issue #61733 (token-based vs AST-based expansion)
- [x] Write Phase 4 design doc
- [x] Write Phase 4 checklist

## AST changes

- [x] Add `StmtKind::MacroInvocation(MacroInvocation)` variant
- [x] Update `Stmt` parser to detect `path!{}` at statement start
- [x] Keep `path!()` / `path![]` as expression statements (existing behavior)

## Codegen / traversal

- [x] Update `codegen` for `StmtKind::MacroInvocation`
- [x] Update `visit/walk` for `StmtKind::MacroInvocation`
- [x] Update `visit/fold` for `StmtKind::MacroInvocation`

## Macro expansion engine

- [x] Add `parse_stmts_from_token_stream` fragment re-parser
- [x] Change `expand_stmt` signature to `(Vec<Stmt>, bool)`
- [x] Implement expansion of `StmtKind::MacroInvocation`:
  - [x] Expand to token stream
  - [x] Parse into `Vec<Stmt>`
  - [x] Recursively expand each statement
  - [x] Return flattened vector
- [x] Update `expand_block_expr` to flatten statement vectors
- [x] Update all callers of `expand_stmt` to handle vectors

## Downstream compiler pipeline

- [x] `yelang-resolve` ignores residual `StmtKind::MacroInvocation`
- [x] `yelang-hir` skips residual `StmtKind::MacroInvocation`

## Tests

- [x] Create `yelang-macro/tests/declarative_macros_phase4.rs`
- [x] Statement macro expands to `let` binding
- [x] Statement macro expands to expression statement
- [x] Statement macro expands to block-local item
- [x] Statement macro expands to multiple statements
- [x] Statement macro inside `if` body
- [x] Statement macro inside `match` arm body
- [x] Statement macro inside `loop` body
- [x] Statement macro inside closure body
- [x] Nested statement macro expansion
- [x] Delimiter rule: `foo!{}` vs `foo!()` / `foo![]`
- [x] Error: unknown statement macro
- [x] Error: statement macro producing invalid output
- [x] Error: expression macro at statement position producing invalid expression

## Verification

- [x] `cargo fmt`
- [x] `cargo test -p yelang-ast` passes
- [x] `cargo test -p yelang-macro` passes
- [x] `cargo test` (workspace) passes
