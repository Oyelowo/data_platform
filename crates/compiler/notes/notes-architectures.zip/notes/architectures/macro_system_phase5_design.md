# Macro System Phase 5 Design: Eager Expansion of Built-in Macros

## 1. Goal

Implement **eager expansion** for the built-in macros that require their arguments to be literals (or other eagerly-expandable macros) before the surrounding macro expansion can proceed:

- `concat!(...)` — concatenate string/char/integer/float/boolean literals into one string literal.
- `stringify!(...)` — turn an arbitrary token tree into a string literal.
- `include!("path")` — splice the contents of another Yelang source file into the invocation site.
- `include_str!("path")` — include a file as a string literal.
- `include_bytes!("path")` — include a file as a byte-array literal.
- `env!("VAR")` — read an environment variable as a string literal.
- `option_env!("VAR")` — read an environment variable as `Option<&str>`.
- `compile_error!("msg")` — emit a compiler error.
- `cfg!(...)` — evaluate a `cfg` predicate to a boolean literal.

Eager expansion is a prerequisite for idiomatic patterns such as:

```yelang
include!(concat!(env!("OUT_DIR"), "/generated.rs"));
```

Without it, `concat!` and `env!` would be ordinary expression macros and could not feed `include!`.

## 2. Research and design rationale

### 2.1 Why some builtins are eager

Rust distinguishes **eager** from **lazy** built-in macros. Lazy macros (`panic!`, `assert!`, `format!`, `todo!`, `unreachable!`) expand at the normal macro-expansion site and may contain arbitrary expressions. Eager macros must have fully resolved literal arguments because their result is consumed by the *next* expansion step (e.g., `include!` needs a path string, `concat!` needs literals to assemble a new literal).

Reference: rust-analyzer's `hir_expand/builtin/fn_macro.rs` splits built-ins into `BuiltinFnLikeExpander` and `EagerExpander` ([source](https://rust-lang.github.io/rust-analyzer/src/hir_expand/builtin/fn_macro.rs.html)).

### 2.2 Greenfield hindsight

- **Don't make eager macros special-case expression macros.** In a legacy design, `concat!` could be implemented as an expression macro that returns a string literal. That works for `let s = concat!("a", "b");` but fails for `include!(concat!(...))`. Eager expansion must be a property of the macro, not an implementation detail.
- **Inject file-system and environment access.** Hard-coding `std::fs::read` and `std::env::var` makes unit tests flaky and prevents deterministic cross-platform testing. We define small traits (`FileLoader`, `EnvProvider`) and pass them into the expander.
- **Expand eagerly inside captured token trees.** When a declarative macro captures `$e:expr`, the captured tokens may themselves contain `concat!(...)` or `env!(...)`. The fragment parser must run eager expansion on the captured token stream before parsing the fragment.
- **Keep one token-tree system.** Eager expansion operates on `yelang-macro-core::token_tree::TokenStream`, the same representation used by declarative macros. There is no separate "eager AST".

## 3. Lazy vs eager builtin classification

| Macro | Kind | Output fragment | Notes |
|-------|------|-----------------|-------|
| `assert!` | lazy | expr | Already implemented |
| `assert_eq!` | lazy | expr | Already implemented |
| `assert_ne!` | lazy | expr | Already implemented |
| `panic!` | lazy | expr | Already implemented |
| `todo!` | lazy | expr | Already implemented |
| `unreachable!` | lazy | expr | Already implemented |
| `format!` | lazy | expr | Already implemented |
| `concat!` | **eager** | literal string | New |
| `concat_bytes!` | **eager** | literal byte array | New |
| `stringify!` | **eager** | literal string | New |
| `include!` | **eager** | token tree (items/expr) | New |
| `include_str!` | **eager** | literal string | New |
| `include_bytes!` | **eager** | literal byte array | New |
| `env!` | **eager** | literal string | New |
| `option_env!` | **eager** | expr (`Option<&str>`) | New |
| `compile_error!` | **eager** | error | New |
| `cfg!` | **eager** | literal bool | New |

## 4. Dependency-injection traits

### 4.1 `FileLoader`

```rust
pub trait FileLoader {
    /// Resolve a path relative to the current source file and return the absolute path.
    fn resolve_path(&self, relative_to: &std::path::Path, path: &str) -> Option<std::path::PathBuf>;

    /// Read the entire file as UTF-8 text.
    fn read_to_string(&self, path: &std::path::Path) -> Result<String, std::io::Error>;

    /// Read the entire file as raw bytes.
    fn read_to_bytes(&self, path: &std::path::Path) -> Result<Vec<u8>, std::io::Error>;
}
```

Default implementation uses `std::fs`. Tests provide an in-memory loader keyed by absolute path.

### 4.2 `EnvProvider`

```rust
pub trait EnvProvider {
    fn var(&self, key: &str) -> Option<String>;
}
```

Default implementation uses `std::env::var_os`. Tests provide a deterministic map.

## 5. Eager expansion engine

### 5.1 Core function

```rust
pub fn expand_eager_macros_in_stream(
    stream: &TokenStream,
    ctx: &EagerContext,
) -> Result<TokenStream, ExpandError>
```

The engine walks the token tree. When it sees a macro invocation whose path resolves to an eager builtin, it:

1. Recursively expands eager macros in the invocation's argument token stream.
2. Validates the arguments (e.g., `concat!` only accepts literals; `include!` accepts one string literal).
3. Executes the builtin (reads file, reads env, concatenates, etc.).
4. Replaces the invocation with the resulting token tree.
5. Continues until no eager invocations remain.

### 5.2 Eager builtin dispatch

```rust
pub enum EagerBuiltin {
    Concat,
    ConcatBytes,
    Stringify,
    Include,
    IncludeStr,
    IncludeBytes,
    Env,
    OptionEnv,
    CompileError,
    Cfg,
}
```

`EagerBuiltin::from_path(path, interner)` returns `Some(...)` for the names above.

### 5.3 `EagerContext`

```rust
pub struct EagerContext<'a> {
    pub interner: &'a Interner,
    pub file_loader: &'a dyn FileLoader,
    pub env_provider: &'a dyn EnvProvider,
    pub current_file: Option<&'a std::path::Path>,
    pub cfg_options: &'a CfgOptions,
}
```

`current_file` is needed to resolve relative paths for `include!` / `include_str!` / `include_bytes!`.

### 5.4 Integration with the main expander

The main `MacroExpander` owns a `EagerContext`. It runs eager expansion at these points:

1. **Before parsing a captured fragment.** `expect_fragment` / `parse_expr_from_token_stream` / `parse_type_from_token_stream` / etc. call `expand_eager_macros_in_stream` first. This ensures `concat!(...)` inside `$e:expr` is resolved before `Expr::parse` runs.
2. **Before expanding an eager builtin.** `expand_builtin_macro` first runs eager expansion on the invocation's arguments; if the builtin itself is eager, it executes directly and returns the resulting AST literal or error.
3. **On the output of a declarative macro.** If a user macro expands to `concat!("a", "b")`, the recursive expansion step will pick it up again because `expand_expr` / `expand_stmt` / etc. re-run eager expansion on the parsed result before returning.

This three-point integration avoids an expensive whole-program pre-pass while guaranteeing that eager macros are resolved wherever literals are required.

## 6. Individual builtin semantics

### 6.1 `concat!(lit0, lit1, ...)`

Accepted literals (per Rust Reference and rust-analyzer):

- String literals (`"foo"`) — unescaped content is concatenated.
- Character literals (`'a'`) — single character appended.
- Integer literals (`42`, `0x2A`) — decimal text appended.
- Floating-point literals (`3.14`) — text appended.
- Boolean identifiers (`true`, `false`) — text appended.
- Negative numbers: `-42`, `-3.14`.

Result is a single string literal token. Errors:

- Non-literal token.
- Missing comma or unexpected comma position.
- Byte-string / byte-character literals (Rust rejects these in `concat!`; we do the same).

### 6.2 `concat_bytes!(lit0, lit1, ...)`

Accepted literals:

- Byte literals (`b'a'`).
- Byte string literals (`b"foo"`).
- Arrays of byte literals (`[b'a', b'b']`).
- Integer literals in `u8` range.

Result is a single byte-string literal token.

### 6.3 `stringify!(tokens...)`

Captures the entire argument token tree (including delimiters) and returns a string literal containing the tokens rendered with a canonical spacing. For deterministic output, use the same renderer as `TokenStream::render` but with normalized whitespace.

### 6.4 `include!("path")`

Reads the file, tokenizes it, and returns the token stream. The tokens are then parsed by the caller according to the invocation context (items, expression, etc.). If the included file itself contains eager macros, they will be expanded in the next iteration.

Errors:

- Path is not a string literal.
- File not found or unreadable.
- Recursive self-inclusion.

### 6.5 `include_str!("path")`

Reads the file as UTF-8 and returns a string literal. Raw string form is used if the content contains characters that would require escaping.

### 6.6 `include_bytes!("path")`

Reads the file as bytes and returns a byte-array literal (`[u8; N]`). Alternatively, a byte-string literal if the content is valid UTF-8 (Rust uses byte arrays; we follow Rust for consistency).

### 6.7 `env!("VAR")`

Returns a string literal. If the variable is unset, emits an error.

### 6.8 `option_env!("VAR")`

Returns `Option<&str>::None` or `Option<&str>::Some("value")` as AST tokens. Implemented by producing a token stream that parses as the appropriate expression.

### 6.9 `compile_error!("msg")`

Emits an `ExpandError` with the given message. The result is an empty token stream.

### 6.10 `cfg!(predicate)`

Parses a `cfg` predicate (e.g., `cfg!(unix)`, `cfg!(feature = "foo")`, `cfg!(all(not(unix), feature = "bar"))`), evaluates it against `CfgOptions`, and returns `true` or `false` as an identifier token.

## 7. File tree

```
yelang-macro/src/
  builtin_macros.rs            # split into lazy and eager sections; add EagerBuiltin
  eager.rs                     # NEW: expand_eager_macros_in_stream, EagerContext, builtin impls
  expander.rs                  # wire EagerContext into MacroExpander; call eager expansion before fragment parsing
  lib.rs                       # re-export EagerBuiltin, EagerContext, FileLoader, EnvProvider

yelang-macro/tests/
  declarative_macros_phase5.rs # NEW: eager expansion integration tests

yelang-macro-core/src/
  token_tree/
    mod.rs                     # ensure TokenStream iteration supports eager walking
```

## 8. Checklist

See `notes/architectures/macro_system_phase5_checklist.md`.

## 9. Testing strategy

Add `yelang-macro/tests/declarative_macros_phase5.rs` covering:

1. `concat!("a", "b")` → `"ab"`.
2. `concat!("a", 'b', 1, true, -5)` → `"ab1true-5"`.
3. `concat!()` → `""`.
4. `concat!("a", , "b")` errors.
5. `stringify!(1 + 2)` → `"1 + 2"`.
6. `stringify!({ let x = 1; })` → `"{ let x = 1; }"`.
7. `include!("fixtures/included.rs")` splices items.
8. `include!(concat!("fixtures/include", "d.rs"))` works.
9. `include_str!("fixtures/hello.txt")` → `"hello\n"`.
10. `include_bytes!("fixtures/hello.txt")` → byte array.
11. `env!("YELANG_TEST_VAR")` with deterministic `EnvProvider`.
12. `option_env!("YELANG_TEST_VAR")` → `Some("value")`; unset → `None`.
13. `compile_error!("stop")` emits error.
14. `cfg!(feature = "foo")` with matching `CfgOptions`.
15. Nested eager: `include!(concat!(env!("OUT_DIR"), "/x.rs"))`.
16. Eager macro inside captured fragment: `macro m { ($e:expr) => { $e } }; m!(concat!("a","b"))`.
17. File-not-found errors for include/include_str/include_bytes.
18. Recursive include detection.
19. `concat_bytes!(b'a', [b'b', b'c'])`.
20. `concat!` rejects byte strings.

## 10. Future work

- `line!`, `column!`, `file!`, `module_path!` (source-location macros; require span-to-source mapping).
- `trace_macros!`, `log_syntax!` (debugging macros).
- `format_args!`, `const_format_args!` (lower to a builtin HIR node rather than expanding to a call).
- cfg-driven item removal (`#[cfg(...)]`) integrates with the attribute system, not just `cfg!`.
