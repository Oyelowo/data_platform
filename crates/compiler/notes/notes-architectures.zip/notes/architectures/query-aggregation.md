 
 
Here is the complete architecture: **no hardcoded methods**, **storage-aware polymorphism via traits + capabilities**, **accumulator-based distributed aggregation**, and a **unified memory model** that avoids both `Box`/`Rc` ceremony and GC complexity.

---

## 1. Storage-Aware Polymorphism: One Trait, Multiple Backends

The key insight from DryadLINQ  and the Volcano model  is that the **same logical operator** (Scan, Map, Aggregate) compiles to different physical plans based on where the data lives. Your language should not have `StorageIterator` vs `MemoryIterator`. It should have **one trait** with **backend-dispatching implementations**.

### The Unified Trait

```rust
// core/queryable.fl
// This is the ONLY trait users see. No storage-specific traits.

trait Queryable<T> {
    // --- Transformations (lazy, structural) ---
    fn map<U>(self, f: impl Fn(T) -> U) -> impl Queryable<U>;
    fn filter(self, pred: impl Fn(&T) -> bool) -> impl Queryable<T>;
    fn flat_map<U>(self, f: impl Fn(T) -> impl Queryable<U>) -> impl Queryable<U>;
    
    // --- Aggregations (eager, but the trait doesn't know distributed vs local) ---
    fn fold<U>(self, init: U, f: impl Fn(U, T) -> U) -> U;
    fn reduce(self, f: impl Fn(T, T) -> T) -> Option<T>;
    
    // These are SUGAR that lower to fold/reduce with registered shapes
    fn sum(self) -> T where T: Add;
    fn count(self) -> usize;
    fn avg(self) -> f64 where T: Numeric;
    fn group_by<K>(self, key: impl Fn(&T) -> K) -> impl Queryable<Group<K, T>>;
    
    // --- Execution control ---
    fn execute(self) -> Vec<T>;  // Force materialization
}
```

### How Different Backends Implement It

```rust
// ============================================
// BACKEND 1: In-Memory Vector (embedded)
// ============================================

struct VecQueryable<T> {
    data: Vec<T>,
    pos: usize,
}

impl<T> Queryable<T> for VecQueryable<T> {
    fn map<U>(self, f: impl Fn(T) -> U) -> impl Queryable<U> {
        // Returns a lazy Map iterator
        MapIter { source: self, f }
    }
    
    fn filter(self, pred: impl Fn(&T) -> bool) -> impl Queryable<T> {
        FilterIter { source: self, pred }
    }
    
    fn fold<U>(self, init: U, f: impl Fn(U, T) -> U) -> U {
        let mut acc = init;
        for item in self {
            acc = f(acc, item);
        }
        acc
    }
    
    fn sum(self) -> T where T: Add {
        self.fold(T::zero(), |a, b| a + b)
    }
    
    fn execute(self) -> Vec<T> {
        self.collect()
    }
}

// ============================================
// BACKEND 2: LSM Storage Engine (embedded scan)
// ============================================

struct LsmQueryable<K, V> {
    cursor: LsmCursor,
    snapshot: Snapshot,
}

impl<K, V> Queryable<(K, V)> for LsmQueryable<K, V> {
    fn map<U>(self, f: impl Fn((K, V)) -> U) -> impl Queryable<U> {
        // Same lazy Map, but source is storage cursor
        MapIter { source: self, f }
    }
    
    fn fold<U>(self, init: U, f: impl Fn(U, (K, V)) -> U) -> U {
        let mut acc = init;
        while let Some((k, v)) = self.cursor.next() {
            acc = f(acc, (k, v));
        }
        acc
    }
    
    // sum() inherits default from trait (fold-based)
    // But the optimizer can rewrite this to a storage-native scan
}

// ============================================
// BACKEND 3: Distributed Shard (remote)
// ============================================

struct DistributedQueryable<T> {
    shard_key: Expr,           // How data is partitioned
    nodes: Vec<NodeId>,
    plan_fragment: LogicalPlan, // What to execute on each node
}

impl<T> Queryable<T> for DistributedQueryable<T> {
    fn map<U>(self, f: impl Fn(T) -> U) -> impl Queryable<U> {
        // Push map to each shard, return distributed result
        DistributedQueryable {
            shard_key: self.shard_key,
            nodes: self.nodes,
            plan_fragment: LogicalPlan::Map {
                input: Box::new(self.plan_fragment),
                projection: f,
            },
        }
    }
    
    fn fold<U>(self, init: U, f: impl Fn(U, T) -> U) -> U {
        // DISTRIBUTED: partial fold per node, then merge
        let partials: Vec<U> = self.nodes.map(|node| {
            node.execute(LogicalPlan::Fold {
                input: self.plan_fragment.clone(),
                init: init.clone(),
                combine: f,
            })
        });
        
        // Merge partials locally
        partials.into_iter().fold(init, |a, b| merge_fold(a, b, f))
    }
    
    fn sum(self) -> T where T: Add {
        // DISTRIBUTED: partial sum per node, then sum of sums
        let partials: Vec<T> = self.nodes.map(|node| {
            node.execute(LogicalPlan::Aggregate {
                input: self.plan_fragment.clone(),
                agg: Aggregation::Sum,
                mode: AggregateMode::Partial,
            })
        });
        
        partials.into_iter().fold(T::zero(), |a, b| a + b)
    }
    
    fn execute(self) -> Vec<T> {
        // Gather all shards, concatenate
        self.nodes.flat_map(|node| node.execute(self.plan_fragment.clone()))
    }
}
```

**The user writes the same code regardless of backend:**

```rust
// This works for Vec, LSM, or Distributed — same syntax
let total = users.filter(u => u.age > 18).sum();
```

The type of `users` determines which `Queryable` impl runs. The compiler doesn't know about storage. It just type-checks trait methods.

---

## 2. Generalized Aggregation: The Accumulator Pattern

From DryadLINQ , the key to distributed aggregation is the **accumulator interface**: `Initialize`, `Iterate`, `Merge`. This is how the compiler knows an aggregation can be parallelized without hardcoding `sum` or `count`.

### The User-Defined Aggregate Trait

```rust
// core/aggregate.fl
// Users implement this for custom aggregates. The compiler recognizes it.

trait Aggregate<T, Acc, Out> {
    fn init() -> Acc;
    fn iterate(acc: Acc, value: T) -> Acc;
    fn merge(left: Acc, right: Acc) -> Acc;
    fn finalize(acc: Acc) -> Out;
    
    // CRITICAL: Tells the optimizer how this aggregate behaves
    fn classify() -> AggregateClass;
}

enum AggregateClass {
    Distributive,  // merge == iterate with init. Examples: sum, count, min, max
    Algebraic,     // Fixed-size Acc. Examples: avg (sum+count), stddev
    Holistic,      // Must see all data. Examples: median, percentile, mode
}
```

### Built-in Aggregates (Registered by Stdlib)

```rust
// stdlib/core/aggregate_impls.fl

// sum is Distributive: partial sums merge by addition
struct SumAcc<T> { value: T }

impl<T: Add + Zero> Aggregate<T, SumAcc<T>, T> for Sum {
    fn init() -> SumAcc<T> { SumAcc { value: T::zero() } }
    fn iterate(acc, value) { SumAcc { value: acc.value + value } }
    fn merge(a, b) { SumAcc { value: a.value + b.value } }
    fn finalize(acc) { acc.value }
    fn classify() -> Distributive;
}

// avg is Algebraic: partial = (sum, count), merge = add pairs, final = sum/count
struct AvgAcc<T> { sum: T, count: usize }

impl<T: Add + Div> Aggregate<T, AvgAcc<T>, f64> for Avg {
    fn init() -> AvgAcc<T> { AvgAcc { sum: T::zero(), count: 0 } }
    fn iterate(acc, value) { AvgAcc { sum: acc.sum + value, count: acc.count + 1 } }
    fn merge(a, b) { AvgAcc { sum: a.sum + b.sum, count: a.count + b.count } }
    fn finalize(acc) { acc.sum.to_f64() / acc.count as f64 }
    fn classify() -> Algebraic;
}

// percentile is Holistic: must collect all values
struct PercentileAcc<T> { values: Vec<T>, p: f64 }

impl<T: Ord> Aggregate<T, PercentileAcc<T>, T> for Percentile {
    fn init() -> PercentileAcc<T> { PercentileAcc { values: vec![], p: 0.5 } }
    fn iterate(acc, value) { acc.values.push(value); acc }
    fn merge(mut a, b) { a.values.extend(b.values); a }
    fn finalize(mut acc) { 
        acc.values.sort();
        acc.values[(acc.values.len() as f64 * acc.p) as usize]
    }
    fn classify() -> Holistic;
}
```

### How the User Uses It

```rust
// Surface syntax — just a method call
let avg_age = users.map(u => u.age).avg();

// Lowered to trait method:
let avg_age = Avg::aggregate(users.map(u => u.age));

// The compiler sees:
// - `avg()` is a trait method on `Queryable<T>`
// - It resolves to `Avg::aggregate` which implements `Aggregate<T, AvgAcc<T>, f64>`
// - `classify()` returns `Algebraic`
// - The distributed backend uses this to generate partial + merge plan
```

### The `@register_aggregate` Decorator (Sugar)

```rust
// Instead of manual trait impl, user can write:
@aggregate(class = Holistic)
fn percentile(values: Iterator<f64>, p: f64) -> f64 {
    let mut sorted = values.collect::<Vec<f64>>();
    sorted.sort();
    sorted[(sorted.len() as f64 * p) as usize]
}

// The decorator expands to:
// 1. Define PercentileAcc struct
// 2. impl Aggregate<f64, PercentileAcc<f64>, f64> for Percentile { ... }
// 3. Register in operator registry
```

---

## 3. How the Compiler Recognizes Aggregates (No Hardcoding)

The compiler has a **middle-layer pass** that pattern-matches trait method calls against the registry:

```rust
// middle/query_extractor.rs

fn extract_operator(expr: &Expr) -> Option<Operator> {
    match expr {
        // Pattern: Type::aggregate(collection) or collection.aggregate()
        Expr::Call(func, args) if is_aggregate_trait_method(func) => {
            let aggregate_def = resolve_aggregate(func)?;
            let input = extract_operator(&args[0])?;
            
            Some(Operator::Aggregate {
                input: Box::new(input),
                group_by: None,
                aggregation: Aggregation::UserDefined {
                    def_id: aggregate_def,
                    class: aggregate_def.classify(),  // Distributive/Algebraic/Holistic
                },
            })
        }
        
        // Pattern: collection.sum() — sugar for Sum::aggregate(collection)
        Expr::MethodCall(receiver, method, _) if is_registered_method(method) => {
            let (trait_id, method_id) = resolve_method(method)?;
            let pattern = registry.lookup(trait_id, method_id)?;
            let input = extract_operator(receiver)?;
            build_operator(pattern, input, args)
        }
        
        _ => None,
    }
}
```

**The compiler core never sees `sum`, `avg`, `percentile`.** It sees `Operator::Aggregate { aggregation: UserDefined { class: Distributive } }`.

---

## 4. Distributed Plan Generation Based on AggregateClass

```rust
// backend/distributed.rs

fn generate_distributed(plan: Operator, capabilities: &StorageCapabilities) -> PhysicalPlan {
    match plan {
        Operator::Aggregate { input, group_by: None, aggregation: UserDefined { class: Distributive, def_id } } => {
            // Two-phase: partial agg per shard, then merge
            PhysicalPlan::Exchange {
                input: Box::new(PhysicalPlan::Aggregate {
                    input: Box::new(generate_distributed(*input, capabilities)),
                    agg: Partial(def_id),
                }),
                merge: Box::new(PhysicalPlan::Aggregate {
                    input: Box::new(PhysicalPlan::Gather),
                    agg: Final(def_id),
                }),
            }
        }
        
        Operator::Aggregate { input, group_by: Some(key), aggregation: UserDefined { class: Distributive, def_id } } => {
            // Shuffle by key, then partial agg, then final agg
            PhysicalPlan::Exchange {
                input: Box::new(generate_distributed(*input, capabilities)),
                hash: Some(key),
                merge: Box::new(PhysicalPlan::Aggregate {
                    input: Box::new(PhysicalPlan::Aggregate {
                        input: Box::new(PhysicalPlan::Gather),
                        agg: Partial(def_id),
                    }),
                    agg: Final(def_id),
                }),
            }
        }
        
        Operator::Aggregate { input, aggregation: UserDefined { class: Algebraic, def_id }, .. } => {
            // Same as Distributive: partial + merge works because Acc is fixed-size
            generate_distributed(Operator::Aggregate {
                input,
                group_by: None,  // Algebraic can be handled like Distributive for merging
                aggregation: UserDefined { class: Distributive, def_id },  // reuse logic
            }, capabilities)
        }
        
        Operator::Aggregate { input, aggregation: UserDefined { class: Holistic, def_id }, .. } => {
            // Must gather ALL data to single node first
            PhysicalPlan::Aggregate {
                input: Box::new(PhysicalPlan::Gather {
                    input: Box::new(generate_distributed(*input, capabilities)),
                }),
                agg: Full(def_id),
            }
        }
        
        // Non-aggregate operators: push down or pipeline
        _ => generate_default(plan, capabilities),
    }
}
```

---

## 5. Memory Model: No Box, No Rc, No GC — Regions + Copy-on-Write

Based on the research , here's the pragmatic choice for an infrastructure language without borrow checking:

### The Unified Memory Model

| Construct | Semantics | Implementation |
|-----------|-----------|---------------|
| **Primitives** (`i32`, `f64`, `bool`) | `Copy` (implicit) | Stack or register |
| **Small structs** (< 64 bytes, no heap) | `Copy` by default | `memcpy` |
| **Large structs / collections** | `Share` (reference counted, CoW on mutation) | Non-atomic ref-count for single-threaded; atomic for cross-thread |
| **Closures** | `Share` | Capture environment by ref-count |
| **Query results** | `Arena` (region-allocated) | Bump allocator, freed when query completes |
| **Cross-request caches** | `Share` + explicit invalidation | Atomic ref-count |

### No `Box`, No `Rc` in User Code

```rust
// User writes:
let users = load_users();           // Share<Users> (ref-counted)
let filtered = users.filter(...);    // Share<FilterIter> (shares underlying users)
let total = filtered.sum();          // i32 (primitive, copied)

// Mutation triggers CoW:
let mut modified = users;            // Same refcount, share
modified[0].name = "Alice";          // Refcount > 1, so deep copy first
```

**Under the hood (MIR):**

```rust
// Generated for `let mut modified = users; modified[0].name = "Alice"`
%0 = load users                    // Share<Users>
%1 = rc_check %0                  // If refcount > 1:
%2 = cow_clone %0                 //   Deep copy to new allocation
%3 = store %2 -> modified         // Else: modify in place
%4 = field_write %3[0].name = "Alice"
```

### Why Not GC?

From the research :
- **Reference counting** gives deterministic destruction (critical for file handles, sockets, storage cursors)
- **GC pauses** are unacceptable for a database/storage engine
- **RC + CoW** is essentially "malloc/free with automatic bookkeeping" — no tracing, no generations
- **The compiler optimizes out most RC ops** via escape analysis (local variables don't need RC)

### Why Not `Box`/`Rc` in Surface Syntax?

They leak implementation details. Your language should have **one reference type** (`Share<T>`) that the compiler optimizes based on usage:
- Never escapes local scope → stack allocate
- Escapes but never cloned → unique heap (like Box)
- Escapes and cloned → ref-counted
- Cross-thread → atomic ref-counted

This is what Swift does with ARC, but without the `@escaping` complexity.

---

## 6. Complete File Tree

```
compiler/
├── src/
│   ├── core/                    # LAYER 1: Pure compiler
│   │   ├── parse/
│   │   ├── resolve/
│   │   ├── typeck/              # Type-checks trait methods normally
│   │   ├── hir/
│   │   ├── mir/                 # Includes cow_clone, rc_check ops
│   │   └── lib.rs
│   │
│   ├── query/                   # LAYER 2: Operator extraction
│   │   ├── mod.rs
│   │   ├── registry.rs          # (trait, method) -> OperatorShape
│   │   ├── extractor.rs         # Walk HIR, build operator tree
│   │   ├── plan.rs              # Operator enum (6 kinds)
│   │   ├── decorrelate.rs
│   │   └── optimize.rs
│   │
│   └── backend/                 # LAYER 3: Code generation
│       ├── mod.rs
│       ├── embedded.rs          # Iterator chains, in-memory
│       ├── storage.rs           # LSM scan, pushdown
│       ├── distributed.rs       # Exchange, partial/final agg
│       └── sql.rs               # SQL string generation
│
└── stdlib/
    ├── core/
    │   ├── queryable.fl         # Iterator/Queryable trait
    │   ├── aggregate.fl         # Aggregate trait + classify
    │   ├── share.fl             # Share<T> (unified reference type)
    │   ├── arena.fl             # Region allocator
    │   └── register.fl          # @register_operator, @aggregate
    │
    └── infra/
        ├── storage/
        │   ├── lsm.fl           # LsmQueryable impl
        │   ├── distributed.fl   # DistributedQueryable impl
        │   └── remote.fl        # Remote SQL impl
        └── stream.fl            # Event bus, streaming
```

---

## 7. Summary

| Question | Answer |
|----------|--------|
| **Do iterators/aggregators behave differently per backend?** | Yes, via trait implementations. Same trait, different backends. |
| **How does `percentile` work distributed?** | `classify() -> Holistic` → optimizer gathers all data to one node before running. |
| **Do I need `Box`/`Rc`?** | No. Use `Share<T>` (unified ref type) with CoW. Compiler optimizes to stack/unique-heap/ref-counted. |
| **GC or RC?** | RC + CoW + Arenas. Deterministic, no pauses, suitable for infrastructure. |
| **How does compiler know aggregates?** | Registry maps trait methods to `OperatorShape`. `Aggregate` trait provides `classify()`. |

---

Want me to write out the **full MIR lowering** for `Share<T>` with CoW (showing `rc_check` → `cow_clone` → `field_write`), or the **distributed physical plan** for a `group_by` + `avg` + `percentile` mixed query?