Let me search for more robust resources on these specific design questions before answering.
Let me search for more specific resources on the architecture questions you're asking.
Now I have robust resources. Let me answer all your questions with the corrected architecture.

---

## 1. Why `Sum` is a Marker but `Percentile` Has Fields

You caught the inconsistency. Here's the corrected design: **all aggregates are structs with state**. The "marker" types are just zero-sized when they have no configuration. The accumulator is a **separate** type.

```rust
// ============================================
// AGGREGATE: The user-facing configuration type
// ============================================

// Sum has no configuration → zero-sized
struct Sum;

// Avg has no configuration → zero-sized  
struct Avg;

// Percentile HAS configuration → has fields
struct Percentile { p: f64 }

// Windowed average has configuration
struct WindowedAvg { window_size: usize }


// ============================================
// ACCUMULATOR: The internal state type
// These are what get serialized for distributed execution
// ============================================

struct SumAcc<T> { value: T }
struct AvgAcc<T> { sum: T, count: usize }
struct PercentileAcc<T> { values: Vec<T>, p: f64 }
struct WindowedAvgAcc<T> { window: Vec<T>, sum: T, pos: usize }


// ============================================
// TRAIT: Connects aggregate config → accumulator → output
// ============================================

trait Aggregate<T, Acc, Out> {
    fn init(self: &Self) -> Acc;           // self = config, returns fresh accumulator
    fn iterate(self: &Self, acc: Acc, value: T) -> Acc;
    fn merge(self: &Self, left: Acc, right: Acc) -> Acc;
    fn finalize(self: &Self, acc: Acc) -> Out;
    fn classify(self: &Self) -> AggregateClass;
}
```

**Why separate Aggregate and Acc?**
- `Sum` (config) is sent to all nodes in distributed execution
- `SumAcc<i32>` (state) is what each node builds locally, then serializes and sends back
- The config never changes; the accumulator grows/shrinks

**Distributed execution flow:**

```
Coordinator:
  1. Create Sum config (zero-sized, just a marker)
  2. Send to all nodes: "run Sum on your local data"
  
Node 1:
  3. acc = Sum.init() → SumAcc { value: 0 }
  4. For each row: acc = Sum.iterate(acc, row.value)
  5. Serialize SumAcc { value: 150 } → send to coordinator
  
Node 2:
  6. acc = Sum.init() → SumAcc { value: 0 }
  7. For each row: acc = Sum.iterate(acc, row.value)
  8. Serialize SumAcc { value: 250 } → send to coordinator

Coordinator:
  9. merged = Sum.merge(SumAcc{150}, SumAcc{250}) → SumAcc{400}
  10. result = Sum.finalize(SumAcc{400}) → 400
```

For `Percentile`:
```
Coordinator sends: Percentile { p: 0.5 } to all nodes

Node 1:
  acc = Percentile.init() → PercentileAcc { values: [], p: 0.5 }
  iterate: push all local values
  serialize: send PercentileAcc { values: [1,3,5], p: 0.5 }

Node 2:
  acc = PercentileAcc { values: [], p: 0.5 }
  iterate: push all local values
  serialize: send PercentileAcc { values: [2,4,6], p: 0.5 }

Coordinator:
  merged = Percentile.merge(acc1, acc2) 
    → PercentileAcc { values: [1,3,5,2,4,6], p: 0.5 }
  finalize: sort [1,2,3,4,5,6], pick index 3 → 4
```

---

## 2. How the Compiler Knows Without a Registry

You're right to question the registry. With a full compiler, you don't need one. Use **lang items** or **trait bounds** instead.

### Option A: Lang Items (What Rust Does)

Rust marks certain traits as `#[lang = "..."]` so the compiler knows about them :

```rust
// In your stdlib:
#[lang = "queryable"]
trait Queryable<T> {
    fn map<U>(self, f: impl Fn(T) -> U) -> impl Queryable<U>;
    fn filter(self, pred: impl Fn(&T) -> bool) -> impl Queryable<T>;
    fn aggregate<A, Acc, Out>(self, agg: A) -> Out 
    where A: Aggregate<T, Acc, Out>;
}

#[lang = "aggregate"]
trait Aggregate<T, Acc, Out> {
    fn init(self: &Self) -> Acc;
    fn iterate(self: &Self, acc: Acc, value: T) -> Acc;
    fn merge(self: &Self, left: Acc, right: Acc) -> Acc;
    fn finalize(self: &Self, acc: Acc) -> Out;
    fn classify(self: &Self) -> AggregateClass;
}
```

The compiler knows:
- `Queryable` is the pipeline trait
- `Aggregate` is the aggregation trait
- When it sees `.aggregate(Percentile { p: 0.5 })`, it checks if `Percentile: Aggregate<T, _, _>`
- If yes, it extracts the `classify()` method to determine distributed strategy

**No registry needed.** The compiler uses normal trait resolution.

### Option B: Even Simpler — Convention + Trait Bounds

Don't use lang items at all. Just have the query extractor pattern-match on trait bounds:

```rust
// The compiler's query extractor pass:
fn extract_aggregate(expr: &Expr) -> Option<Operator> {
    // Pattern: expr.aggregate(agg) where expr: Queryable<T> and agg: Aggregate<T, Acc, Out>
    if let Expr::MethodCall(receiver, "aggregate", [agg_expr]) = expr {
        let receiver_ty = type_of(receiver)?;  // Queryable<T>
        let agg_ty = type_of(agg_expr)?;        // Some type implementing Aggregate<T, _, _>
        
        // Resolve the Aggregate trait impl to get the classify() result
        let classify = resolve_associated_const(agg_ty, "classify")?;
        
        Some(Operator::Aggregate {
            input: extract_operator(receiver)?,
            aggregation: agg_ty,
            class: classify,
        })
    } else {
        None
    }
}
```

This uses the **existing type system** — no registry, no lang items, just trait resolution.

---

## 3. `Queryable` vs `Iterator`: Keep Them Separate

From Rust's design :

- `Iterator` = pull-based, single-threaded, in-memory
- `IntoIterator` = "convert to iterator" for `for` loops
- `Queryable` = your extension for lazy, optimizable, possibly-distributed pipelines

```rust
// core/iter.fl — Standard iteration (what Rust has)
trait Iterator<T> {
    fn next(self: &mut Self) -> Option<T>;
}

trait IntoIterator<T> {
    fn into_iter(self) -> impl Iterator<T>;
}

// core/queryable.fl — Your extension for query optimization
trait Queryable<T> {
    // Lazy transformations (same names as Iterator, but different return types)
    fn map<U>(self, f: impl Fn(T) -> U) -> impl Queryable<U>;
    fn filter(self, pred: impl Fn(&T) -> bool) -> impl Queryable<T>;
    
    // Aggregation hook
    fn aggregate<A, Acc, Out>(self, agg: A) -> Out 
    where A: Aggregate<T, Acc, Out>;
    
    // Sugar (default impls calling aggregate)
    fn sum(self) -> T where T: Add, Self: Sized {
        self.aggregate(Sum)
    }
    
    fn avg(self) -> f64 where T: Numeric, Self: Sized {
        self.aggregate(Avg)
    }
    
    // Force execution
    fn execute(self) -> Vec<T>;
}
```

**Why separate?**
- `Iterator` is for concrete, immediate, single-node iteration
- `Queryable` is for abstract, lazy, optimizable, possibly-distributed pipelines
- A type can implement both: `Vec<T>` implements `IntoIterator`, `LsmTable` implements `Queryable`

---

## 4. How User-Defined Methods Get Lowered

The user writes a regular function. The compiler decides if it's optimizable:

```rust
// User writes:
fn my_analysis(users: Queryable<User>) -> f64 {
    users
        .filter(|u| u.active)
        .map(|u| u.spend)
        .percentile(0.95)
}

// The compiler sees:
// 1. `users` is `Queryable<User>` (from parameter type)
// 2. `.filter(...)` returns `Queryable<User>` (trait method)
// 3. `.map(...)` returns `Queryable<f64>` (trait method)
// 4. `.percentile(0.95)` — resolve method:
//    - Is this a Queryable trait method? No.
//    - Is this an extension trait? Check `QueryablePercentileExt`
//    - Found: `fn percentile(self, p: f64) -> f64` 
//      where Self: Queryable<f64>, p: f64
//    - Body: `self.aggregate(Percentile { p })`
// 5. So `.percentile(0.95)` lowers to `.aggregate(Percentile { p: 0.95 })`

// Lowered HIR:
fn my_analysis(users: Queryable<User>) -> f64 {
    users
        .filter(|u| u.active)
        .map(|u| u.spend)
        .aggregate(Percentile { p: 0.95 })
}
```

**The compiler doesn't need to know `percentile` upfront.** It just needs to know that `Queryable::aggregate` exists, and that `Percentile` implements `Aggregate`. The rest is normal type checking.

---

## 5. Holistic = Gather All Data to One Node

Yes. `Holistic` means the accumulator state grows with input size, so partial results from different nodes cannot be merged without seeing all data.

| Class | Distributed Strategy | Examples |
|-------|---------------------|----------|
| **Distributive** | Partial agg per node → merge | `sum`, `count`, `min`, `max` |
| **Algebraic** | Partial agg per node → merge | `avg`, `stddev`, `variance` |
| **Holistic** | Gather ALL data to one node → aggregate | `median`, `percentile`, `mode` |

From the research on distributed query execution , the exchange operator handles this:

```rust
// Distributed plan for Holistic:
PhysicalPlan::Aggregate {
    input: Box::new(PhysicalPlan::Gather {  // ALL data to coordinator
        input: Box::new(PhysicalPlan::Exchange {
            input: Box::new(PhysicalPlan::Scan { table: "users" }),
            // No hash — send everything to coordinator
        }),
    }),
    agg: Full(Percentile { p: 0.95 }),
}
```

---

## 6. Memory Model: No `Box`, No `Rc`, No GC

Use **region/arena allocation** for queries + **copy-on-write** for shared mutation.

```rust
// User writes:
let users = load_users();        // Share<Users> — ref-counted handle
let active = users.filter(...);   // Share<FilterIter> — shares users, no copy
let total = active.sum();         // i32 — primitive, copied

// Mutation:
let mut modified = users;         // Same Share, refcount > 1
modified[0].name = "Alice";       // CoW trigger: deep copy before mutate
```

**Under the hood:**

```rust
// MIR for mutation when refcount > 1
%0 = load users              // Share<Users>
%1 = rc_check %0           // Check refcount
%2 = branch %1 > 1, cow, inplace

cow:
  %3 = deep_clone %0       // Copy all data
  %4 = store %3 -> modified
  jmp write

inplace:
  %5 = store %0 -> modified

write:
  %6 = field_write modified[0].name = "Alice"
```

**Why no GC:**
- Deterministic destruction for storage cursors, file handles, sockets
- No pause times (critical for database)
- RC + escape analysis = most RC ops optimized away 

**Why no `Box`/`Rc` in surface syntax:**
- `Share<T>` is the unified reference type
- Compiler optimizes: local → stack, unique → heap, shared → ref-counted

---

## 7. What Runs on Shards: Native Code, Not Interpreted

From distributed query execution research :

**Option 1: Pre-deployed Code (Production)**
- All stdlib + user code compiled to shared libraries (.so / .dll)
- Deployed to all nodes
- Query plan references functions by symbol name
- Node loads symbol, executes

**Option 2: Serialized Plan with Embedded Bytecode (Development)**
- Query plan serialized to protobuf/flatbuffers
- Includes closure bytecode for lambdas
- Node has a JIT or interpreter for the bytecode

**Your language compiles to:**
1. **MIR** — portable IR with your semantics
2. **LLVM IR / Cranelift** — for AOT compilation to native code
3. **Bytecode** — for JIT or interpreter on nodes

```rust
// Coordinator generates plan:
DistributedPlan {
    stages: [
        Stage {
            nodes: [1, 2, 3],
            plan: PhysicalPlan::Aggregate {
                input: Scan { table: "users" },
                agg: Partial(Sum),
            },
            // References pre-deployed `Sum::init`, `Sum::iterate`, `Sum::serialize`
        },
        Stage {
            nodes: [0],  // coordinator
            plan: PhysicalPlan::Aggregate {
                input: Gather,
                agg: Final(Sum),
            },
        },
    ],
}
```

---

## 8. Corrected File Tree (No Registry)

```
compiler/
├── src/
│   ├── core/                    # LAYER 1: Pure compiler
│   │   ├── parse/
│   │   ├── resolve/
│   │   ├── typeck/              # Normal trait resolution
│   │   ├── hir/
│   │   ├── mir/                 # Includes cow_clone, rc_check
│   │   └── lib.rs
│   │
│   ├── query/                   # LAYER 2: Extracts from typed HIR
│   │   ├── mod.rs
│   │   ├── extractor.rs         # Pattern-match Queryable/Aggregate trait calls
│   │   ├── plan.rs              # Operator enum
│   │   ├── decorrelate.rs
│   │   └── optimize.rs
│   │
│   └── backend/                 # LAYER 3: Code generation
│       ├── mod.rs
│       ├── embedded.rs
│       ├── distributed.rs       # Exchange operators, serialization
│       └── sql.rs
│
└── stdlib/
    ├── core/
    │   ├── queryable.fl         # #[lang = "queryable"] trait
    │   ├── aggregate.fl         # #[lang = "aggregate"] trait + Sum, Avg, etc.
    │   ├── iter.fl              # Iterator trait (not lang item)
    │   ├── share.fl             # Share<T> unified reference
    │   └── arena.fl             # Region allocator
    │
    └── infra/
        ├── storage/
        │   ├── lsm.fl           # LsmQueryable impl
        │   └── distributed.fl   # DistributedQueryable impl
        └── stream.fl
```

---

## Summary of Answers

| Question | Answer |
|----------|--------|
| **Why `Sum` marker vs `Percentile` with fields?** | All aggregates are structs. `Sum` is zero-sized (no config). `Percentile` has `p: f64`. Separate `Acc` type for serializable state. |
| **How compiler knows without registry?** | Use `#[lang = "aggregate"]` on trait, or just pattern-match trait bounds in query extractor. No registry needed. |
| **Queryable vs Iterator?** | Separate. `Iterator` = concrete pull. `Queryable` = lazy optimizable pipeline. |
| **How user-defined methods get lowered?** | Normal trait resolution. If body calls `.aggregate(X)`, query extractor sees that. |
| **Holistic = all data to one node?** | Yes. `Gather` exchange operator brings all data to coordinator. |
| **Box/Rc/GC?** | None. `Share<T>` with CoW. Regions for queries. |
| **What runs on shards?** | Native code (pre-deployed) or JIT bytecode. Serialized plan references symbols. |

---

Want me to write out the **full MIR for `Share<T>` CoW** (showing `rc_check`, `deep_clone`, `field_write`), or the **serialized plan format** for distributed execution with accumulator state?