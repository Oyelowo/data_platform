# YeLang Query System Design Document
## Aggregate Framework, Decorrelation, and Trait Solver Architecture

**Version:** 1.0  
**Language:** `.mm` (YeLang)  
**Status:** Design Proposal  
**Date:** 2026-07-13

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [The Core Problem](#2-the-core-problem)
3. [Architecture Overview](#3-architecture-overview)
4. [The Aggregate Protocol](#4-the-aggregate-protocol)
5. [The Decorrelator (Neumann 2025)](#5-the-decorrelator-neumann-2025)
6. [The Solver: How the Compiler "Knows"](#6-the-solver-how-the-compiler-knows)
7. [Closure Analysis: Proving Properties](#7-closure-analysis-proving-properties)
8. [Storage Pushdown & Distribution](#8-storage-pushdown--distribution)
9. [Complete Code Reference](#9-complete-code-reference)
10. [Example Queries & Lowering](#10-example-queries--lowering)
11. [Implementation Roadmap](#11-implementation-roadmap)
12. [References](#12-references)

---

## 1. Executive Summary

YeLang (`.mm`) is a general-purpose language with native query support. Unlike SQL, queries are first-class expressions embedded in the language. This creates a unique challenge: **how do we support arbitrary user-defined functions as query aggregates without hardcoding every case?**

This document proposes a unified architecture:

- **Generic Aggregate Protocol**: A four-phase trait (`init`, `accumulate`, `merge`, `finalize`) that subsumes fold/reduce while admitting distributed execution.
- **Top-Down Decorrelation**: Neumann's 2025 algorithm adapted for YeLang's graph-traversal syntax (`links`, path expressions, nested selects).
- **Property-Driven Solver**: The compiler proves aggregate properties (associative? distributable? holistic?) using canonical goals and candidate assembly, modeled on rustc's next-gen trait solver.
- **Zero-Cross-Boundary Overhead**: Since compiler, VM, and storage are all Rust in one workspace, aggregates compile to native trait objects. No WASM, no JIT, no bytecode interpretation for hot paths.

---

## 2. The Core Problem

### 2.1 Why `fold`/`reduce` Is Insufficient

A pure `fold(init, f)` works for single-threaded, single-node aggregation. But distributed execution requires:

| Requirement | What `fold` Provides | What's Missing |
|-------------|---------------------|----------------|
| Partial aggregation | `init + accumulate` | `merge` two partial states |
| Serializable state | In-memory struct | Cross-network serialization |
| Final transformation | Identity | `finalize` (e.g., `sum/count` for avg) |
| Planner optimization | None | Algebraic properties (associative? commutative?) |

### 2.2 The User-Defined Function Problem

In a general-purpose language, users write:

```mm
// User-defined function
fn my_score(acc: f64, post: Post) -> f64 {
    acc + post.likes * 2.0 + post.comments
}

// Used in a query
select users@u[*].{
    total_score: u.posts@p[*].reduce(my_score, 0.0)
}
```

The compiler must:
1. Recognize `reduce(my_score, 0.0)` as an aggregate
2. Prove `my_score` is associative (or mark it non-distributable)
3. Generate a runtime implementation that the storage layer can execute
4. Decide whether to push it to distributed storage nodes

### 2.3 The Decorrelation Problem

YeLang queries are deeply correlated by design:

```mm
select users@u[*].{
    name: u.name,
    recent_posts: u.posts@p[where p.date > cutoff][*].title,
    avg_likes: u.posts@p[*].reduce(|a, x| a + x.likes, 0) / len(u.posts),
    has_viral: u.posts@p[*].any(|p| p.likes > 10000),
}
from users@u:User
links (users)->[writes]->(posts@p:Post)
```

Every `u.posts@p[...]` is a dependent join. Without decorrelation, this executes as nested loops.

---

## 3. Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                         .mm SOURCE                              │
│  select users@u[*].{ total: u.orders@o[*].reduce(|a,x|a+x,0) }  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  PARSER → AST                                                   │
│  (Surface syntax with `@binders`, `links`, path expressions)      │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  NAME RESOLUTION + TYPE CHECKING                                │
│  - Resolve `users`, `orders`, field accesses                     │
│  - Type-check closures, infer element types                     │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  AGGREGATE SOLVER (like rustc trait solver)                     │
│  - Goal: "Does this expression satisfy QueryAggregateFn?"       │
│  - Candidate assembly: builtin / user-defined / closure analysis  │
│  - Prove properties: associative? distributable? holistic?       │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  HIR (High-level IR)                                            │
│  - Annotated with aggregate metadata (properties, fn_id)        │
│  - Decorrelated (no DependentJoin operators)                     │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  QIR (Query IR) — Relational Algebra                            │
│  - Scan, Filter, Project, Join, GroupBy, OrderBy, Limit          │
│  - Generic Aggregate operator with fn_id                       │
│  - Decorrelated via Neumann 2025 top-down algorithm              │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  PHYSICAL PLANNER                                               │
│  - Check aggregate properties for pushdown decisions           │
│  - Insert Exchange nodes for distributed execution               │
│  - Choose streaming unit (per-parent vs leaf)                   │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  CODE GENERATION                                                │
│  - VM bytecode for interpreted paths                             │
│  - Machine code (LLVM/cranelift) for hot paths                  │
│  - Aggregate registry populated with compiled trait objects      │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  RUNTIME / STORAGE                                              │
│  - Embedded: direct trait calls (zero overhead)                  │
│  - Distributed: serialized partial states + merge                │
└─────────────────────────────────────────────────────────────────┘
```

---

## 4. The Aggregate Protocol

### 4.1 The Core Trait

```rust
// yelang-traits/src/aggregate.rs

/// Algebraic properties used by the query planner.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct AggregateProperties {
    /// Can partial results be merged?
    /// Examples: sum, count, min, max, bool_and, bool_or → true
    /// Counter-examples: string_agg (ORDER BY), median, percentile_cont → false
    pub associative: bool,
    /// Does the aggregate ignore null inputs?
    pub ignore_nulls: bool,
    /// Does the aggregate need to see all input before producing partial state?
    /// Examples: median, percentile_cont, mode → true
    pub holistic: bool,
    /// Can the aggregate be pushed to distributed storage nodes?
    /// True iff associative AND NOT holistic AND state is serializable.
    pub distributable: bool,
}

/// The generic aggregate trait.
/// Every aggregate—built-in, compiler-generated, or user-defined—implements this.
pub trait AggregateFn: Send + Sync + 'static {
    type Input: FromValue + Send;
    type State: AccumulatorState;
    type Output: IntoValue;

    fn properties(&self) -> AggregateProperties;
    fn init(&self) -> Self::State;
    fn accumulate(&self, state: &mut Self::State, input: Self::Input);
    fn merge(&self, left: &mut Self::State, right: Self::State);
    fn finalize(&self, state: Self::State) -> Self::Output;
}

/// State that can cross process/network boundaries.
pub trait AccumulatorState: Clone + Send + 'static {
    fn serialize(&self) -> Vec<u8>;
    fn deserialize(bytes: &[u8]) -> Self;
}
```

### 4.2 Why Four Phases?

| Phase | Single-Node | Distributed | Example |
|-------|------------|-------------|---------|
| `init` | Create local state | Create per-node state | `0` for sum |
| `accumulate` | Consume each row | Consume local rows | `state += row.value` |
| `merge` | Not used | Combine node results | `left += right` |
| `finalize` | Return result | Return result | `state` (identity) or `sum/count` (avg) |

### 4.3 Built-in Implementations

```rust
// yelang-traits/src/builtins.rs

pub struct Sum;

impl AggregateFn for Sum {
    type Input = f64;
    type State = f64;
    type Output = f64;

    fn properties(&self) -> AggregateProperties {
        AggregateProperties {
            associative: true,
            ignore_nulls: false,
            holistic: false,
            distributable: true,
        }
    }

    fn init(&self) -> f64 { 0.0 }
    fn accumulate(&self, state: &mut f64, input: f64) { *state += input; }
    fn merge(&self, left: &mut f64, right: f64) { *left += right; }
    fn finalize(&self, state: f64) -> f64 { state }
}

pub struct Count;

impl AggregateFn for Count {
    type Input = ();
    type State = u64;
    type Output = i64;

    fn properties(&self) -> AggregateProperties {
        AggregateProperties {
            associative: true,
            ignore_nulls: true,
            holistic: false,
            distributable: true,
        }
    }

    fn init(&self) -> u64 { 0 }
    fn accumulate(&self, state: &mut u64, _input: ()) { *state += 1; }
    fn merge(&self, left: &mut u64, right: u64) { *left += right; }
    fn finalize(&self, state: u64) -> i64 { state as i64 }
}

pub struct Avg;

impl AggregateFn for Avg {
    type Input = f64;
    type State = (f64, u64); // (sum, count)
    type Output = f64;

    fn properties(&self) -> AggregateProperties {
        AggregateProperties {
            associative: true,
            ignore_nulls: false,
            holistic: false,
            distributable: true,
        }
    }

    fn init(&self) -> (f64, u64) { (0.0, 0) }
    fn accumulate(&self, state: &mut (f64, u64), input: f64) {
        state.0 += input;
        state.1 += 1;
    }
    fn merge(&self, left: &mut (f64, u64), right: (f64, u64)) {
        left.0 += right.0;
        left.1 += right.1;
    }
    fn finalize(&self, state: (f64, u64)) -> f64 {
        state.0 / state.1 as f64
    }
}

pub struct Any<F> {
    predicate: F,
}

impl<F> AggregateFn for Any<F>
where
    F: Fn(&Value) -> bool + Send + Sync + 'static,
{
    type Input = Value;
    type State = bool;
    type Output = bool;

    fn properties(&self) -> AggregateProperties {
        AggregateProperties {
            associative: true,
            ignore_nulls: true,
            holistic: false,
            distributable: true,
        }
    }

    fn init(&self) -> bool { false }
    fn accumulate(&self, state: &mut bool, input: Value) {
        *state = *state || (self.predicate)(&input);
    }
    fn merge(&self, left: &mut bool, right: bool) { *left = *left || right; }
    fn finalize(&self, state: bool) -> bool { state }
}
```

### 4.4 User-Defined Aggregates

Users can define aggregates explicitly:

```mm
#[aggregate(associative = true, distributable = true)]
fn weighted_score(acc: f64, post: Post) -> f64 {
    acc + post.likes * 2.0 + post.comments
}
```

Or the compiler can infer properties from closure analysis (see §7).

---

## 5. The Decorrelator (Neumann 2025)

### 5.1 The Problem

YeLang's `links` and path expressions create deeply nested correlated subqueries:

```mm
select users@u[*].{
    name: u.name,
    posts: u.writes@w[*].books@b[**].title,
}
from users@u:User
links (users)->[writes@w:UserWritesBook]->(books@b:Book)
```

Algebraically, `u.writes@w[*].books@b[**]` is:
```
users ⋈D (writes ⋈D books)
```

A naive evaluator runs this as nested loops: for each user, fetch writes, for each write, fetch books.

### 5.2 The Solution: Top-Down Holistic Unnesting

Neumann's 2025 algorithm processes all dependent joins in a single top-down pass, avoiding the pathological blow-up of the 2015 bottom-up approach when dependent joins are nested.

#### Key Data Structures

```rust
// yelang-qir/src/decorrelator.rs

/// The domain D = Π_{outer_refs}(L), duplicate-free.
/// This is the set of distinct outer-column bindings that the subquery needs.
pub struct Domain {
    pub columns: Vec<Column>,
    pub source: Operator,
}

/// Column equivalence classes discovered from equality predicates.
/// If `a = b` and `b` is an outer reference, `a` can substitute for `b`.
pub struct EquivalenceClasses {
    parent: HashMap<Column, Column>,
}

/// The top-down decorrelation context.
/// Analogous to rustc's `InferCtxt`.
pub struct Decorrelator<'tcx> {
    pub tcx: &'tcx QueryCtxt,
    /// Stack of scopes. Each frame maps outer columns to replacements.
    pub scope_stack: Vec<HashMap<Column, ScalarExpr>>,
    pub equivalences: EquivalenceClasses,
    fresh_counter: usize,
}
```

#### The Fundamental Decomposition

```
L ⋈D R  ≡  L ⋈_{natural D} (D ⋈D R)
```

Where:
- `L` = left side (outer query)
- `R` = right side (correlated subquery)
- `D` = distinct values of outer columns referenced by `R`
- `natural D` = join on D's columns (with NULL = NULL semantics)

#### Push-Down Rules

| Operator | Rule |
|----------|------|
| Selection | `D ⋈D σ_p(R)` → `σ_p(D ⋈D R)` |
| Projection | `D ⋈D Π_A(R)` → `Π_{A ∪ D}(D ⋈D R)` |
| Inner Join (one side dependent) | Push to dependent side only |
| Inner Join (both dependent) | Replicate D on both sides |
| Group By | `D ⋈D Γ_{A;agg}(R)` → `Γ_{A ∪ D; agg}(D ⋈D R)` |
| Union | `D ⋈D (L ∪ R)` → `(D ⋈D L) ∪ (D ⋈D R)` |
| Order By / Limit | Add D columns to partition_by |

#### Core Algorithm

```rust
impl<'tcx> Decorrelator<'tcx> {
    /// Entry point: eliminate all DependentJoins from the plan.
    pub fn unnest(mut self, plan: Operator) -> Operator {
        self.transform(plan)
    }

    fn transform(&mut self, op: Operator) -> Operator {
        match op {
            // The critical case: eliminate the dependent join.
            Operator::Join {
                kind: JoinKind::Dependent,
                left,
                right,
                condition,
            } => self.eliminate_dependent(*left, *right, condition),

            // Selection: extract equivalences, rewrite, recurse.
            Operator::Filter { predicate, input } => {
                self.extract_equivalences(&predicate);
                Operator::Filter {
                    predicate: self.rewrite_scalar(&predicate),
                    input: Box::new(self.transform(*input)),
                }
            }

            // Inner join: split context if both sides need outer refs.
            Operator::Join { kind, left, right, condition } => {
                let mut left_ctx = self.fork();
                let mut right_ctx = self.fork();
                let new_left = left_ctx.transform(*left);
                let new_right = right_ctx.transform(*right);
                self.equivalences.parent.extend(left_ctx.equivalences.parent);
                self.equivalences.parent.extend(right_ctx.equivalences.parent);
                Operator::Join {
                    kind,
                    left: Box::new(new_left),
                    right: Box::new(new_right),
                    condition: self.rewrite_scalar(&condition),
                }
            }

            // Group by: outer refs become additional grouping keys.
            Operator::GroupBy { keys, aggregates, input } => {
                let mut new_keys = keys;
                for (col, replacement) in self.current_outer_refs() {
                    new_keys.push(replacement.clone());
                }
                let new_aggregates = aggregates.into_iter().map(|agg| Aggregate {
                    output_name: agg.output_name,
                    func: agg.func,
                    expr: self.rewrite_scalar(&agg.expr),
                    distinct: agg.distinct,
                }).collect();
                Operator::GroupBy {
                    keys: new_keys,
                    aggregates: new_aggregates,
                    input: Box::new(self.transform(*input)),
                }
            }

            // ... other cases (see §9 for full code)
            _ => op,
        }
    }

    fn eliminate_dependent(
        &mut self,
        left: Operator,
        right: Operator,
        condition: ScalarExpr,
    ) -> Operator {
        // 1. Identify free variables in right that come from left.
        let right_free = AttributeAnalysis::free_vars(&right);
        let left_attrs = AttributeAnalysis::produced_attrs(&left);
        let outer_refs: Vec<Column> = right_free.intersection(&left_attrs).cloned().collect();

        if outer_refs.is_empty() {
            // Trivial dependent join: no actual correlation.
            return Operator::Join {
                kind: JoinKind::Inner,
                left: Box::new(left),
                right: Box::new(right),
                condition,
            };
        }

        // 2. Build the domain D.
        let domain = self.build_domain(&left, &outer_refs);

        // 3. Create child context with outer refs bound.
        let mut child_scope = HashMap::new();
        for col in &outer_refs {
            child_scope.insert(col.clone(), ScalarExpr::Column(col.clone()));
        }
        self.scope_stack.push(child_scope);

        // 4. Push D down into R.
        let right_with_domain = self.push_domain(domain.clone(), right);
        self.scope_stack.pop();

        // 5. Build natural join condition on D columns.
        let natural = self.build_natural_join(&domain.columns);

        // 6. Return L ⋈ (D ⟕ R)
        let d_name = self.fresh_name("D");
        Operator::Join {
            kind: JoinKind::Inner,
            left: Box::new(left),
            right: Box::new(Operator::Cte {
                name: d_name,
                source: Box::new(right_with_domain),
                input: Box::new(domain.source),
            }),
            condition: ScalarExpr::Binary(BinOp::And, Box::new(condition), Box::new(natural)),
        }
    }
}
```

---

## 6. The Solver: How the Compiler "Knows"

### 6.1 The rustc Next-Gen Trait Solver Pattern

From the actual rustc source code:

```rust
// compiler/rustc_next_trait_solver/src/solve/eval_ctxt/mod.rs

pub(super) fn compute_goal(
    &mut self,
    goal: Goal<I, I::Predicate>,
) -> QueryResultOrRerunNonErased<I> {
    let Goal { param_env, predicate } = goal;
    let kind = predicate.kind();
    self.enter_forall_with_assumptions(kind, param_env, |ecx, kind| {
        Ok(match kind {
            ty::PredicateKind::Clause(ty::ClauseKind::Trait(predicate)) => {
                ecx.compute_trait_goal(Goal { param_env, predicate }).map(|(r, _via)| r)?
            }
            // ... dispatch to specific goal computers
        })
    })
}
```

**Key insight:** The solver doesn't hardcode "is this `Add`?" It asks: "given this goal (a predicate), what candidates (impls) could satisfy it?"

### 6.2 Adapted for YeLang Aggregate Detection

```rust
// yelang-tyecheck/src/aggregate_solver.rs

/// The "predicate" for your aggregate system.
pub enum AggregatePredicate {
    /// Can this expression be used as an aggregate function?
    IsAggregateFn {
        expr: ExprId,
        input_ty: Type,
        output_ty: Type,
    },
    /// Does this aggregate support distributed execution?
    IsDistributable { expr: ExprId },
    /// Does this aggregate ignore nulls?
    IgnoresNulls { expr: ExprId },
}

/// Your aggregate solver, modeled on rustc's EvalCtxt.
pub struct AggregateSolver<'tcx> {
    tcx: &'tcx TypeCtxt,
}

impl<'tcx> AggregateSolver<'tcx> {
    /// Entry point: evaluate whether an expression can be used as an aggregate.
    pub fn evaluate_aggregate_goal(
        &mut self,
        goal: Goal<AggregatePredicate>,
    ) -> Result<AggregateProperties, NoSolution> {
        let canonical = self.canonicalize_goal(goal);
        self.compute_aggregate_goal(canonical)
    }

    fn compute_aggregate_goal(
        &mut self,
        goal: CanonicalInput<AggregatePredicate>,
    ) -> Result<AggregateProperties, NoSolution> {
        let AggregatePredicate::IsAggregateFn { expr, input_ty, output_ty } = goal.predicate;

        // Candidate assembly: what could make this true?
        // Try candidates in order of specificity.

        // Candidate 1: Built-in aggregate (sum, count, avg, any, all)
        if let Some(builtin) = self.try_builtin_aggregate(expr, input_ty, output_ty) {
            return Ok(builtin.properties);
        }

        // Candidate 2: User-defined function with #[aggregate] attribute
        if let Some(user_def) = self.try_user_defined_aggregate(expr, input_ty, output_ty) {
            return Ok(user_def.properties);
        }

        // Candidate 3: Closure that structurally matches fold/reduce
        if let Some(closure) = self.try_closure_aggregate(expr, input_ty, output_ty) {
            return Ok(closure.properties);
        }

        // No candidates found.
        Err(NoSolution)
    }
}
```

### 6.3 Candidate Assembly

```rust
impl<'tcx> AggregateSolver<'tcx> {
    fn try_builtin_aggregate(
        &self,
        expr: ExprId,
        input_ty: Type,
        output_ty: Type,
    ) -> Option<AggregateCandidate> {
        if let Expr::VarRef(name) = self.tcx.expr(expr) {
            match name.as_str() {
                "sum" => Some(AggregateCandidate {
                    properties: AggregateProperties {
                        associative: true, ignore_nulls: false,
                        holistic: false, distributable: true,
                    },
                    lowering: AggregateLowering::Builtin(BuiltinAgg::Sum),
                }),
                "count" => Some(AggregateCandidate {
                    properties: AggregateProperties {
                        associative: true, ignore_nulls: true,
                        holistic: false, distributable: true,
                    },
                    lowering: AggregateLowering::Builtin(BuiltinAgg::Count),
                }),
                "avg" => Some(AggregateCandidate {
                    properties: AggregateProperties {
                        associative: true, ignore_nulls: false,
                        holistic: false, distributable: true,
                    },
                    lowering: AggregateLowering::Builtin(BuiltinAgg::Avg),
                }),
                "any" => Some(AggregateCandidate {
                    properties: AggregateProperties {
                        associative: true, ignore_nulls: true,
                        holistic: false, distributable: true,
                    },
                    lowering: AggregateLowering::Builtin(BuiltinAgg::Any),
                }),
                "all" => Some(AggregateCandidate {
                    properties: AggregateProperties {
                        associative: true, ignore_nulls: true,
                        holistic: false, distributable: true,
                    },
                    lowering: AggregateLowering::Builtin(BuiltinAgg::All),
                }),
                _ => None,
            }
        } else {
            None
        }
    }

    fn try_user_defined_aggregate(
        &self,
        expr: ExprId,
        input_ty: Type,
        output_ty: Type,
    ) -> Option<AggregateCandidate> {
        let fn_def = self.tcx.resolve_expr_to_fn(expr)?;
        let attrs = self.tcx.fn_attrs(fn_def);

        if let Some(agg_attr) = attrs.get("aggregate") {
            Some(AggregateCandidate {
                properties: AggregateProperties {
                    associative: agg_attr.get_bool("associative").unwrap_or(false),
                    ignore_nulls: agg_attr.get_bool("ignore_nulls").unwrap_or(false),
                    holistic: agg_attr.get_bool("holistic").unwrap_or(false),
                    distributable: agg_attr.get_bool("distributable").unwrap_or(false),
                },
                lowering: AggregateLowering::UserDefined(fn_def),
            })
        } else {
            None
        }
    }

    fn try_closure_aggregate(
        &self,
        expr: ExprId,
        input_ty: Type,
        output_ty: Type,
    ) -> Option<AggregateCandidate> {
        // Expect: reduce(|acc, x| <body>, init) or fold(|acc, x| <body>, init)
        let Expr::MethodCall { receiver, method, args } = self.tcx.expr(expr)?;

        if method != "reduce" && method != "fold" {
            return None;
        }

        let closure = args.get(0)?;
        let init_expr = args.get(1)?;
        let (acc_param, item_param, body) = self.tcx.closure_body(closure)?;

        let body_properties = self.analyze_closure_body(body, acc_param, item_param)?;
        let init_properties = self.analyze_init_expr(init_expr, &body_properties)?;

        Some(AggregateCandidate {
            properties: AggregateProperties {
                associative: body_properties.is_associative,
                ignore_nulls: false,
                holistic: false,
                distributable: body_properties.is_associative && init_properties.is_identity,
            },
            lowering: AggregateLowering::Closure { closure, init: init_expr },
        })
    }
}
```

---

## 7. Closure Analysis: Proving Properties

### 7.1 The Analysis Engine

```rust
impl<'tcx> AggregateSolver<'tcx> {
    /// Analyzes a closure body to determine if it represents an associative operation.
    fn analyze_closure_body(
        &self,
        body: ExprId,
        acc_param: ParamId,
        item_param: ParamId,
    ) -> Option<BodyProperties> {
        match self.tcx.expr(body) {
            // Case: acc + item
            Expr::Binary(BinOp::Add, left, right)
                if self.is_param_ref(left, acc_param)
                && self.is_param_ref(right, item_param) =>
            {
                Some(BodyProperties {
                    is_associative: self.is_add_associative(self.tcx.type_of(left)),
                    operation: AggregateOperation::Add,
                })
            }

            // Case: acc * item
            Expr::Binary(BinOp::Mul, left, right)
                if self.is_param_ref(left, acc_param)
                && self.is_param_ref(right, item_param) =>
            {
                Some(BodyProperties {
                    is_associative: self.is_mul_associative(self.tcx.type_of(left)),
                    operation: AggregateOperation::Mul,
                })
            }

            // Case: acc && item (boolean AND)
            Expr::Binary(BinOp::And, left, right)
                if self.is_param_ref(left, acc_param)
                && self.is_param_ref(right, item_param) =>
            {
                Some(BodyProperties {
                    is_associative: true,
                    operation: AggregateOperation::BoolAnd,
                })
            }

            // Case: acc || item (boolean OR)
            Expr::Binary(BinOp::Or, left, right)
                if self.is_param_ref(left, acc_param)
                && self.is_param_ref(right, item_param) =>
            {
                Some(BodyProperties {
                    is_associative: true,
                    operation: AggregateOperation::BoolOr,
                })
            }

            // Case: min(acc, item)
            Expr::Call(func, args)
                if self.is_min_function(func)
                && args.len() == 2
                && self.is_param_ref(args[0], acc_param)
                && self.is_param_ref(args[1], item_param) =>
            {
                Some(BodyProperties {
                    is_associative: true,
                    operation: AggregateOperation::Min,
                })
            }

            // Case: max(acc, item)
            Expr::Call(func, args)
                if self.is_max_function(func)
                && args.len() == 2
                && self.is_param_ref(args[0], acc_param)
                && self.is_param_ref(args[1], item_param) =>
            {
                Some(BodyProperties {
                    is_associative: true,
                    operation: AggregateOperation::Max,
                })
            }

            // Case: acc + f(item) — still associative if f is pure
            Expr::Binary(BinOp::Add, left, right)
                if self.is_param_ref(left, acc_param) =>
            {
                let right_properties = self.analyze_expr_for_purity(right, item_param)?;
                Some(BodyProperties {
                    is_associative: self.is_add_associative(self.tcx.type_of(left))
                        && right_properties.is_pure,
                    operation: AggregateOperation::AddMapped(right_properties.expr),
                })
            }

            // Case: acc * f(item)
            Expr::Binary(BinOp::Mul, left, right)
                if self.is_param_ref(left, acc_param) =>
            {
                let right_properties = self.analyze_expr_for_purity(right, item_param)?;
                Some(BodyProperties {
                    is_associative: self.is_mul_associative(self.tcx.type_of(left))
                        && right_properties.is_pure,
                    operation: AggregateOperation::MulMapped(right_properties.expr),
                })
            }

            // Default: cannot prove associativity
            _ => None,
        }
    }

    fn analyze_init_expr(
        &self,
        init: ExprId,
        body: &BodyProperties,
    ) -> Option<InitProperties> {
        match body.operation {
            AggregateOperation::Add | AggregateOperation::AddMapped(_) => {
                // Identity for addition is 0
                if self.is_zero_literal(init) {
                    Some(InitProperties { is_identity: true })
                } else {
                    None
                }
            }
            AggregateOperation::Mul | AggregateOperation::MulMapped(_) => {
                // Identity for multiplication is 1
                if self.is_one_literal(init) {
                    Some(InitProperties { is_identity: true })
                } else {
                    None
                }
            }
            AggregateOperation::BoolAnd => {
                if self.is_true_literal(init) {
                    Some(InitProperties { is_identity: true })
                } else {
                    None
                }
            }
            AggregateOperation::BoolOr => {
                if self.is_false_literal(init) {
                    Some(InitProperties { is_identity: true })
                } else {
                    None
                }
            }
            AggregateOperation::Min => {
                // Identity for min is +infinity (or first element)
                // We can't prove this statically in general
                None
            }
            AggregateOperation::Max => {
                // Identity for max is -infinity
                None
            }
        }
    }
}
```

### 7.2 What Can and Cannot Be Proven

| Pattern | Provable? | Notes |
|---------|-----------|-------|
| `\|a, x\| a + x` | ✅ Yes | Associative for numeric types |
| `\|a, x\| a * x` | ✅ Yes | Associative for numeric types |
| `\|a, x\| a && x` | ✅ Yes | Boolean AND |
| `\|a, x\| a \| x` | ✅ Yes | Boolean OR |
| `\|a, x\| min(a, x)` | ✅ Yes | Min is associative |
| `\|a, x\| max(a, x)` | ✅ Yes | Max is associative |
| `\|a, x\| a + x.views` | ✅ Yes | Pure projection + associative op |
| `\|a, x\| a + f(x)` | ⚠️ Maybe | If `f` is proven pure |
| `\|a, x\| a + random()` | ❌ No | Not pure |
| `\|a, x\| a + x` with init `5` | ❌ No | `5` is not identity for `+` |
| `\|a, x\| a / x` | ❌ No | Division is not associative |
| `\|a, x\| a - x` | ❌ No | Subtraction is not associative |
| `\|a, x\| string_concat(a, x)` | ❌ No | String concat is not commutative |

---

## 8. Storage Pushdown & Distribution

### 8.1 The Decision Flow

```
Is the aggregate associative?
├── No → Must execute locally (pull all data up)
│         └── Add Exchange::Gather before aggregate
│
└── Yes → Is the aggregate holistic?
          ├── Yes → Must see all data (e.g., median)
          │         └── Execute on coordinator or use approximation
          │
          └── No → Can distribute!
                    └── Push accumulate to storage nodes
                        └── Gather partial states
                            └── Merge + Finalize on coordinator
```

### 8.2 The Pushdown Protocol

```rust
// yelang-query/src/planner.rs

impl QueryPlanner {
    fn plan_aggregate(
        &mut self,
        agg: &AggregateExpr,
        input_plan: PlanNode,
    ) -> PlanNode {
        let properties = self.tcx.aggregate_properties(agg);

        if !properties.associative {
            // Non-associative: must execute locally
            return PlanNode::LocalAggregate {
                input: Box::new(input_plan),
                agg_id: agg.fn_id,
            };
        }

        if properties.holistic {
            // Holistic: needs all data. Either execute locally
            // or use an approximate distributed algorithm.
            return PlanNode::LocalAggregate {
                input: Box::new(input_plan),
                agg_id: agg.fn_id,
            };
        }

        // Associative + non-holistic: can distribute
        if self.is_distributed_storage() {
            PlanNode::Exchange {
                input: Box::new(PlanNode::PartialAggregate {
                    input: Box::new(input_plan),
                    agg_id: agg.fn_id,
                }),
                exchange_type: ExchangeType::Gather,
                post_exchange: Some(Box::new(PlanNode::FinalAggregate {
                    agg_id: agg.fn_id,
                })),
            }
        } else {
            // Single node: just execute locally
            PlanNode::LocalAggregate {
                input: Box::new(input_plan),
                agg_id: agg.fn_id,
            }
        }
    }
}
```

### 8.3 Storage Node Execution

Since everything is in the same Rust workspace, storage nodes have direct access to the aggregate implementations:

```rust
// yelang-storage/src/scan.rs

impl StorageNode {
    fn execute_partial_aggregate<A: AggregateFn>(
        &self,
        range: KeyRange,
        agg: &A,
    ) -> Vec<u8> {
        let mut state = agg.init();
        for row in self.scan(range) {
            let input = extract_input::<A::Input>(&row);
            agg.accumulate(&mut state, input);
        }
        state.serialize()
    }
}
```

The storage node receives the `agg_id`, looks it up in the registry, and calls the trait methods directly. No serialization of logic, only of state.

---

## 9. Complete Code Reference

### 9.1 QIR Operator Enum

```rust
// yelang-qir/src/operator.rs

pub enum Operator {
    Scan { table: Ident, alias: Ident },
    Filter { predicate: ScalarExpr, input: Box<Operator> },
    Project { outputs: Vec<(Ident, ScalarExpr)>, input: Box<Operator> },
    Map { computations: Vec<(Ident, ScalarExpr)>, input: Box<Operator> },
    Join { kind: JoinKind, left: Box<Operator>, right: Box<Operator>, condition: ScalarExpr },
    GroupBy { keys: Vec<ScalarExpr>, aggregates: Vec<Aggregate>, input: Box<Operator> },
    OrderBy { keys: Vec<OrderKey>, input: Box<Operator> },
    Limit { offset: usize, limit: usize, input: Box<Operator> },
    Unnest { input: Box<Operator>, column: Column, alias: Ident },
    Cte { name: Ident, source: Box<Operator>, input: Box<Operator> },
    Union(Box<Operator>, Box<Operator>),
    Intersect(Box<Operator>, Box<Operator>),
    Except(Box<Operator>, Box<Operator>),
}

pub enum JoinKind {
    Inner, Left, Right, Full, Semi, Anti, Single, Dependent,
}

pub struct Aggregate {
    pub output_name: Ident,
    pub func_id: AggregateFnId,
    pub expr: ScalarExpr,
    pub distinct: bool,
}
```

### 9.2 Scalar Expression Enum

```rust
// yelang-qir/src/expr.rs

pub enum ScalarExpr {
    Column(Column),
    Lit(Literal),
    Binary(BinOp, Box<ScalarExpr>, Box<ScalarExpr>),
    IsNull(Box<ScalarExpr>),
    Case(Vec<(ScalarExpr, ScalarExpr)>, Option<Box<ScalarExpr>>),
    AggCall(AggFunc, Vec<ScalarExpr>),
    Window { func: AggFunc, args: Vec<ScalarExpr>, partition_by: Vec<ScalarExpr>, order_by: Vec<OrderKey> },
    Subquery(Box<Operator>),
}

pub struct Column {
    pub qualifier: Option<Ident>,
    pub name: Ident,
    pub path: Vec<ColumnPath>,
}

pub enum ColumnPath {
    Field(Ident),
    Index(usize),
    Unnest,
}
```

### 9.3 Full Decorrelator Implementation

```rust
// yelang-qir/src/decorrelator.rs

use std::collections::{HashMap, HashSet};

pub struct Domain {
    pub columns: Vec<Column>,
    pub source: Operator,
}

pub struct EquivalenceClasses {
    parent: HashMap<Column, Column>,
}

impl EquivalenceClasses {
    pub fn new() -> Self { Self { parent: HashMap::new() } }
    pub fn union(&mut self, a: &Column, b: &Column) {
        self.parent.insert(a.clone(), b.clone());
        self.parent.insert(b.clone(), a.clone());
    }
    pub fn find(&self, col: &Column) -> Option<Column> {
        self.parent.get(col).cloned()
    }
}

pub struct Decorrelator<'tcx> {
    pub tcx: &'tcx QueryCtxt,
    pub scope_stack: Vec<HashMap<Column, ScalarExpr>>,
    pub equivalences: EquivalenceClasses,
    fresh_counter: usize,
}

impl<'tcx> Decorrelator<'tcx> {
    pub fn new(tcx: &'tcx QueryCtxt) -> Self {
        Self {
            tcx,
            scope_stack: vec![HashMap::new()],
            equivalences: EquivalenceClasses::new(),
            fresh_counter: 0,
        }
    }

    pub fn unnest(mut self, plan: Operator) -> Operator {
        self.transform(plan)
    }

    fn transform(&mut self, op: Operator) -> Operator {
        match op {
            Operator::Join { kind: JoinKind::Dependent, left, right, condition } => {
                self.eliminate_dependent(*left, *right, condition)
            }
            Operator::Filter { predicate, input } => {
                self.extract_equivalences(&predicate);
                Operator::Filter {
                    predicate: self.rewrite_scalar(&predicate),
                    input: Box::new(self.transform(*input)),
                }
            }
            Operator::Join { kind, left, right, condition } => {
                let mut left_ctx = self.fork();
                let mut right_ctx = self.fork();
                let new_left = left_ctx.transform(*left);
                let new_right = right_ctx.transform(*right);
                self.equivalences.parent.extend(left_ctx.equivalences.parent);
                self.equivalences.parent.extend(right_ctx.equivalences.parent);
                Operator::Join {
                    kind,
                    left: Box::new(new_left),
                    right: Box::new(new_right),
                    condition: self.rewrite_scalar(&condition),
                }
            }
            Operator::GroupBy { keys, aggregates, input } => {
                let mut new_keys = keys;
                for (col, replacement) in self.current_outer_refs() {
                    new_keys.push(replacement.clone());
                }
                let new_aggregates = aggregates.into_iter().map(|agg| Aggregate {
                    output_name: agg.output_name,
                    func_id: agg.func_id,
                    expr: self.rewrite_scalar(&agg.expr),
                    distinct: agg.distinct,
                }).collect();
                Operator::GroupBy {
                    keys: new_keys,
                    aggregates: new_aggregates,
                    input: Box::new(self.transform(*input)),
                }
            }
            Operator::Project { outputs, input } => {
                let mut new_outputs = outputs;
                for (col, replacement) in self.current_outer_refs() {
                    new_outputs.push((col.name, replacement.clone()));
                }
                Operator::Project {
                    outputs: new_outputs,
                    input: Box::new(self.transform(*input)),
                }
            }
            Operator::Map { computations, input } => {
                let new_computations = computations.into_iter()
                    .map(|(name, expr)| (name, self.rewrite_scalar(&expr)))
                    .collect();
                Operator::Map {
                    computations: new_computations,
                    input: Box::new(self.transform(*input)),
                }
            }
            Operator::OrderBy { keys, input } => {
                let new_keys = keys.into_iter().map(|k| OrderKey {
                    expr: self.rewrite_scalar(&k.expr),
                    asc: k.asc,
                }).collect();
                Operator::OrderBy { keys: new_keys, input: Box::new(self.transform(*input)) }
            }
            Operator::Limit { offset, limit, input } => {
                Operator::Limit { offset, limit, input: Box::new(self.transform(*input)) }
            }
            Operator::Union(left, right) => {
                Operator::Union(Box::new(self.transform(*left)), Box::new(self.transform(*right)))
            }
            Operator::Intersect(left, right) => {
                Operator::Intersect(Box::new(self.transform(*left)), Box::new(self.transform(*right)))
            }
            Operator::Except(left, right) => {
                Operator::Except(Box::new(self.transform(*left)), Box::new(self.transform(*right)))
            }
            Operator::Cte { name, source, input } => Operator::Cte {
                name,
                source: Box::new(self.transform(*source)),
                input: Box::new(self.transform(*input)),
            },
            Operator::Unnest { input, column, alias } => Operator::Unnest {
                input: Box::new(self.transform(*input)),
                column,
                alias,
            },
            op @ Operator::Scan { .. } => op,
        }
    }

    fn eliminate_dependent(&mut self, left: Operator, right: Operator, condition: ScalarExpr) -> Operator {
        let right_free = AttributeAnalysis::free_vars(&right);
        let left_attrs = AttributeAnalysis::produced_attrs(&left);
        let outer_refs: Vec<Column> = right_free.intersection(&left_attrs).cloned().collect();

        if outer_refs.is_empty() {
            return Operator::Join {
                kind: JoinKind::Inner,
                left: Box::new(left),
                right: Box::new(right),
                condition,
            };
        }

        let domain = self.build_domain(&left, &outer_refs);
        let mut child_scope = HashMap::new();
        for col in &outer_refs {
            child_scope.insert(col.clone(), ScalarExpr::Column(col.clone()));
        }
        self.scope_stack.push(child_scope);
        let right_with_domain = self.push_domain(domain.clone(), right);
        self.scope_stack.pop();

        let natural = self.build_natural_join(&domain.columns);
        let d_name = self.fresh_name("D");

        Operator::Join {
            kind: JoinKind::Inner,
            left: Box::new(left),
            right: Box::new(Operator::Cte {
                name: d_name,
                source: Box::new(right_with_domain),
                input: Box::new(domain.source),
            }),
            condition: ScalarExpr::Binary(BinOp::And, Box::new(condition), Box::new(natural)),
        }
    }

    fn push_domain(&mut self, domain: Domain, op: Operator) -> Operator {
        match op {
            Operator::Filter { predicate, input } => Operator::Filter {
                predicate: self.rewrite_scalar(&predicate),
                input: Box::new(self.push_domain(domain, *input)),
            },
            Operator::Join { kind, left, right, condition } => {
                let left_needs = self.needs_domain(&left, &domain);
                let right_needs = self.needs_domain(&right, &domain);

                if !left_needs {
                    Operator::Join { kind, left, right: Box::new(self.push_domain(domain, *right)), condition }
                } else if !right_needs {
                    Operator::Join { kind, left: Box::new(self.push_domain(domain, *left)), right, condition }
                } else {
                    let left_dom = domain.clone();
                    let right_dom = domain;
                    let natural = self.build_natural_join(&left_dom.columns);
                    Operator::Join {
                        kind,
                        left: Box::new(self.push_domain(left_dom, *left)),
                        right: Box::new(self.push_domain(right_dom, *right)),
                        condition: ScalarExpr::Binary(BinOp::And, Box::new(condition), Box::new(natural)),
                    }
                }
            }
            Operator::GroupBy { keys, aggregates, input } => {
                let mut new_keys = keys;
                for col in &domain.columns {
                    new_keys.push(ScalarExpr::Column(col.clone()));
                }
                Operator::GroupBy { keys: new_keys, aggregates, input: Box::new(self.push_domain(domain, *input)) }
            }
            Operator::Project { outputs, input } => {
                let mut new_outputs = outputs;
                for col in &domain.columns {
                    new_outputs.push((col.name, ScalarExpr::Column(col.clone())));
                }
                Operator::Project { outputs: new_outputs, input: Box::new(self.push_domain(domain, *input)) }
            }
            Operator::Map { computations, input } => {
                Operator::Map { computations, input: Box::new(self.push_domain(domain, *input)) }
            }
            Operator::Union(left, right) => {
                Operator::Union(Box::new(self.push_domain(domain.clone(), *left)), Box::new(self.push_domain(domain, *right)))
            }
            Operator::Intersect(left, right) => {
                Operator::Intersect(Box::new(self.push_domain(domain.clone(), *left)), Box::new(self.push_domain(domain, *right)))
            }
            Operator::Except(left, right) => {
                Operator::Except(Box::new(self.push_domain(domain.clone(), *left)), Box::new(self.push_domain(domain, *right)))
            }
            Operator::OrderBy { keys, input } => {
                Operator::OrderBy { keys, input: Box::new(self.push_domain(domain, *input)) }
            }
            Operator::Limit { offset, limit, input } => {
                Operator::Limit { offset, limit, input: Box::new(self.push_domain(domain, *input)) }
            }
            Operator::Unnest { input, column, alias } => {
                Operator::Unnest { input: Box::new(self.push_domain(domain, *input)), column, alias }
            }
            Operator::Cte { name, source, input } => Operator::Cte {
                name,
                source: Box::new(self.push_domain(domain.clone(), *source)),
                input: Box::new(self.push_domain(domain, *input)),
            },
            op @ Operator::Scan { .. } => op,
        }
    }

    fn build_domain(&mut self, left: &Operator, outer_refs: &[Column]) -> Domain {
        let source = Operator::Project {
            outputs: outer_refs.iter().map(|c| (c.name, ScalarExpr::Column(c.clone()))).collect(),
            input: Box::new(left.clone()),
        };
        Domain { columns: outer_refs.to_vec(), source }
    }

    fn build_natural_join(&self, columns: &[Column]) -> ScalarExpr {
        let mut expr = ScalarExpr::Lit(Literal::Bool(true));
        for col in columns {
            let eq = ScalarExpr::Binary(BinOp::Eq,
                Box::new(ScalarExpr::Column(col.clone())),
                Box::new(ScalarExpr::Column(col.clone()))
            );
            expr = ScalarExpr::Binary(BinOp::And, Box::new(expr), Box::new(eq));
        }
        expr
    }

    fn needs_domain(&self, op: &Operator, domain: &Domain) -> bool {
        let free = AttributeAnalysis::free_vars(op);
        let domain_cols: HashSet<Column> = domain.columns.iter().cloned().collect();
        !free.is_disjoint(&domain_cols)
    }

    fn extract_equivalences(&mut self, expr: &ScalarExpr) {
        match expr {
            ScalarExpr::Binary(BinOp::Eq, left, right) => {
                if let (ScalarExpr::Column(a), ScalarExpr::Column(b)) = (left.as_ref(), right.as_ref()) {
                    self.equivalences.union(a, b);
                }
            }
            ScalarExpr::Binary(BinOp::And, left, right) => {
                self.extract_equivalences(left);
                self.extract_equivalences(right);
            }
            _ => {}
        }
    }

    fn rewrite_scalar(&self, expr: &ScalarExpr) -> ScalarExpr {
        match expr {
            ScalarExpr::Column(c) => {
                for scope in self.scope_stack.iter().rev() {
                    if let Some(replacement) = scope.get(c) {
                        return replacement.clone();
                    }
                }
                if let Some(equiv) = self.equivalences.find(c) {
                    return ScalarExpr::Column(equiv);
                }
                ScalarExpr::Column(c.clone())
            }
            ScalarExpr::Binary(op, left, right) => ScalarExpr::Binary(*op,
                Box::new(self.rewrite_scalar(left)),
                Box::new(self.rewrite_scalar(right))
            ),
            ScalarExpr::AggCall(func, args) => ScalarExpr::AggCall(*func,
                args.iter().map(|a| self.rewrite_scalar(a)).collect()
            ),
            ScalarExpr::Window { func, args, partition_by, order_by } => ScalarExpr::Window {
                func: *func,
                args: args.iter().map(|a| self.rewrite_scalar(a)).collect(),
                partition_by: partition_by.iter().map(|p| self.rewrite_scalar(p)).collect(),
                order_by: order_by.iter().map(|o| OrderKey {
                    expr: self.rewrite_scalar(&o.expr),
                    asc: o.asc,
                }).collect(),
            },
            ScalarExpr::Subquery(op) => ScalarExpr::Subquery(Box::new(self.transform((**op).clone()))),
            other => other.clone(),
        }
    }

    fn current_outer_refs(&self) -> Vec<(Column, ScalarExpr)> {
        vec![] // Simplified; in production, track explicitly
    }

    fn fork(&self) -> Self {
        Self {
            tcx: self.tcx,
            scope_stack: self.scope_stack.clone(),
            equivalences: EquivalenceClasses { parent: self.equivalences.parent.clone() },
            fresh_counter: self.fresh_counter,
        }
    }

    fn fresh_name(&mut self, prefix: &str) -> Ident {
        let id = self.fresh_counter;
        self.fresh_counter += 1;
        // In production, intern prefix + id
        id as u32
    }
}
```

### 9.4 Aggregate Registry

```rust
// yelang-vm/src/registry.rs

use std::collections::HashMap;
use yelang_traits::{AggregateFn, AccumulatorState, AggregateProperties};

pub type AggregateFnId = u32;

pub struct AggregateRegistry {
    fns: HashMap<AggregateFnId, Box<dyn ErasedAggregateFn>>,
}

pub trait ErasedAggregateFn: Send + Sync {
    fn properties(&self) -> AggregateProperties;
    fn init(&self) -> Vec<u8>;
    fn accumulate_bytes(&self, state: &mut Vec<u8>, input: &Value);
    fn merge_bytes(&self, left: &mut Vec<u8>, right: Vec<u8>);
    fn finalize_bytes(&self, state: Vec<u8>) -> Value;
}

pub struct CompiledAggregate<F: AggregateFn> {
    _phantom: std::marker::PhantomData<F>,
}

impl<F: AggregateFn> ErasedAggregateFn for CompiledAggregate<F>
where
    F::Input: FromValue + Send,
    F::Output: IntoValue,
    F::State: AccumulatorState,
{
    fn properties(&self) -> AggregateProperties { F::properties() }

    fn init(&self) -> Vec<u8> { F::init().serialize() }

    fn accumulate_bytes(&self, state: &mut Vec<u8>, input: &Value) {
        let mut s = F::State::deserialize(state);
        let i = F::Input::from_value(input).unwrap();
        F::accumulate(&mut s, i);
        *state = s.serialize();
    }

    fn merge_bytes(&self, left: &mut Vec<u8>, right: Vec<u8>) {
        let mut l = F::State::deserialize(left);
        let r = F::State::deserialize(&right);
        F::merge(&mut l, r);
        *left = l.serialize();
    }

    fn finalize_bytes(&self, state: Vec<u8>) -> Value {
        let s = F::State::deserialize(&state);
        F::finalize(s).into_value()
    }
}
```

---

## 10. Example Queries & Lowering

### 10.1 Simple Aggregate

```mm
select users@u[*].{
    name: u.name,
    total_likes: u.posts@p[*].reduce(|a, x| a + x.likes, 0),
}
from users@u:User
links (users)->[writes]->(posts@p:Post)
```

**QIR (correlated):**
```
Project(
  name: u.name,
  total_likes: Subquery(
    GroupBy(
      keys: [],
      aggregates: [reduce(|a,x|a+x.likes, 0)],
      DependentJoin(
        users,
        Filter(p.user_id == u.id, posts)
      )
    )
  )
)
```

**QIR (decorrelated):**
```
Project(
  name: u.name,
  total_likes: D.total_likes,
)
Join(
  Inner,
  users,
  Cte(
    "D",
    GroupBy(
      keys: [u.id],
      aggregates: [SUM(p.likes) AS total_likes],
      Join(posts, users, p.user_id == u.id)
    ),
    users
  ),
  users.id == D.id
)
```

### 10.2 Complex Query with Cross-Referencing Links

```mm
select users@u[*].{
    name: u.name,
    tech_posts: u.writes@w[*].posts@p[where p.genre == "Tech"].title,
    has_young_readers: u.writes@w[*].posts@p[*].read_by@r[*].readers@ru[where ru.age < 20].any(|ru| ru.active),
    avg_reader_age: u.writes@w[*].posts@p[*].read_by@r[*].readers@ru[*].reduce(|a, ru| a + ru.age, 0) / len(u.writes@w[*].posts@p[*].read_by@r[*].readers@ru[*]),
}
from users@u:User
links (users)->[writes@w:UserWritesPost]->(posts@p:Post),
      (posts)->[read_by@r:UserReadsPost]->(readers@ru:User)
```

**Key challenge:** The `read_by` path references `posts` from the first path. The 2025 top-down algorithm handles this by tracking all outer refs simultaneously and extracting a single domain D that covers all free variables.

### 10.3 User-Defined Aggregate

```mm
#[aggregate(associative = true, distributable = true)]
fn geometric_mean(acc: (f64, u64), x: f64) -> (f64, u64) {
    (acc.0 * x, acc.1 + 1)
}

select products@p[*].{
    category: p.category,
    geo_mean: p.items@i[*].reduce(geometric_mean, (1.0, 0)).finalize(|state| state.0.powf(1.0 / state.1 as f64)),
}
from products@p:Product
```

**Note:** The `finalize` closure is applied after the aggregate. If the aggregate itself needs a finalize step, the `#[aggregate]` attribute should declare it, or the compiler should generate a wrapper.

---

## 11. Implementation Roadmap

### Phase 1: Foundation (Weeks 1-4)
- [ ] Implement `AggregateFn` trait and basic built-ins (sum, count, avg, min, max)
- [ ] Implement `AccumulatorState` for serializable types
- [ ] Implement QIR operator enum and basic lowering from HIR
- [ ] Implement simple decorrelator (scalar subqueries only)

### Phase 2: Solver (Weeks 5-8)
- [ ] Implement `AggregateSolver` with canonical goals
- [ ] Implement candidate assembly (builtin, user-defined, closure)
- [ ] Implement closure body analysis for common patterns
- [ ] Integrate solver with typechecker

### Phase 3: Full Decorrelation (Weeks 9-12)
- [ ] Implement Neumann 2025 top-down algorithm
- [ ] Handle `links` paths as dependent joins
- [ ] Handle nested selects, `any`/`all`, `len`
- [ ] Handle `ORDER BY`/`LIMIT` in correlated subqueries

### Phase 4: Distribution (Weeks 13-16)
- [ ] Implement aggregate registry with compiled trait objects
- [ ] Implement physical planner with pushdown decisions
- [ ] Implement `Exchange` nodes for distributed execution
- [ ] Implement storage node partial aggregation

### Phase 5: Optimization (Weeks 17-20)
- [ ] Implement equivalence class-based perfect unnesting
- [ ] Implement domain pruning (only extract columns actually referenced)
- [ ] Implement shared subquery elimination
- [ ] Benchmark against naive nested-loop execution

---

## 12. References

### Papers
1. **Neumann & Kemper (2015)** — *Unnesting Arbitrary Queries*. BTW 2015. The foundational bottom-up algebraic approach.
2. **Neumann (2024)** — *A Formalization of Top-Down Unnesting*. Proves correctness of the 2025 algorithm using characteristic functions.
3. **Neumann (2025)** — *Improving Unnesting of Complex Queries*. BTW 2025. The top-down holistic algorithm that fixes nested-subquery blow-up.
4. **Neumann et al. (2026)** — *How To Scan Nested Data With On-the-Fly Key Generation and Joins*. SIGMOD 2026. Extends to arrays/objects.

### Rust Compiler
5. **rustc Next-Gen Trait Solver** — `compiler/rustc_next_trait_solver/src/solve/`. The canonical goal + candidate assembly pattern.
6. **rustc Trait Selection** — `compiler/rustc_trait_selection/src/traits/select/mod.rs`. Classic trait solver for reference.
7. **rustc-dev-guide** — https://rustc-dev-guide.rust-lang.org/traits/resolution.html

### Code Repositories
8. **Rust Language Repository** — https://github.com/rust-lang/rust
9. **Trait System Refactor Initiative** — https://github.com/rust-lang/trait-system-refactor-initiative

---

## Appendix A: Glossary

| Term | Definition |
|------|-----------|
| **Aggregate** | A function that reduces a collection to a single value (or smaller collection) |
| **Associative** | `f(f(a,b),c) = f(a,f(b,c))`. Required for distributed aggregation |
| **Canonical** | A goal with local variables abstracted, enabling caching and reuse |
| **Decorrelation** | Transforming a correlated subquery into a regular join |
| **Dependent Join** | `L ⋈D R` — a join where R references columns from L |
| **Domain (D)** | The distinct values of outer columns that a subquery references |
| **Distributable** | Can be pushed to distributed storage nodes |
| **Holistic** | Requires seeing all input before producing any output |
| **QIR** | Query Intermediate Representation — relational algebra for YeLang |
| **Unnesting** | Another term for decorrelation — removing nested subquery structure |

---

*End of Document*
