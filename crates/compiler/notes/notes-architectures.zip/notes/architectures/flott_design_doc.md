# Flott Language & Infrastructure Design Document
## Version 0.1.0 — Comprehensive Architecture Specification

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Language Philosophy & Goals](#2-language-philosophy--goals)
3. [Memory Model](#3-memory-model)
4. [Type System](#4-type-system)
5. [Lexer Design](#5-lexer-design)
6. [AST Architecture](#6-ast-architecture)
7. [Name Resolution](#7-name-resolution)
8. [HIR & Lowering](#8-hir--lowering)
9. [MIR Design](#9-mir-design)
10. [Query Language](#10-query-language)
11. [Aggregation Framework](#11-aggregation-framework)
12. [Distributed Execution](#12-distributed-execution)
13. [Storage Engine Integration](#13-storage-engine-integration)
14. [Async & Generators](#14-async--generators)
15. [Interoperability](#15-interoperability)
16. [IDE Support](#16-ide-support)
17. [Compiler Pipeline](#17-compiler-pipeline)
18. [File Tree](#18-file-tree)
19. [Examples](#19-examples)

---

## 1. Executive Summary

Flott is a general-purpose systems programming language designed as the native language for an entire infrastructure stack including databases, storage engines, event buses, and distributed compute. It adopts Rust-like syntax while eliminating lifetimes and borrow checking in favor of a unified memory model based on Copy-on-Write (CoW) reference counting with explicit opt-in for shared mutation.

Key design decisions:
- **No lifetimes, no borrow checker**: Memory safety via CoW + regions + explicit unsafe opt-ins
- **First-class queries**: Query expressions are syntactic sugar over method chains on the `Queryable` trait
- **Unified aggregation**: User-defined aggregates via a single `Aggregate` trait with classification (Distributive/Algebraic/Holistic)
- **Zero-copy serialization**: Apache Arrow IPC for cross-node data transfer
- **Storage-aware execution**: Same query compiles to embedded iterators, SQL, or distributed plans
- **Lang items, not registries**: Compiler recognizes optimizable patterns via `#[lang]` traits, not hardcoded registries

---

## 2. Language Philosophy & Goals

### 2.1 Core Principles

| Principle | Implementation |
|-----------|---------------|
| **Expressiveness** | General-purpose language with query syntax sugar, not a DSL |
| **Performance** | Zero-copy where possible, CoW for mutations, arena allocation for queries |
| **Scalability** | Distributive/Algebraic aggregates parallelize; Holistic gather-all |
| **Correctness** | Strong static typing, no implicit conversions, explicit effects |
| **Interoperability** | C ABI + Arrow IPC + generated bindings for Python/Rust/JS/TS |
| **IDE-First** | Same AST/compiler pipeline for batch compilation and language server |

### 2.2 What Flott Is Not

- Not a SQL replacement (it's a general language with query capabilities)
- Not Rust (no lifetimes, no borrow checker, different memory model)
- Not a garbage-collected language (deterministic RC + CoW + regions)
- Not a DSL (queries compile to regular method calls on regular traits)

---

## 3. Memory Model

### 3.1 The Unified Reference Type: `Share<T>`

Flott has one reference type in the surface language. The compiler optimizes it based on usage:

```flott
// User writes:
let users = load_users();        // Share<Users>
let active = users.filter(...);   // Shares underlying data, no copy
let total = active.sum();         // i32 (primitive, copied)

// Mutation triggers CoW:
let mut modified = users;         // Same Share, refcount > 1
modified[0].name = "Alice";       // Deep copy triggered, then mutate
```

### 3.2 Under the Hood (MIR)

```rust
// Generated MIR for `modified[0].name = "Alice"`
%0 = load users                 // Share<Users>
%1 = rc_check %0              // Check strong_count
%2 = branch %1 > 1, cow, inplace

cow:
  %3 = deep_clone %0          // Copy all fields recursively
  %4 = store %3 -> modified
  jmp write

inplace:
  %5 = store %0 -> modified

write:
  %6 = field_write modified[0].name = "Alice"
```

### 3.3 Memory Categories

| Category | Semantics | Implementation |
|----------|-----------|---------------|
| **Primitives** (`i32`, `f64`, `bool`) | `Copy` (implicit) | Stack or register |
| **Small structs** (< 64 bytes, no heap) | `Copy` by default | `memcpy` |
| **Large structs / collections** | `Share<T>` (CoW) | Non-atomic RC (single-threaded); atomic RC (cross-thread) |
| **Closures** | `Share<T>` | Capture environment by RC |
| **Query results** | `Arena<T>` | Bump allocator, freed when query completes |
| **Cross-request caches** | `Share<T>` + explicit invalidation | Atomic RC |

### 3.4 Why Not GC?

- **Deterministic destruction**: Critical for file handles, sockets, storage cursors
- **No pause times**: Essential for database/storage engine SLAs
- **RC + escape analysis**: Most RC ops optimized away for local variables
- **Regions for queries**: Short-lived data uses arena, no refcount overhead

### 3.5 Explicit Opt-Ins

```flott
// Shared mutation (honest model)
let shared = RefCell::new(Point { x: 1, y: 2 });
let a = shared;
let b = shared;
b.borrow_mut().x = 5;   // a sees the change

// Raw pointer for FFI/unsafe
let raw: *Node = ...;    // Unsafe escape hatch
```

---

## 4. Type System

### 4.1 Core Types

```flott
// Primitives
let i: i32 = 42;
let f: f64 = 3.14;
let b: bool = true;
let c: char = 'a';

// String (interned, immutable, RC)
let s: String = "hello";

// Collections
let v: Vec<i32> = [1, 2, 3];
let m: Map<String, i32> = {"a": 1, "b": 2};

// Structs (RC by default)
struct Point { x: f32, y: f32 }
let p = Point { x: 1.0, y: 2.0 };  // Share<Point>

// Enums (tagged unions)
enum Result<T, E> {
    Ok(T),
    Err(E),
}

// Structural unions
type Status = Active | Inactive | Pending;
type StringOrNum = String | i32;

// Anonymous structs
let anon: { x: i32, y: i32 } = { x: 1, y: 2 };

// Literal types
type HttpStatus = 200 | 404 | 500;
type LogLevel = "debug" | "info" | "warn" | "error";

// Type-level operators
type UserSafe = Omit<User, "password_hash", "internal_id">;
type HandlerSig = Params<typeof(my_handler)>;   // (Request, Context)
type HandlerRet = ReturnType<typeof(my_handler)>; // Response
type PartialUser = Partial<User>;  // All fields optional
```

### 4.2 Type Aliases

All types can be aliased:

```flott
type MyUnion = String | i32 | bool;
type MyEnum = Result<String, Error>;
type UserSafe = Omit<User, "password_hash">;
```

### 4.3 Generics

```flott
struct Vec<T> {
    data: Box<[T]>,
    len: usize,
}

fn identity<T>(x: T) -> T {
    x
}

fn max<T: Ord>(a: T, b: T) -> T {
    if a > b { a } else { b }
}
```

**No lifetime parameters.** `&T` exists internally but not in user code.

---

## 5. Lexer Design

### 5.1 Architecture

Hand-rolled state machine with jump table for single-byte tokens, perfect hash table for keywords.

```rust
// lexer/mod.rs

pub struct Lexer<'a> {
    source: &'a [u8],       // Raw bytes for fast indexing
    pos: usize,
    line: u32,
    col: u32,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum TokenKind {
    // Literals
    Integer(i64),
    Float(f64),
    String(Symbol),
    Char(char),
    Bool(bool),

    // Identifiers
    Ident(Symbol),
    TypeIdent(Symbol),
    Underscore,

    // Keywords
    Fn, Let, Mut, If, Else, Match, Loop, Break, Continue, Return,
    Struct, Enum, Union, Trait, Impl, For, In, Where,
    Select, From, Links, GroupBy, OrderBy, WhereKw,
    Into, As, Is, TypeOf,

    // Operators
    Plus, Minus, Star, Slash, Percent,
    Eq, NotEq, Lt, Gt, Le, Ge,
    And, Or, Not,
    Assign, PlusAssign, MinusAssign,
    Arrow, FatArrow,
    At, Dot, DotDot, DotDotDot,
    Colon, ColonColon, Semi, Comma,
    LParen, RParen, LBracket, RBracket, LBrace, RBrace,

    // Special
    Eof,
    Error(LexError),
}
```

### 5.2 State Machine (Fast Path)

```rust
impl<'a> Lexer<'a> {
    pub fn next_token(&mut self) -> Token {
        self.skip_whitespace_and_comments();

        let start = self.pos;
        let byte = self.peek_byte();

        match byte {
            b'+' => {
                self.advance();
                if self.peek_byte() == b'=' {
                    self.advance();
                    return self.token_at(start, PlusAssign);
                }
                return self.token_at(start, Plus);
            }
            b'-' => {
                self.advance();
                match self.peek_byte() {
                    b'>' => { self.advance(); return self.token_at(start, Arrow); }
                    b'=' => { self.advance(); return self.token_at(start, MinusAssign); }
                    _ => return self.token_at(start, Minus),
                }
            }
            b'@' => { self.advance(); return self.token_at(start, At); }
            b'.' => {
                self.advance();
                match (self.peek_byte(), self.peek_byte_at(1)) {
                    (b'.', b'.') => { self.advance_by(2); return self.token_at(start, DotDotDot); }
                    (b'.', _) => { self.advance(); return self.token_at(start, DotDot); }
                    _ => return self.token_at(start, Dot),
                }
            }
            b'a'..=b'z' | b'_' => return self.ident_or_keyword(start),
            b'A'..=b'Z' => return self.type_ident(start),
            b'0'..=b'9' => return self.number(start),
            b'"' | b''' => return self.string_or_char(start),
            0 => return self.token_at(start, Eof),
            _ => {
                self.advance_utf8();
                return self.token_at(start, Error(InvalidChar));
            }
        }
    }
}
```

### 5.3 Keyword Table (Perfect Hash)

```rust
// lexer/keywords.rs

static KEYWORD_TABLE: phf::Map<&'static [u8], TokenKind> = phf_map! {
    b"fn" => TokenKind::Fn,
    b"let" => TokenKind::Let,
    b"mut" => TokenKind::Mut,
    b"if" => TokenKind::If,
    b"else" => TokenKind::Else,
    b"match" => TokenKind::Match,
    b"loop" => TokenKind::Loop,
    b"break" => TokenKind::Break,
    b"continue" => TokenKind::Continue,
    b"return" => TokenKind::Return,
    b"struct" => TokenKind::Struct,
    b"enum" => TokenKind::Enum,
    b"union" => TokenKind::Union,
    b"trait" => TokenKind::Trait,
    b"impl" => TokenKind::Impl,
    b"for" => TokenKind::For,
    b"in" => TokenKind::In,
    b"where" => TokenKind::Where,
    b"select" => TokenKind::Select,
    b"from" => TokenKind::From,
    b"links" => TokenKind::Links,
    b"group" => TokenKind::GroupBy,
    b"order" => TokenKind::OrderBy,
    b"into" => TokenKind::Into,
    b"as" => TokenKind::As,
    b"is" => TokenKind::Is,
    b"typeof" => TokenKind::TypeOf,
    b"true" => TokenKind::Bool(true),
    b"false" => TokenKind::Bool(false),
};
```

---

## 6. AST Architecture

### 6.1 Design Principles

- **Arena allocation**: All nodes allocated in a bump allocator
- **Lifetime `'a`**: All nodes reference the arena
- **Struct variants**: Self-documenting field names
- **Generated visitors**: Via proc macro from AST definitions

### 6.2 Core AST Types

```rust
// ast/mod.rs

pub struct Ast<'a> {
    pub allocator: &'a Allocator,
    pub source: &'a str,
    pub items: Vec<'a, Item<'a>>,
}

pub struct Item<'a> {
    pub span: Span,
    pub kind: ItemKind<'a>,
    pub attrs: Vec<'a, Attribute<'a>>,
}

pub enum ItemKind<'a> {
    Fn { item: FnItem<'a> },
    Struct { item: StructItem<'a> },
    Enum { item: EnumItem<'a> },
    Union { item: UnionItem<'a> },
    Trait { item: TraitItem<'a> },
    Impl { item: ImplItem<'a> },
    TypeAlias { item: TypeAliasItem<'a> },
    Const { item: ConstItem<'a> },
    Static { item: StaticItem<'a> },
    Mod { item: ModItem<'a> },
    Use { item: UseItem<'a> },
}

pub struct FnItem<'a> {
    pub name: Ident,
    pub generics: Option<&'a Generics<'a>>,
    pub params: Vec<'a, Param<'a>>,
    pub ret: Option<&'a Ty<'a>>,
    pub body: &'a Expr<'a>,
    pub is_async: bool,
    pub is_const: bool,
}

pub struct Param<'a> {
    pub span: Span,
    pub pat: &'a Pat<'a>,
    pub ty: Option<&'a Ty<'a>>,
    pub kind: ParamKind,
}

pub enum ParamKind {
    Regular,
    SelfValue,
    SelfRef { mutability: Mutability },
    QueryBinding { cardinality: Cardinality },
}
```

### 6.3 Expressions

```rust
pub enum Expr<'a> {
    Lit { lit: &'a Lit<'a> },
    Path { path: Path<'a> },
    Binary { op: BinOp, left: &'a Expr<'a>, right: &'a Expr<'a> },
    Unary { op: UnOp, expr: &'a Expr<'a> },
    Call { func: &'a Expr<'a>, args: Vec<'a, &'a Expr<'a>> },
    MethodCall { receiver: &'a Expr<'a>, method: Ident, args: Vec<'a, &'a Expr<'a>> },
    Field { expr: &'a Expr<'a>, field: Ident },
    Index { expr: &'a Expr<'a>, index: &'a Expr<'a> },
    StructLit { lit: &'a StructLit<'a> },
    ArrayLit { elems: Vec<'a, &'a Expr<'a>> },
    Block { block: &'a Block<'a> },
    If { cond: &'a Expr<'a>, then_branch: &'a Expr<'a>, else_branch: Option<&'a Expr<'a>> },
    Match { expr: &'a Expr<'a>, arms: Vec<'a, Arm<'a>> },
    Loop { block: &'a Block<'a>, label: Option<Label> },
    While { cond: &'a Expr<'a>, block: &'a Block<'a> },
    For { pat: &'a Pat<'a>, expr: &'a Expr<'a>, block: &'a Block<'a> },
    Closure { params: Vec<'a, Param<'a>>, body: &'a Expr<'a> },
    Async { block: &'a Block<'a> },
    Await { expr: &'a Expr<'a> },
    Try { expr: &'a Expr<'a> },
    Assign { left: &'a Expr<'a>, right: &'a Expr<'a> },
    CompoundAssign { op: BinOp, left: &'a Expr<'a>, right: &'a Expr<'a> },
    Range { start: Option<&'a Expr<'a>>, end: Option<&'a Expr<'a>>, kind: RangeKind },
    Cast { expr: &'a Expr<'a>, ty: &'a Ty<'a> },
    Query { query: &'a QueryExpr<'a> },
    Err,
}
```

### 6.4 Types

```rust
pub enum Ty<'a> {
    Path { path: Path<'a> },
    Tuple { elems: Vec<'a, &'a Ty<'a>> },
    Array { elem: &'a Ty<'a>, len: &'a Expr<'a> },
    Slice { elem: &'a Ty<'a> },
    Ref { mutability: Mutability, elem: &'a Ty<'a> },
    Fn { params: Vec<'a, &'a Ty<'a>>, ret: &'a Ty<'a> },
    AnonStruct { fields: Vec<'a, FieldDef<'a>> },
    Union { variants: Vec<'a, &'a Ty<'a>> },
    TypeOf { expr: &'a Expr<'a> },
    TypeIs { expr: &'a Expr<'a>, ty: &'a Ty<'a> },
    Query { query: &'a QueryExpr<'a> },
    Lit { lit: LitTy },
    Omit { ty: &'a Ty<'a>, fields: Vec<'a, Symbol> },
    Pick { ty: &'a Ty<'a>, fields: Vec<'a, Symbol> },
    ReturnType { ty: &'a Ty<'a> },
    Params { ty: &'a Ty<'a> },
    Infer,
    Err,
}
```

### 6.5 Query Expressions

```rust
pub struct QueryExpr<'a> {
    pub span: Span,
    pub projection: &'a Expr<'a>,
    pub sources: Vec<'a, QuerySource<'a>>,
    pub links: Vec<'a, LinkDef<'a>>,
    pub filter: Option<&'a Expr<'a>>,
    pub group_by: Option<&'a GroupBy<'a>>,
    pub order_by: Option<&'a OrderBy<'a>>,
    pub range: Option<&'a Range<'a>>,
}

pub struct QuerySource<'a> {
    pub collection: Path<'a>,
    pub alias: Ident,
    pub ty: &'a Ty<'a>,
    pub cardinality: Cardinality,
}

pub enum Cardinality {
    One,
    Many,
    Flatten,
    Optional,
}

pub struct LinkDef<'a> {
    pub from: Path<'a>,
    pub from_alias: Ident,
    pub edge: Path<'a>,
    pub edge_alias: Ident,
    pub edge_ty: &'a Ty<'a>,
    pub to: Path<'a>,
    pub to_alias: Ident,
}

pub struct GroupBy<'a> {
    pub key: &'a Expr<'a>,
    pub into: Ident,
}

pub struct OrderBy<'a> {
    pub key: &'a Expr<'a>,
    pub direction: Direction,
}
```

### 6.6 Arena Allocation

```rust
// ast/arena.rs

use bumpalo::Bump;

pub struct Allocator {
    bump: Bump,
}

impl Allocator {
    pub fn new() -> Self {
        Self { bump: Bump::new() }
    }

    pub fn alloc<T>(&self, value: T) -> &mut T {
        self.bump.alloc(value)
    }

    pub fn alloc_slice<T: Copy>(&self, values: &[T]) -> &mut [T] {
        self.bump.alloc_slice_copy(values)
    }

    pub fn alloc_str(&self, string: &str) -> &str {
        self.bump.alloc_str(string)
    }
}
```

---

## 7. Name Resolution

### 7.1 Two-Pass Resolution (Like rustc)

```rust
// resolve/early.rs — Build module tree, resolve imports
// resolve/late.rs — Resolve paths in expressions, types, patterns
```

### 7.2 Decorator Resolution

Decorators are resolved like regular items. The compiler doesn't know what `@table` means — it just resolves the path and validates the decorator exists.

```rust
// resolve/decorator.rs

pub fn resolve_decorators(item: &Item, resolver: &mut Resolver) -> Vec<ResolvedDecorator> {
    item.attrs.iter()
        .filter_map(|attr| match &attr.kind {
            AttrKind::Decorator(dec) => {
                let def_id = resolver.resolve_path(&dec.path)?;
                Some(ResolvedDecorator {
                    def_id,
                    args: resolve_decorator_args(dec, resolver),
                })
            }
            _ => None,
        })
        .collect()
}
```

### 7.3 Query Binding Resolution

```flott
select users@u[*].{ name: u.name } from users@u:User
//     ^^^^^^^^                       ^^^^^^^^
//     u bound here                    u bound here (shadows if same name)
```

The `@` operator creates a binding in the current scope. Late resolution handles this like any other pattern binding.

---

## 8. HIR & Lowering

### 8.1 HIR Structure

HIR is a desugared, name-resolved version of AST. Every path is a `DefId` or `HirId`.

```rust
// hir/mod.rs

pub struct Crate<'hir> {
    pub items: &'hir [Item<'hir>],
    pub bodies: Bodies<'hir>,
}

pub struct Item<'hir> {
    pub hir_id: HirId,
    pub def_id: DefId,
    pub ident: Ident,
    pub kind: ItemKind<'hir>,
    pub attrs: &'hir [Attribute<'hir>],
}

pub enum ItemKind<'hir> {
    Fn { sig: FnSig<'hir>, body: BodyId },
    Struct { def: StructDef<'hir> },
    Enum { def: EnumDef<'hir> },
    Union { def: UnionDef<'hir> },
    Trait { items: &'hir [TraitItem<'hir>] },
    Impl { items: &'hir [ImplItem<'hir>] },
    // ...
}
```

### 8.2 Query Lowering

Query syntax lowers to method calls on `Queryable`:

```flott
// Surface:
select users@u[*].{ id, age }
from users@u:User
where u.age > 18
order by u.age desc
range 20..30

// Lowered HIR:
users
    .filter(|u| u.age > 18)
    .order_by(|u| u.age, desc)
    .range(20..30)
    .map(|u| { id: u.id, age: u.age })
```

### 8.3 Decorator Expansion

```flott
// Surface:
@derive(Show, Eq)
struct Point { x: i32, y: i32 }

// After decorator expansion:
struct Point { x: i32, y: i32 }

impl Show for Point { ... }  // Generated
impl Eq for Point { ... }    // Generated
```

---

## 9. MIR Design

### 9.1 MIR Structure

MIR is a control-flow graph with explicit memory operations.

```rust
// mir/mod.rs

pub struct Body<'tcx> {
    pub blocks: Vec<BasicBlock>,
    pub locals: Vec<LocalDecl<'tcx>>,
    pub arg_count: usize,
}

pub struct BasicBlock {
    pub statements: Vec<Statement<'tcx>>,
    pub terminator: Terminator<'tcx>,
}

pub enum Statement<'tcx> {
    Assign(Place<'tcx>, Rvalue<'tcx>),
    SetDiscriminant(Place<'tcx>, VariantIdx),
    StorageLive(Local),
    StorageDead(Local),
    // Memory management
    RcNew { dest: Place<'tcx>, type_id: DefId },
    RcClone { dest: Place<'tcx>, source: Operand<'tcx> },
    RcDrop(Place<'tcx>),
    CowClone { dest: Place<'tcx>, source: Operand<'tcx> },
    // Effects
    EffectBarrier(Effect),
}

pub enum Rvalue<'tcx> {
    Use(Operand<'tcx>),
    BinaryOp(BinOp, Operand<'tcx>, Operand<'tcx>),
    UnaryOp(UnOp, Operand<'tcx>),
    Ref(Place<'tcx>),
    Aggregate(AggKind, Vec<Operand<'tcx>>),
    Discriminant(Place<'tcx>),
    VirtualCall { method: DefId, receiver: Operand<'tcx>, args: Vec<Operand<'tcx>> },
}

pub enum Terminator<'tcx> {
    Goto(BlockId),
    SwitchInt { discr: Operand<'tcx>, targets: Vec<(u128, BlockId)>, otherwise: BlockId },
    Call { func: Operand<'tcx>, args: Vec<Operand<'tcx>>, destination: Place<'tcx>, cleanup: Option<BlockId> },
    Return,
    Unreachable,
}
```

### 9.2 CoW MIR Generation

```rust
// mir/cow.rs

fn generate_assignment(dest: Place, source: Operand, ty: Ty) -> Vec<Statement> {
    if ty.is_copy() {
        // Primitives, small structs: direct copy
        vec![Statement::Assign(dest, Rvalue::Use(source))]
    } else {
        // Share<T>: check refcount, clone or CoW
        vec![
            Statement::RcClone { dest, source },
        ]
    }
}

fn generate_mutation(place: Place, ty: Ty) -> Vec<Statement> {
    vec![
        Statement::CowClone { dest: place.clone(), source: Operand::Copy(place.clone()) },
        // ... actual mutation
    ]
}
```

---

## 10. Query Language

### 10.1 Surface Syntax

```flott
// Basic query
select users@u[*].{ id, name, age }
from users@u:User
where u.age > 18

// With links
select users@u[*].{
    name: u.name,
    books: u.writes@w[*].books@b[*].{ title: b.title }
}
from users@u:User
links (users)->[writes]->(books)
where u.active == true

// Group by
select groups@g[*].{
    city: g.city,
    avg_age: g.users.avg(u => u.age),
    total: g.users.count()
}
from users@u:User
group by { city: u.city } into groups

// Order and range
select users@u[*].{ id, age }
from users@u:User
order by u.age desc
range 20..30

// Type is and typeof
let active_users = select users@u[*] from users where u.status is Active;
let max_age: typeof(active_users.map(u => u.age).max()) = ...;
```

### 10.2 Lowering to Method Calls

```flott
// Surface query:
select users@u[*].{ id, age }
from users@u:User
where u.age > 18

// Lowered HIR:
users
    .filter(|u| u.age > 18)
    .map(|u| { id: u.id, age: u.age })

// Type: Iterator<{ id: i32, age: i32 }>
```

### 10.3 Cardinality Rules

| Syntax | Cardinality | Output Type |
|--------|-------------|-------------|
| `users@u` | One | `User` |
| `users@u[*]` | Many | `Iterator<User>` |
| `users@u[**]` | Flatten | `Iterator<T>` (flattens nested) |
| `users@u[?]` | Optional | `Option<User>` |

---

## 11. Aggregation Framework

### 11.1 The Aggregate Trait

```flott
// core/aggregate.fl

#[lang = "aggregate"]
trait Aggregate<T, Acc, Out> {
    fn init(self: &Self) -> Acc;
    fn iterate(self: &Self, acc: Acc, value: T) -> Acc;
    fn merge(self: &Self, left: Acc, right: Acc) -> Acc;
    fn finalize(self: &Self, acc: Acc) -> Out;
    fn classify(self: &Self) -> AggregateClass;
}

enum AggregateClass {
    Distributive,   // Partial results mergeable: sum, count, min, max
    Algebraic,      // Fixed-size intermediate: avg, stddev
    Holistic,       // Must see all data: median, percentile, mode
}
```

### 11.2 Built-in Aggregates

```flott
// Sum — Distributive, zero-sized config
struct Sum;

impl<T: Add + Zero> Aggregate<T, SumAcc<T>, T> for Sum {
    fn init(self: &Self) -> SumAcc<T> { SumAcc { value: T::zero() } }
    fn iterate(self: &Self, acc: SumAcc<T>, value: T) -> SumAcc<T> {
        SumAcc { value: acc.value + value }
    }
    fn merge(self: &Self, a: SumAcc<T>, b: SumAcc<T>) -> SumAcc<T> {
        SumAcc { value: a.value + b.value }
    }
    fn finalize(self: &Self, acc: SumAcc<T>) -> T { acc.value }
    fn classify(self: &Self) -> AggregateClass { Distributive }
}

struct SumAcc<T> { value: T }

// Avg — Algebraic, zero-sized config
struct Avg;

impl<T: Add + Zero + ToF64> Aggregate<T, AvgAcc<T>, f64> for Avg {
    fn init(self: &Self) -> AvgAcc<T> { AvgAcc { sum: T::zero(), count: 0 } }
    fn iterate(self: &Self, acc: AvgAcc<T>, value: T) -> AvgAcc<T> {
        AvgAcc { sum: acc.sum + value, count: acc.count + 1 }
    }
    fn merge(self: &Self, a: AvgAcc<T>, b: AvgAcc<T>) -> AvgAcc<T> {
        AvgAcc { sum: a.sum + b.sum, count: a.count + b.count }
    }
    fn finalize(self: &Self, acc: AvgAcc<T>) -> f64 {
        acc.sum.to_f64() / acc.count as f64
    }
    fn classify(self: &Self) -> AggregateClass { Algebraic }
}

struct AvgAcc<T> { sum: T, count: usize }

// Percentile — Holistic, has config fields
struct Percentile { p: f64 }

impl<T: Ord + Clone> Aggregate<T, PercentileAcc<T>, T> for Percentile {
    fn init(self: &Self) -> PercentileAcc<T> {
        PercentileAcc { values: Vec::new(), p: self.p }
    }
    fn iterate(self: &Self, mut acc: PercentileAcc<T>, value: T) -> PercentileAcc<T> {
        acc.values.push(value);
        acc
    }
    fn merge(self: &Self, mut a: PercentileAcc<T>, b: PercentileAcc<T>) -> PercentileAcc<T> {
        a.values.extend(b.values);
        a
    }
    fn finalize(self: &Self, mut acc: PercentileAcc<T>) -> T {
        acc.values.sort();
        let idx = (acc.values.len() as f64 * acc.p) as usize;
        acc.values[idx].clone()
    }
    fn classify(self: &Self) -> AggregateClass { Holistic }
}

struct PercentileAcc<T> { values: Vec<T>, p: f64 }
```

### 11.3 User-Defined Aggregates

```flott
// User writes:
@aggregate(class = Holistic)
fn percentile(values: Iterator<f64>, p: f64) -> f64 {
    let mut sorted = values.collect::<Vec<f64>>();
    sorted.sort();
    sorted[(sorted.len() as f64 * p) as usize]
}

// The @aggregate decorator expands to:
// 1. Define Percentile struct with p field
// 2. impl Aggregate<f64, PercentileAcc<f64>, f64> for Percentile
// 3. Define percentile() method on Queryable<f64>
// 4. Register in lang item system
```

### 11.4 The Queryable Trait

```flott
// core/queryable.fl

#[lang = "queryable"]
trait Queryable<T> {
    fn map<U>(self, f: impl Fn(T) -> U) -> impl Queryable<U>;
    fn filter(self, pred: impl Fn(&T) -> bool) -> impl Queryable<T>;
    fn flat_map<U>(self, f: impl Fn(T) -> impl Queryable<U>) -> impl Queryable<U>;

    // Core aggregation hook
    fn aggregate<A, Acc, Out>(self, agg: A) -> Out
    where A: Aggregate<T, Acc, Out>;

    // Sugar (default implementations)
    fn sum(self) -> T where T: Add + Zero, Self: Sized {
        self.aggregate(Sum)
    }

    fn avg(self) -> f64 where T: Numeric, Self: Sized {
        self.aggregate(Avg)
    }

    fn count(self) -> usize where Self: Sized {
        self.aggregate(Count)
    }

    fn percentile(self, p: f64) -> T where T: Ord + Clone, Self: Sized {
        self.aggregate(Percentile { p })
    }

    fn group_by<K>(self, key: impl Fn(&T) -> K) -> impl Queryable<Group<K, T>>;
    fn order_by(self, key: impl Fn(&T) -> impl Ord, dir: Direction) -> impl Queryable<T>;
    fn range(self, r: Range<usize>) -> impl Queryable<T>;

    fn execute(self) -> Vec<T>;
}
```

---

## 12. Distributed Execution

### 12.1 Operator Algebra

The compiler core knows 6 operator kinds:

```rust
// query/operator.rs

pub enum Operator {
    Source(SourceOp),
    Transform { input: Box<Operator>, kind: TransformKind, closure: ClosureId },
    Aggregate { input: Box<Operator>, group_by: Option<ClosureId>, aggregation: Aggregation },
    Combine { kind: CombineKind, left: Box<Operator>, right: Box<Operator>, on: ClosureId },
    Order { input: Box<Operator>, keys: Vec<(ClosureId, Direction)> },
    Limit { input: Box<Operator>, skip: usize, take: usize },
}

pub enum TransformKind {
    Map,
    Filter,
    FlatMap,
    Project,
}

pub enum Aggregation {
    Fold { init: Value, combine: ClosureId },
    Scalar { method: DefId, class: AggregateClass },
    Group,
}
```

### 12.2 Physical Plans by Backend

```flott
// Same query:
let total = users.filter(u => u.age > 18).sum();

// Embedded backend:
// Iterator chain: scan -> filter -> fold

// Distributed backend (Distributive):
// Phase 1 (each node): partial_sum = local_users.filter(...).sum()
// Phase 2 (coordinator): total = partial_sum_1 + partial_sum_2 + ...

// SQL backend:
// SELECT SUM(age) FROM users WHERE age > 18
```

### 12.3 Exchange Operators

```rust
// backend/distributed.rs

pub enum PhysicalPlan {
    Scan { table: DefId, predicate: Option<Expr> },
    Filter { input: Box<PhysicalPlan>, predicate: Expr },
    Project { input: Box<PhysicalPlan>, exprs: Vec<Expr> },
    Aggregate { input: Box<PhysicalPlan>, agg: AggregateMode },

    // Distributed-specific
    Exchange {
        input: Box<PhysicalPlan>,
        hash: Option<Expr>,  // None = broadcast, Some = hash shuffle
    },
    Gather {
        input: Box<PhysicalPlan>,  // Collect all data to coordinator
    },

    // Local execution fallback
    Local { expr: Expr },
}

pub enum AggregateMode {
    Partial,   // Per-node partial aggregation
    Final,     // Merge partials
    Full,      // Holistic: must see all data
}
```

### 12.4 Zero-Copy Serialization (Arrow IPC)

```rust
// Arrow IPC for cross-node data transfer

// Node produces Arrow RecordBatch
let batch = RecordBatch::try_new(
    schema.clone(),
    vec![
        Arc::new(Int32Array::from(vec![1, 2, 3])) as ArrayRef,
        Arc::new(StringArray::from(vec!["a", "b", "c"])) as ArrayRef,
    ],
)?;

// Serialize: metadata only, buffers shared via mmap/RDMA
let ipc = serialize_ipc(&batch);  // ~100 bytes of metadata

// Send over network
socket.send(&ipc);

// Deserialize on receiver: zero-copy, points to same buffers
let batch = deserialize_ipc(&ipc);  // No data copied
```

---

## 13. Storage Engine Integration

### 13.1 Storage Trait

```flott
// infra/storage.fl

trait StorageBackend {
    fn capabilities(self: &Self) -> StorageCapabilities;
    fn collection<T>(self: &Self, name: String) -> impl Queryable<T>;
    fn transaction(self: &Self) -> impl Transaction;
}

struct StorageCapabilities {
    pushdown_filter: bool,
    pushdown_project: bool,
    indexed_scan: bool,
    streaming: bool,
    distributed: bool,
    supports_shuffle: bool,
    supports_sql: bool,
    supports_seek: bool,
}

trait Transaction {
    fn get<T>(self: &Self, collection: String, key: Value) -> Option<T>;
    fn put<T>(self: &Self, collection: String, key: Value, value: T);
    fn commit(self: Self);
}
```

### 13.2 LSM Storage Implementation

```flott
// infra/storage/lsm.fl

struct LsmStorage {
    engine: LsmEngine,
}

impl StorageBackend for LsmStorage {
    fn capabilities(self: &Self) -> StorageCapabilities {
        StorageCapabilities {
            pushdown_filter: true,
            pushdown_project: true,
            indexed_scan: true,
            streaming: true,
            distributed: false,
            supports_shuffle: false,
            supports_sql: false,
            supports_seek: true,
        }
    }

    fn collection<T>(self: &Self, name: String) -> LsmCollection<T> {
        LsmCollection { storage: self, name }
    }
}

struct LsmCollection<T> {
    storage: &LsmStorage,
    name: String,
}

impl<T> Queryable<T> for LsmCollection<T> {
    fn map<U>(self, f: impl Fn(T) -> U) -> LsmMap<T, U> {
        LsmMap { source: self, f }
    }

    fn filter(self, pred: impl Fn(&T) -> bool) -> LsmFilter<T> {
        // Push predicate to storage layer
        LsmFilter { source: self, pred, pushed: true }
    }

    fn aggregate<A, Acc, Out>(self, agg: A) -> Out
    where A: Aggregate<T, Acc, Out> {
        // Use storage-native aggregation if available
        if self.storage.engine.supports_aggregate(A::classify()) {
            self.storage.engine.aggregate(self.name, agg)
        } else {
            // Fallback: scan and aggregate
            let mut acc = agg.init();
            for item in self {
                acc = agg.iterate(acc, item);
            }
            agg.finalize(acc)
        }
    }
}
```

---

## 14. Async & Generators

### 14.1 Async Desugaring

```flott
// Surface:
async fn fetch_users() -> Vec<User> {
    let db = connect_db();
    let users = db.query("SELECT * FROM users").await;
    users
}

// Desugared to state machine:
enum FetchUsersState {
    Start,
    Connected { db: DbConnection },
    Queried { db: DbConnection, users: Vec<User> },
    Done,
}

fn fetch_users_poll(state: &mut FetchUsersState) -> Poll<Vec<User>> {
    match state {
        FetchUsersState::Start => {
            let db = connect_db();
            *state = FetchUsersState::Connected { db };
            Poll::Pending
        }
        FetchUsersState::Connected { db } => {
            match db.query_poll() {
                Poll::Ready(users) => {
                    *state = FetchUsersState::Queried { db, users };
                    Poll::Pending
                }
                Poll::Pending => Poll::Pending,
            }
        }
        FetchUsersState::Queried { users, .. } => {
            Poll::Ready(users)
        }
        _ => unreachable!(),
    }
}
```

### 14.2 Generator Desugaring

```flott
// Surface:
fn count_up() -> impl Iterator<i32> {
    for i in 0..10 {
        yield i;
    }
}

// Desugared:
enum CountUpState {
    Start,
    Loop { i: i32 },
    Done,
}

fn count_up_next(state: &mut CountUpState) -> Option<i32> {
    match state {
        CountUpState::Start => {
            *state = CountUpState::Loop { i: 0 };
            Some(0)
        }
        CountUpState::Loop { i } => {
            if *i < 9 {
                *i += 1;
                Some(*i)
            } else {
                *state = CountUpState::Done;
                None
            }
        }
        CountUpState::Done => None,
    }
}
```

### 14.3 Key Difference from Rust

- No `Pin` (no lifetimes)
- State is `Share<State>` (ref-counted)
- Captures are cloned into state machine (CoW semantics)

---

## 15. Interoperability

### 15.1 C ABI Export

```flott
// In Flott:
@repr(C)
@export
struct User {
    id: i64,
    name: String,
    age: i32,
}

@export
fn get_users() -> Vec<User> {
    // ...
}

// Generates C header:
// typedef struct { int64_t id; const char* name; int32_t age; } User;
// UserArray get_users();
```

### 15.2 Python Bindings

```python
# Generated Python module:
from flott import ffi

class User:
    id: int
    name: str
    age: int

def get_users() -> list[User]:
    return ffi.call("get_users")
```

### 15.3 TypeScript Declarations

```typescript
// Generated TypeScript:
interface User {
    id: bigint;
    name: string;
    age: number;
}

declare function get_users(): User[];
```

### 15.4 Arrow IPC for Data Transfer

```python
# Python receives Arrow IPC from Flott
import pyarrow as pa

with pa.ipc.open_stream(socket) as reader:
    for batch in reader:
        df = batch.to_pandas()  # Zero-copy where possible
```

---

## 16. IDE Support

### 16.1 Language Server Protocol (LSP)

```rust
// lsp/server.rs

pub struct LanguageServer {
    compiler: CompilerInstance,
    documents: HashMap<Uri, Document>,
}

impl LanguageServer {
    fn on_change(&mut self, uri: Uri, text: String) {
        let (ast, errors) = self.compiler.parse_incremental(&text);
        let (hir, resolve_errors) = self.compiler.resolve_with_cache(&ast);
        let (typed_hir, type_errors) = self.compiler.typeck_partial(&hir);

        self.publish_diagnostics(uri, errors + resolve_errors + type_errors);
    }

    fn on_hover(&mut self, uri: Uri, position: Position) -> Hover {
        let node = self.compiler.node_at_position(uri, position);
        match node {
            HirNode::Expr(expr) => Hover::Type(format!("{}", expr.ty)),
            HirNode::Pat(pat) => Hover::Type(format!("{}", pat.ty)),
            HirNode::Item(item) => Hover::Docs(item.docs),
        }
    }

    fn on_completion(&mut self, uri: Uri, position: Position) -> Vec<Completion> {
        let scope = self.compiler.scope_at_position(uri, position);
        scope.visible_names().map(|name| Completion {
            label: name.ident,
            kind: name.kind,
            detail: format!("{}", name.ty),
        }).collect()
    }
}
```

### 16.2 Same Pipeline, Different Modes

| Feature | Batch Compiler | Language Server |
|---------|---------------|-----------------|
| Parser | Full parse | Incremental + error recovery |
| AST | Complete | May have "holes" from recovery |
| Type checker | Full | Partial, resilient to errors |
| HIR | Stored for whole crate | Cached per-file, evicted |
| MIR | Generated for all items | On-demand for hovered items |

---

## 17. Compiler Pipeline

```
Source (.fl files)
    ↓
Lexer (hand-rolled state machine)
    ↓
AST (arena-allocated, struct variants)
    ↓
Early Resolution (modules, imports, decorators)
    ↓
Decorator Expansion (@derive generates impls)
    ↓
Late Resolution (paths in exprs, types, patterns)
    ↓
AST → HIR Lowering (desugar queries, async, generators)
    ↓
Type Checking (trait resolution, inference)
    ↓
Query Extraction (pattern-match Queryable/Aggregate calls)
    ↓
Query Optimization (pushdown, decorrelation, partitioning)
    ↓
HIR → MIR Lowering (insert CoW, explicit memory ops)
    ↓
MIR Optimization (simplify, inline, validate)
    ↓
Backend Selection (embedded / distributed / SQL)
    ↓
Code Generation (LLVM / Cranelift / Bytecode / SQL)
```

---

## 18. File Tree

```
flott/
├── compiler/
│   ├── Cargo.toml
│   ├── src/
│   │   ├── main.rs              # CLI driver
│   │   ├── lib.rs               # Public API
│   │   │
│   │   ├── lexer/               # LEXER
│   │   │   ├── mod.rs
│   │   │   ├── state_machine.rs
│   │   │   ├── keywords.rs
│   │   │   ├── tokens.rs
│   │   │   └── errors.rs
│   │   │
│   │   ├── ast/                 # AST
│   │   │   ├── mod.rs
│   │   │   ├── arena.rs
│   │   │   ├── visit.rs
│   │   │   ├── query.rs
│   │   │   └── macros.rs
│   │   │
│   │   ├── parse/               # PARSER
│   │   │   ├── mod.rs
│   │   │   ├── expr.rs
│   │   │   ├── item.rs
│   │   │   ├── ty.rs
│   │   │   ├── pat.rs
│   │   │   └── errors.rs
│   │   │
│   │   ├── span/                # SPANS & SYMBOLS
│   │   │   ├── mod.rs
│   │   │   ├── span.rs
│   │   │   └── symbol.rs
│   │   │
│   │   ├── diagnostics/         # ERROR REPORTING
│   │   │   ├── mod.rs
│   │   │   ├── error.rs
│   │   │   ├── handler.rs
│   │   │   └── codes.rs
│   │   │
│   │   ├── def/                 # DEFINITIONS & IDs
│   │   │   ├── mod.rs
│   │   │   ├── def_id.rs
│   │   │   ├── local_def_id.rs
│   │   │   ├── hir_id.rs
│   │   │   └── path.rs
│   │   │
│   │   ├── resolve/             # NAME RESOLUTION
│   │   │   ├── mod.rs
│   │   │   ├── resolver.rs
│   │   │   ├── module.rs
│   │   │   ├── namespace.rs
│   │   │   ├── binding.rs
│   │   │   ├── import.rs
│   │   │   ├── path_result.rs
│   │   │   ├── late.rs
│   │   │   ├── early.rs
│   │   │   ├── build_reduced_graph.rs
│   │   │   ├── decorator.rs
│   │   │   └── errors.rs
│   │   │
│   │   ├── hir/                 # HIGH-LEVEL IR
│   │   │   ├── mod.rs
│   │   │   ├── hir.rs
│   │   │   ├── hir_id.rs
│   │   │   ├── item.rs
│   │   │   ├── expr.rs
│   │   │   ├── stmt.rs
│   │   │   ├── pat.rs
│   │   │   ├── ty.rs
│   │   │   ├── generics.rs
│   │   │   ├── def.rs
│   │   │   ├── trait.rs
│   │   │   ├── body.rs
│   │   │   ├── map.rs
│   │   │   ├── visitor.rs
│   │   │   └── lowering/
│   │   │       ├── mod.rs
│   │   │       ├── lower.rs
│   │   │       ├── expr.rs
│   │   │       ├── item.rs
│   │   │       ├── pat.rs
│   │   │       ├── ty.rs
│   │   │       ├── query.rs
│   │   │       └── decorator.rs
│   │   │
│   │   ├── ty/                  # TYPE SYSTEM
│   │   │   ├── mod.rs
│   │   │   ├── context.rs
│   │   │   ├── ty.rs
│   │   │   ├── subst.rs
│   │   │   ├── trait_ref.rs
│   │   │   ├── predicate.rs
│   │   │   ├── fold.rs
│   │   │   ├── visit.rs
│   │   │   └── infer/
│   │   │       ├── mod.rs
│   │   │       ├── at.rs
│   │   │       ├── combine.rs
│   │   │       ├── error_reporting.rs
│   │   │       ├── type_variable.rs
│   │   │       └── unify_key.rs
│   │   │
│   │   ├── typeck/              # TYPE CHECKING
│   │   │   ├── mod.rs
│   │   │   ├── check.rs
│   │   │   ├── expr.rs
│   │   │   ├── pat.rs
│   │   │   ├── item.rs
│   │   │   ├── method.rs
│   │   │   ├── coercion.rs
│   │   │   ├── cast.rs
│   │   │   ├── autoderef.rs
│   │   │   ├── writeback.rs
│   │   │   ├── query.rs
│   │   │   └── errors.rs
│   │   │
│   │   ├── mir/                 # MID-LEVEL IR
│   │   │   ├── mod.rs
│   │   │   ├── mir.rs
│   │   │   ├── operand.rs
│   │   │   ├── lowering.rs
│   │   │   ├── pretty.rs
│   │   │   ├── cow.rs
│   │   │   └── pass/
│   │   │       ├── simplify.rs
│   │   │       ├── inline.rs
│   │   │       └── validate.rs
│   │   │
│   │   ├── query/               # QUERY MIDDLE LAYER
│   │   │   ├── mod.rs
│   │   │   ├── operator.rs
│   │   │   ├── properties.rs
│   │   │   ├── extractor.rs
│   │   │   ├── plan.rs
│   │   │   ├── decorrelate.rs
│   │   │   ├── optimize.rs
│   │   │   ├── pushdown.rs
│   │   │   ├── partition.rs
│   │   │   └── validate.rs
│   │   │
│   │   ├── backend/             # CODE GENERATION
│   │   │   ├── mod.rs
│   │   │   ├── embedded.rs
│   │   │   ├── storage.rs
│   │   │   ├── distributed.rs
│   │   │   └── sql.rs
│   │   │
│   │   ├── lsp/                 # LANGUAGE SERVER
│   │   │   ├── mod.rs
│   │   │   ├── server.rs
│   │   │   ├── handlers.rs
│   │   │   └── incremental.rs
│   │   │
│   │   └── session/             # COMPILER SESSION
│   │       ├── mod.rs
│   │       ├── config.rs
│   │       └── search_paths.rs
│   │
│   └── tests/
│       ├── ui/
│       ├── resolve/
│       ├── hir/
│       ├── typeck/
│       └── query/
│
├── stdlib/
│   ├── core/
│   │   ├── iter.fl
│   │   ├── queryable.fl
│   │   ├── aggregate.fl
│   │   ├── share.fl
│   │   ├── arena.fl
│   │   ├── decorators.fl
│   │   └── register.fl
│   │
│   └── infra/
│       ├── storage/
│       │   ├── lsm.fl
│       │   ├── distributed.fl
│       │   └── remote_sql.fl
│       └── stream.fl
│
├── runtime/
│   ├── src/
│   │   ├── value.rs
│   │   ├── rc.rs
│   │   ├── arena.rs
│   │   ├── storage.rs
│   │   └── gc.rs
│   └── Cargo.toml
│
└── Cargo.toml
```

---

## 19. Examples

### 19.1 Hello World

```flott
fn main() {
    print("Hello, Flott!");
}
```

### 19.2 Structs and Pattern Matching

```flott
struct Point { x: f32, y: f32 }

enum Shape {
    Circle { center: Point, radius: f32 },
    Rectangle { top_left: Point, bottom_right: Point },
}

fn area(shape: Shape) -> f32 {
    match shape {
        Shape::Circle { radius, .. } => 3.14159 * radius * radius,
        Shape::Rectangle { top_left, bottom_right } => {
            let width = bottom_right.x - top_left.x;
            let height = bottom_right.y - top_left.y;
            width * height
        }
    }
}
```

### 19.3 Query with Links

```flott
@table
struct User {
    id: i64,
    name: String,
    city: String,
    age: i32,
}

@table
struct Book {
    id: i64,
    title: String,
    genre: String,
}

@table
struct UserWritesBook {
    user_id: i64,
    book_id: i64,
    published_date: Date,
}

fn get_authors_with_books() -> Iterator<{ name: String, books: Iterator<{ title: String, genre: String }> }> {
    select users@u[*].{
        name: u.name,
        books: u.writes@w[*].books@b[*].{
            title: b.title,
            genre: b.genre,
        }
    }
    from users@u:User
    links (users)->[writes]->(books)
}
```

### 19.4 Aggregation

```flott
fn city_stats() -> Iterator<{ city: String, avg_age: f64, total_users: usize }> {
    select groups@g[*].{
        city: g.city,
        avg_age: g.users.avg(u => u.age),
        total_users: g.users.count(),
    }
    from users@u:User
    group by { city: u.city } into groups
}
```

### 19.5 Async

```flott
async fn fetch_and_process() -> Vec<Result> {
    let users = fetch_users().await;
    let orders = fetch_orders().await;

    join(users, orders)
        .filter(|(u, o)| u.id == o.user_id)
        .map(|(u, o)| Result { user: u.name, total: o.amount })
        .collect()
}
```

### 19.6 User-Defined Aggregate

```flott
@aggregate(class = Holistic)
fn percentile(values: Iterator<f64>, p: f64) -> f64 {
    let mut sorted = values.collect::<Vec<f64>>();
    sorted.sort();
    sorted[(sorted.len() as f64 * p) as usize]
}

fn main() {
    let scores = [1.0, 2.0, 3.0, 4.0, 5.0];
    let median = scores.percentile(0.5);
    print("Median: {}", median);  // 3.0
}
```

### 19.7 Interoperability

```flott
@repr(C)
@export
struct User {
    id: i64,
    name: String,
}

@export
fn get_users() -> Vec<User> {
    select users@u[*].{ id: u.id, name: u.name }
    from users@u:User
}
```

Generated Python bindings:
```python
from flott import ffi

users = ffi.call("get_users")
for user in users:
    print(f"User {user.id}: {user.name}")
```

---

## Appendix A: Glossary

| Term | Definition |
|------|-----------|
| **CoW** | Copy-on-Write: mutation detaches if refcount > 1 |
| **HIR** | High-Level IR: desugared, name-resolved AST |
| **MIR** | Mid-Level IR: CFG with explicit memory operations |
| **Queryable** | Trait for lazy, optimizable data pipelines |
| **Aggregate** | Trait for user-defined aggregation with classification |
| **Distributive** | Aggregate where partial results merge directly (sum, count) |
| **Algebraic** | Aggregate with fixed-size intermediate (avg, stddev) |
| **Holistic** | Aggregate requiring all data (median, percentile) |
| **Arrow IPC** | Zero-copy columnar serialization format |
| **Lang item** | Trait/item known to the compiler via `#[lang]` attribute |
| **Decorator** | `@`-prefixed compile-time transformation |

---

## Appendix B: References

1. Gray et al. "Data Cube: A Relational Aggregation Operator." Microsoft Research, 1995.
2. Gatterbauer & Sabale. "Database Research needs an Abstract Relational Query Language." CIDR 2026.
3. Ordonez et al. "Dynamic Optimization of Generalized SQL Queries with Horizontal Aggregations." SIGMOD 2012.
4. Apache Arrow. "Arrow Columnar Format." https://arrow.apache.org/docs/format/Columnar.html
5. Rust Reference. "Lang Items." https://doc.rust-lang.org/reference/items/lang-items.html
6. Rustc Dev Guide. "The MIR." https://rustc-dev-guide.rust-lang.org/mir/index.html
7. Isard et al. "Dryad: Distributed Data-Parallel Programs from Sequential Building Blocks." EuroSys 2007.
8. Graefe. "Volcano — An Extensible and Parallel Query Evaluation System." IEEE TKDE 1994.
9. Clangd. "Design." https://clangd.llvm.org/design/
10. Merlin/OCaml. "Error Recovery in the OCaml Compiler." https://ocaml.org/manual/lexyacc.html

---

*Document version: 0.1.0*
*Last updated: 2026-07-13*
