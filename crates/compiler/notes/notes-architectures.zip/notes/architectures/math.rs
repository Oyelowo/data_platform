//! Linear algebra primitives, 3D-ready from the start.
//!
//! All vectors use f32. UI typically does not need f64 precision,
//! and f32 is the standard for GPU submission.

use std::ops::{Add, AddAssign, Div, DivAssign, Mul, MulAssign, Neg, Sub, SubAssign};

// =============================================================================
// Vec2
// =============================================================================

/// A 2-dimensional vector.
#[derive(Copy, Clone, Debug, PartialEq, Default)]
pub struct Vec2 {
    pub x: f32,
    pub y: f32,
}

impl Vec2 {
    /// Zero vector.
    pub const ZERO: Self = Self { x: 0.0, y: 0.0 };
    /// Unit X vector.
    pub const X: Self = Self { x: 1.0, y: 0.0 };
    /// Unit Y vector.
    pub const Y: Self = Self { x: 0.0, y: 1.0 };

    /// Create a new Vec2.
    pub const fn new(x: f32, y: f32) -> Self {
        Self { x, y }
    }

    /// Create from a single value.
    pub const fn splat(v: f32) -> Self {
        Self { x: v, y: v }
    }

    /// Dot product.
    pub fn dot(self, other: Self) -> f32 {
        self.x * other.x + self.y * other.y
    }

    /// Length squared.
    pub fn length_sq(self) -> f32 {
        self.dot(self)
    }

    /// Length.
    pub fn length(self) -> f32 {
        self.length_sq().sqrt()
    }

    /// Normalize. Returns ZERO if length is zero.
    pub fn normalize(self) -> Self {
        let len = self.length();
        if len == 0.0 {
            Self::ZERO
        } else {
            self / len
        }
    }

    /// Linear interpolation.
    pub fn lerp(self, other: Self, t: f32) -> Self {
        self + (other - self) * t
    }

    /// Component-wise minimum.
    pub fn min(self, other: Self) -> Self {
        Self::new(self.x.min(other.x), self.y.min(other.y))
    }

    /// Component-wise maximum.
    pub fn max(self, other: Self) -> Self {
        Self::new(self.x.max(other.x), self.y.max(other.y))
    }

    /// Component-wise absolute value.
    pub fn abs(self) -> Self {
        Self::new(self.x.abs(), self.y.abs())
    }

    /// Round components.
    pub fn round(self) -> Self {
        Self::new(self.x.round(), self.y.round())
    }

    /// Floor components.
    pub fn floor(self) -> Self {
        Self::new(self.x.floor(), self.y.floor())
    }

    /// Ceil components.
    pub fn ceil(self) -> Self {
        Self::new(self.x.ceil(), self.y.ceil())
    }
}

impl Add for Vec2 {
    type Output = Self;
    fn add(self, rhs: Self) -> Self::Output {
        Self::new(self.x + rhs.x, self.y + rhs.y)
    }
}

impl AddAssign for Vec2 {
    fn add_assign(&mut self, rhs: Self) {
        self.x += rhs.x;
        self.y += rhs.y;
    }
}

impl Sub for Vec2 {
    type Output = Self;
    fn sub(self, rhs: Self) -> Self::Output {
        Self::new(self.x - rhs.x, self.y - rhs.y)
    }
}

impl SubAssign for Vec2 {
    fn sub_assign(&mut self, rhs: Self) {
        self.x -= rhs.x;
        self.y -= rhs.y;
    }
}

impl Mul<f32> for Vec2 {
    type Output = Self;
    fn mul(self, rhs: f32) -> Self::Output {
        Self::new(self.x * rhs, self.y * rhs)
    }
}

impl Mul<Vec2> for f32 {
    type Output = Vec2;
    fn mul(self, rhs: Vec2) -> Self::Output {
        rhs * self
    }
}

impl MulAssign<f32> for Vec2 {
    fn mul_assign(&mut self, rhs: f32) {
        self.x *= rhs;
        self.y *= rhs;
    }
}

impl Div<f32> for Vec2 {
    type Output = Self;
    fn div(self, rhs: f32) -> Self::Output {
        Self::new(self.x / rhs, self.y / rhs)
    }
}

impl DivAssign<f32> for Vec2 {
    fn div_assign(&mut self, rhs: f32) {
        self.x /= rhs;
        self.y /= rhs;
    }
}

impl Neg for Vec2 {
    type Output = Self;
    fn neg(self) -> Self::Output {
        Self::new(-self.x, -self.y)
    }
}

// =============================================================================
// Vec3
// =============================================================================

/// A 3-dimensional vector.
#[derive(Copy, Clone, Debug, PartialEq, Default)]
pub struct Vec3 {
    pub x: f32,
    pub y: f32,
    pub z: f32,
}

impl Vec3 {
    pub const ZERO: Self = Self { x: 0.0, y: 0.0, z: 0.0 };
    pub const X: Self = Self { x: 1.0, y: 0.0, z: 0.0 };
    pub const Y: Self = Self { x: 0.0, y: 1.0, z: 0.0 };
    pub const Z: Self = Self { x: 0.0, y: 0.0, z: 1.0 };

    pub const fn new(x: f32, y: f32, z: f32) -> Self {
        Self { x, y, z }
    }

    pub const fn splat(v: f32) -> Self {
        Self { x: v, y: v, z: v }
    }

    pub fn dot(self, other: Self) -> f32 {
        self.x * other.x + self.y * other.y + self.z * other.z
    }

    pub fn cross(self, other: Self) -> Self {
        Self::new(
            self.y * other.z - self.z * other.y,
            self.z * other.x - self.x * other.z,
            self.x * other.y - self.y * other.x,
        )
    }

    pub fn length_sq(self) -> f32 {
        self.dot(self)
    }

    pub fn length(self) -> f32 {
        self.length_sq().sqrt()
    }

    pub fn normalize(self) -> Self {
        let len = self.length();
        if len == 0.0 {
            Self::ZERO
        } else {
            self / len
        }
    }

    pub fn lerp(self, other: Self, t: f32) -> Self {
        self + (other - self) * t
    }

    pub fn min(self, other: Self) -> Self {
        Self::new(
            self.x.min(other.x),
            self.y.min(other.y),
            self.z.min(other.z),
        )
    }

    pub fn max(self, other: Self) -> Self {
        Self::new(
            self.x.max(other.x),
            self.y.max(other.y),
            self.z.max(other.z),
        )
    }

    pub fn abs(self) -> Self {
        Self::new(self.x.abs(), self.y.abs(), self.z.abs())
    }
}

impl Add for Vec3 {
    type Output = Self;
    fn add(self, rhs: Self) -> Self::Output {
        Self::new(self.x + rhs.x, self.y + rhs.y, self.z + rhs.z)
    }
}

impl AddAssign for Vec3 {
    fn add_assign(&mut self, rhs: Self) {
        self.x += rhs.x;
        self.y += rhs.y;
        self.z += rhs.z;
    }
}

impl Sub for Vec3 {
    type Output = Self;
    fn sub(self, rhs: Self) -> Self::Output {
        Self::new(self.x - rhs.x, self.y - rhs.y, self.z - rhs.z)
    }
}

impl SubAssign for Vec3 {
    fn sub_assign(&mut self, rhs: Self) {
        self.x -= rhs.x;
        self.y -= rhs.y;
        self.z -= rhs.z;
    }
}

impl Mul<f32> for Vec3 {
    type Output = Self;
    fn mul(self, rhs: f32) -> Self::Output {
        Self::new(self.x * rhs, self.y * rhs, self.z * rhs)
    }
}

impl Mul<Vec3> for f32 {
    type Output = Vec3;
    fn mul(self, rhs: Vec3) -> Self::Output {
        rhs * self
    }
}

impl MulAssign<f32> for Vec3 {
    fn mul_assign(&mut self, rhs: f32) {
        self.x *= rhs;
        self.y *= rhs;
        self.z *= rhs;
    }
}

impl Div<f32> for Vec3 {
    type Output = Self;
    fn div(self, rhs: f32) -> Self::Output {
        Self::new(self.x / rhs, self.y / rhs, self.z / rhs)
    }
}

impl DivAssign<f32> for Vec3 {
    fn div_assign(&mut self, rhs: f32) {
        self.x /= rhs;
        self.y /= rhs;
        self.z /= rhs;
    }
}

impl Neg for Vec3 {
    type Output = Self;
    fn neg(self) -> Self::Output {
        Self::new(-self.x, -self.y, -self.z)
    }
}

// =============================================================================
// Vec4
// =============================================================================

/// A 4-dimensional vector. Used for homogeneous coordinates and matrix rows.
#[derive(Copy, Clone, Debug, PartialEq, Default)]
pub struct Vec4 {
    pub x: f32,
    pub y: f32,
    pub z: f32,
    pub w: f32,
}

impl Vec4 {
    pub const ZERO: Self = Self { x: 0.0, y: 0.0, z: 0.0, w: 0.0 };
    pub const X: Self = Self { x: 1.0, y: 0.0, z: 0.0, w: 0.0 };
    pub const Y: Self = Self { x: 0.0, y: 1.0, z: 0.0, w: 0.0 };
    pub const Z: Self = Self { x: 0.0, y: 0.0, z: 1.0, w: 0.0 };
    pub const W: Self = Self { x: 0.0, y: 0.0, z: 0.0, w: 1.0 };

    pub const fn new(x: f32, y: f32, z: f32, w: f32) -> Self {
        Self { x, y, z, w }
    }

    pub const fn splat(v: f32) -> Self {
        Self { x: v, y: v, z: v, w: v }
    }

    pub fn dot(self, other: Self) -> f32 {
        self.x * other.x + self.y * other.y + self.z * other.z + self.w * other.w
    }

    pub fn length_sq(self) -> f32 {
        self.dot(self)
    }

    pub fn length(self) -> f32 {
        self.length_sq().sqrt()
    }

    pub fn normalize(self) -> Self {
        let len = self.length();
        if len == 0.0 {
            Self::ZERO
        } else {
            self / len
        }
    }

    pub fn lerp(self, other: Self, t: f32) -> Self {
        self + (other - self) * t
    }
}

impl Add for Vec4 {
    type Output = Self;
    fn add(self, rhs: Self) -> Self::Output {
        Self::new(self.x + rhs.x, self.y + rhs.y, self.z + rhs.z, self.w + rhs.w)
    }
}

impl Sub for Vec4 {
    type Output = Self;
    fn sub(self, rhs: Self) -> Self::Output {
        Self::new(self.x - rhs.x, self.y - rhs.y, self.z - rhs.z, self.w - rhs.w)
    }
}

impl Mul<f32> for Vec4 {
    type Output = Self;
    fn mul(self, rhs: f32) -> Self::Output {
        Self::new(self.x * rhs, self.y * rhs, self.z * rhs, self.w * rhs)
    }
}

impl Div<f32> for Vec4 {
    type Output = Self;
    fn div(self, rhs: f32) -> Self::Output {
        Self::new(self.x / rhs, self.y / rhs, self.z / rhs, self.w / rhs)
    }
}

impl Neg for Vec4 {
    type Output = Self;
    fn neg(self) -> Self::Output {
        Self::new(-self.x, -self.y, -self.z, -self.w)
    }
}

// =============================================================================
// Mat4 — Column-major 4x4 matrix
// =============================================================================

/// A 4x4 matrix in **column-major** order.
///
/// This is the standard for OpenGL, Vulkan, and Metal.
/// The matrix is stored as 4 columns, each a Vec4.
///
/// To transform a vector: `M * v`.
#[derive(Copy, Clone, Debug, PartialEq)]
pub struct Mat4 {
    pub cols: [Vec4; 4],
}

impl Mat4 {
    /// Identity matrix.
    pub const IDENTITY: Self = Self {
        cols: [
            Vec4::X,
            Vec4::Y,
            Vec4::Z,
            Vec4::W,
        ],
    };

    /// Zero matrix.
    pub const ZERO: Self = Self {
        cols: [Vec4::ZERO; 4],
    };

    /// Create from columns.
    pub const fn from_cols(c0: Vec4, c1: Vec4, c2: Vec4, c3: Vec4) -> Self {
        Self { cols: [c0, c1, c2, c3] }
    }

    /// Create from a 2D array [row][col].
    pub fn from_array(a: [[f32; 4]; 4]) -> Self {
        Self::from_cols(
            Vec4::new(a[0][0], a[1][0], a[2][0], a[3][0]),
            Vec4::new(a[0][1], a[1][1], a[2][1], a[3][1]),
            Vec4::new(a[0][2], a[1][2], a[2][2], a[3][2]),
            Vec4::new(a[0][3], a[1][3], a[2][3], a[3][3]),
        )
    }

    /// Get element at (row, col).
    pub fn at(self, row: usize, col: usize) -> f32 {
        match row {
            0 => self.cols[col].x,
            1 => self.cols[col].y,
            2 => self.cols[col].z,
            3 => self.cols[col].w,
            _ => panic!("row index out of bounds"),
        }
    }

    /// Translation matrix.
    pub fn from_translation(t: Vec3) -> Self {
        let mut m = Self::IDENTITY;
        m.cols[3].x = t.x;
        m.cols[3].y = t.y;
        m.cols[3].z = t.z;
        m
    }

    /// Scale matrix.
    pub fn from_scale(s: Vec3) -> Self {
        Self::from_cols(
            Vec4::new(s.x, 0.0, 0.0, 0.0),
            Vec4::new(0.0, s.y, 0.0, 0.0),
            Vec4::new(0.0, 0.0, s.z, 0.0),
            Vec4::W,
        )
    }

    /// Rotation matrix from quaternion.
    pub fn from_quat(q: Quat) -> Self {
        let x2 = q.x + q.x;
        let y2 = q.y + q.y;
        let z2 = q.z + q.z;
        let xx = q.x * x2;
        let xy = q.x * y2;
        let xz = q.x * z2;
        let yy = q.y * y2;
        let yz = q.y * z2;
        let zz = q.z * z2;
        let wx = q.w * x2;
        let wy = q.w * y2;
        let wz = q.w * z2;

        Self::from_cols(
            Vec4::new(1.0 - (yy + zz), xy + wz, xz - wy, 0.0),
            Vec4::new(xy - wz, 1.0 - (xx + zz), yz + wx, 0.0),
            Vec4::new(xz + wy, yz - wx, 1.0 - (xx + yy), 0.0),
            Vec4::W,
        )
    }

    /// Rotation around an axis (angle in radians).
    pub fn from_axis_angle(axis: Vec3, angle: f32) -> Self {
        Self::from_quat(Quat::from_axis_angle(axis, angle))
    }

    /// Perspective projection matrix.
    ///
    /// `fov_y` is the vertical field of view in radians.
    /// `aspect` is width / height.
    /// `near` and `far` are the clipping planes.
    pub fn perspective(fov_y: f32, aspect: f32, near: f32, far: f32) -> Self {
        let f = 1.0 / (fov_y / 2.0).tan();
        let nf = 1.0 / (near - far);
        Self::from_cols(
            Vec4::new(f / aspect, 0.0, 0.0, 0.0),
            Vec4::new(0.0, f, 0.0, 0.0),
            Vec4::new(0.0, 0.0, (far + near) * nf, -1.0),
            Vec4::new(0.0, 0.0, 2.0 * far * near * nf, 0.0),
        )
    }

    /// Orthographic projection matrix.
    pub fn ortho(left: f32, right: f32, bottom: f32, top: f32, near: f32, far: f32) -> Self {
        let rl = 1.0 / (right - left);
        let tb = 1.0 / (top - bottom);
        let nf = 1.0 / (near - far);
        Self::from_cols(
            Vec4::new(2.0 * rl, 0.0, 0.0, 0.0),
            Vec4::new(0.0, 2.0 * tb, 0.0, 0.0),
            Vec4::new(0.0, 0.0, 2.0 * nf, 0.0),
            Vec4::new(-(right + left) * rl, -(top + bottom) * tb, (far + near) * nf, 1.0),
        )
    }

    /// Look-at view matrix.
    pub fn look_at(eye: Vec3, target: Vec3, up: Vec3) -> Self {
        let f = (target - eye).normalize();
        let s = f.cross(up).normalize();
        let u = s.cross(f);

        Self::from_cols(
            Vec4::new(s.x, u.x, -f.x, 0.0),
            Vec4::new(s.y, u.y, -f.y, 0.0),
            Vec4::new(s.z, u.z, -f.z, 0.0),
            Vec4::new(-s.dot(eye), -u.dot(eye), f.dot(eye), 1.0),
        )
    }

    /// 2D orthographic projection for UI (origin at top-left, Y down).
    pub fn ortho_2d(width: f32, height: f32) -> Self {
        Self::ortho(0.0, width, height, 0.0, -1.0, 1.0)
    }

    /// Transpose.
    pub fn transpose(self) -> Self {
        Self::from_cols(
            Vec4::new(self.cols[0].x, self.cols[1].x, self.cols[2].x, self.cols[3].x),
            Vec4::new(self.cols[0].y, self.cols[1].y, self.cols[2].y, self.cols[3].y),
            Vec4::new(self.cols[0].z, self.cols[1].z, self.cols[2].z, self.cols[3].z),
            Vec4::new(self.cols[0].w, self.cols[1].w, self.cols[2].w, self.cols[3].w),
        )
    }

    /// Matrix multiplication.
    pub fn mul_mat(self, rhs: Self) -> Self {
        let mut result = Self::ZERO;
        for i in 0..4 {
            for j in 0..4 {
                let mut sum = 0.0;
                for k in 0..4 {
                    sum += self.at(i, k) * rhs.at(k, j);
                }
                match i {
                    0 => result.cols[j].x = sum,
                    1 => result.cols[j].y = sum,
                    2 => result.cols[j].z = sum,
                    3 => result.cols[j].w = sum,
                    _ => unreachable!(),
                }
            }
        }
        result
    }

    /// Transform a Vec4.
    pub fn mul_vec4(self, v: Vec4) -> Vec4 {
        Vec4::new(
            self.cols[0].x * v.x + self.cols[1].x * v.y + self.cols[2].x * v.z + self.cols[3].x * v.w,
            self.cols[0].y * v.x + self.cols[1].y * v.y + self.cols[2].y * v.z + self.cols[3].y * v.w,
            self.cols[0].z * v.x + self.cols[1].z * v.y + self.cols[2].z * v.z + self.cols[3].z * v.w,
            self.cols[0].w * v.x + self.cols[1].w * v.y + self.cols[2].w * v.z + self.cols[3].w * v.w,
        )
    }

    /// Transform a Vec3 (assumes w=1).
    pub fn mul_vec3(self, v: Vec3) -> Vec3 {
        let v4 = self.mul_vec4(Vec4::new(v.x, v.y, v.z, 1.0));
        Vec3::new(v4.x, v4.y, v4.z)
    }

    /// Transform a Vec2 (assumes z=0, w=1). Used for 2D UI transforms.
    pub fn mul_vec2(self, v: Vec2) -> Vec2 {
        let v4 = self.mul_vec4(Vec4::new(v.x, v.y, 0.0, 1.0));
        Vec2::new(v4.x, v4.y)
    }

    /// Inverse of a 4x4 matrix (general case).
    pub fn inverse(self) -> Self {
        // Using the adjugate method. This is not the most numerically stable
        // for near-singular matrices, but it is sufficient for UI transforms.
        let m = self;
        let mut inv = Self::ZERO;

        inv.cols[0].x = m.at(1,1) * m.at(2,2) * m.at(3,3) - m.at(1,1) * m.at(2,3) * m.at(3,2) - m.at(2,1) * m.at(1,2) * m.at(3,3) + m.at(2,1) * m.at(1,3) * m.at(3,2) + m.at(3,1) * m.at(1,2) * m.at(2,3) - m.at(3,1) * m.at(1,3) * m.at(2,2);
        inv.cols[1].x = -m.at(1,0) * m.at(2,2) * m.at(3,3) + m.at(1,0) * m.at(2,3) * m.at(3,2) + m.at(2,0) * m.at(1,2) * m.at(3,3) - m.at(2,0) * m.at(1,3) * m.at(3,2) - m.at(3,0) * m.at(1,2) * m.at(2,3) + m.at(3,0) * m.at(1,3) * m.at(2,2);
        inv.cols[2].x = m.at(1,0) * m.at(2,1) * m.at(3,3) - m.at(1,0) * m.at(2,3) * m.at(3,1) - m.at(2,0) * m.at(1,1) * m.at(3,3) + m.at(2,0) * m.at(1,3) * m.at(3,1) + m.at(3,0) * m.at(1,1) * m.at(2,3) - m.at(3,0) * m.at(1,3) * m.at(2,1);
        inv.cols[3].x = -m.at(1,0) * m.at(2,1) * m.at(3,2) + m.at(1,0) * m.at(2,2) * m.at(3,1) + m.at(2,0) * m.at(1,1) * m.at(3,2) - m.at(2,0) * m.at(1,2) * m.at(3,1) - m.at(3,0) * m.at(1,1) * m.at(2,2) + m.at(3,0) * m.at(1,2) * m.at(2,1);

        inv.cols[0].y = -m.at(0,1) * m.at(2,2) * m.at(3,3) + m.at(0,1) * m.at(2,3) * m.at(3,2) + m.at(2,1) * m.at(0,2) * m.at(3,3) - m.at(2,1) * m.at(0,3) * m.at(3,2) - m.at(3,1) * m.at(0,2) * m.at(2,3) + m.at(3,1) * m.at(0,3) * m.at(2,2);
        inv.cols[1].y = m.at(0,0) * m.at(2,2) * m.at(3,3) - m.at(0,0) * m.at(2,3) * m.at(3,2) - m.at(2,0) * m.at(0,2) * m.at(3,3) + m.at(2,0) * m.at(0,3) * m.at(3,2) + m.at(3,0) * m.at(0,2) * m.at(2,3) - m.at(3,0) * m.at(0,3) * m.at(2,2);
        inv.cols[2].y = -m.at(0,0) * m.at(2,1) * m.at(3,3) + m.at(0,0) * m.at(2,3) * m.at(3,1) + m.at(2,0) * m.at(0,1) * m.at(3,3) - m.at(2,0) * m.at(0,3) * m.at(3,1) - m.at(3,0) * m.at(0,1) * m.at(2,3) + m.at(3,0) * m.at(0,3) * m.at(2,1);
        inv.cols[3].y = m.at(0,0) * m.at(2,1) * m.at(3,2) - m.at(0,0) * m.at(2,2) * m.at(3,1) - m.at(2,0) * m.at(0,1) * m.at(3,2) + m.at(2,0) * m.at(0,2) * m.at(3,1) + m.at(3,0) * m.at(0,1) * m.at(2,2) - m.at(3,0) * m.at(0,2) * m.at(2,1);

        inv.cols[0].z = m.at(0,1) * m.at(1,2) * m.at(3,3) - m.at(0,1) * m.at(1,3) * m.at(3,2) - m.at(1,1) * m.at(0,2) * m.at(3,3) + m.at(1,1) * m.at(0,3) * m.at(3,2) + m.at(3,1) * m.at(0,2) * m.at(1,3) - m.at(3,1) * m.at(0,3) * m.at(1,2);
        inv.cols[1].z = -m.at(0,0) * m.at(1,2) * m.at(3,3) + m.at(0,0) * m.at(1,3) * m.at(3,2) + m.at(1,0) * m.at(0,2) * m.at(3,3) - m.at(1,0) * m.at(0,3) * m.at(3,2) - m.at(3,0) * m.at(0,2) * m.at(1,3) + m.at(3,0) * m.at(0,3) * m.at(1,2);
        inv.cols[2].z = m.at(0,0) * m.at(1,1) * m.at(3,3) - m.at(0,0) * m.at(1,3) * m.at(3,1) - m.at(1,0) * m.at(0,1) * m.at(3,3) + m.at(1,0) * m.at(0,3) * m.at(3,1) + m.at(3,0) * m.at(0,1) * m.at(1,3) - m.at(3,0) * m.at(0,3) * m.at(1,1);
        inv.cols[3].z = -m.at(0,0) * m.at(1,1) * m.at(3,2) + m.at(0,0) * m.at(1,2) * m.at(3,1) + m.at(1,0) * m.at(0,1) * m.at(3,2) - m.at(1,0) * m.at(0,2) * m.at(3,1) - m.at(3,0) * m.at(0,1) * m.at(1,2) + m.at(3,0) * m.at(0,2) * m.at(1,1);

        inv.cols[0].w = -m.at(0,1) * m.at(1,2) * m.at(2,3) + m.at(0,1) * m.at(1,3) * m.at(2,2) + m.at(1,1) * m.at(0,2) * m.at(2,3) - m.at(1,1) * m.at(0,3) * m.at(2,2) - m.at(2,1) * m.at(0,2) * m.at(1,3) + m.at(2,1) * m.at(0,3) * m.at(1,2);
        inv.cols[1].w = m.at(0,0) * m.at(1,2) * m.at(2,3) - m.at(0,0) * m.at(1,3) * m.at(2,2) - m.at(1,0) * m.at(0,2) * m.at(2,3) + m.at(1,0) * m.at(0,3) * m.at(2,2) + m.at(2,0) * m.at(0,2) * m.at(1,3) - m.at(2,0) * m.at(0,3) * m.at(1,2);
        inv.cols[2].w = -m.at(0,0) * m.at(1,1) * m.at(2,3) + m.at(0,0) * m.at(1,3) * m.at(2,1) + m.at(1,0) * m.at(0,1) * m.at(2,3) - m.at(1,0) * m.at(0,3) * m.at(2,1) - m.at(2,0) * m.at(0,1) * m.at(1,3) + m.at(2,0) * m.at(0,3) * m.at(1,1);
        inv.cols[3].w = m.at(0,0) * m.at(1,1) * m.at(2,2) - m.at(0,0) * m.at(1,2) * m.at(2,1) - m.at(1,0) * m.at(0,1) * m.at(2,2) + m.at(1,0) * m.at(0,2) * m.at(2,1) + m.at(2,0) * m.at(0,1) * m.at(1,2) - m.at(2,0) * m.at(0,2) * m.at(1,1);

        let det = m.at(0,0) * inv.cols[0].x + m.at(0,1) * inv.cols[1].x + m.at(0,2) * inv.cols[2].x + m.at(0,3) * inv.cols[3].x;
        if det == 0.0 {
            return Self::ZERO; // Singular matrix
        }
        inv * (1.0 / det)
    }
}

impl Mul for Mat4 {
    type Output = Self;
    fn mul(self, rhs: Self) -> Self::Output {
        self.mul_mat(rhs)
    }
}

impl Mul<Vec4> for Mat4 {
    type Output = Vec4;
    fn mul(self, rhs: Vec4) -> Self::Output {
        self.mul_vec4(rhs)
    }
}

impl Mul<Vec3> for Mat4 {
    type Output = Vec3;
    fn mul(self, rhs: Vec3) -> Self::Output {
        self.mul_vec3(rhs)
    }
}

impl Mul<Vec2> for Mat4 {
    type Output = Vec2;
    fn mul(self, rhs: Vec2) -> Self::Output {
        self.mul_vec2(rhs)
    }
}

impl Mul<f32> for Mat4 {
    type Output = Self;
    fn mul(self, rhs: f32) -> Self::Output {
        Self::from_cols(self.cols[0] * rhs, self.cols[1] * rhs, self.cols[2] * rhs, self.cols[3] * rhs)
    }
}

// =============================================================================
// Quat — Quaternion for 3D rotations
// =============================================================================

/// A quaternion representing a rotation in 3D space.
#[derive(Copy, Clone, Debug, PartialEq, Default)]
pub struct Quat {
    pub x: f32,
    pub y: f32,
    pub z: f32,
    pub w: f32,
}

impl Quat {
    /// Identity quaternion (no rotation).
    pub const IDENTITY: Self = Self { x: 0.0, y: 0.0, z: 0.0, w: 1.0 };

    pub const fn new(x: f32, y: f32, z: f32, w: f32) -> Self {
        Self { x, y, z, w }
    }

    /// From axis-angle (axis must be normalized, angle in radians).
    pub fn from_axis_angle(axis: Vec3, angle: f32) -> Self {
        let half = angle * 0.5;
        let s = half.sin();
        Self::new(axis.x * s, axis.y * s, axis.z * s, half.cos())
    }

    /// From Euler angles (XYZ order, angles in radians).
    pub fn from_euler(x: f32, y: f32, z: f32) -> Self {
        let cx = (x * 0.5).cos();
        let sx = (x * 0.5).sin();
        let cy = (y * 0.5).cos();
        let sy = (y * 0.5).sin();
        let cz = (z * 0.5).cos();
        let sz = (z * 0.5).sin();
        Self::new(
            sx * cy * cz + cx * sy * sz,
            cx * sy * cz - sx * cy * sz,
            cx * cy * sz + sx * sy * cz,
            cx * cy * cz - sx * sy * sz,
        )
    }

    /// Length.
    pub fn length(self) -> f32 {
        (self.x * self.x + self.y * self.y + self.z * self.z + self.w * self.w).sqrt()
    }

    /// Normalize.
    pub fn normalize(self) -> Self {
        let len = self.length();
        if len == 0.0 {
            Self::IDENTITY
        } else {
            self * (1.0 / len)
        }
    }

    /// Quaternion multiplication (composition: q * r applies r then q).
    pub fn mul(self, rhs: Self) -> Self {
        Self::new(
            self.w * rhs.x + self.x * rhs.w + self.y * rhs.z - self.z * rhs.y,
            self.w * rhs.y - self.x * rhs.z + self.y * rhs.w + self.z * rhs.x,
            self.w * rhs.z + self.x * rhs.y - self.y * rhs.x + self.z * rhs.w,
            self.w * rhs.w - self.x * rhs.x - self.y * rhs.y - self.z * rhs.z,
        )
    }

    /// Spherical linear interpolation.
    pub fn slerp(self, other: Self, t: f32) -> Self {
        let mut dot = self.x * other.x + self.y * other.y + self.z * other.z + self.w * other.w;
        let mut rhs = other;
        if dot < 0.0 {
            dot = -dot;
            rhs = -rhs;
        }
        if dot > 0.9995 {
            return (self + t * (rhs - self)).normalize();
        }
        let theta_0 = dot.acos();
        let theta = theta_0 * t;
        let sin_theta = theta.sin();
        let sin_theta_0 = theta_0.sin();
        let s0 = theta.cos() - dot * sin_theta / sin_theta_0;
        let s1 = sin_theta / sin_theta_0;
        self * s0 + rhs * s1
    }
}

impl Mul<f32> for Quat {
    type Output = Self;
    fn mul(self, rhs: f32) -> Self::Output {
        Self::new(self.x * rhs, self.y * rhs, self.z * rhs, self.w * rhs)
    }
}

impl Add for Quat {
    type Output = Self;
    fn add(self, rhs: Self) -> Self::Output {
        Self::new(self.x + rhs.x, self.y + rhs.y, self.z + rhs.z, self.w + rhs.w)
    }
}

impl Neg for Quat {
    type Output = Self;
    fn neg(self) -> Self::Output {
        Self::new(-self.x, -self.y, -self.z, -self.w)
    }
}

// =============================================================================
// Rect
// =============================================================================

/// An axis-aligned rectangle.
#[derive(Copy, Clone, Debug, PartialEq, Default)]
pub struct Rect {
    pub min: Vec2,
    pub max: Vec2,
}

impl Rect {
    /// Create from origin and size.
    pub fn from_origin_size(origin: Vec2, size: Vec2) -> Self {
        Self {
            min: origin,
            max: origin + size,
        }
    }

    /// Create from min and max points.
    pub fn from_min_max(min: Vec2, max: Vec2) -> Self {
        Self { min, max }
    }

    /// Create from center and half-size.
    pub fn from_center_half_size(center: Vec2, half_size: Vec2) -> Self {
        Self {
            min: center - half_size,
            max: center + half_size,
        }
    }

    /// Origin (top-left in UI coordinates).
    pub fn origin(self) -> Vec2 {
        self.min
    }

    /// Size (width, height).
    pub fn size(self) -> Vec2 {
        self.max - self.min
    }

    pub fn width(self) -> f32 {
        self.max.x - self.min.x
    }

    pub fn height(self) -> f32 {
        self.max.y - self.min.y
    }

    pub fn center(self) -> Vec2 {
        (self.min + self.max) * 0.5
    }

    /// Check if a point is inside.
    pub fn contains(self, point: Vec2) -> bool {
        point.x >= self.min.x && point.x < self.max.x && point.y >= self.min.y && point.y < self.max.y
    }

    /// Check intersection with another rect.
    pub fn intersects(self, other: Self) -> bool {
        self.min.x < other.max.x && self.max.x > other.min.x &&
        self.min.y < other.max.y && self.max.y > other.min.y
    }

    /// Intersection of two rects.
    pub fn intersection(self, other: Self) -> Option<Self> {
        let min = self.min.max(other.min);
        let max = self.max.min(other.max);
        if min.x < max.x && min.y < max.y {
            Some(Self::from_min_max(min, max))
        } else {
            None
        }
    }

    /// Union of two rects.
    pub fn union(self, other: Self) -> Self {
        Self::from_min_max(self.min.min(other.min), self.max.max(other.max))
    }

    /// Inflate by a margin on all sides.
    pub fn inflate(self, margin: f32) -> Self {
        Self::from_min_max(self.min - Vec2::splat(margin), self.max + Vec2::splat(margin))
    }

    /// Translate by a vector.
    pub fn translate(self, offset: Vec2) -> Self {
        Self::from_min_max(self.min + offset, self.max + offset)
    }

    /// Scale around origin.
    pub fn scale(self, factor: Vec2) -> Self {
        Self::from_min_max(self.min * factor, self.max * factor)
    }
}

// =============================================================================
// Tests
// =============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn vec2_basics() {
        let a = Vec2::new(1.0, 2.0);
        let b = Vec2::new(3.0, 4.0);
        assert_eq!(a + b, Vec2::new(4.0, 6.0));
        assert_eq!(a - b, Vec2::new(-2.0, -2.0));
        assert_eq!(a * 2.0, Vec2::new(2.0, 4.0));
        assert_eq!(2.0 * a, Vec2::new(2.0, 4.0));
        assert_eq!(a.dot(b), 11.0);
        assert!((a.length() - 2.236068).abs() < 1e-5);
        let n = a.normalize();
        assert!((n.length() - 1.0).abs() < 1e-5);
    }

    #[test]
    fn vec3_cross() {
        let a = Vec3::X;
        let b = Vec3::Y;
        assert_eq!(a.cross(b), Vec3::Z);
    }

    #[test]
    fn mat4_identity() {
        let m = Mat4::IDENTITY;
        let v = Vec4::new(1.0, 2.0, 3.0, 4.0);
        assert_eq!(m * v, v);
    }

    #[test]
    fn mat4_translation() {
        let m = Mat4::from_translation(Vec3::new(1.0, 2.0, 3.0));
        let v = Vec3::new(0.0, 0.0, 0.0);
        assert_eq!(m * v, Vec3::new(1.0, 2.0, 3.0));
    }

    #[test]
    fn mat4_mul_mat() {
        let a = Mat4::from_translation(Vec3::new(1.0, 0.0, 0.0));
        let b = Mat4::from_translation(Vec3::new(0.0, 1.0, 0.0));
        let c = a * b;
        let v = Vec3::ZERO;
        assert_eq!(c * v, Vec3::new(1.0, 1.0, 0.0));
    }

    #[test]
    fn mat4_inverse_identity() {
        let m = Mat4::IDENTITY;
        let inv = m.inverse();
        assert_eq!(inv, Mat4::IDENTITY);
    }

    #[test]
    fn mat4_inverse_translation() {
        let m = Mat4::from_translation(Vec3::new(1.0, 2.0, 3.0));
        let inv = m.inverse();
        let v = Vec3::new(1.0, 2.0, 3.0);
        assert!((inv * v).length() < 1e-4);
    }

    #[test]
    fn mat4_ortho_2d() {
        let m = Mat4::ortho_2d(800.0, 600.0);
        let top_left = m * Vec2::new(0.0, 0.0);
        let bottom_right = m * Vec2::new(800.0, 600.0);
        // In NDC, top-left should be (-1, 1) and bottom-right (1, -1) for Y-up,
        // but our ortho_2d uses Y-down, so top-left is (-1, -1) and bottom-right is (1, 1)
        // Wait, let's check: ortho(0, 800, 600, 0, -1, 1)
        // x: 0 -> -(800+0)/(800-0) = -1, 800 -> 1
        // y: 0 -> -(600+0)/(600-0) = -1, 600 -> 1
        assert!((top_left.x + 1.0).abs() < 1e-4);
        assert!((top_left.y + 1.0).abs() < 1e-4);
        assert!((bottom_right.x - 1.0).abs() < 1e-4);
        assert!((bottom_right.y - 1.0).abs() < 1e-4);
    }

    #[test]
    fn quat_identity() {
        let q = Quat::IDENTITY;
        let m = Mat4::from_quat(q);
        assert_eq!(m, Mat4::IDENTITY);
    }

    #[test]
    fn quat_rotation_90_degrees() {
        let q = Quat::from_axis_angle(Vec3::Z, std::f32::consts::PI / 2.0);
        let m = Mat4::from_quat(q);
        let v = Vec3::X;
        let r = m * v;
        assert!((r.x - 0.0).abs() < 1e-4);
        assert!((r.y - 1.0).abs() < 1e-4);
        assert!((r.z - 0.0).abs() < 1e-4);
    }

    #[test]
    fn rect_basics() {
        let r = Rect::from_origin_size(Vec2::new(0.0, 0.0), Vec2::new(100.0, 50.0));
        assert_eq!(r.width(), 100.0);
        assert_eq!(r.height(), 50.0);
        assert!(r.contains(Vec2::new(50.0, 25.0)));
        assert!(!r.contains(Vec2::new(100.0, 50.0))); // half-open
        let s = r.inflate(10.0);
        assert_eq!(s.width(), 120.0);
    }

    #[test]
    fn rect_intersection() {
        let a = Rect::from_origin_size(Vec2::ZERO, Vec2::new(100.0, 100.0));
        let b = Rect::from_origin_size(Vec2::new(50.0, 50.0), Vec2::new(100.0, 100.0));
        let i = a.intersection(b).unwrap();
        assert_eq!(i.origin(), Vec2::new(50.0, 50.0));
        assert_eq!(i.size(), Vec2::new(50.0, 50.0));
    }

    #[test]
    fn lerp_invariants() {
        let a = Vec2::new(0.0, 0.0);
        let b = Vec2::new(10.0, 20.0);
        assert_eq!(a.lerp(b, 0.0), a);
        assert_eq!(a.lerp(b, 1.0), b);
        let mid = a.lerp(b, 0.5);
        assert_eq!(mid, Vec2::new(5.0, 10.0));
    }
}
