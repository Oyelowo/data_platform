# Phase 2: Stdlib in `.ye`

> Status: **implemented and verified**  
> Goal: make the core stdlib (`Iterator`, `Queryable`, `Aggregate`) the authoritative definition of query/iteration semantics, with `@intrinsic` query hooks and proper wrapper types.

## 1. What Phase 2 must accomplish

### 1.1 `Queryable` is the lazy pipeline trait

`Queryable<T>` must be implemented by wrapper types that represent lazy query plans, not by raw arrays. The stdlib defines `QueryArray<T>` and `QuerySlice<T>` wrappers; each `Queryable` method body calls `@intrinsic(query_*, ...)` so the compiler can lower it to a LIR operator in Phase 3.

### 1.2 `Iterator` is the eager local iteration trait

`Iterator<T>` is for concrete, immediate, single-node iteration. It is a regular trait (not a lang item beyond recognition). Default methods (`map`, `filter`, `fold`, `collect`, `take`, `skip`) are written in plain `.ye`.

### 1.3 `Aggregate` is the user-defined aggregation protocol

`Aggregate<T, Acc, Out>` defines `init`, `step`, `merge`, `finish`, and `class`. Built-in aggregates (`Sum`, `Count`, `Avg`, `Min`, `Max`) are provided. Where the bootstrap compiler supports generic associated-item calls (e.g., `T::zero()`), aggregates are generic; otherwise concrete numeric impls are used with a clear path to generalization once the type checker supports it.

### 1.4 Driver integration

The driver already loads `stdlib/core/src/{iter,aggregate,query}.ye` as a prelude. Phase 2 ensures:

- The stdlib parses, resolves, type-checks, and lowers without errors.
- `@lang("queryable")` and `@lang("aggregate")` traits are registered.
- User code can call `Queryable` methods and have them lower through `@intrinsic` hooks.

---

## 2. Stdlib file tree

```
stdlib/
└── core/
    └── src/
        ├── lib.ye              # re-exports
        ├── iter.ye             # Iterator<T>, IntoIterator<T>, adapter types
        ├── aggregate.ye        # Aggregate<T, Acc, Out>, AggregateClass
        ├── aggregate_impls.ye  # Sum, Count, Avg, Min, Max impls
        ├── query.ye            # Queryable<T>, QueryArray<T>, QuerySlice<T>, Seq<T>, Group<K, T>
        └── array.ye            # Array<T> and slice helpers (if not in prelude)
```

---

## 3. Trait definitions

### 3.1 `Iterator<T>`

```ye
// stdlib/core/src/iter.ye

@lang("iterator")
trait Iterator<T> {
    // State-passing next. Returns the next iterator state and the element,
    // or None when exhausted. This model works without a borrow checker.
    fn next(self) -> Option<(Self, T)>;

    // Default combinators.
    fn map<U>(self, f: fn(T) -> U) -> MapIter<Self, T, U>
    where Self: Sized {
        MapIter { inner: self, f }
    }

    fn filter(self, pred: fn(&T) -> bool) -> FilterIter<Self, T>
    where Self: Sized {
        FilterIter { inner: self, pred }
    }

    fn take(self, n: usize) -> TakeIter<Self, T>
    where Self: Sized {
        TakeIter { inner: self, n }
    }

    fn skip(self, n: usize) -> SkipIter<Self, T>
    where Self: Sized {
        SkipIter { inner: self, n }
    }

    fn fold<U>(self, init: U, f: fn(U, T) -> U) -> U
    where Self: Sized {
        let mut acc = init;
        let mut iter = self;
        while let Some((next, x)) = iter.next() {
            acc = f(acc, x);
            iter = next;
        }
        acc
    }

    fn collect<C>(self) -> C
    where C: FromIterator<T>, Self: Sized {
        C::from_iter(self)
    }
}

@lang("into_iterator")
trait IntoIterator<T> {
    fn into_iter(self) -> impl Iterator<T>;
}

// Adapter types.
struct MapIter<I, T, U>    { inner: I, f: fn(T) -> U }
struct FilterIter<I, T>    { inner: I, pred: fn(&T) -> bool }
struct TakeIter<I, T>      { inner: I, n: usize }
struct SkipIter<I, T>      { inner: I, n: usize }

// Adapter impls are ordinary code.
impl<I: Iterator<T>, T, U> Iterator<U> for MapIter<I, T, U> { ... }
impl<I: Iterator<T>, T> Iterator<T> for FilterIter<I, T> { ... }
```

### 3.2 `IntoIterator` for slices and arrays

```ye
impl<T> IntoIterator<T> for [T] {
    fn into_iter(self) -> SliceIter<T> { ... }
}

impl<T, const N: usize> IntoIterator<T> for Array<T, N> {
    fn into_iter(self) -> ArrayIter<T, N> { ... }
}
```

If `for` loops already desugar to `IntoIterator::into_iter` calls, this is the only integration point.

### 3.3 `Queryable<T>`

```ye
// stdlib/core/src/query.ye

@lang("queryable")
trait Queryable<T> {
    // Lazy transformations.
    fn map<U>(self, f: fn(T) -> U) -> impl Queryable<U>;
    fn filter(self, pred: fn(&T) -> bool) -> impl Queryable<T>;
    fn flat_map<U>(self, f: fn(T) -> impl Queryable<U>) -> impl Queryable<U>;

    // Ordering, grouping, slicing.
    fn order_by<K>(self, key: fn(T) -> K) -> Seq<T>;
    fn group_by<K>(self, key: fn(T) -> K) -> impl Queryable<Group<K, T>>;
    fn distinct(self) -> impl Queryable<T>;
    fn take(self, n: usize) -> impl Queryable<T>;
    fn skip(self, n: usize) -> impl Queryable<T>;

    // Core aggregation hook.
    fn aggregate<A, Acc, Out>(self, agg: A) -> Out
    where A: Aggregate<T, Acc, Out>;

    // Sugar methods.
    fn sum(self) -> T     where Self: Sized { self.aggregate(Sum) }
    fn count(self) -> usize where Self: Sized { self.aggregate(Count) }
    fn avg(self) -> f64    where Self: Sized { self.aggregate(Avg) }
    fn min(self) -> Option<T> where Self: Sized { self.aggregate(Min) }
    fn max(self) -> Option<T> where Self: Sized { self.aggregate(Max) }

    fn fold<Acc>(self, init: Acc, f: fn(Acc, T) -> Acc) -> Acc;
    fn reduce(self, f: fn(T, T) -> T) -> Option<T>;

    // Force materialization.
    fn execute(self) -> Vec<T>;
}

// Wrapper type: an array-backed lazy query plan.
struct QueryArray<T> {
    plan: PlanId,
}

impl<T> Queryable<T> for QueryArray<T> {
    fn map<U>(self, f: fn(T) -> U) -> impl Queryable<U> {
        QueryArray { plan: @intrinsic(query_map(self.plan, f)) }
    }

    fn filter(self, pred: fn(&T) -> bool) -> impl Queryable<T> {
        QueryArray { plan: @intrinsic(query_filter(self.plan, pred)) }
    }

    fn flat_map<U>(self, f: fn(T) -> impl Queryable<U>) -> impl Queryable<U> {
        QueryArray { plan: @intrinsic(query_flat_map(self.plan, f)) }
    }

    fn order_by<K>(self, key: fn(T) -> K) -> Seq<T> {
        Seq { inner: QueryArray { plan: @intrinsic(query_order_by(self.plan, key)) } }
    }

    fn group_by<K>(self, key: fn(T) -> K) -> impl Queryable<Group<K, T>> {
        QueryArray { plan: @intrinsic(query_group_by(self.plan, key)) }
    }

    fn distinct(self) -> impl Queryable<T> {
        QueryArray { plan: @intrinsic(query_distinct(self.plan)) }
    }

    fn take(self, n: usize) -> impl Queryable<T> {
        QueryArray { plan: @intrinsic(query_take(self.plan, n)) }
    }

    fn skip(self, n: usize) -> impl Queryable<T> {
        QueryArray { plan: @intrinsic(query_skip(self.plan, n)) }
    }

    fn aggregate<A, Acc, Out>(self, agg: A) -> Out
    where A: Aggregate<T, Acc, Out> {
        @intrinsic(query_aggregate(self.plan, agg))
    }

    fn fold<Acc>(self, init: Acc, f: fn(Acc, T) -> Acc) -> Acc {
        @intrinsic(query_fold(self.plan, init, f))
    }

    fn reduce(self, f: fn(T, T) -> T) -> Option<T> {
        @intrinsic(query_reduce(self.plan, f))
    }

    fn execute(self) -> Vec<T> {
        @intrinsic(query_execute(self.plan))
    }
}

// Opaque plan handle. The compiler/runtime decides its representation.
struct PlanId;

// Ordered collection marker.
struct Seq<T> { inner: impl Queryable<T> }

// Group object.
struct Group<K, T> { key: K, items: impl Queryable<T> }
```

Notes:
- `fn(T)` is used instead of `impl Fn(T)` because the bootstrap type checker does not yet fully support closure trait bounds in trait signatures. This is a deliberate short-term constraint; the trait shape is the same, and callers can pass function pointers or closures that coerce to `fn` where applicable.
- `impl Queryable<U>` return types represent opaque query-plan types; the compiler treats them as the trait object / existential that the concrete wrapper type implements.

### 3.4 `Aggregate<T, Acc, Out>`

```ye
// stdlib/core/src/aggregate.ye

@lang("aggregate")
trait Aggregate<T, Acc, Out> {
    fn init(&self) -> Acc;
    fn step(&self, acc: Acc, item: T) -> Acc;
    fn merge(&self, a: Acc, b: Acc) -> Acc;
    fn finish(&self, acc: Acc) -> Out;
    fn class(&self) -> AggregateClass;
}

enum AggregateClass {
    Distributive,
    Algebraic,
    Holistic,
}
```

### 3.5 Built-in aggregate impls

```ye
// stdlib/core/src/aggregate_impls.ye

struct Sum;
struct SumAcc<T> { value: T }

// Concrete numeric impls are required until the type checker can resolve
// associated items on generic type parameters (e.g. T::zero()).
impl Aggregate<i32, SumAcc<i32>, i32> for Sum { ... class: Distributive }
impl Aggregate<i64, SumAcc<i64>, i64> for Sum { ... class: Distributive }
impl Aggregate<f64, SumAcc<f64>, f64> for Sum { ... class: Distributive }

struct Count;
struct CountAcc { count: usize }

impl<T> Aggregate<T, CountAcc, usize> for Count { ... class: Distributive }

struct Avg;
struct AvgAcc<T> { sum: T, count: usize }

impl Aggregate<i32, AvgAcc<i32>, f64> for Avg { ... class: Algebraic }
impl Aggregate<i64, AvgAcc<i64>, f64> for Avg { ... class: Algebraic }
impl Aggregate<f64, AvgAcc<f64>, f64> for Avg { ... class: Algebraic }

struct Min;
struct Max;

impl<T: Ord> Aggregate<T, Option<T>, Option<T>> for Min { ... class: Distributive }
impl<T: Ord> Aggregate<T, Option<T>, Option<T>> for Max { ... class: Distributive }
```

---

## 4. `Array<T>` and `[T]` integration

Raw arrays and slices implement `IntoIterator<T>`, not `Queryable<T>` directly. A user converts an array to a query plan explicitly:

```ye
let users: Array<User> = ...;
let q: QueryArray<User> = users.into_iter().collect::<QueryArray<User>>();
let total = q.filter(|u| u.active).map(|u| u.salary).sum();
```

Alternatively, the prelude may provide a free function or an extension trait:

```ye
fn query<T>(xs: impl IntoIterator<T>) -> QueryArray<T> {
    QueryArray { plan: @intrinsic(query_from_iter(xs.into_iter())) }
}
```

For Phase 2 we keep the existing `impl<T> Queryable<T> for Array<T>` as a convenience but mark it as transitional in a comment, because the long-term design is that `Queryable` lives on wrapper types. If it causes ambiguity or type-check issues, it is removed.

---

## 5. Driver integration

The driver already concatenates `iter.ye`, `aggregate.ye`, `query.ye` from `stdlib/core/src/` into the prelude. Phase 2 verifies:

- The prelude parses without errors.
- Name resolution succeeds (no missing symbols).
- Type checking succeeds (trait definitions, impls, and default bodies are well-typed).
- `@lang("queryable")` and `@lang("aggregate")` are registered in `resolved.lang_items`.

No changes to the driver loading logic are expected unless the stdlib file list changes.

---

## 6. Exhaustive file tree for Phase 2

```
crates/compiler/
├── stdlib/
│   └── core/
│       └── src/
│           ├── lib.ye
│           ├── iter.ye
│           ├── aggregate.ye
│           ├── aggregate_impls.ye
│           └── query.ye
│
├── yelang-driver/
│   └── src/
│       ├── stdlib.rs            # verify file list and loading
│       └── driver.rs            # no structural changes expected
│
└── yelang-driver/tests/
    ├── stdlib_parse_tests.rs    # existing; expand coverage
    └── stdlib_queryable_tests.rs # new: call Queryable methods through stdlib
```

---

## 7. Implementation checklist

### 7.1 `iter.ye`

- [x] Ensure `Iterator<T>` has `map`, `filter`, `take`, `skip`, `fold` default methods.
- [x] Ensure `IntoIterator<T>` exists and is a lang item.
- [x] Add `FromIterator<T>` trait for `collect`.
- [x] Add adapter structs (`MapIter`, `FilterIter`, `TakeIter`, `SkipIter`).
- [ ] Generic adapter `impl` blocks (`impl<I: Iterator<T>, T, U> Iterator<U> for MapIter<I, T, U>`) are left as declarations because the bootstrap type checker does not yet resolve higher-kinded trait-bound impls.
- [ ] `Iterator::collect` default body is omitted because the bootstrap resolver cannot yet resolve associated-item paths on generic type parameters (`C::from_iter`).

### 7.2 `aggregate.ye`

- [x] Verify `Aggregate<T, Acc, Out>` trait matches design (`init`, `step`, `merge`, `finish`, `class`).
- [x] Verify `AggregateClass` enum.

### 7.3 `aggregate_impls.ye`

- [x] Provide `Sum`, `Product`, `Count`, `Avg`, `Min`, `Max` marker types.
- [x] Provide accumulator types.
- [x] Implement aggregates with correct `class`.
- [x] Document concrete numeric impls and path to generic impls.

### 7.4 `query.ye`

- [x] Define `Queryable<T>` lang-item trait.
- [x] Add `QueryArray<T>` wrapper.
- [x] Implement `Queryable<T>` for `QueryArray<T>` with `@intrinsic` bodies.
- [x] Add `PlanId`, `Seq<T>`, `Group<K, T>` helper types.
- [x] Provide sugar default methods (`sum`, `count`, `avg`, `min`, `max`).
- [x] Keep transitional `impl<T> Queryable<T> for Array<T>` as a compatibility shim; it will be removed once Phase 3/4 expose an explicit `query(iter)` constructor.

### 7.5 Driver / integration

- [x] Verify `yelang-driver/src/stdlib.rs` loads the stdlib files in dependency order.
- [x] Ensure the stdlib parses, resolves, and type-checks without errors.
- [x] Verify `LangItem::Queryable`, `LangItem::Aggregate`, `LangItem::Iterator`, `LangItem::IntoIterator`, and `LangItem::FromIterator` are registered after loading the stdlib.

### 7.6 Tests

- [x] `stdlib_parse_tests.rs`: stdlib loads without errors and lang items are registered.
- [x] `stdlib_queryable_tests.rs` (new): user code can call `QueryArray` methods and they type-check.
- [ ] `stdlib_aggregate_tests.rs` (new): deferred to Phase 3 when `aggregate` lowering from THIR is available.
- [x] Unit test: `@intrinsic` bodies are present in `QueryArray` impl items (verified by type-check tests).

### 7.7 Verification

- [x] `cargo test -p yelang-driver` passes.
- [x] `cargo test --workspace --no-fail-fast` passes.
- [x] No new warnings from the stdlib.

---

## 8. Known bootstrap limitations (temporary)

The following are deliberate concessions to the current bootstrap compiler. They are tracked as cleanup work for later phases and do not affect the architectural direction.

1. **`fn` pointers instead of `impl Fn` / closure traits.** `Queryable` and `Iterator` methods take `fn(T) -> U` rather than `impl Fn(T) -> U` because the bootstrap trait solver does not yet support closure-trait bounds in trait signatures.
2. **No `impl Trait` in return position.** `Queryable` methods return the trait path `Queryable<U>` rather than `impl Queryable<U>`. `IntoIterator::into_iter` and `FromIterator::from_iter` still use `impl Iterator<T>` and happen to parse/type-check, but this will be normalized once existential types are fully supported.
3. **Concrete numeric aggregate impls.** `Sum`, `Product`, and `Avg` provide `i32`, `i64`, and `f64` impls instead of a single generic impl because the resolver cannot yet resolve associated items on generic type parameters (e.g., `T::zero()`).
4. **`Iterator::collect` has no default body.** The default body `C::from_iter(self)` requires generic associated-item resolution, which is not yet supported.
5. **Generic iterator adapter impls are commented out.** Higher-kinded trait-bound impls (`impl<I: Iterator<T>, ...>`) are not yet accepted by the bootstrap type checker.
6. **`Array<T>` transitional `Queryable` impl.** Raw arrays can still call `.sum()` etc. directly. The long-term design is `xs.into_iter().collect::<QueryArray<T>>()` or a `query(xs)` helper; the transitional impl will be removed once that constructor exists.
7. **`query_*` placeholder functions.** The `@intrinsic(query_*(...))` calls currently resolve to placeholder functions so type checking succeeds. Phase 3 intercepts these calls in THIR and lowers them to logical operators instead of emitting calls to the placeholders.

## 9. Definition of done

Phase 2 is complete when:

1. The stdlib defines `Iterator`, `IntoIterator`, `FromIterator`, `Queryable`, and `Aggregate` as `.ye` source.
2. `Queryable` methods use `@intrinsic(query_*, ...)` hooks.
3. `QueryArray<T>` is the canonical wrapper type for array-backed query plans.
4. Built-in aggregates (`Sum`, `Product`, `Count`, `Avg`, `Min`, `Max`) are implemented with correct `AggregateClass`.
5. The driver loads the stdlib and it passes the full parse/resolve/type-check pipeline.
6. New tests verify stdlib loading and `Queryable`/`Aggregate` availability.
7. `cargo test --workspace` passes.

Phase 2 is now complete. We proceed to Phase 3 (QIR extraction from THIR).
