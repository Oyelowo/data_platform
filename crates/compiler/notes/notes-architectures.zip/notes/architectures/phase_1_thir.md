# Phase 1: THIR — Typed High-level IR

> Status: design proposal awaiting implementation  
> Goal: insert a typed, desugared body IR between HIR and QIR, mirroring Rust's THIR.

## 1. Why THIR

HIR is name-resolved but still close to surface syntax: it contains method calls, query expressions, `for` loops, and overloaded operators. QIR needs a simpler input where:

- Method calls have been resolved to plain function calls with an explicit `self` argument.
- Query syntax is represented by `ThirExpr::Query(QueryId)` pointing to a side table.
- `for` loops are desugared into `Iterator` method calls.
- Types are fully known (from `typeck_results`).

THIR is that layer. It is produced **per body** on demand from HIR + type-check results. It is simpler than HIR because it drops syntactic sugar; it is still an expression IR because operators first appear in QIR.

Key references:
- Rust Compiler Development Guide, [The THIR](https://rustc-dev-guide.rust-lang.org/thir.html).

---

## 2. THIR data model

THIR lives in a new crate `yelang-thir`. It uses its own ID spaces for expressions, patterns, statements, and bodies. A `ThirBodyId` identifies a complete body (function, closure, or inline block); it is the unit of THIR construction.

### 2.1 Crate layout

```rust
// yelang-thir/src/lib.rs
pub mod expr;
pub mod pat;
pub mod stmt;
pub mod body;
pub mod ty;
pub mod lower;

pub use expr::{ThirExpr, ThirExprId};
pub use pat::{ThirPat, ThirPatId};
pub use stmt::{ThirStmt, ThirStmtId};
pub use body::{ThirBody, ThirBodyId, ThirBodies};
pub use ty::{ThirTy, ThirTyId};
pub use lower::{lower_body, LoweringError};
```

### 2.2 Expressions

```rust
// yelang-thir/src/expr.rs

use yelang_arena::DefId;
use yelang_hir::hir::core::Lit;
use yelang_hir::ids::{BodyId, QueryId};
use yelang_hir::res::Res;
use yelang_interner::Symbol;

new_key_type! {
    pub struct ThirExprId;
}

#[derive(Debug, Clone)]
pub enum ThirExpr {
    Literal(Lit),
    Var(DefId),                  // item, const, fn item, `self` parameter
    Local(ThirPatId),            // local variable or parameter introduced by a pattern
    Field { base: ThirExprId, field: Symbol },
    Call { func: ThirExprId, args: Vec<ThirExprId> },
    Closure { params: Vec<ThirPatId>, body: ThirBodyId },
    Block { stmts: Vec<ThirStmtId>, tail: Option<ThirExprId> },
    Binary { op: BinaryOp, left: ThirExprId, right: ThirExprId },
    Unary { op: UnaryOp, expr: ThirExprId },
    Assign { left: ThirExprId, right: ThirExprId },
    AssignOp { op: AssignOpKind, left: ThirExprId, right: ThirExprId },
    Index { base: ThirExprId, index: ThirExprId },
    Tuple { fields: Vec<ThirExprId> },
    Array { exprs: Vec<ThirExprId> },
    ArrayRepeat { value: ThirExprId, count: ThirExprId },
    Struct { path: Res, fields: Vec<(Symbol, ThirExprId)>, rest: Option<ThirExprId> },
    Object { fields: Vec<(Symbol, ThirExprId)> },
    Range { start: Option<ThirExprId>, end: Option<ThirExprId>, inclusive: bool },
    Cast { expr: ThirExprId, ty: ThirTyId },
    TypeAscription { expr: ThirExprId, ty: ThirTyId },
    If { cond: ThirExprId, then_branch: ThirBodyId, else_branch: Option<ThirBodyId> },
    Match { scrutinee: ThirExprId, arms: Vec<ThirArm> },
    Loop { body: ThirBodyId },
    Break { label: Option<Label>, expr: Option<ThirExprId> },
    Continue { label: Option<Label> },
    Return { expr: Option<ThirExprId> },
    Try { expr: ThirExprId },
    Await { expr: ThirExprId },
    Ref { mutability: Mutability, expr: ThirExprId },
    Deref { expr: ThirExprId },
    IsType { expr: ThirExprId, ty: ThirTyId },
    Query(QueryId),              // select ... from ...; data in HIR side table
    Intrinsic { name: Symbol, args: Vec<ThirExprId> },
    Err,
}

#[derive(Debug, Clone)]
pub struct ThirArm {
    pub pat: ThirPatId,
    pub guard: Option<ThirExprId>,
    pub body: ThirBodyId,
}
```

Notes:
- No `MethodCall` variant. Method calls are desugared to `Call` with the receiver as the first argument.
- No `Comprehension` variant. Array selectors desugar to `map`/`filter`/`flat_map` calls (QIR extraction may later recognize these patterns, but THIR itself stays general).
- `Query(QueryId)` references the same query side table that HIR uses.
- `Intrinsic` preserves the `@intrinsic(...)` expression from Phase 0.

### 2.3 Patterns

```rust
// yelang-thir/src/pat.rs

new_key_type! { pub struct ThirPatId; }

#[derive(Debug, Clone)]
pub enum ThirPat {
    Wild,
    Binding { name: Symbol, subpat: Option<ThirPatId> },
    Struct { res: Res, fields: Vec<(Symbol, ThirPatId)>, rest: bool },
    Tuple { pats: Vec<ThirPatId> },
    TupleStruct { res: Res, pats: Vec<ThirPatId> },
    Path { res: Res },
    Lit { lit: Lit },
    Range { start: Option<ThirPatId>, end: Option<ThirPatId>, end_inclusive: bool },
    Or { pats: Vec<ThirPatId> },
    Slice { prefix: Vec<ThirPatId>, middle: Option<ThirPatId>, suffix: Vec<ThirPatId> },
    Rest,
    Err,
}
```

### 2.4 Statements

```rust
// yelang-thir/src/stmt.rs

new_key_type! { pub struct ThirStmtId; }

#[derive(Debug, Clone)]
pub enum ThirStmt {
    Let { pat: ThirPatId, ty: Option<ThirTyId>, init: Option<ThirExprId> },
    Expr { expr: ThirExprId },
    Item { def_id: DefId },
}
```

### 2.5 Bodies

```rust
// yelang-thir/src/body.rs

use slotmap::SlotMap;

new_key_type! { pub struct ThirBodyId; }

#[derive(Debug, Clone)]
pub struct ThirBody {
    pub params: Vec<ThirPatId>,
    pub value: ThirExprId,
}

#[derive(Debug, Clone, Default)]
pub struct ThirBodies {
    pub bodies: SlotMap<ThirBodyId, ThirBody>,
}

impl ThirBodies {
    pub fn alloc(&mut self, params: Vec<ThirPatId>, value: ThirExprId) -> ThirBodyId {
        self.bodies.insert(ThirBody { params, value })
    }
}
```

### 2.6 Types

THIR uses the same resolved types as the type checker. Instead of redefining a type system, THIR stores `TyId` from `yelang-ty` directly, plus a small wrapper for source spans.

```rust
// yelang-thir/src/ty.rs

use yelang_ty::TyId;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ThirTyId(pub TyId);
```

Alternatively, if `TyId` is not directly usable, THIR can reference `yelang_tycheck::ty::Ty` via the type context. The principle is: THIR does not introduce new type semantics; it points to the canonical type-check results.

---

## 3. HIR → THIR lowering

The lowering pass walks a HIR body and produces a `ThirBody`. It needs:

- `&yelang_hir::Crate` for HIR nodes.
- `&yelang_tycheck::TypeckResults` for the type of each HIR expression/pattern.
- `&yelang_resolve::lang_items::LangItems` to recognize `Iterator`/`IntoIterator`.

### 3.1 Method-call desugaring

```rust
// HIR
Expr::MethodCall { receiver, method, args, trait_def_id } ->

// THIR
ThirExpr::Call {
    func: ThirExpr::Path { res: Res::Def { def_id: method_def_id } },
    args: [lower(receiver), lower_each(args)],
}
```

If the method is an inherent method, `func` resolves to the inherent method's `DefId`. If it is a trait method, `func` resolves to the trait method's `DefId` and the receiver type tells the backend which impl to use. `trait_def_id` is preserved in the `Res` if needed.

### 3.2 Query syntax

```rust
// HIR
Expr::Query(query_id) -> ThirExpr::Query(query_id)
```

The query side table is not duplicated. QIR extraction reads the same `QueryId` from HIR.

### 3.3 `for` loop desugaring

> Note: the current HIR (`yelang-hir/src/hir/expr.rs`) has no `ForLoop`
> expression variant; `for` loops are already desugared to `Loop` + `Match`
> during AST → HIR lowering. THIR therefore preserves the already-desugared
> shape rather than re-desugaring it.

```ye
for x in xs { body }
```

lowers to:

```ye
{
    let iter = IntoIterator::into_iter(xs);
    loop {
        match Iterator::next(iter) {
            None => break,
            Some(x) => { body },
        }
    }
}
```

THIR:

```rust
ThirExpr::Block {
    stmts: [Let iter_pat = Call(IntoIterator::into_iter, [xs])],
    tail: ThirExpr::Loop {
        body: ThirBody {
            value: ThirExpr::Match {
                scrutinee: Call(Iterator::next, [iter]),
                arms: [
                    Arm { pat: None, body: Break },
                    Arm { pat: Some(x), body: body },
                ],
            },
        },
    },
}
```

The exact shape depends on the stdlib's `Iterator`/`IntoIterator` signatures. For Phase 1 we use the existing `stdlib/core/src/iter.ye` definitions.

### 3.4 Intrinsic expressions

```rust
// HIR
Expr::Intrinsic { name, args } -> ThirExpr::Intrinsic { name: name.symbol, args: lower_each(args) }
```

### 3.5 Closures

Closures are preserved but their body is lowered to a nested `ThirBody`. Captures are not resolved in Phase 1; that is a later concern.

### 3.6 Blocks and locals

A HIR block becomes a THIR block. Local variable `DefId`s are reused from HIR. A local scope map tracks HIR `PatId`/`ExprId` -> THIR `ThirPatId`/`ThirExprId` for the current body.

### 3.7 Type ascription and casts

`TypeAscription` and `Cast` keep their `ThirTyId`. The type ID comes from the type-check results for the original HIR expression.

---

## 4. Exhaustive file tree

```
crates/compiler/
├── yelang-thir/                          # NEW CRATE
│   ├── Cargo.toml
│   └── src/
│       ├── lib.rs
│       ├── ids.rs                        # ThirExprId, ThirPatId, ThirStmtId, ThirBodyId
│       ├── expr.rs                       # ThirExpr, ThirArm
│       ├── pat.rs                        # ThirPat
│       ├── stmt.rs                       # ThirStmt
│       ├── body.rs                       # ThirBody, ThirBodies
│       ├── ty.rs                         # ThirTyId
│       ├── lower.rs                      # HIR -> THIR lowering entry
│       ├── lower_expr.rs                 # Expression lowering
│       ├── lower_pat.rs                  # Pattern lowering
│       ├── lower_stmt.rs                 # Statement lowering
│       ├── context.rs                    # LoweringContext for THIR
│       └── errors.rs                     # LoweringError
│
├── Cargo.toml                            # ADD yelang-thir to workspace members
│
├── yelang-hir/                           # MINOR CHANGES
│   └── src/
│       └── (expose any currently-private helpers needed by THIR lowering)
│
├── yelang-tycheck/                       # MINOR CHANGES
│   └── src/
│       └── typeck_results.rs             # ensure TypeckResults exposes expr/pat ty lookup
│
└── yelang-driver/                        # NO CHANGES YET (Phase 3 wires THIR into driver)
```

---

## 5. Implementation checklist

### 5.1 Crate setup

- [x] Create `yelang-thir/Cargo.toml` depending on `yelang-arena`, `yelang-ast`, `yelang-hir`, `yelang-interner`, `yelang-lexer`, `yelang-resolve`, `yelang-ty`, `yelang-tycheck`, `slotmap`.
- [x] Add `yelang-thir` to the workspace `members` in root `Cargo.toml`.
- [x] Create `yelang-thir/src/lib.rs` with module declarations.

### 5.2 THIR types

- [x] Define `ThirExprId`, `ThirPatId`, `ThirStmtId`, `ThirBodyId` using `yelang_arena::new_key_type!` and `slotmap`.
- [x] Define `ThirExpr` enum (no `MethodCall`, no `Comprehension`). Includes `Local(ThirPatId)` for pattern-bound locals.
- [x] Define `ThirPat` enum.
- [x] Define `ThirStmt` enum.
- [x] Define `ThirBody` and `ThirBodies`.
- [x] Define `ThirTyId` wrapper around `yelang_ty::TyId`.

### 5.3 Lowering infrastructure

- [x] Define `LoweringContext`.
- [x] Implement `lower_body(hir_body_id, typeck_results) -> ThirBodyId`.

### 5.4 Expression lowering

- [x] Lower all HIR expression variants to THIR.
- [x] `MethodCall` -> `Call` with receiver prepended to args, using `typeck_results.method_resolution`.
- [x] `Query` -> `ThirExpr::Query`.
- [x] `Intrinsic` -> `ThirExpr::Intrinsic`.
- [x] `Closure` -> nested `ThirBody`.
- [x] Unsupported HIR forms -> `ThirExpr::Err` (no `unimplemented!()`).

### 5.5 Pattern lowering

- [x] Lower each `Pat` variant to `ThirPat`.
- [x] Track bindings in `local_pats`.

### 5.6 Statement lowering

- [x] Lower each `Stmt` variant to `ThirStmt`.

### 5.7 `for` loop desugaring

- [x] HIR already desugars `for` loops to `Loop` + `Match`; THIR preserves that form. No separate `for` desugaring needed in Phase 1.

### 5.8 Tests

- [x] `lower_literal`
- [x] `lower_method_call_becomes_function_call`
- [x] `lower_query_expr_preserves_query_id`
- [x] `lower_intrinsic_preserves_name_and_args`
- [x] `lower_closure_has_nested_body`
- [x] `lower_block_with_locals`
- [x] `lower_match_arm_patterns`

### 5.9 Verification

- [x] `cargo test -p yelang-thir` passes (7 tests).
- [x] `cargo test --workspace --no-fail-fast` passes.
- [x] No `TODO` or `unimplemented!()` in Phase 1 production paths.

---

## 6. Definition of done

Phase 1 is complete when:

1. `yelang-thir` crate exists and compiles.
2. THIR represents all HIR expression/pattern/statement forms needed for query extraction.
3. Method calls are desugared to function calls.
4. `for` loops are desugared to `Iterator`/`IntoIterator` method calls.
5. `ThirExpr::Query(QueryId)` is the canonical representation of query syntax.
6. `ThirExpr::Intrinsic` preserves `@intrinsic(...)` expressions.
7. Every new lowering path has a unit or integration test.
8. `cargo test --workspace` passes.

Only then do we proceed to Phase 2 (stdlib in `.ye`).
