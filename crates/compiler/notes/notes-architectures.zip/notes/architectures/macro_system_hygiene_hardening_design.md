# Macro System Phase 4: Hygiene Hardening

## 1. Goal

Make the macro expansion engine robust with respect to recursion, hygiene context, and diagnostics. This phase does **not** add new macro kinds or positions; it hardens the existing declarative macro pipeline so it is production-ready and a safe foundation for procedural macros and cross-crate compilation.

## 2. Scope

| Feature | In scope | Out of scope |
|---|---|---|
| Indirect recursion detection | ✅ | |
| Macro expansion backtraces | ✅ | |
| `$crate` / `$package` token in transcribers | ✅ | |
| `call_site` / `mixed_site` span kinds | ✅ | |
| Cross-crate macro definition context | ✅ (design + serialization) | |
| Cross-crate macro import/export | ✅ (design; loading tied to crate loader) | |
| Integration with name resolution | ✅ (consume `$crate` during resolve) | |
| General proc-macro framework | | Phase 7 |
| Fragment fields / unsafe rules | | Phase 6 |
| Eager built-ins | | Phase 5 |

## 3. Research and design rationale

### 3.1 Indirect recursion detection

Rust detects macro expansion cycles with a depth limit and a visited set. `rustc` uses an expansion depth counter and, for some cases, tracks the chain of invocations. Our current engine only detects direct recursion via `expansion_stack` (`a!` → `a!`); it misses `a!` → `b!` → `a!`.

Design choice: keep the existing `expansion_stack` but use it as a true cycle detector. Before expanding a macro, check whether the same macro name is already on the stack. This catches indirect cycles without extra data structures.

### 3.2 `$crate` / `$package`

Rust uses `$crate` inside `macro_rules!` to refer to items in the macro's defining crate. This is essential for macros that generate code referring to helper items, because without it the generated identifier would resolve at the call site and fail.

Design choice: add a `$crate` keyword in the transcriber that is converted to a special path segment carrying the `MacroDefId` (or crate id) of the defining macro. During name resolution, this segment resolves to the macro's defining crate root.

We also add `$package` as the logical package/root namespace for future multi-crate packages.

### 3.3 Span kinds

Rust distinguishes three span kinds (TLBoRM):
- `def_site`: hygienic bindings, unhygienic references (generated identifiers cannot be referenced from outside, but can reference definition-site names).
- `call_site`: fully unhygienic (references resolve at invocation site).
- `mixed_site`: legacy `macro_rules` behavior — types/items are definition-site, local bindings are call-site.

Our current engine always uses `Opaque` (def_site). We add `Transparent` and `Mixed` transparency and allow transcribers to request them explicitly when needed. For declarative macros, `Opaque` remains the default.

### 3.4 Macro backtraces

When expansion fails, the user needs to know the chain of macro calls. We store the expansion stack in errors so diagnostics can render `in macro foo! {}` → `in macro bar! {}` → `here`.

## 4. Data structure changes

### 4.1 `yelang-macro-core/src/id.rs`

Extend `MacroDefData`:
```rust
pub struct MacroDefData {
    pub name: yelang_interner::Symbol,
    pub span: yelang_lexer::Span,
    pub kind: MacroKind,
    pub defining_crate: CrateId,        // NEW
    pub defining_module: Option<DefId>, // NEW (optional, for future nested modules)
}
```

`CrateId` is a small wrapper around `u32` defined in `yelang-macro-core` (or re-used from `yelang-resolve` if available). For now, define it locally to keep the crate self-contained.

### 4.2 `yelang-macro-core/src/token_tree/ident.rs` (or new module)

Add a `crate_ref` field to `Ident` for `$crate` / `$package` resolution:
```rust
pub enum IdentOrigin {
    Plain,
    Crate,
    Package,
}
```

Alternative: represent `$crate` as a special `TokenTree` variant. We choose a special `IdentOrigin` on `Ident` because it behaves like an identifier in paths.

### 4.3 `yelang-macro-core/src/hygiene.rs`

Add helpers:
```rust
impl HygieneData {
    pub fn outer_transparency(&self, ctx: SyntaxContextId) -> Transparency { ... }
    pub fn is_descendant_of(&self, ctx: SyntaxContextId, ancestor: ExpnId) -> bool { ... }
}
```

### 4.4 `yelang-macro/src/expander.rs`

- `MacroExpander` gains `macro_def_id: MacroDefId` for the macro currently being defined (needed to attach `$crate` to generated identifiers).
- `expansion_stack` already stores `(name, span)`; extend it to `(name, span, macro_def_id)`.
- `ExpandError` gains a `backtrace: Vec<BacktraceFrame>` field.

## 5. Expansion engine changes

### 5.1 Indirect recursion detection

Before calling `before_expand(name, span)`:
1. Look up the macro definition id for `name` from the resolver.
2. If that `MacroDefId` is already present in `expansion_stack`, emit `ExpandError::ExpansionLoop` with the chain.
3. Otherwise push the frame and proceed.

This catches `a! → b! → a!` because the second `a!` sees `a`'s `MacroDefId` on the stack.

### 5.2 `$crate` / `$package` transcription

In `transcribe.rs`, when the transcriber emits an identifier whose text is `crate` (or `package`) **and** it originated from the literal `$crate` / `$package` token in the macro body, mark it as `IdentOrigin::Crate` (or `Package`) and attach the defining crate id from the current expansion context.

Implementation detail: the macro body tokenizer must preserve `$crate` as a single identifier token. Currently `$ident` is tokenized as `$` punct + ident. We add `$crate` and `$package` as special tokens emitted by the lexer/transcriber conversion.

### 5.3 Span transparency selection

Add transcriber syntax `${call_site(...)}` and `${mixed_site(...)}` (optional for Phase 4; default remains `Opaque`). If deferred, document it as future work.

For now, implement the data structures (`Transparency::Transparent`, `Transparency::Mixed`) so proc macros can use them later, but keep declarative macros always `Opaque`.

### 5.4 Backtraces

Every `ExpandError` carries a `backtrace` cloned from `expansion_stack` at the moment the error is emitted. The error display implementation renders the chain.

## 6. Name resolution integration

`yelang-resolve` must handle `IdentOrigin::Crate` and `IdentOrigin::Package`:
- When resolving a path that starts with `crate`, look up the crate id stored in the identifier and resolve from that crate's root.
- When resolving a path that starts with `package`, resolve from the package root.

If the identifier has no special origin, `crate` is treated as a normal keyword (the current crate root).

## 7. Cross-crate serialization

Macro definitions need to be serialized with their expansion rules so they can be imported from other crates. Design:
- Add `MacroDefId` and the macro body `TokenStream` to the crate metadata.
- Serialize `SyntaxContextId` chains relative to the defining crate.
- On import, remap `CrateId` references to the importing crate's view.

This phase designs the format but does not require a full crate loader. The format must be forward-compatible with proc macros.

## 8. Testing strategy

Add `yelang-macro/tests/declarative_macros_hygiene.rs`:

1. **Direct recursion still detected**: `a!() => a!()`.
2. **Indirect recursion detected**: `a!() => b!()`, `b!() => a!()`.
3. **Mutual recursion via three macros**: `a! → b! → c! → a!`.
4. **Non-recursive deep nesting passes**: `a! → b! → c!` with no cycle.
5. **`$crate` resolves to defining crate item**: macro in crate A generates `crate::helper()`, used from crate B (test via synthetic crate id if full crate loader unavailable).
6. **Backtrace contains macro chain**: assert error string contains the names in order.
7. **Hygienic binding does not leak**: existing test, now also checks indirect paths.
8. **Opaque default is preserved**: generated `let x = 1;` does not collide with outer `x`.
9. **Span transparency data structures compile**: unit test for `Transparency` variants.

## 9. File tree

```
yelang-macro-core/src/
  id.rs                    # add CrateId, extend MacroDefData
  hygiene.rs               # add descendant/transparency helpers
  token_tree/
    ident.rs               # add IdentOrigin

yelang-macro/src/
  expander.rs              # indirect recursion, backtraces, $crate context
  resolver.rs              # expose MacroDefId lookup
  transcribe.rs            # emit $crate/$package origins
  error.rs                 # add backtrace field

yelang-resolve/src/
  late.rs                  # resolve $crate/$package path origins

yelang-macro/tests/
  declarative_macros_hygiene.rs
```

## 10. Implementation status

Phase 4 is implemented and tested. The following checklist reflects the state of the codebase after the hardening work:

- [x] Add `CrateId` and `IdentOrigin` types (`yelang-macro-core/src/id.rs`, `yelang-macro-core/src/token_tree/ident.rs`).
- [x] Extend `MacroDefData` with defining crate (`yelang-macro-core/src/id.rs`).
- [x] Expose macro-def-id lookup from `MacroResolver` (`yelang-macro/src/resolver.rs`).
- [x] Update `MacroExpander` to track `ExpansionFrame { name, span, def_id }` frames (`yelang-macro/src/expander.rs`).
- [x] Implement indirect recursion detection using the expansion stack (`yelang-macro/src/expander.rs`).
- [x] Add backtrace frames to `ExpandError` (`yelang-macro/src/error.rs`, `yelang-macro/src/expander.rs`).
- [x] Preserve `$crate` / `$package` through macro body tokenization (`yelang-lexer/src/tokenizer/ident.rs`).
- [x] Emit `IdentOrigin::Crate` / `Package` in transcription (`yelang-macro/src/transcribe.rs`, `yelang-macro-core/src/token_tree/render.rs`).
- [x] Resolve `$crate` / `$package` paths in `yelang-resolve` (`yelang-resolve/src/path.rs`).
- [x] Add `Transparency::Opaque`, `Transparent`, `Mixed` data structures (`yelang-macro-core/src/id.rs`).
- [ ] Implement `${call_site(...)}` / `${mixed_site(...)}` transcriber syntax (deferred to proc-macro work).
- [ ] Design cross-crate macro metadata format (deferred until the crate loader is ready).
- [x] Add hygiene hardening integration tests (`yelang-macro/tests/declarative_macros_hygiene.rs`).
- [x] Run `cargo fmt` and full `cargo test`.

### Test results

- `cargo test -p yelang-macro`: 74 unit tests + 17 declarative + 42 exhaustive + 6 hygiene + 35 phase-2 + 17 phase-3 + 17 phase-4 = **208 passed**.
- `cargo test -p yelang-resolve`: **188 passed**.
- `cargo check`: workspace compiles cleanly (warnings are pre-existing unused-import/dead-code noise).
